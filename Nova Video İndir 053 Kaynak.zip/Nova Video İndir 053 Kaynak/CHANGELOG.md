# Checkpoint 053 — Nova Video İndir 0.53 Google Play sertleştirmesi

- Ürün adı kullanıcıya görünen tüm Android metinlerinde `Nova Video İndir` olarak güncellendi.
- `versionName=0.53`, `versionCode=55`, `checkpoint=053`.
- Ham Gradle `independent*` flavor adı ana ekrandan kaldırıldı; kullanıcıya `Bağımsız` gösterilir.
- Google Play varyantında runtime yt-dlp stable/nightly güncellemesi kaldırıldı; paketli motor zorunlu.
- Google Play varyantında remote EJS ve üçüncü taraf Python yt-dlp plugin yükleme/çalıştırma kaldırıldı.
- `youtubedl-android 0.18.1` ile AAB içinde gelen yt-dlp-ejs + QuickJS zinciri korunur.
- Bağımsız varyant Play'in tüm ortak özelliklerini taşır; ek olarak runtime motor güncellemesi, plugin/remote-EJS, APK araçları, self-update ve pet overlay özelliklerini korur.
- `bundleNovaPlayRelease`, signing + HTTPS privacy publication gate + merged manifest denetimini zorunlu çalıştırır.
- Teslim dosyaları dağıtım adını dosya isminde açık taşır; `İndir` Türkçe karakterle ve tiresiz adlandırılır.

# Checkpoint 052 — Media3 1.11.0 + sosyal platform desteği

- AndroidX Media3 ExoPlayer/UI `1.11.0` sürümüne yükseltildi.
- X, Threads, Bluesky, Mastodon ve Telegram URL/platform algılama ve extractor yönlendirme politikalarına eklendi.
- Hesap profili ve tarayıcı oturumu altyapısı bu platformları tanıyacak şekilde genişletildi.
- Media3 `AspectRatioFrameLayout` / `PlayerView` / `PlayerControlView` R8 keep kuralları korunarak release/minify inflate hatasına karşı koruma sürdürüldü.
- İstenen bağımsız Pro debug derleme komutu kaynak üzerinde hedef olarak doğrulandı; bu çalışma ortamında Gradle 8.13 ve Android bağımlılıkları indirilemediği için gerçek derleme çalıştırılamadı.

# Checkpoint 049

- Yerel Nova log yazımı eşzamanlı çağrılara karşı seri hale getirildi; kilit/yazma hatalarında `nova-fallback-<pid>.log` devreye girer.
- Tanılama ZIP’i `İndirilenler/NovaDownloader/Diagnostics/` içine kalıcı olarak kopyalanır; paylaşım sayfası açılamasa bile dosya cihazda kalır.
- Tanılama raporu alt bileşen hatalarında tamamen çökmek yerine minimal rapor, `logger-status.json` ve varsa `export-warnings.txt` üretir.
- Nova Player dosya URI’sinin okunabilirliğini önce doğrular ve Media3’e geçmiş MIME değerini zorlamaz; yerel medya kapsayıcısı doğrudan sniff edilir.
- Media3 `PlaybackException` hata kodu Nova içinde gösterilir ve “Hata ayrıntısını kopyala” ile panoya alınabilir.
- Çözümleme/fallback ve indirme çekirdeği korunmuştur.
- Sürüm `0.10.0-alpha`, versionCode `51`, checkpoint `049`.

# Checkpoint 048

- Nova iç oynatıcı açılışına gerçek `outputUri`, MIME ve başlık doğrudan aktarılır.
- Oynatıcı kurulum/decoder/source hataları yakalanır; uygulama kapanmak yerine Nova içinde hata gösterir.
- Yeniden adlandırma penceresine her zaman görünür `İptal` ve `Uygula` düğmeleri eklendi.
- Klavye `Done/Bitti` eylemi yeniden adlandırmayı uygular.
- Medya çözümleme ve indirme çekirdeği değiştirilmedi.
- Sürüm `0.10.0-alpha`, versionCode `50`, checkpoint `048`.

# Checkpoint 047

- Dijital evcil hayvana tek dokunma artık menü yerine Nova ana penceresini açar.
- Hareketsiz uzun basma evcil hayvan menüsünü açar ve kısa haptik geri bildirim verir.
- Parmağın Android `touchSlop` eşiğini aşması uzun basmayı iptal eder ve taşıma moduna geçer; taşıma ile menü çakışmaz.
- Çift dokunma menü için alternatif kısayoldur.
- Tek dokunma, çift dokunma ile karışmaması için sistemin çift dokunma penceresi sonunda onaylanır.
- Play sürümünde pet overlay kaynak izolasyonu korunur; değişiklik yalnız Independent source-set içindedir.
- Sürüm `0.10.0-alpha`, versionCode `49`, checkpoint `047`.

# Checkpoint 046

- Çözümleme ekranındaki varsayılan dosya adı için konservatif temizleme katmanı eklendi.
- `49K views`, `1.6K reactions`, likes/comments/shares ve Türkçe karşılıkları gibi salt sayaç segmentleri varsayılan addan çıkarılır.
- Boşluklarla çevrili dekoratif `_`, `|`, `·`, `•`, `—` ayraçları temiz bir ` - ` ayracına dönüştürülür.
- Sondaki salt platform markası (`Facebook`, `Instagram`, `TikTok`, `YouTube`, `Twitter`) ve gömülü URL gürültüsü varsayılan addan çıkarılır.
- Anlamlı alt çizgiler (`my_video_name`) korunur; kullanıcı tarafından düzenlenen ad üzerinde sonradan otomatik sosyal-temizleme yapılmaz.
- Temizleme yalnız `pendingFileName`/enqueue için önerilen ada uygulanır. Resolver, yt-dlp, fallback ve format seçimi dosyaları değiştirilmedi.
- Sürüm `0.10.0-alpha`, versionCode `48`, checkpoint `046`.

# Checkpoint 045

- İndirme ayrıntıları penceresinde seçenekler ve eylemler ayrıldı.
- **İndir** düğmesi artık sabit alt eylem alanında her zaman görünür.
- **İndirmeyi zamanla** ve **İptal** aynı sabit alanda erişilebilir.
- Seçenekler kendi ScrollView alanında kaydırılır ve pencere açılışında en üstten başlar.
- Çift dokunmayı önlemek için enqueue sırasında İndir/Zamanla düğmeleri geçici olarak devre dışı kalır.
- Checkpoint 044 doğru dosya konumu ve önceki Play/Bağımsız dağıtım mimarisi korunur.

# Checkpoint 044

- **Dosyanın konumunu aç** otomatik indirmelerde artık genel İndirilenler ekranını değil gerçek `Downloads/NovaDownloader/` klasörünü hedefler.
- MediaStore çıktılarında gerçek klasör `RELATIVE_PATH` üzerinden çözülür; özel SAF hedeflerinde seçilen tree URI kullanılır.
- Dosya yöneticisi doğrudan klasör `ACTION_VIEW` desteklemiyorsa `ACTION_OPEN_DOCUMENT_TREE` aynı klasörü `EXTRA_INITIAL_URI` ile açar.
- 043 tamamlanma ekranı düzeltmeleri ve 042 temiz çıktı adlandırması korunur.

# Checkpoint 043

- İndirme tamamlanma kutusundaki görünmeyen native AlertDialog eylem çubuğu kaldırıldı.
- `Nova ile oynat`, `Dosyanın konumunu aç` ve `Kapat` eylemleri pencerenin kendi içeriğinde büyük ve görünür düğmeler olarak gösterilir.
- Tamamlanma kutusu açılmadan geçmiş listesi yenilenir ve tamamlanan dosyanın boyutu görünür.
- Sürüm `0.10.0-alpha`, sürüm kodu `45`, checkpoint `043`.

# Checkpoint 042 — Öz sürüm numaralı temiz dağıtım adları

- Nihai AAB/APK adları checkpoint, `release`, `independent`, `universal` veya Gradle `app-*` iç adlarını taşımaz.
- Dosya adı için `novaVersionName` içindeki temel sürüm otomatik kullanılır: `0.10.0-alpha` → `0.10.0`.
- Google Play çıktıları: `Nova İndir 0.10.0 Google Play\Nova İndir 0.10.0 Lite.aab` ve `Nova İndir 0.10.0 Pro.aab`.
- Bağımsız çıktılar: `Nova İndir 0.10.0 Bağımsız\Nova İndir 0.10.0 Lite.apk` ve `Nova İndir 0.10.0 Pro.apk`.
- Debug/test çıktıları release klasörlerinden ayrıldı; test derlemesi resmî teslim dosyalarını silmez.
- 041 oturumsuz otomatik medya çözümleme, 040 indirme başlatma onarımı ve 039 kalıcı signing yapısı korunur.
- Sürüm `0.10.0-alpha`, sürüm kodu `44`, checkpoint `042`.

---

# Checkpoint 041 — Oturumsuz Otomatik Medya Çözümleme

- Herkese açık içeriklerde kayıtlı oturum kullanmadan anonim yt-dlp profil zinciri eklendi.
- YouTube için `web_safari`, `web_embedded`, `android_vr`; yapılandırılmış PO-token sağlayıcısı varsa `mweb` otomatik fallback olarak denenir.
- Genel platformlarda standart mobil/masaüstü tarayıcı profilleri otomatik denenir.
- Başarılı çözümleme profili gerçek indirmeye taşınır; indirme sırasında da gerektiğinde otomatik fallback yapılır.
- Private/üyelik/yaş/premium gibi açık erişim kapıları anonim yöntemlerle zorlanmaz.
- 040 Hemen Başlat düzeltmesi, çift dağıtım, signing ve temiz çıktı adları korunur.
- Sürüm `0.10.0-alpha`, sürüm kodu `43`, checkpoint `041`.

---

# Checkpoint 040 — İndirme Ayrıntıları Başlatma Onarımı

- `Hemen başlat` artık seçili indirme seçeneklerini gerçek `enqueue(...)` akışına gönderir.
- `İndirmeyi zamanla`, tarih ve saat onayından sonra zamanlanmış indirmeyi kuyruğa ekler.
- `Ses dili` alanındaki boş ve `null` değerleri filtrelenir; geçerli seçim yoksa `Otomatik` gösterilir.
- Kuyruğa ekleme başarısız olduğunda indirme ayrıntıları dialogu kapanmaz; hata görünür kalır.
- Dialog içeriğinin maksimum yüksekliği düşürüldü; standart İndir/İptal eylemlerinin küçük ekranlarda görünürlüğü iyileştirildi.
- Checkpoint 039'daki Play/Independent paralel flavor yapısı, release signing ve temiz teslim klasörleri korunur.
- Sürüm `0.10.0-alpha`, sürüm kodu `42`, checkpoint `040`.

# Checkpoint 039 — İmzalı dağıtım ve temiz adlandırma

- Play Lite/Pro AAB + bağımsız Lite/Pro imzalı Universal APK tek Gradle görevinde üretilebilir.
- Release ABI split otomatik açılması kaldırıldı; AAB `Multiple shrunk-resources files` çakışması giderildi.
- Bağımsız release imzasız teslim engellendi.
- Kullanıcıya ait release ayarları kaynak dışındaki `%USERPROFILE%\.nova-indir\release.properties` dosyasından okunabilir.
- `SETUP_RELEASE_SIGNING.cmd` ve `BUILD_PLAY_AAB_AND_INDEPENDENT_APK.cmd` eklendi.
- Resmî teslim çıktıları `Nova İndir 039 Google Play` / `Nova İndir 039 Bağımsız` altında temiz Nova dosya adlarına dönüştürüldü.

---

# Checkpoint 038 — Play + Bağımsız yayın hazırlığı

- Sürüm kodu 40, checkpoint 038 oldu.
- `distribution=play/independent` ve `edition=lite/pro` matrisi korunup gerçek source-set ayrımına geçirildi.
- Google Play varyantlarından APK indirme/çeviri, anonim Play teslimatı, self-update kurulumu ve pet overlay servisi/izinleri çıkarıldı.
- `PetOverlayService` ve `PetMenuActivity` yalnız `src/independent` altında derlenir; Play `PetIntegration` no-op köprüsü kullanır.
- Bağımsız varyanta APK araçları, Play teslimatı, APK çeviri ve güvenli güncelleme kaynakları/dependency'leri geri alındı.
- İki flavor dimension sonrası self-update `BuildConfig.FLAVOR` karşılaştırması kaldırıldı; Full/Lite kanalı `HAS_FFMPEG` ile seçilir ve ayrı manifest URL'leri kullanılır.
- Play release için signing + `NOVA_PLAY_PRIVACY_URL` ön denetimi eklendi.
- `PRIVACY_PLAY.md`, `PRIVACY_INDEPENDENT.md`, `DATA_SAFETY_PLAY.md`, güncel FGS beyanı, release checklist ve signing rehberi eklendi.
- `VERIFY_PLAY_RELEASE.ps1/cmd`, AAB üretiminden sonra 16 KB raporunun `PASS` olmasını teknik yayın kapısı yapar.
- Bağımsız imzalı release APK üretimi için `assembleNovaIndependentRelease` eklendi.
- Checkpoint 037 indirme başlatma hata görünürlüğü düzeltmesi korunuyor.

# Checkpoint 036 — Google Play manifest, izin ve foreground service denetimi

- Sürüm kodu 38, checkpoint 036 oldu.
- Lite ve Pro release birleştirilmiş manifestleri için `checkNovaPlayMergedManifests` Gradle doğrulaması eklendi.
- `bundleNovaPlayRelease`, manifest doğrulamasını geçmeden başarılı sayılmaz.
- Nova Play sürümünde gereksiz/yüksek riskli depolama, paket görünürlüğü, APK kurma, konum, kamera, mikrofon, kişiler, telefon ve SMS izinleri engellendi.
- `WRITE_EXTERNAL_STORAGE` yalnız Android 8-9 için `maxSdkVersion=28` sınırıyla doğrulanır.
- Nova service/receiver/provider bileşenlerinin kapalı; yalnız `MainActivity` ve `SetupActivity` bileşenlerinin dışa açık olduğu doğrulanır. AndroidX altyapısında yalnız sistem izniyle korunan bileşenlere izin verilir.
- `dataSync` ve `specialUse` foreground service türleri ve special-use alt tür açıklaması doğrulanır.
- `allowBackup=false`, `usesCleartextTraffic=false` ve gerekli temel izinler doğrulanır.
- Nova İndir web adresi BuildConfig, kaynak ve manifest meta-data alanına eklendi.
- Play Console FGS beyan taslağı eklendi.
- Kaynak paketten üretilmiş 16 KB TXT raporları çıkarıldı; audit betiği Checkpoint 036 adıyla rapor üretir.

# Checkpoint 035 — Yerel motor paketleme ve 16 KB denetim temizliği

- Sürüm kodu 37, checkpoint 035 oldu.
- youtubedl-android çalışma zamanı için `jniLibs.useLegacyPackaging = true` etkinleştirildi.
- `libpython.zip.so` ve `libffmpeg.zip.so` dosyalarının gerçek ZIP yükleri olduğu imza kontrolüyle doğrulanıyor.
- Bilinen ZIP yükleri artık yanlış ELF uyarısı üretmiyor; bilinmeyen `.so` içerikleri uyarılmaya devam ediyor.
- PowerShell 5.1 uyumlu tek `AUDIT_16KB.ps1` betiği ve bundletool hazırlama betiği eklendi.
- Lite/Pro AAB ve APK çıktı klasörü `Nova İndir 035 Google Play` oldu.

# Checkpoint 034 — Google Play AAB Build Fix ve 16 KB Hazırlığı

- Lite/Pro AAB derlemesini durduran `Sequence contains more than one matching element` hatası giderildi.
- ABI split yapılandırması APK ve AAB modları için ayrıldı.
- Android Gradle Plugin 8.13.2, Gradle 8.13 ve Kotlin 2.3.21 eşleşmesine geçildi.
- Modern yerel kütüphane paketlemesi etkinleştirildi (`useLegacyPackaging = false`).
- AAB/APK içindeki yerel kütüphaneler için `AUDIT_16KB.ps1` denetim betiği eklendi.
- Sürüm kodu 36, checkpoint 034 oldu.

# Checkpoint 032 — Eski Lila Zemin + Mavi Glossy Butonlar

- Eski ana ekranın `#EEE6FF` lila zemini aynen korundu.
- Lila glossy butonlar, mavi glossy gradyanla değiştirildi.
- Durum çubuğu ve vurgu rengi orijinal mavi başlık ailesine alındı.
- `assembleNovaDebug` ve standart `assembleDebug` temiz isimli altı APK üretir.

# Checkpoint 030 — Lite çıktı paketi ve temiz adlandırma

- Full ile birlikte Lite ARM v7a, ARM v8a ve Universal APK üretim betikleri eklendi.
- `BUILD_ALL_DEBUG.cmd` iki flavor için altı APK’yı tek komutla hazırlar.
- Çıktılar ortak `Nova Downloader 030 v0.9.9 Alpha Lila Glossy` klasörünün Full ve Lite alt klasörlerine yazılır.
- APK adları kullanıcının belirlediği sade, boşluklu biçime sabitlendi.
- Ana menü kimliği sürüm kodu 32 ve Checkpoint 030 olarak güncellendi.

## Checkpoint 029 — Eski lila kilidi ve temiz çıktı adları

- Eski ana ekranın lila rengi `#EEE6FF` bütün ekranlarda korunuyor.
- `values-night` koyu renk geçersiz kılmaları kaldırıldı; cihaz koyu modda olsa da eski lila değişmiyor.
- Android otomatik force-dark kapatıldı.
- Glossy lila butonlar aynen korundu.
- Full APK derleme betiği temiz klasör ve APK adları üretir.
- Sürüm kodu `31`, checkpoint `029` oldu.

# 0.9.9-alpha — Checkpoint 028

- `#EEE6FF` lila ana arka plan bütün ekranlarda kaynak tabanlı olarak geri getirildi.
- Açık lila kart/yüzey ve lila kenarlık paleti tek merkezde toplandı.
- Uygulamadaki standart butonların tamamına tema düzeyinde glossy lila görünüm uygulandı.
- Butonlara üst parlama yansıması, dikey lila geçiş, koyu alt gölge, yuvarlatılmış köşe, basılı ve devre dışı durumları eklendi.
- Koyu tema için uyumlu mürdüm arka plan ve mor glossy buton paleti eklendi.
- Sürüm `0.9.9-alpha`, sürüm kodu `30` ve checkpoint `028` olarak güncellendi.

# 0.9.8-alpha — Checkpoint 027

- Gerçek Android derlemesinde APK çeviri modülünü durduran Kotlin hataları düzeltildi.
- ML Kit `DownloadConditions` sınıfı doğru `com.google.mlkit.common.model` paketinden içe aktarılıyor.
- Çeviri ekranında `ScrollView.LayoutParams` yerine geçerli `FrameLayout.LayoutParams` kullanılıyor.
- APK yeniden oluşturma kontrolündeki geçersiz Elvis/`if` ifadesi açık çağrı ve dosya doğrulamasına ayrıldı.
- `versionCode` 29 ve checkpoint 027 olarak güncellendi; ana menü tam derleme kimliğini göstermeye devam ediyor.

# 0.9.8-alpha — Checkpoint 026

- Ana menüye kalıcı tam derleme kimliği eklendi: sürüm adı, sürüm kodu, checkpoint, flavor ve build type.
- `versionCode` 28 ve checkpoint 026 olarak güncellendi.
- Sürüm değerleri Gradle içinde tek merkezden yönetiliyor.

# 0.9.8-alpha — Checkpoint 025

- Added a real APK translation screen under APK Download Center.
- Added SAF selection and validation for a single installable APK without modifying the original file.
- Added compiled Android `resources.arsc` string reading/writing and target-locale insertion with ARSCLib 1.4.0.
- Added on-device Google ML Kit translation with on-demand language-model download and optional Wi-Fi-only model acquisition.
- Added placeholder/tag/URL masking for format-safe resource translation.
- Added APK rebuild, local AndroidKeyStore RSA signing, v1/v2/v3 signature generation and post-sign verification with apksig 8.10.1.
- Added foreground WorkManager progress, cancellation, notifications and `Downloads/NovaDownloader/APK/Translated/` output.
- Added English, Turkish and German UI strings, tests, privacy/security documentation and third-party notices.
- Current scope is simple compiled `string` resources in one APK; split bundles, plurals, arrays, styled strings, code/image/web text and signature/integrity bypass are intentionally unsupported.

# 0.9.7-alpha — Checkpoint 024.2 compile fix

- `StorageHelper` için eksik `FileNameResolver` importu eklendi.
- `fixedLengthStreamingMode(...)` çağrısı Java API ile uyumlu `setFixedLengthStreamingMode(...)` biçimine geçirildi.
- WorkManager gözlemcisi `LiveData<WorkInfo?>` nullable sözleşmesine uyarlandı.

# 0.9.7-alpha — Checkpoint 024.1 build hotfix

- Kotlin 2.3.21 ile hata veren `android.kotlinOptions.jvmTarget` kaldırıldı.
- `kotlin.compilerOptions.jvmTarget = JvmTarget.fromTarget("17")` kullanımına geçildi.
- Java 17 ve Kotlin JVM 17 hedef eşleşmesi korundu.

# 0.9.7-alpha — Checkpoint 024

- Added an Evozi-independent Google Play link/package-name downloader using GPlayAPI 3.6.4.
- Added temporary anonymous Play authentication through a configurable HTTPS dispenser.
- Restricted independent delivery to free apps and retained payment/licensing/account/region protections.
- Added device-compatible base/split/OBB delivery, size/hash verification and APK/APKS packaging.
- Added WorkManager foreground progress, cancellation, completion/failure notifications and `Downloads/NovaDownloader/APK/PlayStore/` output.
- Added English, Turkish and German UI/privacy/security documentation for the experimental flow.

# 0.9.6-alpha — Checkpoint 023

- Added an Evozi-independent direct APK/APKS/XAPK/APKM/ZIP downloader.
- Added HTTPS redirect, MIME/file-name and private-network safety validation.
- Added direct package-link share routing and `Downloads/NovaDownloader/APK/Direct/` output.

# Değişiklik Günlüğü

## 0.9.4-alpha — Checkpoint 021 arka plan çözümleme, tamamlanma uyarıları ve evcil hayvan denetimleri

- Link çözümleme işlemi kalıcı görev kaydı kullanan `dataSync` ön plan servisine taşındı; Nova aşağı alındığında çözümleme devam eder.
- Çözümleme tamamlanınca varsayılan kalite/biçim/klasörle otomatik indirme seçeneği eklendi.
- Otomatik başlatma kapalıysa çözümlenen video saklanır ve bildirimden ya da Nova yeniden açıldığında seçenek ekranına dönülür.
- Doğrudan ve yt-dlp indirmeleri için ayrı önem düzeyi normal tamamlanma bildirim kanalı eklendi.
- Nova ekrandayken isteğe bağlı tamamlanma kutucuğu ve dosyayı Nova Player'da/konumunda açma eylemleri eklendi.
- Evcil hayvan çözümleme, video hazır ve tamamlandı durumlarını gösterecek şekilde genişletildi.
- Evcil hayvan menüsüne Nova'yı ekrana getirme ve arka plana alma eylemleri eklendi.
- Arka plan çalışma ve uyarılar için altı ayrı kullanıcı ayarı eklendi.
- Sürüm kodu 23 ve sürüm adı 0.9.4-alpha olarak güncellendi.

## 0.9.3-alpha — Checkpoint 020 tek dokunuşla oynatma, uzun basışla eylem menüsü

- Ana indirme geçmişinde tamamlanmış video veya ses dosyasına normal dokunulduğunda Nova'nın dahili oynatıcısı doğrudan açılır.
- Galeride video veya ses dosyasına normal dokunulduğunda Nova'nın dahili oynatıcısı doğrudan açılır.
- Ana indirme geçmişinde veya Galeride dosyaya uzun basıldığında eylem menüsü açılır.
- Eylem menüsünde Nova içinde oynat, haricî uygulamada aç, dosya konumunu aç, yeniden adlandır ve paylaş seçenekleri korunur.
- Henüz tamamlanmamış bir indirmeye normal dokunulduğunda duraklatma, devam ettirme ve iptal gibi uygun indirme eylemleri gösterilir.
- Sürüm kodu 22 ve sürüm adı 0.9.3-alpha olarak güncellendi.

## 0.9.2-alpha — Checkpoint 019 arayüzden tek dokunuşla yeniden adlandırma

- Galeride indirilen video, ses veya dosyaya normal şekilde dokunulduğunda artık doğrudan Nova eylem menüsü açılır.
- Eylem menüsünde **Nova içinde oynat**, **Haricî uygulamada aç**, **Dosya konumunu aç**, **Yeniden adlandır** ve **Paylaş** seçenekleri birlikte gösterilir.
- Yeniden adlandırmak için depolama alanına veya sistem dosya yöneticisine gitmek gerekmez.
- Ana indirme geçmişindeki tek dokunuş eylem menüsü korunmuştur; Galeri davranışı bununla aynı hâle getirilmiştir.
- Yeniden adlandırmadan sonra Room kaydı, gerçek dosya URI'si, galeri, oynatıcı, paylaşım ve konum açma işlemleri yeni adı kullanmaya devam eder.
- Sürüm kodu 21 ve sürüm adı 0.9.2-alpha olarak güncellendi.

## 0.9.1-alpha — Checkpoint 018 tamamlanan dosyayı yeniden adlandırma

- Tamamlanan video, ses ve diğer indirmelere Nova içinden yeniden adlandırma seçeneği eklendi.
- Yeniden adlandırma ana indirme geçmişi ve Galeri eylem menülerine eklendi.
- MediaStore, SAF belge sağlayıcıları ve Android 8–9 klasik İndirilenler klasörü desteklenir hâle getirildi.
- Yeni adda uzantı yazılmasa veya yanlış medya uzantısı yazılsa bile gerçek MP4/M4A/WebM vb. uzantının korunması sağlandı.
- Dosyanın URI'si ve gerçek sağlayıcı adı Room geçmişinde atomik biçimde güncellenir; oynatıcı, galeri, paylaşım ve dosya konumu yeni adı kullanır.
- Sistem dosya yöneticisinde adı değiştirilen ve URI'si geçerli kalan dosyaların adı Nova yeniden öne geldiğinde eşitlenir.
- Aynı ad mevcutsa güvenli biçimde numaralı benzersiz ad üretilir.
- Sürüm kodu 20 ve sürüm adı 0.9.1-alpha olarak güncellendi.

## 0.9.0-alpha — Checkpoint 017 medya kitaplığı, zamanlama ve hesap yönetimi

- Media3 ExoPlayer tabanlı dahili video/ses oynatıcısı eklendi.
- Küçük resimli, aramalı, tür filtreli ve sıralanabilir indirme galerisi eklendi.
- Doğrudan HTTP ve yt-dlp indirmeleri için kullanıcı ayarlı hız sınırı eklendi.
- Tarih/saat seçilebilir indirme planlama ve WorkManager tabanlı gecikmeli başlatma eklendi.
- ItemTouchHelper ile sürükleyip bırakılabilen, kalıcı kuyruk sırası eklendi.
- Paralel indirme sınırı ve kuyruk koordinatörü eklendi.
- YouTube, Instagram, Facebook, TikTok, X/Twitter ve genel web için çoklu, adlandırılmış ve şifreli hesap profilleri eklendi.
- Uygulama içi oturum açma/yenileme, cookies.txt içe aktarma, etkin profil, yeniden adlandırma, etkinleştirme/devre dışı bırakma, oturum kapatma ve silme eklendi.
- Planlanan görev tetiklendiğinde kayıt durumunu güvenli biçimde yeniden PENDING yapan kurtarma davranışı eklendi.
- Sürüm kodu 19 ve sürüm adı 0.9.0-alpha olarak güncellendi.

## 0.8.5-alpha — Checkpoint 016 Windows yol düzeltmesi

- Türkçe/non-ASCII karakter içeren Windows proje yollarında Android Gradle Plugin tarafından durdurulan derleme düzeltildi.
- Tek tıklamalı derleme betiği projeyi kopyalamadan geçici ASCII sürücü harfine bağlar, derler ve bağlantıyı otomatik kaldırır.
- Boş sürücü harfi bulunamazsa `android.overridePathCheck=true` yedek ayarı kullanılır.
- APK çıktıları ve `build-full.log` yine kullanıcının çıkardığı proje klasöründe kalır.
- Sürüm kodu 18 ve sürüm adı 0.8.5-alpha olarak güncellendi.

## 0.8.4-alpha — Checkpoint 015 derleme betiği düzeltmesi

- PowerShell'in Gradle tarafından stderr'e yazılan normal çıktıyı `NativeCommandError` olarak kesmesi giderildi.
- Gradle, stderr/stdout birleştirmesini güvenli yapan `cmd.exe` katmanı üzerinden çalıştırılıyor.
- Derleme günlükleri yine `build-full.log` dosyasına eksiksiz kaydediliyor.
- Windows PowerShell 5.1 için UTF-8 BOM ve konsol kod sayfası düzeltildi.
- Sürüm kodu 17 ve sürüm adı 0.8.4-alpha olarak güncellendi.

## 0.8.3-alpha — Checkpoint 014 eksiksiz Gradle Wrapper paketi

- Kaynak ZIP'e yanlışlıkla alınmayan `gradle/wrapper/gradle-wrapper.jar` eklendi.
- Tek tıklamalı derleme betiğine Wrapper JAR varlık ve SHA-256 ön denetimi eklendi.
- Derleme çıktısı otomatik olarak `build-full.log` dosyasına kaydediliyor.
- Gradle Wrapper başlatıcısı eksik Java veya eksik Wrapper durumlarında açık hata verecek şekilde güçlendirildi.
- Sürüm kodu 16 ve sürüm adı 0.8.3-alpha olarak güncellendi.

# Changelog

## 0.8.2-alpha — Checkpoint 013 derleme düzeltme paketi

- Kotlin derlemesini durduran `YtDlpMediaResolver` ifade-gövdesi dönüş hataları düzeltildi.
- Motor bakım servisindeki `Any`/`String` tür uyuşmazlığı giderildi.
- Evcil hayvan servisindeki eksik `R` kaynağı içe aktarımı eklendi.
- WebView hata açıklaması güvenli biçimde `String` değerine dönüştürüldü.
- Sürüm kodu 15 ve sürüm adı 0.8.2-alpha olarak güncellendi.

## 0.8.1-alpha — Checkpoint 012 tam paket

- Android Gradle Plugin sürümü `8.10.1` olarak düzeltildi.
- Gradle Wrapper `8.11.1` ile tam proje paketi yeniden oluşturuldu.
- Kullanıcının proje içinde elle dosya veya satır değiştirmesine gerek kalmayacak şekilde düzeltme doğrudan kaynak pakete işlendi.
- Sürüm kodu `14`, sürüm adı `0.8.1-alpha` olarak güncellendi.

## Build hotfix — 2026-07-26

- Android Gradle Plugin sürümü, yayımlanmamış/çözümlenemeyen `8.10.2` değerinden mevcut `8.10.1` sürümüne düzeltildi.
- Gradle Wrapper `8.11.1` olarak korundu; AGP 8.10 uyumluluğu için doğru eşleşmedir.

## 0.8.0-alpha — Checkpoint 012

- Kullanıcıya gösterilen metinler merkezi Android kaynak kataloğuna taşındı; İngilizce, Türkçe ve Almanca için eş anahtar ve format-placeholder denetimi eklendi.
- Sistem dili ve uygulama içi dil seçimi eklendi; bildirimler, servisler, kurulum, tarayıcı, motor ve güncelleme metinleri yerelleştirildi.
- 512 KB × 3 dönen, cihazda kalan ve gizli değerleri maskeleyen yerel hata günlüğü eklendi.
- Uygulama/cihaz/bellek/motor ve maskelenmiş indirme özeti içeren, kullanıcı tarafından ZIP olarak dışa aktarılabilen tanılama raporu eklendi.
- RSA-SHA256 imzalı HTTPS güncelleme bildirimi, varyant doğrulama, APK SHA-256, paket/sürüm ve kurulu imzalayan sertifika doğrulaması eklendi.
- Güncelleme APK’sı özel önbelleğe alındı ve Android paket yükleyicisi açılmadan önce ikinci kez doğrulanır hâle getirildi.
- Full ve Lite varyantları için ayrı güncelleme bildirim adresleri desteklenir hâle getirildi.
- yt-dlp güncellemesi öncesi bilinen-iyi motor görüntüsü, sağlık denetimi, otomatik/elle geri alma ve paketlenmiş motora dönme eklendi.
- Full (FFmpeg dahil) ve Lite (FFmpeg hariç) ürün varyantları; ARM ABI APK ayrımları ve AAB dil/yoğunluk/ABI ayrımları eklendi.
- Release R8 kod/kaynak küçültme, optimize edilmiş kaynak küçültme, AndroidX etkin/Jetifier kapalı yapılandırması eklendi.
- Python/yt-dlp/FFmpeg işi ayrı `:media` işlemine taşındı; tek ağır indirme, bellek moduna göre fragment sınırı ve boşta işlem kapatma eklendi.
- FFmpeg başlatma, yalnız işlem gerçekten birleştirme/dönüştürme/meta veri sonrası işlemi gerektirdiğinde yapılacak şekilde ertelendi.
- URL doğrulamasına yerel birim testlerinde kaynak gerektirmeyen saf politika sonucu eklendi.
- Kaynak bütünlük denetimi; çeviri placeholder eşliği, hardcoded kullanıcı metni, güvenli güncelleme, geri alma ve optimizasyon kontrolleriyle genişletildi.
- Sürüm `0.8.0-alpha`, sürüm kodu `13` olarak güncellendi.

## 0.7.0-alpha — Checkpoint 011

- Reklamlı referans uygulamadaki temel kullanım akışına karşılık gelen dahili **Nova Browser** eklendi.
- WebView açık sayfası, ağ kaynakları, indirme olayları, HTML5 `video`/`audio`/`source` öğeleri ve performans kaynaklarından otomatik medya algılama eklendi.
- MP4/WebM ve diğer doğrudan video/ses bağlantıları ile HLS `m3u8` ve DASH `mpd` manifestleri ayrı aday türleri olarak listelenir; gürültü oluşturan `m4s`/`ts` parça bağlantıları filtrelenir.
- “Bu sayfayı indir” geri dönüşü ile dinamik veya `blob:` oynatıcıların sayfa adresi doğrudan yt-dlp çözümleyicisine gönderilir.
- Tarayıcı oturumunu YouTube/Instagram/Facebook/genel platform profiline Netscape biçiminde ve Android Keystore destekli şifreli olarak aktarma eklendi.
- Doğrudan algılanan medyada WebView User-Agent, Referer ve geçici Cookie başlıkları ilk indirme isteğine aktarılır; hassas başlıklar kalıcı geçmişe yazılmaz.
- Tarayıcı için açılış sayfası, otomatik algılama, oturum eşitleme, üçüncü taraf çerezi ve çıkışta önbellek temizleme ayarları eklendi.
- Tarayıcı verilerini tek işlemle temizleme eklendi; içe aktarılmış şifreli cookies.txt profilleri ayrı tutulur.
- WebView yerel dosya/içerik erişimi kapatıldı, karışık içerik ve HTTP engellendi, TLS hataları aşılmadı, Safe Browsing etkinleştirildi ve JavaScript yerel köprüsü kullanılmadı.
- Sürüm `0.7.0-alpha`, sürüm kodu `12` olarak güncellendi.

## 0.6.0-alpha — Checkpoint 010

- Eski `RecoveryReceiver` içindeki tanımsız yarım dosya değişkeni kaldırılarak derlemeyi durduran kaynak hatası düzeltildi.
- İndirme geçmişi ve kuyruğu SharedPreferences JSON depolamasından Room 2.8.4 veritabanına taşındı; tek seferlik eski kayıt göçü ve 500 kayıt sınırı eklendi.
- WorkManager 2.11.2 ile ağ/şarj koşullu kurtarma taraması eklendi. Android 12+ arka plan ön plan-servisi başlatma sınırı nedeniyle yarım dosyaları koruyan ve kullanıcı eylemi isteyen güvenli geri dönüş eklendi. Nova öne geldiğinde seçilen Wi-Fi/her ağ ve şarj koşullarına göre otomatik devam denenir.
- Gerçek yt-dlp biçim incelemesi eklendi: format kimliği, çözünürlük, FPS, HDR/dinamik aralık, codec, ses dili, tahmini boyut ve HLS/DASH protokolü listelenir.
- Oynatma listesi, canlı yayın başlangıcı, ses dili, altyazı, otomatik altyazı, kapak, açıklama, meta veri ve bölüm seçenekleri eklendi.
- YouTube, Instagram, Facebook ve genel kullanım için ayrı şifreli çerez profilleri eklendi.
- Uyumlu haricî PO Token sağlayıcı eklentisi ZIP içe aktarma, özel eklenti dizini ve sağlayıcı `base_url` desteği eklendi.
- Eklenti ZIP'lerinde yol geçişi, dosya türü, boyut ve giriş sayısı denetimleri ile atomik yedekleme/geri alma eklendi.
- İptal ve duraklatma tamamen ayrıldı; iptal yarım veriyi siler, duraklatma devam verisini korur.
- Aynı isimli dosya için yeniden adlandır, üzerine yaz veya atla politikaları eklendi.
- Tamamlanan dosyaları topluca taşıma, tamamlanan geçmişi temizleme ve yarım/hatalı kayıtları topluca temizleme eklendi.
- Çıktılar hedef konumda SHA-256 ile tekrar okunarak doğrulanır; taşıma doğrulanmadan kaynak silinmez.
- Release imzalama değişkenleri, R8/resource shrinking ve ARM ABI ayrımı eklendi.
- Özel PNG/WebP/GIF ve durum tabanlı ZIP dijital evcil hayvan paketleri eklendi.
- Evcil hayvan boyutu, saydamlık, kenara yaslama, düşük güç modu ve açılışta gösterme ayarları eklendi.
- Evcil hayvan Android 8+ için bildirimli `specialUse` ön plan servisine dönüştürüldü; bildirimden menü açma ve devre dışı bırakma eylemleri eklendi.
- FFmpeg sınıfının doğru `com.yausername.ffmpeg.FFmpeg` paketinden içe aktarılması sağlandı.
- Boşta yalnız komut işleyen indirme servislerinin işlem bittikten sonra kendini kapatmaması düzeltildi.
- AndroidX Core 1.17.0, AndroidX Test Core/Runner 1.7.0 ve JUnit Extensions 1.3.0 sürümlerine güncellendi.
- Kaynak bütünlük denetimi, saf Kotlin smoke testleri, Room cihaz testi ve release yapılandırması kontrolleri genişletildi.

## 0.5.1-alpha — Checkpoint 009

- Açık temadaki beyaz/açık gri ana arka plan lila `#EEE6FF` olarak değiştirildi.
- İndirme kartı ve iletişim yüzeyleri daha açık lila `#F9F5FF` olarak uyumlandırıldı.
- Açık tema kart kenarlıkları `#D7C7F2` yapılarak metin ve kontrollerin ayrımı korundu.
- Ana ekran, kurulum, ayarlar ve evcil hayvan menüsü aynı merkezi renk paletini kullanacak şekilde birleştirildi.
- Koyu tema renkleri değiştirilmedi.

## 0.5.0-alpha — Checkpoint 008

- YouTube, YouTube Music ve diğer bilinen platform alan adları yt-dlp motoruna doğrudan yönlendirildi.
- `youtubedl-android` FFmpeg 0.18.1 bileşeni eklendi ve servis başlangıcında başlatıldı.
- Ayrı görüntü/ses akışlarını birleştirme ve ses çıkarma motoru eklendi.
- HLS `.m3u8` ve DASH `.mpd`/`application/dash+xml` akışlarının reddedilmesi kaldırıldı.
- yt-dlp tabanlı tüm desteklenen platformlarda video/yalnızca ses seçimi eklendi.
- En iyi, 2160p, 1440p, 1080p, 720p, 480p ve 360p kalite üst sınırı seçenekleri eklendi.
- MP4, MKV ve WebM video kapsayıcısı; M4A, MP3, Opus, FLAC ve WAV ses biçimi seçenekleri eklendi.
- MP4 ve WebM için uygun kaynak biçimlerini önceleyen format seçicileri eklendi.
- Netscape/Mozilla `cookies.txt` içe aktarma, etkinleştirme ve temizleme arayüzü eklendi.
- Çerezlerin Android Keystore AES-GCM ile şifreli saklanması ve yalnızca işlem sırasında geçici olarak açılması eklendi.
- Instagram özel gönderi/hikâye ve diğer oturum gerektiren içerikler için kullanıcının yetkili oturumunu aktarma desteği eklendi.
- Yeniden deneme, üstel bekleme, istek gecikmesi ve 1–8 eşzamanlı HLS/DASH parçası ayarları eklendi.
- YouTube EJS uzak bileşen anahtarı, oynatıcı istemcisi, PO Token ve Visitor Data ayarları eklendi.
- PO Token ve Visitor Data değerleri Android Keystore ile şifreli saklanır.
- yt-dlp görevleri için ayrı ön plan indirme servisi, bildirim ilerlemesi, durdurma ve `.part` tabanlı devam desteği eklendi.
- yt-dlp yüzdesi geçmişte ve dijital evcil hayvanda gösterilir.
- Yeniden başlatma kurtarması yt-dlp çalışma dizinlerini de kapsayacak şekilde genişletildi.
- Ayarlar ekranı uzun içerik için kaydırılabilir hâle getirildi.

## 0.4.0-alpha — Checkpoint 007

- MP4 ve diğer bilinen medya türleri için MIME, sunucu başlıkları, URL ve dosya imzasına dayalı zorunlu uzantı düzeltmesi eklendi.
- Uzantısız ve `.bin`, `.download`, `.dat`, `.tmp`, `.part` adlarının gerçek medya uzantısıyla değiştirilmesi eklendi.
- MP4 `ftyp`, WebM/Matroska, MP3, OGG, FLAC ve WAV dosya imzası algılama eklendi.
- İndirmelerin uygulamaya özel `.nova.part` dosyasına yazılması ve yalnızca tamamlanınca seçilen hedefe aktarılması eklendi.
- HTTP `Range`, `If-Range`, `ETag`, `Last-Modified` ve `Content-Range` doğrulamalı devam motoru eklendi.
- Sunucu Range isteğini yok saydığında veya uzaktaki dosya değiştiğinde güvenli baştan başlatma eklendi.
- Durdurulan, bağlantısı kesilen veya servis tarafından yarım bırakılan indirmeler için “Kaldığı yerden devam et” eylemi eklendi.
- Geçici ağ ve HTTP 408/429/5xx hataları için üç otomatik yeniden deneme eklendi.
- Bildirimde “İptal” yerine yarım dosyayı koruyan “Durdur” eylemi eklendi.
- Ekran kapalı indirmeler için altı saatle sınırlı `PARTIAL_WAKE_LOCK` eklendi.
- Servis yeniden oluşturulmasında görev teslimi için `START_REDELIVER_INTENT` eklendi.
- Uygulama yeniden açıldığında kesilmiş aktif kayıtların yarım dosya boyutuyla kurtarılması eklendi.
- Telefon yeniden başlatma/uygulama güncellemesi sonrasında yarım indirme kurtarma bildirimi eklendi; boot sırasında veri aktarımı servisi başlatılmaz.
- Aynı anda iki indirme çalıştırabilen sabit iş havuzu ve ortak ön plan özet bildirimi eklendi.
- Tamamlanmamış dosyayı geçmiş kaydıyla birlikte silme ve geçmiş temizliğinde kısmi dosyaları kaldırma eklendi.
- `Cookie`, `Authorization` ve benzeri hassas başlıkların kalıcı geçmişe yazılmaması sağlandı.

## 0.3.0-alpha — Checkpoint 006

- İlk açılış kurulum ekranı eklendi.
- Kurulumda otomatik indirme dizinini koruma veya özel klasör seçme desteği eklendi.
- Kurulumda evcil hayvan ve indirme durumu görünürlüğü seçimi eklendi.
- İndirme başlamadan önce dosya adı ve hedef klasör düzenleme penceresi eklendi.
- İndirme öncesi onay penceresini Ayarlardan devre dışı bırakma eklendi.
- Otomatik `İndirilenler/NovaDownloader` hedefi MediaStore ile uygulandı.
- Kullanıcının seçtiği klasöre kalıcı SAF izniyle yazma desteği eklendi.
- DownloadManager yerine hedef URI'ye yazabilen ön plan indirme servisi eklendi.
- HTTPS yönlendirmeleri için sekiz adımlı ve HTTP düşürmesini reddeden güvenli takip eklendi.
- İndirme ilerlemesi, iptal, tamamlanma ve hata durumları yeni geçmiş modeline taşındı.
- Dosyayı ve dosyanın bulunduğu konumu açma eylemleri eklendi.
- Ayarlar ekranı eklendi.
- Taşınabilir dijital evcil hayvan katmanı eklendi.
- Evcil hayvanda indirme yüzdesi ve tamamlanma durumu eklendi.
- Evcil hayvan menüsüne dosya konumu, ana pencere, tür değiştirme, özelleştirme ve kapatma eylemleri eklendi.
- Nova, robot, kedi ve baloncuk içeren genişletilebilir evcil hayvan kataloğu eklendi.
- Evcil hayvan rengi ve yuvarlatılmış, daire, köşeli, şeffaf çerçeve kabukları eklendi.
- Android 8–9 için FileProvider, Android 10+ için MediaStore desteği eklendi.
- HTML içeriğin indirme servisinde ikinci kez reddedilmesi eklendi.


## 0.2.3-alpha — Checkpoint 005

- Facebook kısa `/share/v/`, `/share/r/` ve `fb.watch` adresleri için cihaz içi gerçek sayfa çözümleyicisi eklendi.
- yt-dlp ilk isteğindeki zorunlu mobil `User-Agent` kaldırıldı; çözümleyicinin varsayılan yönlendirme davranışı korundu.
- HTTP Location, canonical, `og:url`, meta refresh ve gömülü Facebook URL adayları desteklendi.
- Sayısal video kimliğinden `watch`, `video.php`, mobil watch ve `facebook:<id>` adayları üretildi.
- Varsayılan, iPhone ve `facebookexternalhit/1.1` profilleriyle kontrollü yeniden deneme eklendi.
- En anlamlı çözümleyici hatasını seçen hata önceliklendirmesi eklendi.
- yt-dlp tarafından döndürülen `Cookie` başlığının ilgili Android indirme isteğine aktarılması eklendi.
- Teknik hata içindeki URL gösterimi `(adres gizlendi)` olarak netleştirildi.

## 0.2.2-alpha — Checkpoint 004

- yt-dlp çözümleyicisi her uygulama oturumunda kararlı kanaldan güncellenir.
- Facebook ayrıştırma hatalarında gecelik yt-dlp sürümüyle tek seferlik otomatik yeniden deneme eklendi.
- Facebook paylaşım bağlantılarının HTTP yönlendirmeleri çözülerek gerçek sayfa adresi de denenir.
- Biçim seçimi Facebook'un tek parça MP4/video+ses akışlarına göre gevşetildi.
- Genel hata yerine yt-dlp sürümü, güncelleme durumu ve güvenli biçimde kısaltılmış teknik hata gösterilir.

# Değişiklik Günlüğü

## 0.2.1-alpha — Checkpoint 003

- Facebook paylaşım bağlantısının video sayfası olarak çözülmesi eklendi.
- Cihaz üzerinde çalışan `youtubedl-android` / `yt-dlp` çözümleme motoru eklendi.
- Tek parça video+ses akışı seçimi eklendi.
- Çözümlenen medya için `User-Agent`, `Referer`, `Origin` ve `Accept-Language` başlıklarının güvenli aktarımı eklendi.
- Facebook ve benzeri sayfa bağlantıları için çözümleyici öncelikli hâle getirildi.
- Statik HTML taramasına `progressive_url`, `playable_url_dash`, `hls_playlist_url`, `manifest_url` ve `video_redirect` desteği eklendi.
- HTML okuma üst sınırı 2 MiB'den 8 MiB'ye çıkarıldı.
- “Doğrudan medya bağlantısı değil” şeklindeki yanıltıcı hata metni kaldırıldı.
- Arayüz durumu “Video çözümleniyor…” olarak değiştirildi.
- Lisans GPL-3.0 olarak güncellendi.

## 0.2.0-alpha — Checkpoint 002

- Web sayfasının `.bin` olarak indirilip yanlışlıkla başarılı gösterilmesi düzeltildi.
- İndirme öncesi HTTPS bağlantı ve MIME türü denetimi eklendi.
- Güvenli yönlendirme izleme eklendi.
- Halka açık HTML sayfalarından temel medya adresi çıkarımı eklendi.

## 0.1.1-alpha

- Kullanıcı tarafından seçilen Nova Downloader logosu uygulandı.

## 0.1.0-alpha

- İlk güvenli doğrudan dosya indirme prototipi.

## 0.9.5-alpha — Checkpoint 022
- Added a separate **APK Download** tab under the main navigation controls.
- Added Google Play URL/package-name parsing and canonical Play URL conversion.
- Added hardened in-app Evozi provider workflow with automatic form filling/submission fallback.
- Added Android DownloadManager handling for APK/APKS/XAPK/ZIP files under `Downloads/NovaDownloader/APK`.
- Added Play-link share routing directly into the APK downloader.
- Added English, Turkish and German strings for the complete APK workflow.
- Paid, DRM-protected, account-restricted and region-restricted delivery is intentionally not bypassed.
