# Nova Video İndir — Google Play Foreground Service Beyan Taslağı (Checkpoint 038)

Bu belge yalnız Google Play `playLite` / `playPro` varyantları içindir.

## `dataSync`

### Özelliğin açıklaması
Nova Video İndir, kullanıcının açıkça başlattığı dosya/medya indirmesini ve gerekli medya çözümleme işini tamamlamak, ilerlemeyi kalıcı bildirimle görünür kılmak için `dataSync` foreground service kullanır.

### İlgili servisler
- `DownloadService`
- `YtDlpDownloadService`
- `BackgroundResolutionService`
- WorkManager `SystemForegroundService`

### Kullanıcı nasıl başlatır?
1. Kullanıcı uygulamayı açar veya bir bağlantıyı Nova Video İndir'e paylaşır.
2. Bağlantı çözümlenir.
3. Kullanıcı dosya adı/kalite/hedef seçeneklerini onaylar.
4. Kullanıcı **İndir** düğmesine basar.
5. İş sürdüğü sürece foreground bildirimi gösterilir.

### Kullanıcı nasıl durdurur?
Kuyruk ekranından veya bildirimin sağladığı eylemlerden indirmeyi duraklatabilir/iptal edebilir. İş bittiğinde servis kapanır.

### Ertelenirse/kesilirse etkisi
Kullanıcı tarafından beklenen indirme hemen başlamaz veya yarıda kalır; süreli medya URL'si geçersizleşebilir. Bu nedenle işlem kullanıcı tarafından başlatılan, zamanında ve kullanıcıya görünür bir veri aktarımıdır.

### Play Console demo videosu
Videoda bağlantı girme/paylaşma → çözümleme → **İndir** → foreground bildirimin görünmesi → uygulamayı arka plana alma → kuyruktan/bildirimden iptal adımları gösterilmelidir.

## 038'de `specialUse` yok
Dijital pet overlay özelliği Google Play source-set'inden çıkarılmıştır. Play merged manifestinde `SYSTEM_ALERT_WINDOW`, `FOREGROUND_SERVICE_SPECIAL_USE` ve `PetOverlayService` bulunmamalıdır. Dolayısıyla Play Console FGS formunda pet için `specialUse` beyanı yapılmamalıdır. Pet yalnız bağımsız dağıtımda bulunur.
