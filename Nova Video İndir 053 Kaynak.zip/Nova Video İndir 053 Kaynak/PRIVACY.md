# Nova Video İndir Gizlilik Belgeleri

Checkpoint 038 ile dağıtım kanalları ayrılmıştır. Google Play'e gönderilecek binary için **PRIVACY_PLAY.md**, bağımsız APK dağıtımı için **PRIVACY_INDEPENDENT.md** esas alınır.

- Google Play: `PRIVACY_PLAY.md`
- Bağımsız dağıtım: `PRIVACY_INDEPENDENT.md`

Play Console'daki herkese açık gizlilik URL'si, yayınlanan `PRIVACY_PLAY.md` içeriğiyle uyumlu olmalı ve `NOVA_PLAY_PRIVACY_URL` olarak release derlemesine verilmelidir.
