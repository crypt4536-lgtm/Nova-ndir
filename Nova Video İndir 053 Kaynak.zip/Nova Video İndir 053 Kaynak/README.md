# Nova Video İndir

> **Checkpoint 053 — Google Play paketli motor + temiz Nova Video İndir kimliği:** Sürüm `0.53`, kod `55`, Checkpoint `053`. Google Play varyantı yalnız AAB içinde paketlenen yt-dlp + yt-dlp-ejs + QuickJS motorunu kullanır; runtime yt-dlp güncellemesi, uzaktan EJS indirme ve üçüncü taraf Python plugin yükleme Play'de kapalıdır. Bağımsız varyant Google Play'deki ortak Nova özelliklerinin tamamını taşır ve bunlara APK araçları, imzalı self-update, pet overlay, runtime motor güncellemesi ve plugin/remote-EJS esnekliğini ekler. Kullanıcıya görünen ürün adı **Nova Video İndir**, dağıtım adı **Bağımsız** olarak sabitlenmiştir.

> **Checkpoint 049 — sağlam tanılama + Nova Player hata görünürlüğü:** Yerel log yazımı eşzamanlı çağrılarda güvenli hale getirildi ve dosya kilidi başarısız olursa süreç bazlı fallback log kullanılıyor. Tanılama ZIP’i paylaşım ekranına bağlı kalmadan `İndirilenler/NovaDownloader/Diagnostics/` içine kalıcı olarak kaydediliyor; raporun bir bölümü hata verse bile minimal rapor ve logger durumu üretilebiliyor. Nova Player yerel URI’yi oynatmadan önce okunabilirliğini doğruluyor, geçmişte saklanan MIME türünü Media3’e zorlamayı bırakıp kapsayıcıyı Media3’ün doğrudan algılamasına izin veriyor. Oynatma hatasında Media3 hata kodu ekranda görünür ve tek dokunuşla kopyalanabilir. Medya çözümleme, yt-dlp fallback, dosya adı temizleme ve indirme motoru değiştirilmedi. Sürüm `0.10.0-alpha`, kod `51`, Checkpoint `049`.

> **Checkpoint 048 — oynatıcı ve yeniden adlandırma düzeltmesi:** Tamamlanan dosyayı “Nova ile oynat” seçildiğinde oynatıcı artık gerçek URI/MIME/başlığı doğrudan alır; Media3 kurulum ve oynatma hataları Nova sürecini kapatmak yerine uygulama içinde güvenli hata ekranına düşer. Yeniden adlandırma penceresinde native AlertDialog düğme çubuğu kaldırıldı; görünür `İptal` ve `Uygula` düğmeleri doğrudan pencere içine alındı ve klavyedeki Bitti eylemi de uygular. 047 dijital evcil hayvan hareketleri, 046 temiz dosya adı, çözümleme/fallback zinciri ve dağıtım yapısı korunur. Sürüm `0.10.0-alpha`, kod `50`, Checkpoint `048`.

> **Checkpoint 047 — dijital evcil hayvan hareketleri:** Bağımsız sürümde dijital evcil hayvanın dokunma davranışı yeniden düzenlendi. Tek dokunma Nova ana penceresini açar; parmak Android dokunma eşiğini aşacak kadar hareket ederse menü zamanlayıcısı iptal edilip taşıma başlar; hareketsiz uzun basma kısa titreşimle evcil hayvan menüsünü açar; çift dokunma da menü için alternatif kısayoldur. 046’daki temiz varsayılan dosya adı, 045’teki sabit İndir düğmesi, 044’teki doğru dosya konumu, Play AAB + bağımsız imzalı APK ve anonim medya fallback zinciri korunur. Sürüm `0.10.0-alpha`, kod `49`, Checkpoint `047`.

> **Checkpoint 046 — temiz varsayılan dosya adı:** Link çözümleme sonucunun gerçek başlığı artık indirme ekranında varsayılan dosya adına dönüştürülürken sosyal platformların eklediği `49K views · 1.6K reactions _` benzeri sayaç/ayraç gürültüsü temizlenir. Bu katman yalnız kullanıcıya önerilen dosya adını değiştirir; URL çözümleme, yt-dlp extractor/fallback, format seçimi ve indirme motoruna dokunmaz. Kullanıcı dosya adını yine elle değiştirebilir. 045’teki sabit İndir düğmesi, 044’teki doğru dosya konumu, 043’teki tamamlanma ekranı, temiz sürüm çıktı adları, Play AAB + bağımsız imzalı APK ve anonim medya fallback zinciri korunur. Sürüm `0.10.0-alpha`, kod `48`, Checkpoint `046`.

> **Checkpoint 045 — sabit İndir eylemi:** Link çözümlemeden sonra **İndir** düğmesi artık seçeneklerin altına gömülmez. Seçenekler bağımsız kaydırılır; İndir düğmesi, zamanlama ve İptal eylemleri ekranın altındaki sabit eylem alanında her zaman görünür kalır. Pencere açıldığında seçenek listesi en üste konumlanır. 044’teki doğru dosya konumu, 043’teki tamamlanma ekranı, temiz sürüm adlandırması, Play AAB + bağımsız imzalı APK ve anonim medya fallback zinciri korunur. Sürüm `0.10.0-alpha`, kod `47`, Checkpoint `045`.

> **Checkpoint 044 — doğru dosya konumunu açma:** Tamamlanan dosyada **Dosyanın konumunu aç** artık genel İndirilenler ekranına düşmek yerine gerçek hedef klasörü açar. Özel SAF hedeflerinde seçilen klasör URI’si, otomatik indirmelerde ise MediaStore `RELATIVE_PATH` (`Downloads/NovaDownloader/`) kullanılır. Dosya yöneticisi doğrudan klasör görüntülemeyi desteklemiyorsa klasör seçici aynı hedef klasörde başlatılır. 043’teki görünür tamamlanma düğmeleri, temiz sürüm adlandırması, Play AAB + bağımsız imzalı APK ve anonim medya fallback zinciri korunur. Sürüm `0.10.0-alpha`, kod `46`, Checkpoint `044`.

# Nova Video İndir

> **Checkpoint 042 — öz sürüm adlandırması:** Nihai dağıtım dosyaları checkpoint/build iç adlarını taşımaz. `versionName` içindeki temel sürüm otomatik alınır (`0.10.0-alpha` → `0.10.0`). Google Play AAB'leri `Nova İndir 0.10.0 Google Play`, bağımsız imzalı APK'lar `Nova İndir 0.10.0 Bağımsız` klasörüne çıkar; dosyalar yalnız `Nova İndir 0.10.0 Lite/Pro` adını taşır. Sürüm `0.10.0-alpha`, kod `44`, Checkpoint `042`.

> **Checkpoint 041 — Oturumsuz otomatik medya çözümleme:** Herkese açık videolarda Nova önce kayıtlı oturum kullanmadan anonim yt-dlp profillerini otomatik dener. YouTube için public-player istemci fallback'leri, diğer platformlarda standart mobil/masaüstü tarayıcı profilleri kullanılır. Kullanıcının zaten kayıtlı bir oturumu varsa ancak anonim denemelerden sonra sessiz son fallback olur. Private/üyelik/yaş/premium gibi gerçek erişim kapıları anonim yöntemlerle zorlanmaz. 040'taki **Hemen başlat** onarımı, Play AAB + imzalı bağımsız APK, signing ve temiz çıktı klasörleri korunur. Sürüm `0.10.0-alpha`, kod `43`, Checkpoint `041`.

> **Checkpoint 039 — temiz dağıtım + kalıcı release imzası:** Google Play ve bağımsız kanal aynı kaynak tabanında paralel kalır. Tek komutla Play Lite/Pro **AAB** ve bağımsız Lite/Pro **imzalı Universal APK** üretilir. Release APK'larda ABI split kapalıdır; bu sayede aynı Gradle çağrısında Play AAB ile çakışmaz. Resmî teslim klasörleri ve dosyaları yeniden temiz Nova adlarıyla üretilir. Signing bilgileri kaynak dışında `%USERPROFILE%\.nova-indir\release.properties` dosyasından okunabilir; `SETUP_RELEASE_SIGNING.cmd` bir kez çalıştırılarak kalıcı anahtar hazırlanır. Sürüm `0.10.0-alpha`, kod `41`, Checkpoint `039`.

> **Checkpoint 038 — Play + Bağımsız yayın hazırlığı:** Tek kaynak kodu `play/independent × lite/pro` matrisiyle yürütür. Google Play varyantlarından APK/self-update/anonim Play teslimatı ve overlay pet servisi derleme seviyesinde ayrılmıştır; Play release, signing + herkese açık HTTPS gizlilik URL'si olmadan başlamaz. Play'e özel privacy/Data Safety/FGS/checklist belgeleri ve 16 KB teknik yayın kapısı eklenmiştir. Bağımsız varyant APK araçlarını, imzalı self-update'i ve pet overlay'i ayrı source-set/manifest/dependency katmanında taşır. Sürüm `0.10.0-alpha`, kod `40`, Checkpoint `038`.

> **Checkpoint 037 — indirme başlatma onarımı:** `DownloadRepository.startStored()` hatasının `DownloadQueueCoordinator` tarafından tekrar `PENDING` ile ezilmesi kaldırıldı; gerçek servis başlatma hatası `FAILED` olarak korunur ve yerel loga yazılır.

> **Checkpoint 036:** Lite/Pro release birleştirilmiş manifestleri artık AAB görevi içinde otomatik denetlenir. Nova Play için gereksiz/yüksek riskli izinler engellenir; yalnız iki gerekli activity dışa açıktır; `dataSync` ve `specialUse` foreground service türleri, güvenli ağ/backup ayarları ve Android 8-9 depolama sınırı doğrulanır. Web adresi kaynakta kalıcıdır. Sürüm `0.10.0-alpha`, kod `38`, Checkpoint `036`.

> **Checkpoint 035:** Google Play Lite/Pro paketinde youtubedl-android Python/FFmpeg ZIP yüklerinin çalışma zamanı uyumluluğu korundu. `useLegacyPackaging = true` ile upstream `nativeLibraryDir` erişimi güvenceye alındı; 16 KB denetimi bilinen `.zip.so` arşivlerini ZIP imzasıyla doğruluyor. Sürüm `0.10.0-alpha`, kod `37`, Checkpoint `035`.

> **Checkpoint 030:** Eski ana ekranın lila arka planı `#EEE6FF` olarak bütün cihaz modlarında sabitlendi. Sistem koyu tema/force-dark artık bu rengi değiştiremez. Glossy butonlar korunur. Ana menü tam kimliği: `0.9.9-alpha`, kod `32`, Checkpoint `030`.

>
> **Checkpoint 026:** Ana menü başlığında tam derleme kimliği (`versionName`, `versionCode`, checkpoint, flavor ve build type) her APK varyantında sürekli görünür.
>
> **Checkpoint 025:** Gerçek APK çeviri ekranı eklendi. Seçilen tek APK'nın derlenmiş `strings.xml` karşılığı olan `resources.arsc` içindeki basit metin kaynakları hedef dile çevrilir, yeni dil kaynağı APK'ya yazılır, paket yeniden oluşturulur, yerel Nova anahtarıyla imzalanır ve imza doğrulanır.
> **024.2 derleme düzeltmesi:** Gerçek Kotlin derlemesinde çıkan eksik import, `HttpURLConnection` setter çağrısı ve nullable WorkManager `LiveData` türleri düzeltildi.
> **024.1 derleme düzeltmesi:** Kotlin 2.3.21 için eski `android.kotlinOptions` bloğu kaldırılarak tür güvenli `kotlin.compilerOptions` DSL kullanıldı.

Reklamsız, izleyicisiz ve medya çözümleme/indirme işlemlerini cihaz üzerinde yapan Android uygulaması.

## Sürüm

`0.53` — Android 8.0+ (`minSdk 26`), `targetSdk 36`, JDK 17.

## Checkpoint 042 hızlı derleme

İlk kez release derlemeden önce yalnız bir kez:

```powershell
.\SETUP_RELEASE_SIGNING.cmd
```

Ardından Google Play AAB + bağımsız imzalı APK çıktılarının tamamı:

```powershell
.\BUILD_PLAY_AAB_AND_INDEPENDENT_APK.cmd
```

Resmî çıktı düzeni:

```text
Nova Video İndir 0.53 Google Play\
  Nova Video İndir 0.53 Google Play Lite.aab
  Nova Video İndir 0.53 Google Play Pro.aab

Nova Video İndir 0.53 Bağımsız\
  Nova Video İndir 0.53 Bağımsız Lite.apk
  Nova Video İndir 0.53 Bağımsız Pro.apk
```

`app\build\outputs` Gradle'ın iç çalışma alanıdır; dağıtım için yukarıdaki temiz Nova klasörleri esas alınır.

## Checkpoint 030 ile tamamlananlar

### Eski lila arka plan ve glossy butonlar

- Eski ana ekrandaki ana arka plan `#EEE6FF`, yüzey `#F9F5FF`, kenarlık `#D7C7F2` olarak kullanılır.
- `values-night` renk ve tema geçersiz kılmaları kaldırıldı; cihaz koyu modda olsa da eski lila değişmez.
- Android otomatik force-dark kapatıldı.
- `UiPalette` bütün ekranları aynı kaynak paletine bağlar; beyaz veya gri varsayılan arka plana dönüş engellenir.
- Glossy lila buton stili, parlak üst yansıma, dikey geçiş, alt gölge, yuvarlatılmış köşe ve basılı/devre dışı durumlarıyla korunur.
- Ana menü tam derleme kimliği `v0.9.9-alpha · kod 32 · Checkpoint 030 · flavor/buildType` biçiminde görünür.
- Full ve Lite derleme betikleri temiz klasör ve APK dosya adları üretir. `BUILD_ALL_DEBUG.cmd` iki sürümü tek seferde hazırlar.

## Checkpoint 027 ile düzeltilenler

- ML Kit 17.0.3 ile uyumlu `com.google.mlkit.common.model.DownloadConditions` importu kullanılıyor.
- Wi-Fi koşullu model indirme oluşturucusu tekrar derlenebilir durumda.
- `ScrollView` kök görünümü geçerli `FrameLayout.LayoutParams` ile ekleniyor.
- ARSCLib yeniden oluşturma çağrısının ardından çıktı dosyası ayrı ve açık biçimde doğrulanıyor.
- Ana menü her varyantta `v0.9.8-alpha · kod 29 · Checkpoint 027 · flavor/buildType` bilgisini gösteriyor.

## Checkpoint 026 ile tamamlananlar

- Ana menüde daima görünür tam sürüm satırı eklendi.
- Sürüm adı, sürüm kodu ve checkpoint değeri `app/build.gradle.kts` içinde tek merkezde tutuluyor.
- Full/lite ve debug/release varyantları kendi gerçek `BuildConfig` değerlerini gösteriyor.

## Checkpoint 025 ile tamamlananlar

### Gerçek APK çevirici

- **APK İndirme Merkezi** içine ayrı **Gerçek APK Çevirici** bölümü eklendi.
- Android belge seçicisiyle tek, kurulabilir `.apk` dosyası alınır; özgün dosya değiştirilmez.
- Yayın APK'larında düz XML yerine derlenmiş kaynak tablosu bulunduğu için `resources.arsc` açılır ve basit `string` girdileri okunur.
- Kaynak ve hedef dil kullanıcı tarafından seçilir. İngilizce, Türkçe, Almanca, İspanyolca, Fransızca, İtalyanca, Portekizce, Rusça, Arapça, Japonca, Korece ve Çince seçenekleri bulunur.
- `%1$s`, `%d`, HTML/XML etiketleri, kaçış dizileri, URL'ler ve yer tutucular çeviri sırasında korunur.
- Google ML Kit çeviri modeli ilk kullanımda indirilir; model hazır olduğunda metin çevirisi cihaz üzerinde yürütülür. İsteğe bağlı yalnız Wi-Fi modeli indirme seçeneği vardır.
- Hedef dil için yeni Android kaynak niteleyicisi oluşturulur; örneğin Türkçe `-tr`, basitleştirilmiş Çince `-zh-rCN`.
- ARSCLib ile kaynak tablosu APK'ya geri yazılır ve paket yeniden oluşturulur.
- Çıktı AndroidKeyStore'da oluşturulan Nova yerel RSA anahtarıyla APK Signature Scheme v1/v2/v3 kullanılarak imzalanır; ardından `ApkVerifier` ile doğrulanır.
- Çevrilmiş APK `Downloads/NovaDownloader/APK/Translated/` klasörüne kaydedilir ve uygulama içinden açılabilir.
- WorkManager ön plan işi; ilerleme, iptal, başarı ve hata bildirimi sağlar.

### Bilinen sınırlar

- Bu sürüm yalnız tek `.apk` dosyasını kabul eder; `.apks`, `.xapk`, `.apkm` ve split paketler henüz çevrilmez.
- Yalnız derlenmiş basit `<string>` kaynakları çevrilir. `plurals`, `string-array`, biçimlendirilmiş karmaşık metinler, kod içine gömülü metinler, resimler ve web içerikleri değişmeden kalabilir.
- Yeniden oluşturulan APK özgün geliştirici anahtarıyla değil Nova'nın cihazdaki yerel anahtarıyla imzalanır. Bu nedenle özgün kurulu uygulamanın üzerine güncelleme olarak kurulamaz.
- İmza veya bütünlük denetimi yapan uygulamalar değiştirilmiş paketi reddedebilir. Nova bu denetimleri aşmaz.
- Makine çevirisi bağlamı sınırlı kısa kaynaklarda hatalı veya doğal olmayan sonuç üretebilir; sonuç gerçek cihazda sınanmalıdır.

## Checkpoint 024 ile tamamlananlar

### Evozi’den bağımsız Play Store APK indirici

- Evozi bölümünün altına ayrı **Bağımsız Play Store İndirici** eklendi.
- Kullanıcıdan doğrudan APK adresi, Google hesabı, e-posta veya parola istenmez; Google Play bağlantısı ya da paket adı yeterlidir.
- Nova, yapılandırılabilir HTTPS anonim oturum dağıtıcısından geçici bir hesap oturumu alır ve Google Play teslimat API’sine doğrudan bağlanır.
- Uygulama ayrıntıları ve ücretsiz teklif denetlenir; ücretli uygulama, lisans, hesap veya bölge koruması aşılmaz.
- Cihaza uygun `base.apk`, split APK ve varsa OBB dosyaları indirilir.
- Tek dosyalı uygulama `.apk`, çok parçalı uygulama `base.apk` ve split dosyalarını içeren `.apks` paketi olarak kaydedilir.
- Google Play’in bildirdiği dosya boyutu, SHA-256 ve gerektiğinde SHA-1 değerleri indirme sonunda doğrulanır.
- İndirme WorkManager `dataSync` ön plan işi olarak sürer; ilerleme, iptal ve sonuç bildirimi bulunur.
- Çıktılar `Downloads/NovaDownloader/APK/PlayStore/` klasörüne kaydedilir.
- Varsayılan anonim oturum adresi derleme sırasında `NOVA_PLAY_DISPENSER_URL` ile değiştirilebilir.
- Bu özellik belgelenmemiş Google Play protokolüne ve anonim oturum hizmetinin kullanılabilirliğine bağlı olduğu için **deneysel** kabul edilir.

## Checkpoint 023 ile tamamlananlar

### Bağımsız APK indirici

- Evozi destekli Play Store bölümünün altına ayrı **Bağımsız APK İndirici** eklendi.
- Doğrudan HTTPS üzerinden APK, APKS, XAPK, APKM ve ZIP bağlantıları kabul edilir.
- WebView, Evozi veya başka bir dönüştürme sağlayıcısı kullanılmaz.
- İndirme başlamadan önce yönlendirme, sunucu adresi, dosya adı ve MIME türü denetlenir.
- Yerel/özel ağ adresleri ve güvensiz yönlendirmeler engellenir.
- Dosyalar `Downloads/NovaDownloader/APK/Direct/` klasörüne kaydedilir.
- Paylaşılan doğrudan paket bağlantıları otomatik olarak bağımsız indiriciye yönlendirilir.

## Checkpoint 022 ile tamamlananlar

### Play Store bağlantısından APK indirme

- Ana ekran gezinme düğmelerinin altına ayrı bir **APK İndir** sekmesi eklendi.
- Google Play uygulama bağlantısı veya doğrudan paket adı kabul edilir ve standart Play Store bağlantısına dönüştürülür.
- Paylaş menüsünden Nova'ya gönderilen Google Play bağlantıları doğrudan APK indirici ekranını açar.
- Haricî Evozi APK sağlayıcısı güvenlik kısıtlı WebView içinde açılır; form otomatik doldurulup gönderilmeye çalışılır, sayfa değişirse görünür form elle kullanılabilir.
- Sağlayıcının ürettiği APK, APKS, XAPK ve ZIP bağlantıları Android DownloadManager ile `Downloads/NovaDownloader/APK` klasörüne kaydedilir.
- WebView yalnız HTTPS'e izin verir; TLS hataları reddedilir, yerel dosya erişimi ve JavaScript köprüsü kapalıdır.
- Ücretli, DRM korumalı, hesap yetkisi veya bölge kısıtı gerektiren içeriklerin koruması aşılmaz.
- Tüm yeni metinler İngilizce, Türkçe ve Almanca kaynaklara eklendi.

## Checkpoint 021 ile tamamlananlar

### Arka plan çözümleme ve kesintisiz indirme

- Link çözümleme işlemi `dataSync` ön plan servisinde yürütülür; Nova ana penceresi aşağı alındığında çözümleme devam eder.
- Çözümleme görevi uygulamanın iç depolamasında atomik olarak saklanır. Arayüz yeniden oluşturulsa bile hazır sonuç veya hata kaybolmaz.
- İstenirse çözümleme bitince varsayılan kalite, biçim, dosya adı ve hedef klasör ile indirme otomatik başlar.
- Otomatik başlatma kapalıysa sistem bildirimi ve evcil hayvan **Video hazır** durumunu gösterir; Nova açıldığında normal indirme seçenekleri sunulur.
- İndirme başladıktan sonra doğrudan HTTP ve yt-dlp/FFmpeg ön plan servisleri ekran kapalıyken veya Nova arka plandayken çalışmayı sürdürür.

### Tamamlanma uyarıları

- Sistem bildirimi, Nova içi tamamlanma kutucuğu ve evcil hayvan uyarısı birbirinden bağımsız açılıp kapatılabilir.
- Nova içi kutucuktan dosya dahili oynatıcıda veya kayıt konumunda açılabilir.
- Uygulama arka plandaysa kutucuk olayı saklanır ve Nova yeniden ekrana geldiğinde gösterilir.

### Evcil hayvan uygulama denetimleri

- Evcil hayvan menüsü Nova Downloader'ı ekrana getirebilir.
- Aynı menü Nova Downloader görevini kapatmadan arka plana alabilir.
- Evcil hayvan çözümleme, video hazır, indirme yüzdesi ve indirme tamamlandı durumlarını gösterebilir.

## Checkpoint 020 ile tamamlananlar

### Tek dokunuşla oynatma, uzun basışla eylem menüsü

- Ana indirme geçmişinde tamamlanmış video veya ses dosyasına normal dokunulduğunda Nova'nın dahili oynatıcısı doğrudan açılır.
- Galeride tamamlanmış video veya ses dosyasına normal dokunulduğunda Nova'nın dahili oynatıcısı doğrudan açılır.
- Ana indirme geçmişinde veya Galeride dosyaya uzun basıldığında eylem menüsü açılır.
- Eylem menüsündeki **Yeniden adlandır**, **Haricî uygulamada aç**, **Dosya konumunu aç** ve **Paylaş** seçenekleri korunur.
- Henüz tamamlanmamış indirmelerde normal dokunma, duraklatma/devam ettirme/iptal gibi indirme eylemlerini açar.

## Checkpoint 017–018 ile tamamlananlar

### Dahili video ve ses oynatıcı

- Media3/ExoPlayer tabanlı uygulama içi oynatma ekranı eklendi.
- Video ve ses dosyaları Nova içinde oynatılabilir; paylaşma, haricî oynatıcıda açma ve dosya konumunu açma eylemleri bulunur.
- Oynatıcı ekran kapanırken kaynağı serbest bırakır ve arka planda gereksiz medya belleği tutmaz.

### Galeri

- Tamamlanan indirmeler küçük resimli galeri görünümünde listelenir.
- Arama; video/ses/dosya filtresi; tarihe, ada ve boyuta göre sıralama bulunur.
- Video küçük resimleri cihaz üzerinde üretilir ve sınırlı bellek önbelleğinde tutulur.
- Galeriden Nova oynatıcısı, haricî oynatıcı, paylaşma ve klasör konumu eylemleri açılabilir.

### Hız sınırı ve paralel indirme

- Ayarlardan sınırsız veya KB/sn cinsinden indirme hız sınırı seçilebilir.
- Doğrudan HTTP motorunda yerel bant genişliği sınırlayıcı, yt-dlp motorunda `--limit-rate` kullanılır.
- Aynı anda çalışacak indirme sayısı ayarlanabilir; ağır yt-dlp/FFmpeg işlemleri mevcut güvenli tek-iş sınırını korur.

### Zamanlama ve sürüklenebilir kuyruk

- İndirme onay ekranından veya kuyruk ekranından tarih/saat seçilerek görev planlanabilir.
- Kuyruk öğeleri uzun basıp sürükleyerek yeniden sıralanabilir.
- Sıra kalıcıdır; uygulama kapanıp açıldığında korunur.
- Planlanan görev zamanı geldiğinde Android WorkManager kuyruğu uyandırır; sistem pil/Doze kuralları nedeniyle başlama zamanı yaklaşık olabilir.

### Kullanıcı dostu hesap yönetimi

- YouTube, Instagram, Facebook, TikTok, X/Twitter ve genel web için birden fazla adlandırılmış hesap profili desteklenir.
- Uygulama içi güvenli giriş sayfası, `cookies.txt` içe aktarma, oturumu yenileme, etkin profil seçme, yeniden adlandırma, geçici devre dışı bırakma, oturum silme ve profil silme eklendi.
- Parolalar Nova tarafından kaydedilmez; kullanıcı onayıyla alınan oturum çerezleri Android Keystore destekli şifreli kasada ve profil bazında tutulur.
- İndirme motoru kaynak URL’ye göre uygun etkin hesabı otomatik seçer.

## Checkpoint 012–016 ile tamamlanan altyapı


### Çoklu dil ve merkezi metin kataloğu

- Kullanıcıya gösterilen metinler Android kaynaklarına taşındı.
- Varsayılan İngilizce, Türkçe ve Almanca çeviriler aynı anahtar kümesini kullanır.
- Uygulama içinden **Sistem dili / English / Türkçe / Deutsch** seçilebilir.
- Android 13+ uygulama dili sistemi ve Android 8–12 için yerel bağlam desteği bulunur.
- Bildirimler, servis hataları, ayarlar, kurulum, tarayıcı, güncelleme ve motor kurtarma mesajları da yerelleştirilmiştir.

Kaynaklar:

```text
app/src/main/res/values/strings.xml
app/src/main/res/values-tr/strings.xml
app/src/main/res/values-de/strings.xml
```

### Yerel hata günlüğü ve tanılama raporu

- Günlükler yalnız uygulamanın özel alanında tutulur.
- Her günlük en fazla 512 KB, toplam en fazla üç dönen dosyadır.
- Çerez, Authorization, PO Token, Visitor Data, sorgu sırları ve tam URL’ler yazılmadan önce maskelenir.
- Yakalanmamış uygulama hataları yerel günlüğe eklenir.
- Ayarlar içinden günlükler temizlenebilir.
- Kullanıcı isterse ZIP tanılama raporu oluşturup paylaşabilir.
- Raporda uygulama/cihaz bilgileri, bellek durumu, motor sürümü ve indirme durumlarının sınırlı özeti bulunur; medya başlıkları ve tam kaynak URL’leri eklenmez.

### Güvenli uygulama içi güncelleme denetimi

Güncelleme sistemi varsayılan olarak kapalı yapılandırmadadır. Yayıncı HTTPS bildirim adresini ve RSA açık anahtarını derleme sırasında sağlamalıdır.

Denetim sırası:

1. Yalnız HTTPS ve aynı alan adına yönlendirme
2. RSA-SHA256 ile imzalı güncelleme bildirimi
3. Full/Lite varyant eşleşmesi
4. Sürüm kodu, sürüm adı ve minimum Android sürümü
5. APK SHA-256 değeri
6. Paket adı
7. Kurulu Nova Downloader ile imzalayan sertifika eşleşmesi
8. Kurulum ekranı açılmadan hemen önce ikinci APK doğrulaması
9. Son kullanıcı onayı için Android paket yükleyicisi

İmzalı bildirim üretme aracı:

```text
tools/sign_update_manifest.py
```

Ayrıntılı yayıncı kurulumu: `UPDATE_CONFIGURATION.md`.

### yt-dlp motoru sürüm geri alma

- Motor güncellenmeden önce etkin dosyanın SHA-256 tanımlı özel alan yedeği alınır.
- Başarılı güncelleme sonrasında bilinen iyi sürüm saklanır.
- Güncellenen motor temel sağlık denetiminden geçmezse önceki dosya atomik olarak geri yüklenir.
- Tekrarlanan motor düzeyi hatalarda otomatik geri alma denenir.
- Ayarlarda **önceki sürüme dön** ve **uygulamayla gelen motoru geri yükle** seçenekleri bulunur.
- En fazla üç özel motor görüntüsü saklanır; kullanıcı indirmeleri ve medya dosyaları geri alma işleminden etkilenmez.

### APK boyutu ve RAM optimizasyonu

İki motor varyantı bulunur:

- **Full:** Python/yt-dlp/QuickJS + FFmpeg; ayrı ses-görüntü birleştirme, dönüştürme ve yalnız ses çıktıları.
- **Lite:** Python/yt-dlp/QuickJS; FFmpeg paketi bulunmaz, bu nedenle APK daha küçüktür ve FFmpeg gerektiren işlemler açık bir uyarıyla reddedilir.

Ek önlemler:

- `arm64-v8a` ve `armeabi-v7a` ABI APK ayrımı ile isteğe bağlı universal APK
- AAB için ABI, yoğunluk ve dil ayrımı
- Release derlemesinde R8 kod küçültme ve kaynak küçültme
- Yalnız İngilizce, Türkçe ve Almanca kaynaklarının paketlenmesi
- Jetifier kapalı, AndroidX etkin
- Python/yt-dlp/FFmpeg ana uygulamadan ayrı `:media` işleminde çalışır
- Aynı anda yalnız bir ağır yt-dlp indirmesi
- Bellek tasarrufu modunda tek HLS/DASH parçası; dengeli modda en fazla iki parça
- FFmpeg yalnız gerçekten gereken görevlerde başlatılır
- Medya işlemi boş kaldıktan sonra kapatılarak Python/FFmpeg belleği işletim sistemine geri verilir

## Önceki temel özellikler

- Bağlantı yapıştırma, Android Paylaş menüsü ve güvenli dahili Nova Browser
- Otomatik MP4/WebM/ses/HLS/DASH algılama
- YouTube, Instagram, Facebook ve yt-dlp’nin desteklediği platformlar
- Platforma özel şifreli `cookies.txt` profilleri
- QuickJS, EJS, isteğe bağlı PO Token/Visitor Data ve güvenilen yt-dlp eklentisi
- Kalite, format, video/yalnız ses, altyazı, kapak, açıklama, bölüm ve meta veri seçenekleri
- FFmpeg ile ayrı ses-görüntü birleştirme
- Doğru MP4 ve diğer medya uzantıları
- Duraklatma, HTTP Range ile kaldığı yerden devam, iptal ve yarım dosya temizleme
- Room tabanlı kalıcı kuyruk ve geçmiş
- Dosya adı/hedef klasör seçimi, dosyayı ve konumunu açma
- Arka plan bildirimleri ve özelleştirilebilir dijital evcil hayvan
- Lila açık tema ve koyu tema

## Güvenlik sınırları

- DRM, ücretli erişim, hesabın erişemediği içerik veya platform güvenlik mekanizmaları aşılmaz.
- Oturum çerezi yalnız kullanıcının kendi hesabıyla zaten erişebildiği içeriklerde kullanılabilir.
- Platformların sayfa yapıları değiştiğinde yt-dlp güncellemesi veya geri alma gerekebilir.
- Haricî Python eklentileri kod çalıştırabilir; yalnız güvenilen ve doğrulanmış paketler kullanılmalıdır.
- Nova Browser içindeki web siteleri kendi reklam ve takip kodlarını gösterebilir; Nova bunları eklemez.

## Tek komutla derleme

Windows’ta proje kökünde şu hazır betikler bulunur:

- `BUILD_FULL_DEBUG.cmd`: yalnız Full ARM v7a, ARM v8a ve Universal
- `BUILD_LITE_DEBUG.cmd`: yalnız Lite ARM v7a, ARM v8a ve Universal
- `BUILD_ALL_DEBUG.cmd`: Full ve Lite sürümlerinin altısını birlikte üretir

Betikler Android Studio JDK yolunu otomatik bulur ve çıktıları temiz adlandırılmış klasörlere kopyalar.

Terminalden:

```powershell
.\build-debug.ps1 -Target Full
.\build-debug.ps1 -Target Lite
.\build-debug.ps1 -Target All
```

`All` hedefinin temiz çıktı düzeni:

```text
Nova Downloader 032 v0.9.9 Alpha Lila Mavi Glossy
├── Nova Downloader 032 v0.9.9 Alpha Lila Mavi Glossy Full
│   ├── Nova Downloader 0.32 v0.9.9 Alpha Mavi Glossy Full Arm v7a.apk
│   ├── Nova Downloader 0.32 v0.9.9 Alpha Mavi Glossy Full Arm v8a.apk
│   └── Nova Downloader 0.32 v0.9.9 Alpha Mavi Glossy Full Universal.apk
└── Nova Downloader 032 v0.9.9 Alpha Lila Mavi Glossy Lite
    ├── Nova Downloader 0.32 v0.9.9 Alpha Mavi Glossy Lite Arm v7a.apk
    ├── Nova Downloader 0.32 v0.9.9 Alpha Mavi Glossy Lite Arm v8a.apk
    └── Nova Downloader 0.32 v0.9.9 Alpha Mavi Glossy Lite Universal.apk
```

## Derleme

ZIP’i örneğin `C:\Nova Downloader 032 v0.9.9 Alpha Lila Mavi Glossy Kaynak` içine çıkarın. Android Studio terminalinde:

```powershell
cd "C:\Nova Downloader 032 v0.9.9 Alpha Lila Mavi Glossy Kaynak"
.\gradlew.bat clean :app:assembleFullDebug :app:assembleLiteDebug --stacktrace
```

Beklenen debug APK yolları:

```text
app\build\outputs\apk\full\debug\app-full-arm64-v8a-debug.apk
app\build\outputs\apk\full\debug\app-full-armeabi-v7a-debug.apk
app\build\outputs\apk\full\debug\app-full-universal-debug.apk
app\build\outputs\apk\lite\debug\app-lite-arm64-v8a-debug.apk
app\build\outputs\apk\lite\debug\app-lite-armeabi-v7a-debug.apk
app\build\outputs\apk\lite\debug\app-lite-universal-debug.apk
```

Çoğu güncel telefon için `arm64-v8a` kullanılır. Tek APK ile iki ARM mimarisini desteklemek için daha büyük `universal` dosyası kullanılabilir.

### Release APK ve AAB

İmzalama değerlerini kullanıcı Gradle özelliklerinde veya ortam değişkenlerinde tanımlayın:

```text
NOVA_KEYSTORE=C:\secure\nova-release.jks
NOVA_KEY_ALIAS=nova
NOVA_STORE_PASSWORD=...
NOVA_KEY_PASSWORD=...
```

Release komutları:

```powershell
.\gradlew.bat clean :app:assembleFullRelease :app:assembleLiteRelease --stacktrace
.\gradlew.bat :app:bundleFullRelease :app:bundleLiteRelease --stacktrace
```

## Güvenli güncelleme yapılandırması

```text
NOVA_UPDATE_MANIFEST_URL_FULL=https://updates.example.org/nova/full/update.json
NOVA_UPDATE_MANIFEST_URL_LITE=https://updates.example.org/nova/lite/update.json
NOVA_UPDATE_PUBLIC_KEY_B64=MIIBIjANBgkqh...
```

Eski tek adresli yapılandırma için `NOVA_UPDATE_MANIFEST_URL` geri dönüş değeri olarak desteklenir. Güncelleme APK’sında iki mimariyi kapsayan universal release dosyasının kullanılması dağıtımı kolaylaştırır.

## Bağımsız Play Store indirici yapılandırması

Varsayılan anonim oturum dağıtıcısını değiştirmek için Gradle özelliği veya ortam değişkeni kullanılabilir:

```text
NOVA_PLAY_DISPENSER_URL=https://example.org/api/auth
```

Adres HTTPS olmalı ve Aurora uyumlu biçimde cihaz özelliklerini JSON POST gövdesi olarak kabul edip `email` ile `auth` (veya geriye dönük `authToken`) alanlarını döndürmelidir. Kullanıcı Google hesabı bilgileri Nova’da saklanmaz.

## Kaynak testleri

```bash
python3 tools/check_project.py

kotlinc \
  app/src/main/java/com/nova/downloader/core/DirectApkLinkParser.kt \
  app/src/main/java/com/nova/downloader/core/FacebookUrlExtractor.kt \
  app/src/main/java/com/nova/downloader/core/FileNameResolver.kt \
  app/src/main/java/com/nova/downloader/core/HtmlMediaExtractor.kt \
  app/src/main/java/com/nova/downloader/core/HttpRangePolicy.kt \
  app/src/main/java/com/nova/downloader/core/MediaSignatureDetector.kt \
  app/src/main/java/com/nova/downloader/core/MediaTypePolicy.kt \
  app/src/main/java/com/nova/downloader/core/PlayStoreLinkParser.kt \
  app/src/main/java/com/nova/downloader/core/SitePagePolicy.kt \
  app/src/main/java/com/nova/downloader/data/DuplicatePolicy.kt \
  app/src/main/java/com/nova/downloader/data/PlatformPolicy.kt \
  app/src/main/java/com/nova/downloader/data/RecoveryPolicy.kt \
  app/src/main/java/com/nova/downloader/translation/ApkTranslationCore.kt \
  tools/SourceSmokeTest.kt -include-runtime -d nova-smoke.jar
java -jar nova-smoke.jar
```

Gerçek Android/Gradle derlemesi, JUnit ve cihaz testleri internet bağlantılı Android Studio ortamında ayrıca çalıştırılmalıdır.

## Belgeler

- `PRIVACY.md`
- `SECURITY.md`
- `UPDATE_CONFIGURATION.md`
- `TEST_REPORT.md`
- `THIRD_PARTY_NOTICES.md`

## Lisans

Kaynak paket, kullanılan GPL-3.0 bileşenlerle uyumluluk için GPL-3.0 altında sunulur.

---

# Nova İndir 034 — Google Play Lite / Pro

Bu checkpoint APK split üretimini App Bundle üretiminden ayırır.

Test APK'ları:

```powershell
.\gradlew.bat clean :app:assembleNovaPlayDebug --stacktrace --console=plain
```

Google Play AAB dosyaları:

```powershell
.\gradlew.bat clean :app:bundleNovaPlayRelease --stacktrace --console=plain
```

16 KB yerel kütüphane denetimi:

```powershell
.\AUDIT_16KB.ps1
```

Ayrıntılar için `GOOGLE_PLAY_034_RAPOR.md` dosyasına bakın.
