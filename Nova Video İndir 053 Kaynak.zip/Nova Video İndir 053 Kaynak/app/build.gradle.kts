import java.io.File
import java.net.URI
import java.util.Properties
import javax.xml.parsers.DocumentBuilderFactory
import org.jetbrains.kotlin.gradle.dsl.JvmTarget
import org.w3c.dom.Element

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.kapt")
}

// Release identity: update these three values together for every checkpoint.
val novaVersionName = "0.53"
val novaVersionCode = 55
val novaCheckpoint = "053"
val novaArtifactVersion = novaVersionName.substringBefore("-")
val novaArtifactBaseName = "Nova Video İndir $novaArtifactVersion"

// Checkpoint 050: release secrets live outside the source tree by default.
// Precedence: Gradle property > environment variable > %USERPROFILE%\.nova-indir\release.properties.
val novaReleasePropertiesFile = File(System.getProperty("user.home"), ".nova-indir/release.properties")
val novaReleaseProperties = Properties().apply {
    if (novaReleasePropertiesFile.isFile) {
        novaReleasePropertiesFile.inputStream().use { load(it) }
    }
}
fun novaReleaseValue(name: String): String? =
    providers.gradleProperty(name).orNull
        ?: System.getenv(name)
        ?: novaReleaseProperties.getProperty(name)

val novaKeystorePath = novaReleaseValue("NOVA_KEYSTORE")
val novaKeyAlias = novaReleaseValue("NOVA_KEY_ALIAS")
val novaStorePassword = novaReleaseValue("NOVA_STORE_PASSWORD")
val novaKeyPassword = novaReleaseValue("NOVA_KEY_PASSWORD")
val releaseSigningConfigured = listOf(novaKeystorePath, novaKeyAlias, novaStorePassword, novaKeyPassword).all { !it.isNullOrBlank() }

val novaUpdateManifestUrl = providers.gradleProperty("NOVA_UPDATE_MANIFEST_URL").orNull ?: System.getenv("NOVA_UPDATE_MANIFEST_URL") ?: ""
val novaUpdateManifestUrlFull = providers.gradleProperty("NOVA_UPDATE_MANIFEST_URL_FULL").orNull ?: System.getenv("NOVA_UPDATE_MANIFEST_URL_FULL") ?: novaUpdateManifestUrl
val novaUpdateManifestUrlLite = providers.gradleProperty("NOVA_UPDATE_MANIFEST_URL_LITE").orNull ?: System.getenv("NOVA_UPDATE_MANIFEST_URL_LITE") ?: novaUpdateManifestUrl
val novaUpdatePublicKey = providers.gradleProperty("NOVA_UPDATE_PUBLIC_KEY_B64").orNull ?: System.getenv("NOVA_UPDATE_PUBLIC_KEY_B64") ?: ""
val novaWebsiteUrl = "https://novadwnldr-wdkn6daq.manus.space/"
val novaPlayPrivacyUrl = novaReleaseValue("NOVA_PLAY_PRIVACY_URL") ?: ""
val novaIndependentPrivacyUrl = novaReleaseValue("NOVA_INDEPENDENT_PRIVACY_URL") ?: novaPlayPrivacyUrl
val novaPlayDispenserUrl = providers.gradleProperty("NOVA_PLAY_DISPENSER_URL").orNull
    ?: System.getenv("NOVA_PLAY_DISPENSER_URL")
    ?: "https://auroraoss.com/api/auth"
fun buildConfigString(value: String): String = "\"" + value.replace("\\", "\\\\").replace("\"", "\\\"") + "\""

// APK builds need ABI splits; App Bundle builds must not use APK split outputs.
// The custom APK task enables this automatically. It can also be forced with
// -PNOVA_APK_SPLITS=true for direct assemblePlayLiteDebug/assemblePlayProDebug or independent variants.
val requestedGradleTasks = gradle.startParameter.taskNames.map { it.lowercase() }
val novaApkSplitsEnabled = providers.gradleProperty("NOVA_APK_SPLITS").orNull
    ?.toBooleanStrictOrNull()
    ?: requestedGradleTasks.any { task ->
        task.contains("assemblenovaplaydebug") ||
            task.contains("assemblenovaindependentdebug") ||
            task.contains("assembleplaylitedebug") ||
            task.contains("assembleplayprodebug") ||
            task.contains("assembleindependentlitedebug") ||
            task.contains("assembleindependentprodebug")
    }

android {
    namespace = "com.nova.downloader"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.nova.indir"
        minSdk = 26
        targetSdk = 36
        versionCode = novaVersionCode
        versionName = novaVersionName
        buildConfigField("String", "NOVA_CHECKPOINT", buildConfigString(novaCheckpoint))
        buildConfigField("String", "NOVA_UPDATE_PUBLIC_KEY_B64", buildConfigString(""))
        buildConfigField("String", "NOVA_UPDATE_MANIFEST_URL_FULL", buildConfigString(""))
        buildConfigField("String", "NOVA_UPDATE_MANIFEST_URL_LITE", buildConfigString(""))
        buildConfigField("String", "NOVA_PLAY_DISPENSER_URL", buildConfigString(""))
        buildConfigField("String", "NOVA_WEBSITE_URL", buildConfigString(novaWebsiteUrl))
        buildConfigField("String", "NOVA_PRIVACY_POLICY_URL", buildConfigString(""))
        ndk { abiFilters += setOf("arm64-v8a", "armeabi-v7a") }

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"

    }

    buildFeatures { buildConfig = true }

    // Checkpoint 050: Play-hardened + independent full distribution from one codebase.
    // Variant matrix: playLite, playPro, independentLite, independentPro.
    flavorDimensions += listOf("distribution", "edition")
    productFlavors {
        create("play") {
            dimension = "distribution"
            buildConfigField("boolean", "PLAY_STORE_BUILD", "true")
            buildConfigField("boolean", "HAS_APK_TOOLS", "false")
            buildConfigField("boolean", "HAS_SELF_UPDATE", "false")
            buildConfigField("boolean", "HAS_PET_OVERLAY", "false")
            buildConfigField("String", "NOVA_PRIVACY_POLICY_URL", buildConfigString(novaPlayPrivacyUrl))
        }
        create("independent") {
            dimension = "distribution"
            applicationIdSuffix = ".independent"
            buildConfigField("boolean", "PLAY_STORE_BUILD", "false")
            // Infrastructure flag: independent-only APK/update UI can be restored without touching Play variants.
            buildConfigField("boolean", "HAS_APK_TOOLS", "true")
            buildConfigField("boolean", "HAS_SELF_UPDATE", "true")
            buildConfigField("boolean", "HAS_PET_OVERLAY", "true")
            buildConfigField("String", "NOVA_PRIVACY_POLICY_URL", buildConfigString(novaIndependentPrivacyUrl))
            buildConfigField("String", "NOVA_UPDATE_PUBLIC_KEY_B64", buildConfigString(novaUpdatePublicKey))
            buildConfigField("String", "NOVA_UPDATE_MANIFEST_URL_FULL", buildConfigString(novaUpdateManifestUrlFull))
            buildConfigField("String", "NOVA_UPDATE_MANIFEST_URL_LITE", buildConfigString(novaUpdateManifestUrlLite))
            buildConfigField("String", "NOVA_PLAY_DISPENSER_URL", buildConfigString(novaPlayDispenserUrl))
        }
        create("pro") {
            dimension = "edition"
            applicationIdSuffix = ".pro"
            buildConfigField("boolean", "HAS_FFMPEG", "true")
        }
        create("lite") {
            dimension = "edition"
            applicationIdSuffix = ".lite"
            buildConfigField("boolean", "HAS_FFMPEG", "false")
        }
    }

    signingConfigs {
        if (releaseSigningConfigured) {
            create("novaRelease") {
                storeFile = file(novaKeystorePath!!)
                storePassword = novaStorePassword
                keyAlias = novaKeyAlias
                keyPassword = novaKeyPassword
                enableV1Signing = true
                enableV2Signing = true
                enableV3Signing = true
                enableV4Signing = true
            }
        }
    }

    buildTypes {
        debug {
            isMinifyEnabled = false
        }
        release {
            signingConfig = signingConfigs.findByName("novaRelease")
            isMinifyEnabled = false
            isShrinkResources = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    splits {
        abi {
            isEnable = novaApkSplitsEnabled
            reset()
            include("arm64-v8a", "armeabi-v7a")
            isUniversalApk = novaApkSplitsEnabled
        }
    }

    androidResources {
        localeFilters += listOf("tr", "en", "sv", "fr", "es", "ja", "zh-rCN", "de")
    }

    bundle {
        abi { enableSplit = true }
        density { enableSplit = true }
        language { enableSplit = true }
    }

    testOptions {
        unitTests.isReturnDefaultValues = true
    }

    packaging {
        // youtubedl-android reads libpython.zip.so and libffmpeg.zip.so from
        // applicationInfo.nativeLibraryDir. Keep native payloads extracted so
        // the upstream runtime can open those files. Actual ELF files remain
        // 16 KB aligned and are verified by AUDIT_16KB.ps1.
        jniLibs.useLegacyPackaging = true
        resources.excludes += setOf(
            "META-INF/AL2.0",
            "META-INF/LGPL2.1"
        )
    }

    // Distribution-specific code belongs under src/play and src/independent.
}

kotlin {
    compilerOptions {
        jvmTarget = JvmTarget.fromTarget("17")
    }
}

dependencies {
        implementation("io.github.junkfood02.youtubedl-android:library:0.18.1")
    add("proImplementation", "io.github.junkfood02.youtubedl-android:ffmpeg:0.18.1")
    implementation("androidx.core:core:1.17.0")
    implementation("androidx.room:room-runtime:2.8.4")
    implementation("androidx.room:room-ktx:2.8.4")
    kapt("androidx.room:room-compiler:2.8.4")
    implementation("androidx.work:work-runtime-ktx:2.11.2")
    implementation("androidx.recyclerview:recyclerview:1.4.0")
    implementation("androidx.media3:media3-exoplayer:1.11.0")
    implementation("androidx.media3:media3-ui:1.11.0")

    // Independent distribution only: these libraries are not packaged in Google Play variants.
    add("independentImplementation", "com.auroraoss:gplayapi:3.6.4")
    add("independentImplementation", "io.github.reandroid:ARSCLib:1.4.0")
    add("independentImplementation", "com.google.mlkit:translate:17.0.3")
    add("independentImplementation", "com.android.tools.build:apksig:8.10.1")

    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test:runner:1.7.0")
    androidTestImplementation("androidx.test:core:1.7.0")
    androidTestImplementation("androidx.test.ext:junit:1.3.0")
}

kapt {
    correctErrorTypes = true
    arguments {
        arg("room.schemaLocation", "$projectDir/schemas")
        arg("room.incremental", "true")
    }
}


val ANDROID_XML_NAMESPACE = "http://schemas.android.com/apk/res/android"

fun Element.androidAttribute(name: String): String =
    getAttributeNS(ANDROID_XML_NAMESPACE, name).ifBlank { getAttribute("android:$name") }

fun normalizedComponentName(rawName: String): String = when {
    rawName.startsWith(".") -> "com.nova.downloader$rawName"
    "." !in rawName -> "com.nova.downloader.$rawName"
    else -> rawName
}

val forbiddenNovaPlayPermissions = setOf(
    // Nova Video İndir Play sürümünün mevcut özellikleri için gerekli olmayan veya
    // ayrı Play Console incelemesi doğurabilecek izinler.
    "android.permission.MANAGE_EXTERNAL_STORAGE",
    "android.permission.REQUEST_INSTALL_PACKAGES",
    "android.permission.QUERY_ALL_PACKAGES",
    "android.permission.SYSTEM_ALERT_WINDOW",
    "android.permission.FOREGROUND_SERVICE_SPECIAL_USE",
    "android.permission.READ_EXTERNAL_STORAGE",
    "android.permission.READ_MEDIA_IMAGES",
    "android.permission.READ_MEDIA_VIDEO",
    "android.permission.READ_MEDIA_AUDIO",
    "android.permission.ACCESS_FINE_LOCATION",
    "android.permission.ACCESS_COARSE_LOCATION",
    "android.permission.CAMERA",
    "android.permission.RECORD_AUDIO",
    "android.permission.READ_CONTACTS",
    "android.permission.READ_PHONE_STATE",
    "android.permission.READ_SMS",
    "android.permission.SEND_SMS"
)

val requiredNovaPlayPermissions = setOf(
    "android.permission.INTERNET",
    "android.permission.ACCESS_NETWORK_STATE",
    "android.permission.POST_NOTIFICATIONS",
    "android.permission.FOREGROUND_SERVICE",
    "android.permission.FOREGROUND_SERVICE_DATA_SYNC",
    "android.permission.WAKE_LOCK",
    "android.permission.RECEIVE_BOOT_COMPLETED"
)

val checkNovaPlayMergedManifests = tasks.register("checkNovaPlayMergedManifests") {
    group = "verification"
    description = "Lite ve Pro release birleştirilmiş manifestlerini Google Play izin, export ve FGS kurallarına göre denetler."
    dependsOn("processPlayLiteReleaseManifest", "processPlayProReleaseManifest")

    doLast {
        val allowedExportedActivities = setOf(
            "com.nova.downloader.ui.MainActivity",
            "com.nova.downloader.ui.SetupActivity"
        )
        val expectedServiceTypes = mapOf(
            "com.nova.downloader.service.DownloadService" to "dataSync",
            "com.nova.downloader.service.YtDlpDownloadService" to "dataSync",
            "com.nova.downloader.service.BackgroundResolutionService" to "dataSync",
            "androidx.work.impl.foreground.SystemForegroundService" to "dataSync"
        )

        listOf("playLiteRelease", "playProRelease").forEach { variant ->
            val variantToken = "/${variant.lowercase()}/"
            val manifestCandidates = fileTree(layout.buildDirectory.dir("intermediates")) {
                include("**/AndroidManifest.xml")
            }.files.mapNotNull { file ->
                val pathToken = file.invariantSeparatorsPath.lowercase()
                if (variantToken !in pathToken) return@mapNotNull null
                val text = runCatching { file.readText() }.getOrNull() ?: return@mapNotNull null
                if ("SetupActivity" !in text || "<application" !in text) return@mapNotNull null
                file to text
            }

            check(manifestCandidates.isNotEmpty()) {
                "$variant için birleştirilmiş AndroidManifest.xml bulunamadı."
            }

            val manifestFile = manifestCandidates.maxBy { (file, text) -> file.length() + text.length }
                .first
            val factory = DocumentBuilderFactory.newInstance().apply {
                isNamespaceAware = true
                isExpandEntityReferences = false
            }
            val document = factory.newDocumentBuilder().parse(manifestFile)
            val application = document.getElementsByTagName("application").item(0) as? Element
                ?: error("$variant manifestinde application öğesi bulunamadı: ${manifestFile.absolutePath}")

            val permissionTags = listOf("uses-permission", "uses-permission-sdk-23")
            val permissions = permissionTags.flatMap { tag ->
                val nodes = document.getElementsByTagName(tag)
                (0 until nodes.length).mapNotNull { index ->
                    (nodes.item(index) as? Element)?.androidAttribute("name")?.takeIf(String::isNotBlank)
                }
            }.toSet()

            val forbiddenFound = permissions.intersect(forbiddenNovaPlayPermissions)
            check(forbiddenFound.isEmpty()) {
                "$variant birleştirilmiş manifestinde Nova Play özellikleri için izin verilmeyen izinler bulundu: ${forbiddenFound.sorted()}"
            }

            val writeStorageNodes = document.getElementsByTagName("uses-permission")
            val writeStorageDeclarations = (0 until writeStorageNodes.length)
                .mapNotNull { writeStorageNodes.item(it) as? Element }
                .filter { it.androidAttribute("name") == "android.permission.WRITE_EXTERNAL_STORAGE" }
            check(writeStorageDeclarations.isNotEmpty()) {
                "$variant manifestinde Android 8-9 uyumluluğu için sınırlandırılmış WRITE_EXTERNAL_STORAGE bildirimi eksik."
            }
            check(writeStorageDeclarations.all { it.androidAttribute("maxSdkVersion") == "28" }) {
                "$variant manifestinde WRITE_EXTERNAL_STORAGE yalnız android:maxSdkVersion=28 ile kullanılabilir."
            }

            val requiredMissing = requiredNovaPlayPermissions - permissions
            check(requiredMissing.isEmpty()) {
                "$variant birleştirilmiş manifestinde gerekli izinler eksik: ${requiredMissing.sorted()}"
            }

            check(application.androidAttribute("allowBackup") == "false") {
                "$variant manifestinde android:allowBackup=false olmalı."
            }
            check(application.androidAttribute("usesCleartextTraffic") == "false") {
                "$variant manifestinde android:usesCleartextTraffic=false olmalı."
            }

            fun componentElements(tagName: String): List<Element> {
                val nodes = document.getElementsByTagName(tagName)
                return (0 until nodes.length).mapNotNull { nodes.item(it) as? Element }
            }

            val allowedAndroidxExportPermissions = setOf(
                "android.permission.BIND_JOB_SERVICE",
                "android.permission.DUMP"
            )
            listOf("service", "receiver", "provider").forEach { tagName ->
                val unsafeExportedComponents = componentElements(tagName).filter {
                    it.androidAttribute("exported").equals("true", ignoreCase = true)
                }.map { element ->
                    normalizedComponentName(element.androidAttribute("name")) to
                        element.androidAttribute("permission")
                }.filter { (componentName, permission) ->
                    componentName.startsWith("com.nova.downloader") ||
                        !componentName.startsWith("androidx.") ||
                        permission !in allowedAndroidxExportPermissions
                }
                check(unsafeExportedComponents.isEmpty()) {
                    "$variant manifestinde korumasız veya beklenmeyen dışa açık $tagName bulundu: ${unsafeExportedComponents.sortedBy { it.first }}"
                }
            }

            val exportedActivities = componentElements("activity").filter {
                it.androidAttribute("exported").equals("true", ignoreCase = true)
            }.map { normalizedComponentName(it.androidAttribute("name")) }.toSet()

            check(exportedActivities == allowedExportedActivities) {
                "$variant dışa açık activity listesi beklenenden farklı. Beklenen: ${allowedExportedActivities.sorted()}, bulunan: ${exportedActivities.sorted()}"
            }

            val servicesByName = componentElements("service").associateBy {
                normalizedComponentName(it.androidAttribute("name"))
            }
            expectedServiceTypes.forEach { (serviceName, requiredType) ->
                val service = servicesByName[serviceName]
                    ?: error("$variant manifestinde gerekli servis yok: $serviceName")
                val actualTypes = service.androidAttribute("foregroundServiceType")
                    .split('|')
                    .map(String::trim)
                    .filter(String::isNotBlank)
                    .toSet()
                check(requiredType in actualTypes) {
                    "$variant manifestinde $serviceName için $requiredType FGS türü eksik; bulunan: $actualTypes"
                }
            }

            check("com.nova.downloader.service.PetOverlayService" !in servicesByName) {
                "$variant Play manifestinde PetOverlayService bulunmamalı."
            }

            logger.lifecycle("Nova Play manifest denetimi başarılı [$variant]: ${manifestFile.absolutePath}")
        }
    }
}


// Checkpoint 041: signing is required for every release binary.
val checkNovaReleaseSigning = tasks.register("checkNovaReleaseSigning") {
    group = "verification"
    description = "Play AAB ve Bağımsız APK release imza yapılandırmasını denetler."
    doLast {
        check(releaseSigningConfigured) {
            "Release imzası hazır değil. Önce SETUP_RELEASE_SIGNING.cmd çalıştırın veya NOVA_KEYSTORE / NOVA_KEY_ALIAS / NOVA_STORE_PASSWORD / NOVA_KEY_PASSWORD tanımlayın."
        }
        check(File(novaKeystorePath!!).isFile) {
            "Release keystore bulunamadı: $novaKeystorePath"
        }
        logger.lifecycle("Nova release imza yapılandırması hazır: $novaKeystorePath")
    }
}

// Publication-only gate: binary compilation can happen earlier, but Play upload readiness also needs a public HTTPS privacy URL.
val checkNovaPlayPublicationConfig = tasks.register("checkNovaPlayPublicationConfig") {
    group = "verification"
    description = "Google Play yayın aşaması için HTTPS gizlilik politikası yapılandırmasını denetler."
    dependsOn(checkNovaReleaseSigning)
    doLast {
        check(novaPlayPrivacyUrl.isNotBlank()) {
            "Google Play yayını için NOVA_PLAY_PRIVACY_URL gerekli."
        }
        val privacy = URI(novaPlayPrivacyUrl)
        check(privacy.scheme.equals("https", true) && !privacy.host.isNullOrBlank()) {
            "NOVA_PLAY_PRIVACY_URL herkese açık HTTPS adresi olmalı: $novaPlayPrivacyUrl"
        }
        logger.lifecycle("Nova Play yayın yapılandırması hazır: signing + privacy URL.")
    }
}

// Google Play delivery tasks: two AAB files for Store upload and six APKs for local testing.
val novaPlayOutputRoot = rootProject.layout.projectDirectory.dir("$novaArtifactBaseName Google Play").asFile
val novaPlayDebugOutputRoot = rootProject.layout.projectDirectory.dir("$novaArtifactBaseName Google Play Test").asFile

val exportNovaPlayDebugApks = tasks.register("exportNovaPlayDebugApks") {
    group = "build"
    dependsOn("assemblePlayLiteDebug", "assemblePlayProDebug")
    doLast {
        novaPlayDebugOutputRoot.deleteRecursively()
        novaPlayDebugOutputRoot.mkdirs()
        data class Export(val source: String, val target: File)
        val exports = listOf(
            Export("outputs/apk/playLite/debug/app-play-lite-armeabi-v7a-debug.apk", novaPlayDebugOutputRoot.resolve("$novaArtifactBaseName Google Play Lite Arm v7a.apk")),
            Export("outputs/apk/playLite/debug/app-play-lite-arm64-v8a-debug.apk", novaPlayDebugOutputRoot.resolve("$novaArtifactBaseName Google Play Lite Arm v8a.apk")),
            Export("outputs/apk/playLite/debug/app-play-lite-universal-debug.apk", novaPlayDebugOutputRoot.resolve("$novaArtifactBaseName Google Play Lite Universal.apk")),
            Export("outputs/apk/playPro/debug/app-play-pro-armeabi-v7a-debug.apk", novaPlayDebugOutputRoot.resolve("$novaArtifactBaseName Google Play Pro Arm v7a.apk")),
            Export("outputs/apk/playPro/debug/app-play-pro-arm64-v8a-debug.apk", novaPlayDebugOutputRoot.resolve("$novaArtifactBaseName Google Play Pro Arm v8a.apk")),
            Export("outputs/apk/playPro/debug/app-play-pro-universal-debug.apk", novaPlayDebugOutputRoot.resolve("$novaArtifactBaseName Google Play Pro Universal.apk"))
        )
        exports.forEach { item ->
            val source = layout.buildDirectory.file(item.source).get().asFile
            check(source.isFile) { "Beklenen APK bulunamadı: ${source.absolutePath}" }
            source.copyTo(item.target, overwrite = true)
        }
        logger.lifecycle("Nova Video İndir test APK klasörü: ${novaPlayDebugOutputRoot.absolutePath}")
    }
}

tasks.register("assembleNovaPlayDebug") {
    group = "build"
    description = "Nova Video İndir Lite/Pro ARM v7, ARM v8 ve Universal test APK'larını üretir."
    dependsOn(exportNovaPlayDebugApks)
}

val exportNovaPlayBundles = tasks.register("exportNovaPlayBundles") {
    group = "build"
    dependsOn(checkNovaReleaseSigning, "bundlePlayLiteRelease", "bundlePlayProRelease")
    doLast {
        novaPlayOutputRoot.deleteRecursively()
        novaPlayOutputRoot.mkdirs()
        val lite = layout.buildDirectory.file("outputs/bundle/playLiteRelease/app-play-lite-release.aab").get().asFile
        val pro = layout.buildDirectory.file("outputs/bundle/playProRelease/app-play-pro-release.aab").get().asFile
        check(lite.isFile) { "Lite AAB bulunamadı: ${lite.absolutePath}" }
        check(pro.isFile) { "Pro AAB bulunamadı: ${pro.absolutePath}" }
        lite.copyTo(novaPlayOutputRoot.resolve("$novaArtifactBaseName Google Play Lite.aab"), overwrite = true)
        pro.copyTo(novaPlayOutputRoot.resolve("$novaArtifactBaseName Google Play Pro.aab"), overwrite = true)
        logger.lifecycle("Nova Video İndir Google Play AAB klasörü: ${novaPlayOutputRoot.absolutePath}")
    }
}

tasks.register("bundleNovaPlayRelease") {
    group = "build"
    description = "Google Play için Lite/Pro imzalı AAB üretir; yayın, manifest ve imza kapılarının tamamını zorunlu çalıştırır."
    dependsOn(checkNovaPlayPublicationConfig, checkNovaPlayMergedManifests, exportNovaPlayBundles)
}

// Independent delivery: APK-first channel, kept separate from Google Play outputs.
val novaIndependentOutputRoot = rootProject.layout.projectDirectory.dir("$novaArtifactBaseName Bağımsız").asFile
val novaIndependentDebugOutputRoot = rootProject.layout.projectDirectory.dir("$novaArtifactBaseName Bağımsız Test").asFile

val exportNovaIndependentDebugApks = tasks.register("exportNovaIndependentDebugApks") {
    group = "build"
    dependsOn("assembleIndependentLiteDebug", "assembleIndependentProDebug")
    doLast {
        novaIndependentDebugOutputRoot.deleteRecursively()
        novaIndependentDebugOutputRoot.mkdirs()
        data class Export(val source: String, val target: File)
        val exports = listOf(
            Export("outputs/apk/independentLite/debug/app-independent-lite-armeabi-v7a-debug.apk", novaIndependentDebugOutputRoot.resolve("$novaArtifactBaseName Bağımsız Lite Arm v7a.apk")),
            Export("outputs/apk/independentLite/debug/app-independent-lite-arm64-v8a-debug.apk", novaIndependentDebugOutputRoot.resolve("$novaArtifactBaseName Bağımsız Lite Arm v8a.apk")),
            Export("outputs/apk/independentLite/debug/app-independent-lite-universal-debug.apk", novaIndependentDebugOutputRoot.resolve("$novaArtifactBaseName Bağımsız Lite Universal.apk")),
            Export("outputs/apk/independentPro/debug/app-independent-pro-armeabi-v7a-debug.apk", novaIndependentDebugOutputRoot.resolve("$novaArtifactBaseName Bağımsız Pro Arm v7a.apk")),
            Export("outputs/apk/independentPro/debug/app-independent-pro-arm64-v8a-debug.apk", novaIndependentDebugOutputRoot.resolve("$novaArtifactBaseName Bağımsız Pro Arm v8a.apk")),
            Export("outputs/apk/independentPro/debug/app-independent-pro-universal-debug.apk", novaIndependentDebugOutputRoot.resolve("$novaArtifactBaseName Bağımsız Pro Universal.apk"))
        )
        exports.forEach { item ->
            val source = layout.buildDirectory.file(item.source).get().asFile
            check(source.isFile) { "Beklenen bağımsız APK bulunamadı: ${source.absolutePath}" }
            source.copyTo(item.target, overwrite = true)
        }
        logger.lifecycle("Nova Video İndir bağımsız test APK klasörü: ${novaIndependentDebugOutputRoot.absolutePath}")
    }
}

tasks.register("assembleNovaIndependentDebug") {
    group = "build"
    description = "Bağımsız Lite/Pro ARM v7, ARM v8 ve Universal test APK'larını üretir."
    dependsOn(exportNovaIndependentDebugApks)
}



val exportNovaIndependentReleaseApks = tasks.register("exportNovaIndependentReleaseApks") {
    group = "build"
    dependsOn(checkNovaReleaseSigning, "assembleIndependentLiteRelease", "assembleIndependentProRelease")
    doLast {
        novaIndependentOutputRoot.deleteRecursively()
        novaIndependentOutputRoot.mkdirs()
        data class Export(val source: String, val target: File)
        // Release APKs intentionally use one universal package per edition.
        // ABI splits stay disabled so Play AAB and Independent APK can be built in the same Gradle invocation.
        val exports = listOf(
            Export("outputs/apk/independentLite/release/app-independent-lite-release.apk", novaIndependentOutputRoot.resolve("$novaArtifactBaseName Bağımsız Lite.apk")),
            Export("outputs/apk/independentPro/release/app-independent-pro-release.apk", novaIndependentOutputRoot.resolve("$novaArtifactBaseName Bağımsız Pro.apk"))
        )
        exports.forEach { item ->
            val source = layout.buildDirectory.file(item.source).get().asFile
            check(source.isFile) { "Beklenen bağımsız release APK bulunamadı: ${source.absolutePath}" }
            source.copyTo(item.target, overwrite = true)
        }
        logger.lifecycle("Nova Video İndir bağımsız release APK klasörü: ${novaIndependentOutputRoot.absolutePath}")
    }
}

tasks.register("assembleNovaIndependentRelease") {
    group = "build"
    description = "Bağımsız Lite/Pro imzalı Universal release APK'larını üretir."
    dependsOn(exportNovaIndependentReleaseApks)
}


// Distribution release: one command produces Play AAB + signed Independent APK with version-clean delivery names.
tasks.register("buildNovaDistributionRelease") {
    group = "build"
    description = "Google Play Lite/Pro AAB ve Bağımsız Lite/Pro imzalı Universal APK çıktılarının tamamını üretir."
    dependsOn("bundleNovaPlayRelease", "assembleNovaIndependentRelease")
    doLast {
        logger.lifecycle("Nova dağıtım çıktıları hazır ($novaArtifactVersion):")
        logger.lifecycle("  Google Play: ${novaPlayOutputRoot.absolutePath}")
        logger.lifecycle("  Bağımsız: ${novaIndependentOutputRoot.absolutePath}")
    }
}
