package com.nova.downloader.data

import com.nova.downloader.i18n.AppText
import com.nova.downloader.R
import com.nova.downloader.BuildConfig
import android.content.Context
import com.nova.downloader.core.FacebookUrlExtractor
import com.nova.downloader.core.FileNameResolver
import com.nova.downloader.core.MediaTypePolicy
import com.nova.downloader.core.YtDlpOptionBuilder
import com.nova.downloader.diagnostics.LocalLog
import com.nova.downloader.engine.EngineRecoveryManager
import com.yausername.youtubedl_android.YoutubeDL

class YtDlpMediaResolver(context: Context) {
    private val appContext = context.applicationContext
    private val facebookPageResolver = FacebookPageResolver()
    private val inspector = YtDlpMetadataInspector(appContext)
    private val engineRecovery = EngineRecoveryManager(appContext)
    private val requestConfigurator = YtDlpRequestConfigurator(appContext)

    fun resolve(sourceUrl: String): Result {
        return try {
            YoutubeDL.getInstance().init(appContext)
            val stableNote = ensureStableExtractor()
            var candidates = listOf(sourceUrl)
            var resolutionNote = ""
            var attempt = tryCandidates(sourceUrl, candidates)
            if (attempt is Attempt.Ready) return Result.Ready(attempt.download)

            if (FacebookUrlExtractor.isShareAlias(sourceUrl)) {
                val resolution = facebookPageResolver.resolve(sourceUrl)
                candidates = resolution.candidates
                resolutionNote = resolution.note
                attempt = tryCandidates(sourceUrl, candidates)
                if (attempt is Attempt.Ready) return Result.Ready(attempt.download)
            }

            val first = attempt as Attempt.Failed
            if (!BuildConfig.PLAY_STORE_BUILD && shouldRetryWithNightly(first.rawMessage)) {
                val nightly = ensureNightlyExtractor()
                val second = tryCandidates(sourceUrl, candidates)
                if (second is Attempt.Ready) return Result.Ready(second.download)
                return Result.Unsupported(
                    humanMessage(
                        (second as Attempt.Failed).rawMessage,
                        listOf(stableNote, nightly, resolutionNote)
                    )
                )
            }
            Result.Unsupported(humanMessage(first.rawMessage, listOf(stableNote, resolutionNote)))
        } catch (_: InterruptedException) {
            Thread.currentThread().interrupt()
            Result.Error(AppText.get(R.string.resolver_interrupted))
        } catch (error: Exception) {
            Result.Error(error.message ?: AppText.get(R.string.resolver_start_failed))
        }
    }

    private fun tryCandidates(sourceUrl: String, candidates: List<String>): Attempt {
        val failures = mutableListOf<String>()
        val attempted = mutableSetOf<String>()
        for (candidate in candidates) {
            var hardGateSeen = false
            val profiles = requestConfigurator.automaticProfiles(sourceUrl)
            for (profile in profiles) {
                if (hardGateSeen && !profile.allowStoredCookies) continue
                if (!attempted.add("$candidate\u0000${profile.id}")) continue
                try {
                    LocalLog.info("Resolver", "Trying profile=${profile.id} platform=${PlatformPolicy.platformFor(sourceUrl)}")
                    val inspection = inspector.inspect(candidate, profile)
                    val extension = inspection.extension.ifBlank { "mp4" }
                    val title = FileNameResolver.sanitize(
                        if (inspection.title.endsWith(".$extension", true)) inspection.title else "${inspection.title}.$extension",
                        "nova_${System.currentTimeMillis()}.$extension"
                    )
                    val selected = inspection.formats.firstOrNull()
                        ?: error(AppText.get(R.string.media_format_not_found))
                    engineRecovery.recordSuccess()
                    return Attempt.Ready(
                        ResolvedDownload(
                            sourceUrl = sourceUrl,
                            downloadUrl = candidate,
                            title = title,
                            mimeType = MediaTypePolicy.mimeTypeForExtension(extension) ?: "video/mp4",
                            contentLength = inspection.contentLength,
                            referer = candidate,
                            headers = mapOf(YtDlpRequestConfigurator.PROFILE_HEADER to profile.id),
                            engine = DownloadEngine.YT_DLP,
                            formatSelector = selected.selector,
                            outputMode = YtDlpOptionBuilder.MODE_VIDEO,
                            videoContainer = if (extension in setOf("mkv", "webm", "mp4")) extension else "mp4",
                            qualityId = selected.formatId,
                            formats = inspection.formats,
                            metadata = inspection.metadata,
                            selectedAudioLanguage = inspection.metadata.audioLanguages.firstOrNull(),
                            subtitleLanguages = inspection.metadata.subtitleLanguages,
                            playlistMode = "single"
                        )
                    )
                } catch (error: Exception) {
                    val raw = error.message.orEmpty().ifBlank { AppText.get(R.string.resolver_failed_message) }
                    failures += raw
                    if (YtDlpFallbackPolicy.isHardAccessGate(raw)) hardGateSeen = true
                    engineRecovery.recordFailure(raw, runCatching { java.net.URI(candidate).host }.getOrNull())
                    LocalLog.warn("Resolver", "Candidate failed profile=${profile.id}", error)
                }
            }
        }
        return Attempt.Failed(selectMostUsefulFailure(failures))
    }

    private fun selectMostUsefulFailure(failures: List<String>) =
        failures.maxByOrNull(::failureScore) ?: AppText.get(R.string.media_stream_unresolved)

    private fun failureScore(message: String) = when {
        YtDlpFallbackPolicy.isHardAccessGate(message) -> 110
        message.contains("login", true) || message.contains("cookie", true) || message.contains("not a bot", true) -> 100
        message.contains("private", true) || message.contains("not available", true) -> 95
        message.contains("cannot parse", true) || message.contains("unable to extract", true) -> 90
        message.contains("no video formats", true) -> 85
        message.contains("unsupported url", true) -> 20
        else -> 50
    }

    private fun ensureStableExtractor(): String = synchronized(UPDATE_LOCK) {
        if (!stableChecked) {
            stableChecked = true
            stableUpdateNote = engineRecovery.ensureUpdated(YoutubeDL.UpdateChannel.STABLE).message
        }
        stableUpdateNote
    }

    private fun ensureNightlyExtractor(): String = synchronized(UPDATE_LOCK) {
        if (!nightlyChecked) {
            nightlyChecked = true
            nightlyUpdateNote = engineRecovery.ensureUpdated(YoutubeDL.UpdateChannel.NIGHTLY, 0L).message
        }
        nightlyUpdateNote
    }

    private fun shouldRetryWithNightly(raw: String) =
        YtDlpFallbackPolicy.isRetryableExtractionFailure(raw) ||
            listOf("unsupported url", "requested format").any { raw.contains(it, true) }

    private fun humanMessage(raw: String?, notes: List<String>): String {
        val message = raw.orEmpty()
        val friendly = when {
            YtDlpFallbackPolicy.isHardAccessGate(message) -> AppText.get(R.string.content_unavailable_account)
            message.contains("login", true) || message.contains("cookie", true) || message.contains("not a bot", true) ->
                AppText.get(R.string.content_login_required)
            message.contains("private", true) || message.contains("not available", true) ->
                AppText.get(R.string.content_unavailable_account)
            message.contains("rate", true) || message.contains("429") -> AppText.get(R.string.platform_rate_limited)
            else -> AppText.get(R.string.media_info_unresolved)
        }
        return buildString {
            append(friendly)
            notes.filter(String::isNotBlank).distinct().joinToString("\n").takeIf(String::isNotBlank)?.let {
                append("\n\n").append(AppText.get(R.string.resolver_status_heading)).append("\n").append(it)
            }
            compactTechnicalError(message).takeIf(String::isNotBlank)?.let {
                append("\n\n").append(AppText.get(R.string.technical_detail_heading)).append("\n").append(it)
            }
        }
    }

    private fun compact(value: String?) = value.orEmpty().replace(Regex("\\s+"), " ").trim().take(240)

    private fun compactTechnicalError(raw: String): String = compact(
        raw.lineSequence().lastOrNull { it.trim().startsWith("ERROR:", true) } ?: raw
    ).replace(Regex("https?://\\S+"), AppText.get(R.string.redacted_address)).take(600)

    private sealed class Attempt {
        data class Ready(val download: ResolvedDownload) : Attempt()
        data class Failed(val rawMessage: String) : Attempt()
    }

    sealed class Result {
        data class Ready(val download: ResolvedDownload) : Result()
        data class Unsupported(val message: String) : Result()
        data class Error(val message: String) : Result()
    }

    companion object {
        private val UPDATE_LOCK = Any()
        @Volatile private var stableChecked = false
        @Volatile private var nightlyChecked = false
        @Volatile private var stableUpdateNote = ""
        @Volatile private var nightlyUpdateNote = ""
    }
}
