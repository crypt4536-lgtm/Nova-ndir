package com.nova.downloader.ui

import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.webkit.CookieManager
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewDatabase
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.nova.downloader.BuildConfig
import com.nova.downloader.R
import com.nova.downloader.core.PetCatalog
import com.nova.downloader.core.UrlPolicy
import com.nova.downloader.core.YtDlpOptionBuilder
import com.nova.downloader.data.AppSettings
import com.nova.downloader.data.CookieVault
import com.nova.downloader.data.CustomPetVault
import com.nova.downloader.data.DuplicatePolicy
import com.nova.downloader.data.PlatformPolicy
import com.nova.downloader.data.RecoveryPolicy
import com.nova.downloader.data.StorageHelper
import com.nova.downloader.data.YtDlpPluginVault
import com.nova.downloader.diagnostics.DiagnosticReportExporter
import com.nova.downloader.diagnostics.LocalLog
import com.nova.downloader.engine.EngineMaintenanceClient
import com.nova.downloader.i18n.LocaleController
import com.nova.downloader.i18n.LocalizedActivity
import com.nova.downloader.service.EngineMaintenanceService
import com.nova.downloader.distribution.PetIntegration
import com.nova.downloader.worker.RecoveryScheduler

class SettingsActivity : LocalizedActivity() {
    private lateinit var store: AppSettings
    private lateinit var destinationText: TextView
    private lateinit var cookieStatusText: TextView
    private lateinit var engineStatusText: TextView
    private lateinit var summaryText: TextView
    private lateinit var petEnabledBox: CheckBox
    private var waitingOverlayPermission = false
    private var pendingCookiePlatform = PlatformPolicy.GENERIC

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = AppSettings(this)
        setContentView(buildContent())
        refreshEngineStatus()
    }

    override fun onResume() {
        super.onResume()
        if (BuildConfig.HAS_PET_OVERLAY && waitingOverlayPermission) {
            waitingOverlayPermission = false
            store.petEnabled = PetIntegration.canDrawOverlays(this)
            if (store.petEnabled) PetIntegration.startOrRefresh(this)
            else toast(getString(R.string.pet_overlay_permission_denied))
        }
        updateLabels()
    }

    private fun buildContent(): View {
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(32))
            setBackgroundColor(UiPalette.screenBackground(this@SettingsActivity))
        }
        content.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(actionButton(getString(R.string.back)) { finish() })
            addView(TextView(this@SettingsActivity).apply {
                text = getString(R.string.settings_title)
                textSize = 21f
                setTypeface(typeface, Typeface.BOLD)
                setPadding(dp(12), 0, 0, 0)
            })
        })

        content.addView(section(R.string.settings_language_section))
        content.addView(actionButton(getString(R.string.settings_language, languageLabel(store.languageTag))) { chooseLanguage() })
        content.addView(actionButton(getString(R.string.settings_memory_mode, memoryModeLabel(store.memoryMode))) { chooseMemoryMode() })
        content.addView(infoText(R.string.memory_mode_info))

        content.addView(section(R.string.settings_download_section))
        destinationText = infoText(); content.addView(destinationText)
        content.addView(horizontal(
            actionButton(getString(R.string.change_directory)) { openTreePicker() },
            actionButton(getString(R.string.use_automatic_directory)) { store.defaultTreeUri = null; updateLabels() }
        ))
        content.addView(check(R.string.confirm_each_download, store.confirmEachDownload) { store.confirmEachDownload = it })
        content.addView(actionButton(getString(R.string.default_output, outputModeLabel())) { chooseOutputMode() })
        content.addView(actionButton(getString(R.string.default_quality, YtDlpOptionBuilder.qualityLabel(store.defaultQualityId))) { chooseQuality() })
        content.addView(actionButton(getString(R.string.default_video_container, store.defaultVideoContainer.uppercase())) { chooseVideoContainer() })
        content.addView(actionButton(getString(R.string.default_audio_format, YtDlpOptionBuilder.audioLabel(store.defaultAudioFormat))) { chooseAudioFormat() })
        content.addView(actionButton(getString(R.string.duplicate_policy, duplicateLabel(store.defaultDuplicatePolicy))) { chooseDuplicatePolicy() })
        content.addView(actionButton(getString(R.string.speed_limit_setting, speedLimitLabel())) { chooseSpeedLimit() })
        content.addView(actionButton(getString(R.string.parallel_downloads_setting, store.maxParallelDownloads)) { chooseParallelDownloads() })
        content.addView(check(R.string.embed_metadata_default, store.defaultEmbedMetadata) { store.defaultEmbedMetadata = it })
        content.addView(check(R.string.embed_chapters_default, store.defaultEmbedChapters) { store.defaultEmbedChapters = it })

        content.addView(section(R.string.settings_background_section))
        content.addView(check(R.string.background_resolution_enabled, store.backgroundResolutionEnabled) { store.backgroundResolutionEnabled = it })
        content.addView(check(R.string.auto_start_after_resolution, store.autoStartAfterResolution) { store.autoStartAfterResolution = it })
        content.addView(check(R.string.resolution_ready_notifications, store.resolutionReadyNotifications) { store.resolutionReadyNotifications = it })
        content.addView(check(R.string.system_completion_notifications, store.systemCompletionNotifications) { store.systemCompletionNotifications = it })
        content.addView(check(R.string.in_app_completion_dialog_setting, store.inAppCompletionDialog) { store.inAppCompletionDialog = it })
        content.addView(check(R.string.pet_completion_alerts_setting, store.petCompletionAlerts) {
            store.petCompletionAlerts = it
            PetIntegration.refreshMaybe(this)
        })
        content.addView(infoText(R.string.background_processing_info))

        content.addView(section(R.string.settings_browser_section))
        content.addView(actionButton(getString(R.string.open_nova_browser)) { startActivity(Intent(this, BrowserActivity::class.java)) })
        content.addView(actionButton(getString(R.string.browser_home, store.browserHomeUrl)) { editBrowserHome() })
        content.addView(check(R.string.browser_auto_detect, store.browserAutoDetectEnabled) { store.browserAutoDetectEnabled = it })
        content.addView(check(R.string.browser_sync_cookies, store.browserSyncCookies) { store.browserSyncCookies = it })
        content.addView(check(R.string.browser_third_party_cookies, store.browserThirdPartyCookies) { store.browserThirdPartyCookies = it })
        content.addView(check(R.string.browser_clear_cache_exit, store.browserClearCacheOnExit) { store.browserClearCacheOnExit = it })
        content.addView(actionButton(getString(R.string.browser_clear_data)) { confirmClearBrowserData() })
        content.addView(infoText(R.string.browser_privacy_info))

        content.addView(section(R.string.settings_accounts_section))
        content.addView(actionButton(getString(R.string.manage_accounts)) { startActivity(Intent(this, AccountManagerActivity::class.java)) })
        cookieStatusText = infoText(); content.addView(cookieStatusText)
        content.addView(check(R.string.use_session_cookies, store.useCookies) { store.useCookies = it })
        content.addView(actionButton(getString(R.string.import_youtube_cookies)) { openCookiePicker(PlatformPolicy.YOUTUBE) })
        content.addView(actionButton(getString(R.string.import_instagram_cookies)) { openCookiePicker(PlatformPolicy.INSTAGRAM) })
        content.addView(actionButton(getString(R.string.import_facebook_cookies)) { openCookiePicker(PlatformPolicy.FACEBOOK) })
        content.addView(actionButton(getString(R.string.import_generic_cookies)) { openCookiePicker(PlatformPolicy.GENERIC) })
        content.addView(actionButton(getString(R.string.clear_session_profiles)) {
            CookieVault.clear(this); updateLabels(); toast(getString(R.string.session_profiles_cleared))
        })
        content.addView(infoText(R.string.session_profiles_info))

        content.addView(section(R.string.settings_engine_section))
        if (!BuildConfig.PLAY_STORE_BUILD) {
            content.addView(check(R.string.remote_ejs, store.remoteEjsEnabled) { store.remoteEjsEnabled = it })
        }
        content.addView(actionButton(getString(R.string.request_delay, store.requestDelaySeconds)) { chooseRequestDelay() })
        content.addView(actionButton(getString(R.string.concurrent_fragments, effectiveFragments())) { chooseFragments() })
        content.addView(actionButton(getString(R.string.youtube_client, store.youtubePlayerClient)) { choosePlayerClient() })
        content.addView(actionButton(getString(R.string.po_token_status, secretStatus(store.youtubePoToken))) {
            editSecret(getString(R.string.po_token_label), store.youtubePoToken) { store.youtubePoToken = it }
        })
        content.addView(actionButton(getString(R.string.visitor_data_status, secretStatus(store.youtubeVisitorData))) {
            editSecret(getString(R.string.visitor_data_label), store.youtubeVisitorData) { store.youtubeVisitorData = it }
        })
        if (!BuildConfig.PLAY_STORE_BUILD) {
            content.addView(check(R.string.use_po_provider, store.poTokenProviderEnabled) { store.poTokenProviderEnabled = it })
            content.addView(actionButton(getString(R.string.po_provider_url, store.poTokenProviderBaseUrl)) {
                editText(getString(R.string.provider_base_url), store.poTokenProviderBaseUrl) { store.poTokenProviderBaseUrl = it }
            })
            content.addView(actionButton(getString(R.string.import_ytdlp_plugin)) { confirmPluginImport() })
            content.addView(actionButton(getString(R.string.clear_ytdlp_plugins)) {
                YtDlpPluginVault.clear(this); updateLabels(); toast(getString(R.string.plugins_cleared))
            })
            content.addView(infoText(R.string.po_provider_info))
        } else {
            content.addView(infoText(R.string.play_packaged_engine_info))
        }

        content.addView(section(R.string.settings_engine_recovery_section))
        engineStatusText = infoText(getString(R.string.engine_status_loading)); content.addView(engineStatusText)
        content.addView(actionButton(getString(R.string.engine_restore_bundled_button)) { runEngineCommand(EngineMaintenanceService.COMMAND_RESTORE_BUNDLED) })

        content.addView(section(R.string.settings_recovery_section))
        content.addView(actionButton(getString(R.string.recovery_after_restart, recoveryLabel(store.recoveryPolicy))) { chooseRecoveryPolicy() })
        content.addView(check(R.string.recovery_charging_only, store.recoveryChargingOnly) {
            store.recoveryChargingOnly = it; RecoveryScheduler.schedule(this)
        })
        content.addView(check(R.string.playlist_all_default, store.playlistDefaultAll) { store.playlistDefaultAll = it })
        content.addView(infoText(R.string.recovery_info))

        content.addView(section(R.string.settings_diagnostics_section))
        content.addView(actionButton(getString(R.string.export_diagnostic_report)) { exportDiagnostics() })
        content.addView(actionButton(getString(R.string.clear_local_logs)) {
            LocalLog.clear(); toast(getString(R.string.diagnostics_cleared))
        })
        content.addView(infoText(R.string.diagnostics_info))

        content.addView(section(R.string.settings_privacy_section))
        content.addView(actionButton(getString(R.string.privacy_policy_button)) {
            startActivity(Intent(this, PrivacyPolicyActivity::class.java))
        })

        if (BuildConfig.HAS_SELF_UPDATE) {
            content.addView(actionButton(getString(R.string.independent_update_center_title)) {
                startActivity(Intent().setClassName(this, "com.nova.downloader.ui.UpdateCenterActivity"))
            })
        }

        if (BuildConfig.HAS_PET_OVERLAY) {
            content.addView(section(R.string.settings_pet_section))
        petEnabledBox = check(R.string.pet_enable, store.petEnabled) { enabled ->
            if (enabled && !PetIntegration.canDrawOverlays(this)) {
                waitingOverlayPermission = true
                PetIntegration.requestOverlayPermission(this)
            } else {
                store.petEnabled = enabled
                if (enabled) PetIntegration.startOrRefresh(this) else PetIntegration.stop(this)
            }
        }
        content.addView(petEnabledBox)
        content.addView(check(R.string.pet_show_status, store.petShowStatus) { store.petShowStatus = it; PetIntegration.refreshMaybe(this) })
        content.addView(check(R.string.pet_snap_edge, store.petSnapEdge) { store.petSnapEdge = it; PetIntegration.refreshMaybe(this) })
        content.addView(check(R.string.pet_low_power, store.petLowPower) { store.petLowPower = it; PetIntegration.refreshMaybe(this) })
        content.addView(check(R.string.pet_start_boot, store.petStartOnBoot) { store.petStartOnBoot = it })
        content.addView(actionButton(getString(R.string.pet_type, petLabel())) { choosePetType() })
        content.addView(actionButton(getString(R.string.pet_color, colorLabel(store.petColor))) { choosePetColor() })
        content.addView(actionButton(getString(R.string.pet_shell, shellLabel(store.petShell))) { choosePetShell() })
        content.addView(actionButton(getString(R.string.pet_size, store.petSizePercent)) { choosePetSize() })
        content.addView(actionButton(getString(R.string.pet_opacity, store.petOpacityPercent)) { choosePetOpacity() })
        content.addView(actionButton(getString(R.string.pet_import)) { openPetPicker() })
        content.addView(actionButton(getString(R.string.pet_delete_custom)) {
            CustomPetVault.clear(this); PetIntegration.refreshMaybe(this); recreate(); toast(getString(R.string.pet_custom_deleted))
        })
            content.addView(infoText(R.string.pet_package_info))
        }

        summaryText = infoText(); content.addView(summaryText)
        updateLabels()
        return ScrollView(this).apply { addView(content) }
    }

    private fun chooseLanguage() {
        val values = arrayOf(
            LocaleController.SYSTEM,
            LocaleController.TURKISH,
            LocaleController.ENGLISH,
            LocaleController.SWEDISH,
            LocaleController.FRENCH,
            LocaleController.SPANISH,
            LocaleController.JAPANESE,
            LocaleController.CHINESE_SIMPLIFIED,
            LocaleController.GERMAN
        )
        val labels = values.map(::languageLabel).toTypedArray()
        chooseSingle(getString(R.string.settings_language_section), labels, values.indexOf(store.languageTag)) { index ->
            store.languageTag = values[index]
            LocaleController.setLanguage(this, values[index])
            recreate()
        }
    }

    private fun chooseMemoryMode() {
        val values = arrayOf(AppSettings.MEMORY_SAVER, AppSettings.MEMORY_BALANCED, AppSettings.MEMORY_PERFORMANCE)
        chooseSingle(getString(R.string.settings_memory_mode, memoryModeLabel(store.memoryMode)), values.map(::memoryModeLabel).toTypedArray(), values.indexOf(store.memoryMode)) {
            store.memoryMode = values[it]
            if (store.memoryMode == AppSettings.MEMORY_SAVER) store.concurrentFragments = 1
            recreate()
        }
    }

    private fun editBrowserHome() {
        val input = EditText(this).apply { setText(store.browserHomeUrl); setSelection(text.length); inputType = InputType.TYPE_TEXT_VARIATION_URI }
        AlertDialog.Builder(this)
            .setTitle(R.string.browser_home_title).setView(input)
            .setPositiveButton(R.string.save) { _, _ ->
                when (val result = UrlPolicy.validate(input.text.toString())) {
                    is UrlPolicy.Result.Valid -> { store.browserHomeUrl = result.normalizedUrl; recreate() }
                    is UrlPolicy.Result.Invalid -> toast(getString(R.string.browser_home_invalid))
                }
            }.setNegativeButton(R.string.cancel, null).show()
    }

    private fun confirmClearBrowserData() {
        AlertDialog.Builder(this).setTitle(R.string.browser_clear_confirm_title)
            .setMessage(R.string.browser_clear_confirm_message)
            .setPositiveButton(R.string.clear) { _, _ -> clearBrowserData() }
            .setNegativeButton(R.string.cancel, null).show()
    }

    private fun clearBrowserData() {
        CookieManager.getInstance().removeAllCookies {
            CookieManager.getInstance().flush()
            runOnUiThread { toast(getString(R.string.browser_data_cleared)) }
        }
        WebStorage.getInstance().deleteAllData()
        WebViewDatabase.getInstance(this).apply { clearFormData(); clearHttpAuthUsernamePassword() }
        runCatching { WebView(this).apply { clearCache(true); clearHistory(); destroy() } }
    }


    private fun exportDiagnostics() {
        toast(getString(R.string.diagnostics_exporting))
        Thread {
            val created = DiagnosticReportExporter.create(this)
            val published = created.getOrNull()?.let { DiagnosticReportExporter.publishToDownloads(this, it) }
            runOnUiThread {
                created.onSuccess { file ->
                    published?.onSuccess { location ->
                        toast(getString(R.string.diagnostics_saved_to, location))
                    }?.onFailure { error ->
                        LocalLog.warn("Diagnostics", "Public diagnostic copy failed", error)
                    }
                    DiagnosticReportExporter.share(this, file).onFailure { error ->
                        LocalLog.warn("Diagnostics", "Diagnostic share sheet failed", error)
                        if (published?.isSuccess != true) {
                            toast(error.message ?: getString(R.string.diagnostics_export_failed))
                        }
                    }
                }.onFailure { error ->
                    LocalLog.error("Diagnostics", "Diagnostic report creation failed", error)
                    toast(error.message ?: getString(R.string.diagnostics_export_failed))
                }
            }
        }.start()
    }

    private fun refreshEngineStatus() {
        Thread {
            val result = EngineMaintenanceClient.run(this, EngineMaintenanceService.COMMAND_STATUS)
            runOnUiThread { if (::engineStatusText.isInitialized) engineStatusText.text = result.message }
        }.start()
    }

    private fun runEngineCommand(command: String) {
        if (::engineStatusText.isInitialized) engineStatusText.text = getString(R.string.engine_action_running)
        Thread {
            val result = EngineMaintenanceClient.run(this, command)
            runOnUiThread {
                AlertDialog.Builder(this).setTitle(R.string.engine_operation_title).setMessage(result.message).setPositiveButton(R.string.ok, null).show()
                refreshEngineStatus()
            }
        }.start()
    }

    private fun chooseOutputMode() = chooseSingle(
        getString(R.string.default_output, outputModeLabel()),
        arrayOf(getString(R.string.video), getString(R.string.audio_only)),
        if (store.defaultOutputMode == YtDlpOptionBuilder.MODE_AUDIO) 1 else 0
    ) { store.defaultOutputMode = if (it == 1) YtDlpOptionBuilder.MODE_AUDIO else YtDlpOptionBuilder.MODE_VIDEO; recreate() }

    private fun chooseQuality() {
        val values = YtDlpOptionBuilder.qualityPresets
        chooseSingle(getString(R.string.default_quality, YtDlpOptionBuilder.qualityLabel(store.defaultQualityId)), values.map { getString(it.labelRes) }.toTypedArray(), values.indexOfFirst { it.id == store.defaultQualityId }) {
            store.defaultQualityId = values[it].id; recreate()
        }
    }

    private fun chooseAudioFormat() {
        val values = YtDlpOptionBuilder.audioPresets
        chooseSingle(getString(R.string.default_audio_format, YtDlpOptionBuilder.audioLabel(store.defaultAudioFormat)), values.map { getString(it.labelRes) }.toTypedArray(), values.indexOfFirst { it.id == store.defaultAudioFormat }) {
            store.defaultAudioFormat = values[it].id; recreate()
        }
    }

    private fun chooseVideoContainer() {
        val values = arrayOf("mp4", "mkv", "webm")
        chooseSingle(getString(R.string.default_video_container, store.defaultVideoContainer.uppercase()), values.map(String::uppercase).toTypedArray(), values.indexOf(store.defaultVideoContainer)) {
            store.defaultVideoContainer = values[it]; recreate()
        }
    }

    private fun chooseDuplicatePolicy() {
        val values = arrayOf(DuplicatePolicy.RENAME, DuplicatePolicy.REPLACE, DuplicatePolicy.SKIP)
        chooseSingle(getString(R.string.duplicate_policy, duplicateLabel(store.defaultDuplicatePolicy)), values.map(::duplicateLabel).toTypedArray(), values.indexOf(store.defaultDuplicatePolicy)) {
            store.defaultDuplicatePolicy = values[it]; recreate()
        }
    }

    private fun chooseSpeedLimit() {
        val values = intArrayOf(0, 128, 256, 512, 1024, 2048, 5120, 10240, 20480, 51200)
        val labels = values.map { if (it == 0) getString(R.string.unlimited) else getString(R.string.speed_kbps, it) }.toTypedArray()
        chooseSingle(getString(R.string.speed_limit_title), labels, values.indexOf(store.speedLimitKbps)) {
            store.speedLimitKbps = values[it]; recreate()
        }
    }

    private fun chooseParallelDownloads() = chooseInt(
        getString(R.string.parallel_downloads_title), intArrayOf(1, 2, 3), store.maxParallelDownloads
    ) { store.maxParallelDownloads = it; com.nova.downloader.data.DownloadQueueCoordinator.kick(this); recreate() }

    private fun speedLimitLabel(): String = if (store.speedLimitKbps == 0) getString(R.string.unlimited)
        else getString(R.string.speed_kbps, store.speedLimitKbps)

    private fun chooseRequestDelay() = chooseInt(getString(R.string.request_delay, store.requestDelaySeconds), intArrayOf(0, 2, 5, 10, 20, 30), store.requestDelaySeconds) { store.requestDelaySeconds = it; recreate() }
    private fun chooseFragments() = chooseInt(getString(R.string.concurrent_fragments, effectiveFragments()), if (store.memoryMode == AppSettings.MEMORY_SAVER) intArrayOf(1) else intArrayOf(1, 2, 4, 6, 8), effectiveFragments()) { store.concurrentFragments = it; recreate() }

    private fun choosePlayerClient() {
        val values = arrayOf("default", "android_vr", "mweb", "web_safari", "web_embedded")
        chooseSingle(getString(R.string.youtube_client, store.youtubePlayerClient), values, values.indexOf(store.youtubePlayerClient)) { store.youtubePlayerClient = values[it]; recreate() }
    }

    private fun chooseRecoveryPolicy() {
        val values = arrayOf(RecoveryPolicy.MANUAL, RecoveryPolicy.WIFI, RecoveryPolicy.ANY_NETWORK)
        chooseSingle(getString(R.string.settings_recovery_section), values.map(::recoveryLabel).toTypedArray(), values.indexOf(store.recoveryPolicy)) {
            store.recoveryPolicy = values[it]; RecoveryScheduler.schedule(this); recreate()
        }
    }

    private fun choosePetType() {
        val values = PetCatalog.all.map { it.id } + AppSettings.PET_CUSTOM
        val labels = PetCatalog.all.map { getString(it.labelRes) } + getString(R.string.pet_custom_package)
        chooseSingle(getString(R.string.settings_pet_section), labels.toTypedArray(), values.indexOf(store.petType)) {
            store.petType = values[it]; PetIntegration.refreshMaybe(this); recreate()
        }
    }

    private fun choosePetColor() {
        val labels = arrayOf(R.string.pet_color_nova, R.string.pet_color_purple, R.string.pet_color_orange, R.string.pet_color_green, R.string.pet_color_pink, R.string.pet_color_graphite).map(::getString).toTypedArray()
        val values = intArrayOf(Color.rgb(15,112,255), Color.rgb(111,66,193), Color.rgb(255,106,0), Color.rgb(0,160,105), Color.rgb(220,63,135), Color.rgb(58,64,75))
        AlertDialog.Builder(this).setTitle(R.string.color_title).setItems(labels) { _, i -> store.petColor = values[i]; PetIntegration.refreshMaybe(this); recreate() }.show()
    }

    private fun choosePetShell() {
        val values = arrayOf(AppSettings.SHELL_ROUNDED, AppSettings.SHELL_CIRCLE, AppSettings.SHELL_SQUARE, AppSettings.SHELL_OUTLINE)
        chooseSingle(getString(R.string.pet_shell, shellLabel(store.petShell)), values.map(::shellLabel).toTypedArray(), values.indexOf(store.petShell)) {
            store.petShell = values[it]; PetIntegration.refreshMaybe(this); recreate()
        }
    }

    private fun choosePetSize() = chooseInt(getString(R.string.pet_size_title), intArrayOf(50, 75, 100, 125, 150, 175, 200), store.petSizePercent) { store.petSizePercent = it; PetIntegration.refreshMaybe(this); recreate() }
    private fun choosePetOpacity() = chooseInt(getString(R.string.pet_opacity_title), intArrayOf(25, 40, 55, 70, 85, 100), store.petOpacityPercent) { store.petOpacityPercent = it; PetIntegration.refreshMaybe(this); recreate() }

    private fun editSecret(title: String, current: String, save: (String) -> Unit) = editText(title, current, true, save)
    private fun editText(title: String, current: String, secret: Boolean = false, save: (String) -> Unit) {
        val input = EditText(this).apply {
            setText(current); setSelection(text.length)
            if (secret) inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        AlertDialog.Builder(this).setTitle(title).setView(input)
            .setPositiveButton(R.string.save) { _, _ -> save(input.text.toString().trim()); recreate() }
            .setNegativeButton(R.string.cancel, null).show()
    }

    private fun chooseSingle(title: String, labels: Array<String>, selected: Int, action: (Int) -> Unit) {
        AlertDialog.Builder(this).setTitle(title).setSingleChoiceItems(labels, selected.coerceAtLeast(0)) { dialog, index -> action(index); dialog.dismiss() }.show()
    }
    private fun chooseInt(title: String, values: IntArray, current: Int, action: (Int) -> Unit) = chooseSingle(title, values.map(Int::toString).toTypedArray(), values.indexOf(current)) { action(values[it]) }

    private fun openTreePicker() = startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION), REQ_TREE)
    private fun openCookiePicker(platform: String) { pendingCookiePlatform = platform; startActivityForResult(openDoc(arrayOf("text/plain", "application/octet-stream")), REQ_COOKIE) }
    private fun confirmPluginImport() {
        if (BuildConfig.PLAY_STORE_BUILD) return
        AlertDialog.Builder(this).setTitle(R.string.plugin_security_title).setMessage(R.string.plugin_security_message)
            .setPositiveButton(R.string.choose_file) { _, _ -> openPluginPicker() }.setNegativeButton(R.string.cancel, null).show()
    }
    private fun openPluginPicker() = startActivityForResult(openDoc(arrayOf("application/zip", "application/octet-stream")), REQ_PLUGIN)
    private fun openPetPicker() = startActivityForResult(openDoc(arrayOf("image/png", "image/webp", "image/gif", "application/zip", "application/octet-stream")), REQ_PET)
    private fun openDoc(types: Array<String>) = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"; putExtra(Intent.EXTRA_MIME_TYPES, types); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        when (requestCode) {
            REQ_TREE -> { store.defaultTreeUri = StorageHelper.takeTreePermission(this, data); recreate() }
            REQ_COOKIE -> CookieVault.importFromUri(this, uri, pendingCookiePlatform).onSuccess { store.useCookies = true; toast(it); recreate() }.onFailure { toast(it.message ?: getString(R.string.cookie_import_failed)) }
            REQ_PLUGIN -> YtDlpPluginVault.importZip(this, uri).onSuccess { toast(it); recreate() }.onFailure { toast(it.message ?: getString(R.string.plugin_import_failed)) }
            REQ_PET -> CustomPetVault.import(this, uri).onSuccess { toast(it); PetIntegration.startOrRefresh(this); recreate() }.onFailure { toast(it.message ?: getString(R.string.pet_import_failed)) }
        }
    }

    private fun updateLabels() {
        if (::destinationText.isInitialized) destinationText.text = getString(R.string.default_location, StorageHelper.destinationLabel(this, store.defaultTreeUri))
        if (::cookieStatusText.isInitialized) cookieStatusText.text = getString(R.string.loaded_profiles, CookieVault.profileSummary(this))
        if (::petEnabledBox.isInitialized) petEnabledBox.isChecked = store.petEnabled
        if (::summaryText.isInitialized) summaryText.text = getString(
            R.string.settings_summary,
            if (YtDlpPluginVault.hasPlugins(this)) getString(R.string.loaded) else getString(R.string.none),
            if (BuildConfig.HAS_FFMPEG) getString(R.string.engine_flavor_full) else getString(R.string.engine_flavor_lite)
        )
    }

    private fun outputModeLabel() = if (store.defaultOutputMode == YtDlpOptionBuilder.MODE_AUDIO) getString(R.string.audio_only) else getString(R.string.video)
    private fun secretStatus(value: String) = if (value.isBlank()) getString(R.string.not_configured) else getString(R.string.configured)
    private fun duplicateLabel(value: String) = when (value) { DuplicatePolicy.REPLACE -> getString(R.string.duplicate_replace); DuplicatePolicy.SKIP -> getString(R.string.duplicate_skip); else -> getString(R.string.duplicate_rename) }
    private fun recoveryLabel(value: String) = when (value) { RecoveryPolicy.WIFI -> getString(R.string.recovery_wifi); RecoveryPolicy.ANY_NETWORK -> getString(R.string.recovery_any_network); else -> getString(R.string.recovery_manual) }
    private fun petLabel() = if (store.petType == AppSettings.PET_CUSTOM) getString(R.string.pet_custom_package) else getString(PetCatalog.byId(store.petType).labelRes)
    private fun languageLabel(value: String) = when (value) {
        LocaleController.TURKISH -> getString(R.string.language_turkish)
        LocaleController.ENGLISH -> getString(R.string.language_english)
        LocaleController.SWEDISH -> getString(R.string.language_swedish)
        LocaleController.FRENCH -> getString(R.string.language_french)
        LocaleController.SPANISH -> getString(R.string.language_spanish)
        LocaleController.JAPANESE -> getString(R.string.language_japanese)
        LocaleController.CHINESE_SIMPLIFIED -> getString(R.string.language_chinese_simplified)
        LocaleController.GERMAN -> getString(R.string.language_german)
        else -> getString(R.string.language_system)
    }
    private fun memoryModeLabel(value: String) = when (value) { AppSettings.MEMORY_SAVER -> getString(R.string.memory_saver); AppSettings.MEMORY_PERFORMANCE -> getString(R.string.memory_performance); else -> getString(R.string.memory_balanced) }
    private fun effectiveFragments() = when (store.memoryMode) { AppSettings.MEMORY_SAVER -> 1; AppSettings.MEMORY_BALANCED -> store.concurrentFragments.coerceAtMost(2); else -> store.concurrentFragments }
    private fun colorLabel(value: Int) = when (value) { Color.rgb(111,66,193) -> getString(R.string.pet_color_purple); Color.rgb(255,106,0) -> getString(R.string.pet_color_orange); Color.rgb(0,160,105) -> getString(R.string.pet_color_green); Color.rgb(220,63,135) -> getString(R.string.pet_color_pink); Color.rgb(58,64,75) -> getString(R.string.pet_color_graphite); else -> getString(R.string.pet_color_nova) }
    private fun shellLabel(value: String) = when (value) { AppSettings.SHELL_CIRCLE -> getString(R.string.pet_shell_circle); AppSettings.SHELL_SQUARE -> getString(R.string.pet_shell_square); AppSettings.SHELL_OUTLINE -> getString(R.string.pet_shell_outline); else -> getString(R.string.pet_shell_rounded) }

    private fun section(resId: Int) = TextView(this).apply { setText(resId); textSize = 18f; setTypeface(typeface, Typeface.BOLD); setPadding(0, dp(24), 0, dp(5)) }
    private fun infoText(value: String = ""): TextView = TextView(this).apply { text = value; textSize = 12.5f; alpha = .75f; setPadding(0, dp(5), 0, dp(8)) }
    private fun infoText(resId: Int): TextView = infoText(getString(resId))
    private fun actionButton(label: String, action: () -> Unit) = Button(this).apply { text = label; isAllCaps = false; setOnClickListener { action() } }
    private fun check(resId: Int, checked: Boolean, action: (Boolean) -> Unit) = CheckBox(this).apply { setText(resId); isChecked = checked; setOnCheckedChangeListener { _, value -> action(value) } }
    private fun horizontal(first: View, second: View) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        addView(first, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        addView(second, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(8) })
    }
    private fun toast(value: String) = Toast.makeText(this, value, Toast.LENGTH_LONG).show()
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    companion object {
        private const val REQ_TREE = 711
        private const val REQ_COOKIE = 712
        private const val REQ_PLUGIN = 713
        private const val REQ_PET = 714
        const val EXTRA_OPEN_UPDATE = "open_update"
    }
}
