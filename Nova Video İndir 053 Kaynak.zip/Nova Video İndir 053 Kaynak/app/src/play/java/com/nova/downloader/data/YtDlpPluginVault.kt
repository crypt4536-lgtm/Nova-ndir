package com.nova.downloader.data

import android.content.Context
import android.net.Uri
import com.nova.downloader.R
import com.nova.downloader.i18n.AppText
import java.io.File

/** Google Play build: runtime Python plugin installation/execution is intentionally disabled. */
object YtDlpPluginVault {
    fun importZip(context: Context, uri: Uri): Result<String> =
        Result.failure(IllegalStateException(AppText.get(R.string.play_runtime_extensions_disabled)))

    fun pluginDirectory(context: Context): File = File(context.noBackupFilesDir, "yt_dlp_plugins_disabled")
    fun hasPlugins(context: Context): Boolean = false
    fun clear(context: Context): Result<Boolean> = Result.success(true)
}
