package com.nova.downloader.engine

import android.content.Context
import com.nova.downloader.R
import com.nova.downloader.diagnostics.LocalLog
import com.nova.downloader.i18n.AppText
import com.yausername.youtubedl_android.YoutubeDL
import org.json.JSONObject

/**
 * Google Play engine policy: execute only the yt-dlp/EJS/QuickJS payload bundled in the AAB.
 * No stable/nightly engine download, no remote executable replacement and no snapshot rollback
 * to a downloaded binary are performed in the Play variant.
 */
class EngineRecoveryManager(context: Context) {
    private val appContext = context.applicationContext
    private val prefs = appContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private val baseDir = java.io.File(appContext.noBackupFilesDir, "youtubedl-android")
    private val ytdlpDir = java.io.File(baseDir, YoutubeDL.ytdlpDirName)
    private val activeBinary = java.io.File(ytdlpDir, YoutubeDL.ytdlpBin)

    data class OperationResult(val success: Boolean, val message: String, val version: String = "")

    fun ensureUpdated(channel: YoutubeDL.UpdateChannel, maxAgeMs: Long = 0L): OperationResult = bundledStatus()
    fun update(channel: YoutubeDL.UpdateChannel): OperationResult = bundledStatus()
    fun rollback(): OperationResult = OperationResult(false, AppText.get(R.string.engine_no_rollback_snapshot))

    fun restoreBundled(): OperationResult = runCatching {
        if (activeBinary.exists()) activeBinary.delete()
        ytdlpDir.mkdirs()
        YoutubeDL.getInstance().init_ytdlp(appContext, ytdlpDir)
        prefs.edit().putString(KEY_BUNDLED_CHECKPOINT, "053").apply()
        val version = currentVersion()
        markHealthy(version)
        OperationResult(true, AppText.get(R.string.engine_bundled_restored, version), version)
    }.getOrElse { error ->
        LocalLog.error("Engine", "Bundled Play engine restore failed", error)
        OperationResult(false, error.message ?: AppText.get(R.string.engine_bundled_restore_failed))
    }

    fun recordSuccess() {
        runCatching { markHealthy(currentVersion()) }
    }

    fun recordFailure(rawMessage: String, sourceHost: String? = null): String? {
        LocalLog.warn("Engine", "Play bundled engine failure host=${sourceHost.orEmpty()} message=${LocalLog.redact(rawMessage)}")
        return null
    }

    fun statusText(): String {
        val version = runCatching { currentVersion() }.getOrDefault(prefs.getString(KEY_ACTIVE_VERSION, "").orEmpty())
        return AppText.get(R.string.engine_status_format, version.ifBlank { AppText.get(R.string.unknown) }, "bundled-play", 0, 0)
    }

    fun statusJson(): JSONObject = JSONObject().apply {
        put("version", runCatching { currentVersion() }.getOrDefault(""))
        put("lastGoodVersion", prefs.getString(KEY_ACTIVE_VERSION, ""))
        put("channel", "bundled-play")
        put("failureCount", 0)
        put("snapshots", 0)
        put("runtimeUpdatesEnabled", false)
    }

    private fun bundledStatus(): OperationResult = runCatching {
        if (prefs.getString(KEY_BUNDLED_CHECKPOINT, "") != "053") {
            if (activeBinary.exists()) activeBinary.delete()
            ytdlpDir.mkdirs()
            YoutubeDL.getInstance().init_ytdlp(appContext, ytdlpDir)
            prefs.edit().putString(KEY_BUNDLED_CHECKPOINT, "053").apply()
        } else {
            YoutubeDL.getInstance().init(appContext)
        }
        val version = currentVersion()
        markHealthy(version)
        OperationResult(true, AppText.get(R.string.engine_update_recent, version.ifBlank { AppText.get(R.string.unknown) }), version)
    }.getOrElse { error ->
        OperationResult(false, error.message ?: AppText.get(R.string.engine_update_failed))
    }

    private fun currentVersion(): String = YoutubeDL.getInstance().versionName(appContext).orEmpty()
    private fun markHealthy(version: String) {
        prefs.edit().putString(KEY_ACTIVE_VERSION, version).apply()
    }

    companion object {
        private const val PREFS = "nova_engine_recovery"
        private const val KEY_ACTIVE_VERSION = "active_version"
        private const val KEY_BUNDLED_CHECKPOINT = "bundled_checkpoint"
    }
}
