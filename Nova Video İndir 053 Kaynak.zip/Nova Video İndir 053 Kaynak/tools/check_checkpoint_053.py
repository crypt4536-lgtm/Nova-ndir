from pathlib import Path
import sys
root=Path(__file__).resolve().parents[1]
errors=[]
def ok(cond,msg):
    print(("PASS " if cond else "FAIL ")+msg)
    if not cond: errors.append(msg)
g=(root/"app/build.gradle.kts").read_text(encoding="utf-8")
main=(root/"app/src/main/java/com/nova/downloader/ui/MainActivity.kt").read_text(encoding="utf-8")
req=(root/"app/src/main/java/com/nova/downloader/data/YtDlpRequestConfigurator.kt").read_text(encoding="utf-8")
playeng=(root/"app/src/play/java/com/nova/downloader/engine/EngineRecoveryManager.kt").read_text(encoding="utf-8")
indeng=(root/"app/src/independent/java/com/nova/downloader/engine/EngineRecoveryManager.kt").read_text(encoding="utf-8")
playplug=(root/"app/src/play/java/com/nova/downloader/data/YtDlpPluginVault.kt").read_text(encoding="utf-8")
indplug=(root/"app/src/independent/java/com/nova/downloader/data/YtDlpPluginVault.kt").read_text(encoding="utf-8")
ok('val novaVersionName = "0.53"' in g and 'val novaVersionCode = 55' in g and 'val novaCheckpoint = "053"' in g, '053 identity')
ok('Nova Video İndir' in g, 'new artifact brand')
ok('BuildConfig.FLAVOR' not in main and 'R.string.distribution_independent' in main, 'no raw Independent flavor in main UI')
ok('!BuildConfig.PLAY_STORE_BUILD && settings.remoteEjsEnabled' in req, 'remote EJS excluded from Play')
ok('!BuildConfig.PLAY_STORE_BUILD && YtDlpPluginVault.hasPlugins' in req, 'plugin execution excluded from Play')
ok('updateYoutubeDL' not in playeng and 'updateYoutubeDL' in indeng, 'runtime engine updater isolated to Bağımsız')
ok('.py' not in playplug and '.py' in indplug, 'runtime Python plugin loader isolated to Bağımsız')
ok('checkNovaPlayPublicationConfig, checkNovaPlayMergedManifests, exportNovaPlayBundles' in g, 'Play publication gate wired')
ok('Google Play Lite.aab' in g and 'Bağımsız Pro.apk' in g, 'clean distribution filenames')
if errors: sys.exit(1)
