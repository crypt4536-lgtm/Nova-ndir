@echo off
setlocal EnableExtensions
cd /d "%~dp0"

echo ==================================================
echo Nova Indir 0.10.0 - Lite + Pro - Tum Dagitimlar
echo ==================================================
echo.

where java >nul 2>nul
if errorlevel 1 (
  echo [HATA] Java bulunamadi. JDK 17 gerekli.
  pause
  exit /b 1
)
if not exist "%~dp0gradlew.bat" (
  echo [HATA] gradlew.bat bulunamadi.
  pause
  exit /b 1
)
if not exist "%~dp0app\build.gradle.kts" (
  echo [HATA] Android proje dosyasi bulunamadi.
  pause
  exit /b 1
)

echo [1/4] Temiz build...
call "%~dp0gradlew.bat" clean --no-daemon --max-workers=2 --stacktrace --console=plain
if errorlevel 1 goto FAIL

echo.
echo [2/4] Google Play Lite + Pro ve Independent Lite + Pro DEBUG APK...
call "%~dp0gradlew.bat" :app:assembleNovaPlayDebug :app:assembleNovaIndependentDebug -PNOVA_APK_SPLITS=true --no-daemon --max-workers=2 --stacktrace --console=plain
if errorlevel 1 goto FAIL

echo.
echo [3/4] Release AAB + Universal APK...
call "%~dp0gradlew.bat" :app:buildNovaDistributionRelease --no-daemon --max-workers=2 --stacktrace --console=plain
if errorlevel 1 (
  echo.
  echo [UYARI] Release signing yapilandirilmamis veya release build basarisiz.
  echo         Debug APK'lar yine hazir olabilir.
  echo         Production AAB/APK icin release signing bilgileri gerekir.
  goto DONE_DEBUG
)

echo.
echo [4/4] Ciktilar:
echo   Google Play Lite AAB : Nova Indir 0.10.0 Google Play\Nova Indir 0.10.0 Lite.aab
echo   Google Play Pro AAB  : Nova Indir 0.10.0 Google Play\Nova Indir 0.10.0 Pro.aab
echo   Independent Lite APK : Nova Indir 0.10.0 Bagimsiz\Nova Indir 0.10.0 Lite.apk
echo   Independent Pro APK  : Nova Indir 0.10.0 Bagimsiz\Nova Indir 0.10.0 Pro.apk

echo.
echo [OK] Tum release dagitimlari hazir.
pause
exit /b 0

:DONE_DEBUG
echo.
echo [OK] Debug APK'lar hazir. Release signing tamamlaninca 3. adim tekrar calistirilabilir.
pause
exit /b 0

:FAIL
echo.
echo [HATA] Gradle build basarisiz. Yukaridaki Gradle hatasini inceleyin.
pause
exit /b 1
