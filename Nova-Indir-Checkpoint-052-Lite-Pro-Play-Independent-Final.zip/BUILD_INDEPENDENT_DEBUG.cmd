@echo off
setlocal
cd /d "%~dp0"
call "%~dp0gradlew.bat" clean :app:assembleNovaIndependentDebug -PNOVA_APK_SPLITS=true --no-daemon --stacktrace --console=plain
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" exit /b %RC%
echo.
echo Nova Indir Independent Lite + Pro debug APK'lari hazir.
pause
exit /b 0
