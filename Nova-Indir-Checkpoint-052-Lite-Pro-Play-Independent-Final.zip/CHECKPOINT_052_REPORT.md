# Nova İndir Checkpoint 052

Sürüm: `0.10.0-alpha`
versionCode: `54`
Checkpoint: `052`

## Dağıtım matrisi

- Independent Lite: Lite özellik seti, Google Play dışı dağıtım.
- Independent Pro: ticari ana ürün; Lite'ın tüm özelliklerine ek olarak FFmpeg etkin ve gelişmiş medya işleme kapasitesi mevcut.
- Google Play Lite: Lite + Google Play uyumluluk katmanı; Independent-only özellikler kapalı.
- Google Play Pro: Pro + Google Play uyumluluk katmanı; Pro medya yetenekleri korunur, yalnızca Independent-only özellikler kapalı.

## Build çıktıları

Google Play release:
- `Nova İndir 0.10.0 Lite.aab`
- `Nova İndir 0.10.0 Pro.aab`

Independent release:
- `Nova İndir 0.10.0 Lite.apk`
- `Nova İndir 0.10.0 Pro.apk`

Debug test:
- Play Lite / Pro Universal APK
- Independent Lite / Pro Universal APK

## CI

`.github/workflows/nova-build.yml` tek workflow çalıştırmasında debug APK'ları ve release signing secret'ları mevcutsa production AAB/APK çıktılarının tamamını üretir. Her uygulama ayrı, temiz adlandırılmış Actions artifact olarak yüklenir.

## Play kısıtları

Play flavor'ı `HAS_APK_TOOLS=false`, `HAS_SELF_UPDATE=false` ve `HAS_PET_OVERLAY=false` kullanır. Independent flavor bunları etkin tutar.

## Pro farkı

`pro` flavor'ında `HAS_FFMPEG=true`; `lite` flavor'ında `HAS_FFMPEG=false`. Bu nedenle Pro ticari sürüm olarak daha geniş medya işleme kapasitesine sahiptir.
