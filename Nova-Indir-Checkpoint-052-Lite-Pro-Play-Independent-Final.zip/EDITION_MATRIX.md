# Nova İndir Edition Matrix

## Independent Lite
Temel, hafif dağıtım. Google Play politikası nedeniyle özellik kaldırmaz; Lite kapsamındaki özellik setini kullanır.

## Independent Pro
Ticari ana ürün. Lite'ın tüm özelliklerine ek olarak Pro build'de FFmpeg etkinleştirilir ve gelişmiş medya işleme/format dönüşümü için tam motor kullanılır.

## Google Play Lite
Lite edition + Google Play dağıtım kısıtları. Independent-only APK araçları, self-update ve pet overlay gibi özellikler kapalıdır.

## Google Play Pro
Pro edition + Google Play dağıtım kısıtları. Pro'nun FFmpeg tabanlı medya yetenekleri korunur; yalnızca Play flavor'ında dağıtılamayan Independent-only özellikler kapalıdır.

## Artifact policy
- Google Play: Lite + Pro release **AAB**.
- Independent: Lite + Pro release **Universal APK**.
- Debug: Play + Independent Lite/Pro APK test çıktıları.
- Production release signing secrets olmadan Google Play'e yüklenebilir AAB iddiası yapılmaz.
