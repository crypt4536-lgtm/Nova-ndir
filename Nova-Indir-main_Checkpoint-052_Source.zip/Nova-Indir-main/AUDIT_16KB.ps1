﻿param(
    [string]$Root = (Get-Location).Path,
    [string]$PackageRoot = ""
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = "Stop"

$script:ReportLines = New-Object "System.Collections.Generic.List[string]"
$script:PassCount = 0
$script:FailCount = 0
$script:WarnCount = 0
$script:InfoCount = 0
$script:IncompleteCount = 0

function Add-Line {
    param([string]$Text = "")
    [void]$script:ReportLines.Add($Text)
}

function Add-Result {
    param(
        [ValidateSet("PASS", "FAIL", "WARN", "INFO", "INCOMPLETE")]
        [string]$Level,
        [string]$Message
    )

    switch ($Level) {
        "PASS"       { $script:PassCount++ }
        "FAIL"       { $script:FailCount++ }
        "WARN"       { $script:WarnCount++ }
        "INFO"       { $script:InfoCount++ }
        "INCOMPLETE" { $script:IncompleteCount++ }
    }

    Add-Line ("[{0}] {1}" -f $Level, $Message)
    Write-Host ("[{0}] {1}" -f $Level, $Message)
}

function Get-SdkRoot {
    param([string]$ProjectRoot)

    $candidates = New-Object "System.Collections.Generic.List[string]"

    if ($env:ANDROID_SDK_ROOT) {
        [void]$candidates.Add($env:ANDROID_SDK_ROOT)
    }

    if ($env:ANDROID_HOME) {
        [void]$candidates.Add($env:ANDROID_HOME)
    }

    $localProperties = Join-Path $ProjectRoot "local.properties"
    if (Test-Path -LiteralPath $localProperties) {
        $sdkLine = Get-Content -LiteralPath $localProperties |
            Where-Object { $_ -match "^\s*sdk\.dir\s*=" } |
            Select-Object -First 1

        if ($sdkLine) {
            $sdkValue = (($sdkLine -split "=", 2)[1]).Trim()
            $sdkValue = $sdkValue -replace "\\:", ":"
            $sdkValue = $sdkValue -replace "\\\\", "\"
            if ($sdkValue) {
                [void]$candidates.Add($sdkValue)
            }
        }
    }

    if ($env:LOCALAPPDATA) {
        [void]$candidates.Add((Join-Path $env:LOCALAPPDATA "Android\Sdk"))
    }

    foreach ($candidate in $candidates) {
        if ($candidate -and (Test-Path -LiteralPath $candidate)) {
            return (Resolve-Path -LiteralPath $candidate).Path
        }
    }

    return $null
}

function Find-ZipAlign {
    param([string]$SdkRoot)

    if (-not $SdkRoot) {
        return $null
    }

    $buildToolsRoot = Join-Path $SdkRoot "build-tools"
    if (-not (Test-Path -LiteralPath $buildToolsRoot)) {
        return $null
    }

    $matches = Get-ChildItem -LiteralPath $buildToolsRoot -Directory -ErrorAction SilentlyContinue |
        Sort-Object Name -Descending |
        ForEach-Object {
            $candidate = Join-Path $_.FullName "zipalign.exe"
            if (Test-Path -LiteralPath $candidate) {
                Get-Item -LiteralPath $candidate
            }
        }

    return ($matches | Select-Object -First 1)
}

function Find-ReadElf {
    param([string]$SdkRoot)

    if (-not $SdkRoot) {
        return $null
    }

    $searchRoots = @(
        (Join-Path $SdkRoot "ndk"),
        (Join-Path $SdkRoot "ndk-bundle")
    )

    foreach ($searchRoot in $searchRoots) {
        if (Test-Path -LiteralPath $searchRoot) {
            $match = Get-ChildItem -LiteralPath $searchRoot -Recurse -Filter "llvm-readelf.exe" -File -ErrorAction SilentlyContinue |
                Sort-Object FullName -Descending |
                Select-Object -First 1

            if ($match) {
                return $match
            }
        }
    }

    return $null
}

function Find-Java {
    $candidates = New-Object "System.Collections.Generic.List[string]"

    if ($env:JAVA_HOME) {
        [void]$candidates.Add((Join-Path $env:JAVA_HOME "bin\java.exe"))
    }

    $javaCommand = Get-Command "java.exe" -ErrorAction SilentlyContinue
    if ($javaCommand) {
        [void]$candidates.Add($javaCommand.Source)
    }

    if ($env:ProgramFiles) {
        [void]$candidates.Add((Join-Path $env:ProgramFiles "Android\Android Studio\jbr\bin\java.exe"))
    }

    foreach ($candidate in $candidates) {
        if ($candidate -and (Test-Path -LiteralPath $candidate)) {
            return (Get-Item -LiteralPath $candidate)
        }
    }

    return $null
}

function Find-BundleTool {
    param(
        [string]$ProjectRoot,
        [System.IO.FileInfo]$JavaExe
    )

    if (-not $JavaExe) {
        return $null
    }

    $roots = New-Object "System.Collections.Generic.List[string]"
    [void]$roots.Add($ProjectRoot)

    if ($env:USERPROFILE) {
        $gradleBundleToolRoot = Join-Path $env:USERPROFILE ".gradle\caches\modules-2\files-2.1\com.android.tools.build\bundletool"
        if (Test-Path -LiteralPath $gradleBundleToolRoot) {
            [void]$roots.Add($gradleBundleToolRoot)
        }
    }

    if ($env:ProgramFiles) {
        $studioLib = Join-Path $env:ProgramFiles "Android\Android Studio\plugins\android\lib"
        if (Test-Path -LiteralPath $studioLib) {
            [void]$roots.Add($studioLib)
        }
    }

    $jarCandidates = New-Object "System.Collections.Generic.List[System.IO.FileInfo]"

    foreach ($searchRoot in $roots) {
        if (Test-Path -LiteralPath $searchRoot) {
            Get-ChildItem -LiteralPath $searchRoot -Recurse -Filter "bundletool-all*.jar" -File -ErrorAction SilentlyContinue |
                Sort-Object FullName -Descending |
                ForEach-Object { [void]$jarCandidates.Add($_) }

            Get-ChildItem -LiteralPath $searchRoot -Recurse -Filter "bundletool*.jar" -File -ErrorAction SilentlyContinue |
                Sort-Object FullName -Descending |
                ForEach-Object {
                    if ($_.Name -notlike "bundletool-all*.jar") {
                        [void]$jarCandidates.Add($_)
                    }
                }
        }
    }

    foreach ($jar in $jarCandidates) {
        try {
            $null = & $JavaExe.FullName -jar $jar.FullName version 2>$null
            if ($LASTEXITCODE -eq 0) {
                return $jar
            }
        }
        catch {
            # Try the next candidate.
        }
    }

    return $null
}

function Test-ElfMagic {
    param([string]$FilePath)

    $stream = $null
    try {
        $stream = [System.IO.File]::OpenRead($FilePath)
        $buffer = New-Object byte[] 4
        $read = $stream.Read($buffer, 0, 4)

        return (
            $read -eq 4 -and
            $buffer[0] -eq 0x7F -and
            $buffer[1] -eq 0x45 -and
            $buffer[2] -eq 0x4C -and
            $buffer[3] -eq 0x46
        )
    }
    finally {
        if ($stream) {
            $stream.Dispose()
        }
    }
}


function Test-ZipMagic {
    param([string]$FilePath)

    $stream = $null
    try {
        $stream = [System.IO.File]::OpenRead($FilePath)
        $buffer = New-Object byte[] 4
        $read = $stream.Read($buffer, 0, 4)

        return (
            $read -eq 4 -and
            $buffer[0] -eq 0x50 -and
            $buffer[1] -eq 0x4B -and
            (
                ($buffer[2] -eq 0x03 -and $buffer[3] -eq 0x04) -or
                ($buffer[2] -eq 0x05 -and $buffer[3] -eq 0x06) -or
                ($buffer[2] -eq 0x07 -and $buffer[3] -eq 0x08)
            )
        )
    }
    finally {
        if ($stream) {
            $stream.Dispose()
        }
    }
}

function Get-RelativePathText {
    param(
        [string]$BasePath,
        [string]$FullPath
    )

    if ($FullPath.StartsWith($BasePath, [System.StringComparison]::OrdinalIgnoreCase)) {
        return $FullPath.Substring($BasePath.Length).TrimStart([char[]]"\/")
    }

    return $FullPath
}

function Get-AbiFromPath {
    param([string]$RelativePath)

    if ($RelativePath -match "(^|[\\/])(arm64-v8a|x86_64|armeabi-v7a|x86)([\\/]|$)") {
        return $Matches[2]
    }

    return "unknown"
}

function Test-ElfAlignment {
    param(
        [System.IO.FileInfo]$SoFile,
        [string]$RelativePath,
        [string]$Abi,
        [System.IO.FileInfo]$ReadElf
    )

    if (-not (Test-ElfMagic -FilePath $SoFile.FullName)) {
        $leafName = [System.IO.Path]::GetFileName($RelativePath).ToLowerInvariant()
        $knownPayloadNames = @("libpython.zip.so", "libffmpeg.zip.so")

        if ((Test-ZipMagic -FilePath $SoFile.FullName) -and $knownPayloadNames -contains $leafName) {
            Add-Result "PASS" ("Expected youtubedl-android payload ZIP recognized: {0}" -f $RelativePath)
        }
        elseif (Test-ZipMagic -FilePath $SoFile.FullName) {
            Add-Result "WARN" ("Unexpected ZIP payload uses a .so extension: {0}" -f $RelativePath)
        }
        else {
            Add-Result "WARN" ("File ends with .so but is neither ELF nor ZIP: {0}" -f $RelativePath)
        }
        return
    }

    if (-not $ReadElf) {
        Add-Result "INCOMPLETE" ("ELF alignment not checked because llvm-readelf.exe was not found: {0}" -f $RelativePath)
        return
    }

    $readElfOutput = @(& $ReadElf.FullName -lW $SoFile.FullName 2>&1)
    if ($LASTEXITCODE -ne 0) {
        Add-Result "FAIL" ("llvm-readelf failed for: {0}" -f $RelativePath)
        Add-Line (($readElfOutput | Out-String).TrimEnd())
        return
    }

    $loadLines = @($readElfOutput | Where-Object { $_ -match "^\s*LOAD\s+" })
    if ($loadLines.Count -eq 0) {
        Add-Result "FAIL" ("No ELF LOAD segments found: {0}" -f $RelativePath)
        return
    }

    $minimumAlignment = [Int64]::MaxValue
    $invalidAlignmentText = $false

    foreach ($loadLine in $loadLines) {
        $tokens = @($loadLine.Trim() -split "\s+")
        if ($tokens.Count -lt 2) {
            $invalidAlignmentText = $true
            continue
        }

        $alignToken = $tokens[$tokens.Count - 1]
        if ($alignToken -match "^0x[0-9A-Fa-f]+$") {
            $alignment = [Convert]::ToInt64($alignToken.Substring(2), 16)
            if ($alignment -lt $minimumAlignment) {
                $minimumAlignment = $alignment
            }
        }
        else {
            $invalidAlignmentText = $true
        }
    }

    if ($invalidAlignmentText -or $minimumAlignment -eq [Int64]::MaxValue) {
        Add-Result "INCOMPLETE" ("Could not parse every LOAD alignment value: {0}" -f $RelativePath)
        Add-Line (($loadLines | Out-String).TrimEnd())
        return
    }

    $minimumHex = ("0x{0:X}" -f $minimumAlignment)

    if ($Abi -eq "arm64-v8a" -or $Abi -eq "x86_64") {
        if ($minimumAlignment -ge 0x4000) {
            Add-Result "PASS" ("ELF 16 KB alignment OK ({0}): {1}" -f $minimumHex, $RelativePath)
        }
        else {
            Add-Result "FAIL" ("ELF alignment is below 16 KB ({0}): {1}" -f $minimumHex, $RelativePath)
        }
    }
    else {
        Add-Result "INFO" ("ELF alignment for non-64-bit or unknown ABI is {0}: {1}" -f $minimumHex, $RelativePath)
    }
}

function Test-AabBundleConfig {
    param(
        [System.IO.FileInfo]$AabFile,
        [System.IO.FileInfo]$JavaExe,
        [System.IO.FileInfo]$BundleTool
    )

    if (-not $JavaExe -or -not $BundleTool) {
        Add-Result "INCOMPLETE" ("AAB PAGE_ALIGNMENT flag was not checked because executable bundletool was not found: {0}" -f $AabFile.FullName)
        return
    }

    $bundleArgument = "--bundle={0}" -f $AabFile.FullName
    $output = @(& $JavaExe.FullName -jar $BundleTool.FullName dump config $bundleArgument 2>&1)

    if ($LASTEXITCODE -ne 0) {
        Add-Result "INCOMPLETE" ("bundletool dump config failed: {0}" -f $AabFile.FullName)
        Add-Line (($output | Out-String).TrimEnd())
        return
    }

    $text = $output | Out-String
    if ($text -match "PAGE_ALIGNMENT_16K") {
        Add-Result "PASS" ("AAB requests PAGE_ALIGNMENT_16K: {0}" -f $AabFile.FullName)
    }
    elseif ($text -match "PAGE_ALIGNMENT_4K") {
        Add-Result "FAIL" ("AAB requests PAGE_ALIGNMENT_4K: {0}" -f $AabFile.FullName)
    }
    else {
        Add-Result "INCOMPLETE" ("AAB page alignment flag was not present in bundletool output: {0}" -f $AabFile.FullName)
        Add-Line ($text.TrimEnd())
    }
}

function Test-ApkZipAlignment {
    param(
        [System.IO.FileInfo]$ApkFile,
        [System.IO.FileInfo]$ZipAlign
    )

    if (-not $ZipAlign) {
        Add-Result "INCOMPLETE" ("APK ZIP alignment not checked because zipalign.exe was not found: {0}" -f $ApkFile.FullName)
        return
    }

    $output = @(& $ZipAlign.FullName -c -P 16 -v 4 $ApkFile.FullName 2>&1)
    if ($LASTEXITCODE -eq 0) {
        Add-Result "PASS" ("APK ZIP alignment is valid for 16 KB pages: {0}" -f $ApkFile.FullName)
    }
    else {
        Add-Result "FAIL" ("APK ZIP alignment check failed: {0}" -f $ApkFile.FullName)
        Add-Line (($output | Out-String).TrimEnd())
    }
}

function Inspect-Package {
    param(
        [System.IO.FileInfo]$PackageFile,
        [System.IO.FileInfo]$ReadElf
    )

    Add-Line
    Add-Line ("PACKAGE: {0}" -f $PackageFile.FullName)
    Add-Line ("SIZE: {0} bytes" -f $PackageFile.Length)

    $tempRoot = Join-Path ([System.IO.Path]::GetTempPath()) ("Nova16K_" + [Guid]::NewGuid().ToString("N"))

    try {
        [System.IO.Directory]::CreateDirectory($tempRoot) | Out-Null
        [System.IO.Compression.ZipFile]::ExtractToDirectory($PackageFile.FullName, $tempRoot)

        $soFiles = @(Get-ChildItem -LiteralPath $tempRoot -Recurse -Filter "*.so" -File -ErrorAction SilentlyContinue)
        if ($soFiles.Count -eq 0) {
            Add-Result "INFO" ("No .so files found in package: {0}" -f $PackageFile.Name)
            return
        }

        Add-Result "INFO" ("Native library count: {0}" -f $soFiles.Count)

        foreach ($soFile in $soFiles) {
            $relativePath = Get-RelativePathText -BasePath $tempRoot -FullPath $soFile.FullName
            $abi = Get-AbiFromPath -RelativePath $relativePath
            Test-ElfAlignment -SoFile $soFile -RelativePath $relativePath -Abi $abi -ReadElf $ReadElf
        }
    }
    catch {
        Add-Result "FAIL" ("Could not inspect package {0}: {1}" -f $PackageFile.FullName, $_.Exception.Message)
    }
    finally {
        if (Test-Path -LiteralPath $tempRoot) {
            Remove-Item -LiteralPath $tempRoot -Recurse -Force -ErrorAction SilentlyContinue
        }
    }
}

try {
    Add-Type -AssemblyName "System.IO.Compression.FileSystem"

    $resolvedRoot = (Resolve-Path -LiteralPath $Root).Path
    $resolvedPackageRoot = if ([string]::IsNullOrWhiteSpace($PackageRoot)) {
        $resolvedRoot
    } else {
        (Resolve-Path -LiteralPath $PackageRoot).Path
    }
    $buildGradle = Join-Path $resolvedRoot "app\build.gradle.kts"
    $artifactVersion = "0.10.0"
    if (Test-Path -LiteralPath $buildGradle) {
        $gradleText = Get-Content -LiteralPath $buildGradle -Raw
        $versionMatch = [regex]::Match($gradleText, 'val\s+novaVersionName\s*=\s*"([^"]+)"')
        if ($versionMatch.Success) { $artifactVersion = ($versionMatch.Groups[1].Value -split '-')[0] }
    }
    $reportPath = Join-Path $resolvedRoot ("Nova Indir {0} 16KB Audit Report.txt" -f $artifactVersion)

    Add-Line "NOVA INDIR 038 - 16 KB PAGE SIZE AUDIT"
    Add-Line ("DATE: {0}" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss zzz"))
    Add-Line ("PROJECT ROOT: {0}" -f $resolvedRoot)
    Add-Line ("PACKAGE ROOT: {0}" -f $resolvedPackageRoot)
    Add-Line

    $sdkRoot = Get-SdkRoot -ProjectRoot $resolvedRoot
    if ($sdkRoot) {
        Add-Result "INFO" ("Android SDK: {0}" -f $sdkRoot)
    }
    else {
        Add-Result "INCOMPLETE" "Android SDK root was not found."
    }

    $zipAlign = Find-ZipAlign -SdkRoot $sdkRoot
    if ($zipAlign) {
        Add-Result "INFO" ("zipalign: {0}" -f $zipAlign.FullName)
    }
    else {
        Add-Result "INCOMPLETE" "zipalign.exe was not found. Install Android SDK Build-Tools 35.0.0 or newer."
    }

    $readElf = Find-ReadElf -SdkRoot $sdkRoot
    if ($readElf) {
        Add-Result "INFO" ("llvm-readelf: {0}" -f $readElf.FullName)
    }
    else {
        Add-Result "INCOMPLETE" "llvm-readelf.exe was not found. Install an Android NDK in SDK Manager."
    }

    $javaExe = Find-Java
    if ($javaExe) {
        Add-Result "INFO" ("Java: {0}" -f $javaExe.FullName)
    }
    else {
        Add-Result "INCOMPLETE" "java.exe was not found."
    }

    $bundleTool = Find-BundleTool -ProjectRoot $resolvedRoot -JavaExe $javaExe
    if ($bundleTool) {
        Add-Result "INFO" ("bundletool: {0}" -f $bundleTool.FullName)
    }
    else {
        Add-Result "INCOMPLETE" "An executable bundletool JAR was not found. AAB PAGE_ALIGNMENT flag check will be skipped."
    }

    Add-Line
    Add-Line "PACKAGE DISCOVERY"

    $allPackages = @(
        Get-ChildItem -LiteralPath $resolvedPackageRoot -Recurse -File -ErrorAction SilentlyContinue |
            Where-Object {
                ($_.Extension -ieq ".aab" -or $_.Extension -ieq ".apk") -and
                $_.FullName -notmatch "[\\/]intermediates[\\/]" -and
                $_.FullName -notmatch "[\\/]\.gradle[\\/]"
            } |
            Sort-Object FullName
    )

    if ($allPackages.Count -eq 0) {
        Add-Result "FAIL" "No APK or AAB files were found under the project root."
    }
    else {
        Add-Result "INFO" ("APK/AAB file count before duplicate filtering: {0}" -f $allPackages.Count)

        $seenHashes = @{}
        $uniquePackages = New-Object "System.Collections.Generic.List[System.IO.FileInfo]"

        foreach ($package in $allPackages) {
            try {
                $hash = (Get-FileHash -LiteralPath $package.FullName -Algorithm SHA256).Hash
                if (-not $seenHashes.ContainsKey($hash)) {
                    $seenHashes[$hash] = $package.FullName
                    [void]$uniquePackages.Add($package)
                }
                else {
                    Add-Result "INFO" ("Duplicate package skipped: {0}" -f $package.FullName)
                }
            }
            catch {
                Add-Result "WARN" ("Could not hash package, inspecting anyway: {0}" -f $package.FullName)
                [void]$uniquePackages.Add($package)
            }
        }

        Add-Result "INFO" ("Unique APK/AAB file count: {0}" -f $uniquePackages.Count)

        foreach ($package in $uniquePackages) {
            Inspect-Package -PackageFile $package -ReadElf $readElf

            if ($package.Extension -ieq ".apk") {
                Test-ApkZipAlignment -ApkFile $package -ZipAlign $zipAlign
            }
            elseif ($package.Extension -ieq ".aab") {
                Test-AabBundleConfig -AabFile $package -JavaExe $javaExe -BundleTool $bundleTool
            }
        }
    }

    Add-Line
    Add-Line "SUMMARY"
    Add-Line ("PASS: {0}" -f $script:PassCount)
    Add-Line ("FAIL: {0}" -f $script:FailCount)
    Add-Line ("WARN: {0}" -f $script:WarnCount)
    Add-Line ("INCOMPLETE: {0}" -f $script:IncompleteCount)
    Add-Line ("INFO: {0}" -f $script:InfoCount)

    if ($script:FailCount -gt 0) {
        $overall = "FAIL"
    }
    elseif ($script:IncompleteCount -gt 0) {
        $overall = "INCOMPLETE"
    }
    elseif ($script:WarnCount -gt 0) {
        $overall = "WARNING"
    }
    else {
        $overall = "PASS"
    }

    Add-Line ("OVERALL RESULT: {0}" -f $overall)
    Add-Line
    Add-Line "Interpretation:"
    Add-Line "- PASS means every available mandatory check passed."
    Add-Line "- FAIL means at least one confirmed 16 KB compatibility problem was found."
    Add-Line "- INCOMPLETE means a required tool or verification step was unavailable."
    Add-Line "- WARN means an unknown or suspicious non-blocking package entry was found."
    Add-Line "- Known libpython.zip.so and libffmpeg.zip.so payload archives are validated as ZIP and counted as PASS."

    $script:ReportLines | Set-Content -LiteralPath $reportPath -Encoding UTF8

    Write-Host
    Write-Host ("OVERALL RESULT: {0}" -f $overall)
    Write-Host ("REPORT: {0}" -f $reportPath)

    # Do not call exit here. Keeping the Android Studio PowerShell terminal open
    # is more useful than returning a process exit code.
}
catch {
    Write-Error ("Audit script failed: {0}" -f $_.Exception.Message)
}
