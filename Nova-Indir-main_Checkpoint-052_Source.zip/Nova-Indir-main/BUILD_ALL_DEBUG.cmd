@echo off
setlocal
cd /d "%~dp0"
call "%~dp0gradlew.bat" clean :app:assembleNovaPlayDebug :app:assembleNovaIndependentDebug --stacktrace --console=plain
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" exit /b %RC%
echo.
echo All Checkpoint 042 debug variants are ready. Gradle printed the clean output folders above.
exit /b 0
