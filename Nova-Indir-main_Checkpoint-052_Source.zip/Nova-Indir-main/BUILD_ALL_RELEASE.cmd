@echo off
setlocal
cd /d "%~dp0"
call "%~dp0BUILD_PLAY_AAB_AND_INDEPENDENT_APK.cmd"
exit /b %ERRORLEVEL%
