@echo off
setlocal
cd /d "%~dp0"
echo Building Nova 042: Google Play AAB + Independent signed APK...
call "%~dp0gradlew.bat" clean :app:buildNovaDistributionRelease --no-daemon --stacktrace --console=plain
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" exit /b %RC%
echo.
echo READY - clean versioned output folders were printed by Gradle above.
exit /b 0
