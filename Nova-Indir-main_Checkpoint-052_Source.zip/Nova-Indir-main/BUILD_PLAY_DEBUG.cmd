@echo off
setlocal
cd /d "%~dp0"
call "%~dp0gradlew.bat" clean :app:assembleNovaPlayDebug --stacktrace --console=plain
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" exit /b %RC%
echo.
echo Play debug APKs are ready. Gradle printed the clean output folder above.
exit /b 0
