@echo off
setlocal
cd /d "%~dp0"
call "%~dp0VERIFY_PLAY_RELEASE.cmd"
exit /b %ERRORLEVEL%
