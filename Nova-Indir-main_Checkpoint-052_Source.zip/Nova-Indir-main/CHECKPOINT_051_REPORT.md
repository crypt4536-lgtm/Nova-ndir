# Nova İndir Checkpoint 051 Raporu

Sürüm: `0.10.0-alpha`  
versionCode: `53`  
Checkpoint: `051`

## Media3 runtime düzeltmesi
Release/minify sonrası XML ile inflate edilen Media3 view sınıflarının constructor yolları R8 tarafından bozulabildiği için `AspectRatioFrameLayout`, `PlayerView`, `PlayerControlView` constructor keep kuralları ve `androidx.media3.ui.**` keep kuralı eklendi.

## Dağıtım hattı
GitHub Actions `contents: write` iznine geçirildi. APK/AAB sonuçları GitHub Release varlıklarına da yüklenir. Actions `upload-artifact` adımları kota hatasında build sonucunu tek başına kırmaması için `continue-on-error: true` kullanır. Kaynak geçişinin `.github/NOVA_BUILD_NOW` marker commit'i tüm dağıtım build'ini başlatır.
