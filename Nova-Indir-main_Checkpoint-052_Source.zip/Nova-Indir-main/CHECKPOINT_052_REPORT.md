# Nova İndir Checkpoint 052 Raporu

## Yapılan değişiklikler

- Media3 ExoPlayer/UI: `1.10.1` → `1.11.0`.
- Platform desteği: X, Threads, Bluesky, Mastodon, Telegram.
- Platform URL algılama, extractor yönlendirmesi, hesap profili etiketleri, giriş sayfaları ve browser-cookie probe yolları güncellendi.
- Media3 XML view constructor keep kuralları ve `androidx.media3.ui.**` keep kuralı korundu.

## Doğrulama

Android Developers Media3 1.11.0'ın 5 Ağustos 2026'da stable olduğunu doğruluyor. citeturn0search0

Bu çalışma ortamında:
- `clean assembleIndependentProDebug` komutu başlatıldı.
- Gradle Wrapper Gradle 8.13'ü indirmeye çalıştı ancak çalışma ortamında `services.gradle.org` DNS/ağ erişimi yoktu.
- Bu nedenle APK derleme, gerçek cihaz kurulumu ve gerçek cihazda `AspectRatioFrameLayout` runtime testi burada tamamlanamadı.
- Kaynak seviyesinde `AspectRatioFrameLayout` keep kuralları mevcut ve PlayerActivity doğrudan `PlayerView` oluşturuyor.

## Kullanılacak yerel komutlar

```powershell
.\gradlew.bat clean
.\gradlew.bat assembleIndependentProDebug
.\gradlew.bat assembleIndependentLiteDebug assembleIndependentProDebug assemblePlayLiteDebug assemblePlayProDebug
```

Release dağıtımı için mevcut proje akışı:
```powershell
.\BUILD_PLAY_AAB_AND_INDEPENDENT_APK.cmd
```
