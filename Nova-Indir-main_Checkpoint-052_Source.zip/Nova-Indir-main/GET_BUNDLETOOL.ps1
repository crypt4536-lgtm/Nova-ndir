﻿param(
    [string]$Version = "1.18.3"
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = "Stop"
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$target = Join-Path (Get-Location) ("bundletool-all-{0}.jar" -f $Version)
if (Test-Path -LiteralPath $target) {
    Write-Host ("Already present: {0}" -f $target)
    return
}

$url = "https://github.com/google/bundletool/releases/download/{0}/bundletool-all-{0}.jar" -f $Version
Invoke-WebRequest -Uri $url -OutFile $target
Write-Host ("Downloaded: {0}" -f $target)
