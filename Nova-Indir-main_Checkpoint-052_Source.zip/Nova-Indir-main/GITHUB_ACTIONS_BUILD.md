# Nova İndir - GitHub Actions ile PC'siz Derleme

Checkpoint 050 ile `.github/workflows/nova-build.yml` eklendi.

## GitHub Secrets

Repository > Settings > Secrets and variables > Actions > Secrets altında:

- `NOVA_KEYSTORE_B64` - Kalıcı Nova release keystore dosyasının Base64 içeriği.
- `NOVA_KEY_ALIAS`
- `NOVA_STORE_PASSWORD`
- `NOVA_KEY_PASSWORD`
- `NOVA_UPDATE_PUBLIC_KEY_B64` - kullanılıyorsa.

Windows PowerShell'de mevcut keystore'u Base64'e çevirmek için örnek:

```powershell
[Convert]::ToBase64String([IO.File]::ReadAllBytes("D:\NovaSigning\NovaIndirRelease.p12")) | Set-Clipboard
```

Çıktıyı `NOVA_KEYSTORE_B64` secret'ına yapıştırın. Keystore dosyasının kendisini repoya koymayın.

## GitHub Variables

Repository > Settings > Secrets and variables > Actions > Variables altında ihtiyaca göre:

- `NOVA_PLAY_PRIVACY_URL`
- `NOVA_INDEPENDENT_PRIVACY_URL`
- `NOVA_UPDATE_MANIFEST_URL_FULL`
- `NOVA_UPDATE_MANIFEST_URL_LITE`
- `NOVA_PLAY_DISPENSER_URL`

## Telefondan derleme

1. GitHub'da Nova deposunu açın.
2. Actions > `Nova İndir Dağıtım Derlemesi` seçin.
3. `Run workflow` seçin.
4. Varsayılan `tümü` seçeneği dört resmi çıktıyı üretir.
5. İş bitince workflow sayfasındaki Artifacts bölümünden iki paketi indirin.

Beklenen içerik:

```text
Nova İndir 0.10.0 Google Play
├─ Nova İndir 0.10.0 Lite.aab
└─ Nova İndir 0.10.0 Pro.aab

Nova İndir 0.10.0 Bağımsız
├─ Nova İndir 0.10.0 Lite.apk
└─ Nova İndir 0.10.0 Pro.apk
```

Aynı kalıcı release keystore kullanıldığı sürece Bağımsız APK güncelleme imza zinciri korunur.
