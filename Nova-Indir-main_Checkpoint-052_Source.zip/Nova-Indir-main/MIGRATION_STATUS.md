# Nova İndir GitHub Geçiş Durumu

Tarih: 2026-08-10

## Kanonik hedef
- Checkpoint 051
- 0.10.0-alpha
- versionCode 53
- Yeni depo: `crypt4536-lgtm/Nova-Indir`

## Tamamlananlar
- Yeni depoda admin/push erişimi doğrulandı.
- Depo private olarak doğrulandı.
- Yüklenen devir ZIP'i açıldı ve SHA/teslim yapısı incelendi.
- Fiziksel Checkpoint 050 kaynak snapshot'ı açıldı: 266 dosya, yaklaşık 4.5 MB.
- Checkpoint 051 delta'sı devir kaydından yerelde yeniden uygulandı.
- Yerel statik 051 doğrulaması 10/10 geçti: versionCode 53, checkpoint 051, Media3 keep kuralları, contents: write, Release fallback ve non-fatal artifact upload koşulları doğrulandı.
- `CHECKPOINT_051_REPORT.md` yeni depoya taşındı.
- `migration/CHECKPOINT_051_DELTA.md` yeni depoya eklendi.
- Eksiksiz hafıza/devir kaydı yeni depoya eklendi.
- README kanonik 051 durumunu gösterecek şekilde güncellendi.

## Kaynak aktarım durumu
Checkpoint 050 tam kaynak ağacı yerelde hazırdır. Bağlı GitHub connector'ında klasör/binary dosyaları yerel yoldan toplu yükleyen bir eylem bulunmadığı için 266 dosyalık ağacın birebir aktarımı henüz tamamlanmadı. Kaynak hiçbir üçüncü taraf dosya servisine yüklenmedi.

Özellikle iki büyük tasarım kaynağı (`logo-source.png`, `launcher-icon-source.png`) ile Android PNG/mipmap kaynakları binary aktarım gerektirir. Bunlar atlanmış sayılmamalıdır; tam geçiş tamamlanmadan depo "eksiksiz kaynak" olarak işaretlenmeyecektir.

## Sıradaki zorunlu işler
1. 050 kaynak ağacının tüm text + binary dosyalarını GitHub'a birebir aktar.
2. 051 delta'sını gerçek repo kaynaklarına uygula.
3. Statik Checkpoint 051 doğrulayıcıyı çalıştır.
4. Release fallback CI'ını çalıştır ve Play AAB + Independent Universal APK üret.
5. Signing secrets/variables'ı yeni repo üzerinde güvenli biçimde tanımla; hiçbir secret kaynak ağacına yazılmamalı.
6. İmza, checksum, çıktı varlığı/boyutu ve 16 KB page-size denetimlerini yap.
7. Gerçek cihazda Nova Player Media3 XML inflation smoke testi yap.
8. Başarıdan sonra yeni checkpoint ve güncel eksiksiz hafıza/devir teslimi üret.
