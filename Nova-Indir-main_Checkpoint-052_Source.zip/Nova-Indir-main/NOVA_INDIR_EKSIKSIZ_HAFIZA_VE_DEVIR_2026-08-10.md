# NOVA İNDİR EKSİKSİZ HAFIZA VE DEVİR DOSYASI

Tarih: 2026-08-10
Kanonik son durum: Checkpoint 051, 0.10.0-alpha, versionCode 53.
Yeni hedef depo: crypt4536-lgtm/Nova-Indir. Eski depo: darktekken-hub/Nova-Indir.

## Teslimdeki kaynak gerçeği
Bu devir paketindeki fiziksel en son TAM kaynak arşivi Checkpoint 050'dir. Checkpoint 051 ve son CI değişiklikleri eski özel GitHub deposuna commit edilmişti; hesap değişiminden sonra o depoya erişim kesildiği için 051'in tam repo snapshot'ı fiziksel olarak alınamadı. 051 delta'ları yeni depoda 050 üzerine yeniden uygulanmalıdır.

## Proje amacı ve kanonik mimari
Nova İndir Android medya çözümleme, indirme, zamanlama, dosya yönetimi ve Nova Player oynatma uygulamasıdır. Tek kaynak ağacından play/independent × lite/pro varyantları üretilir. Google Play hattının ana çıktısı AAB, bağımsız hattın ana çıktısı imzalı Universal APK'dır. Play ve bağımsız yetenek farkları flavor/build yapılandırmasıyla ayrılmalıdır. PC olmadan GitHub Actions üzerinden tam dağıtım hedefi kanoniktir.

## Teknik taban
Checkpoint 034 itibarıyla AGP 8.13.2, Gradle 8.13, Kotlin 2.3.21, Java 17, compileSdk/targetSdk 36 kullanıldı. Play hattında 16 KB page-size uyumluluk denetimleri kuruldu. Son Media3 hattında media3-exoplayer 1.10.1 ve media3-ui 1.10.1 kullanıldı.

## Kronolojik geçmiş
- 032 ve öncesi: 0.9.x alpha temel indirme/çözümleme, Android proje yapısı, lila-mavi glossy görsel hat ve compile düzeltmeleri.
- 033-036: Google Play AAB hattı, APK/AAB ayrımı, 16 KB uyumluluk, modern build zinciri. 034'te AGP/Gradle/Kotlin/Java/SDK tabanı doğrulandı; 035-036 Play kaynak ve Gradle compile düzeltmeleri.
- 037: çift dağıtım mimarisi, uygulama adı/ikon/tema ve varyant düzenlemeleri; 0.9.0-alpha, versionCode 38.
- 038: Play/Bağımsız yayın hazırlığı ve Windows CMD build düzeltmeleri; 0.9.0-alpha, versionCode 39; AAB + Independent APK üretimi doğrulandı.
- 039: signing ve çift dağıtım tamamlandı; 0.9.0, versionCode 40. GitHub Actions Run #6 başarılı; Independent ve Play release çıktıları üretildi.
- 040: 0.10.0-alpha, versionCode 42. Hemen başlat gerçek enqueue çağrısına bağlandı; zamanlama, çift tıklama ve null ses dili düzeltildi. Play=AAB, bağımsız=imzalı Universal APK ilkesi korundu.
- 041: versionCode 43. Anonim yt-dlp profil zinciri, platform fallback, başarılı profil metadata kaydı. Private/members-only kapıları zorlanmaz.
- 042: temiz sürüm/çıktı adlandırma.
- 044: doğru dosya konumu düzeltmesi.
- 045: versionCode 47. İndirme eylemi sabit alana taşındı; ScrollView, görünür İndir/Zamanla/İptal ve çift tıklama önleme.
- 046: temiz varsayılan dosya adı.
- 047: dijital evcil hayvan hareketleri/arayüz davranışları.
- 048: versionCode 50. Nova Player URI/MIME/başlık aktarımı, hata dayanıklılığı ve yeniden adlandırma UI düzeltmesi.
- 049: versionCode 51. Paralel log/fallback logger, kalıcı diagnostics ZIP, Media3 öncesi URI okunabilirlik doğrulaması, MIME zorlamasını kaldırma, hata kodu ve kopyalama.
- 050: versionCode 52. GitHub Actions PC'siz dağıtım kaynağı. Fiziksel tam kaynak snapshot'ı budur.
- 051: versionCode 53. Media3 runtime hatası teşhis edilip R8/XML constructor koruması eklendi. CHECKPOINT_051_REPORT.md yeniden oluşturuldu.

## Checkpoint 051 Media3 kök nedeni
Run #7 compile/dağıtım üretimi açısından başarılı olmasına rağmen gerçek cihazda SETUP_InflateException oluştu: layout/exo_player_view içindeki androidx.media3.ui.AspectRatioFrameLayout inflate edilemedi. Diagnostics ZIP en iç nedeni kesinleştirdi: java.lang.NoSuchMethodException: androidx.media3.ui.AspectRatioFrameLayout.<init>(Context, AttributeSet). Bu yt-dlp, video indirme veya dosya bütünlüğü sorunu değildi; release/minify sonrası XML reflection constructor yolu bozulmuştu.

Kanonik düzeltme `migration/CHECKPOINT_051_DELTA.md` içinde eksiksiz korunmaktadır. Genel View constructor keep kuralı tek başına yeterli kabul edilmemelidir. Release sonrası yalnız assembleRelease SUCCESS değil, Media3 XML inflation/runtime smoke test de doğrulanmalıdır. Eski depodaki Media3 düzeltme commit'i: 7308082a578c647169ef13297fd3aa4073d4585c.

## Checkpoint 051 dağıtım ve kota olayı
Run #10, run ID 31412252970: Gradle BUILD SUCCESSFUL in 17m 6s; Play AAB ve bağımsız APK'lar üretildi. Workflow kırmızısının nedeni build değil artifact upload kotasıydı: Failed to CreateArtifact: Artifact storage quota has been hit. Google Play artifact upload hata verince Independent upload adımı skipped oldu.

CI çözümü: workflow'a contents: write; APK/AAB'ları GitHub Release varlıklarına yükleme; Actions upload-artifact adımlarını continue-on-error: true yapma. Workflow düzeltme commit'i 85493d747cc5494a0df3b31558d567413202ad8b. Tetikleyici commit 96d657c4beb7d9548edee1dc683a505118e418e0. Run #11, run ID 31414293404, Checkpoint 051 için başlatıldı; eski devirde nihai sonucu doğrulanmadı.

## Yeni depodaki geçiş durumu
GitHub bağlantısı crypt4536-lgtm/Nova-Indir üzerinde admin/push yetkisiyle doğrulandı. Yeni depo private durumdadır. MIGRATION_STATUS.md, CHECKPOINT_051_REPORT.md ve migration/CHECKPOINT_051_DELTA.md yeni depoya yazıldı. Fiziksel Checkpoint 050 kaynak snapshot'ı 266 dosya ve yaklaşık 4.5 MB açılmış ağaç olarak doğrulandı. Bağlayıcının toplu/binary klasör yükleme eylemi bulunmadığından kaynak ağacının tamamının GitHub'a birebir aktarımı bu aşamada tamamlanmış değildir; hiçbir üçüncü taraf dosya servisi kullanılmamıştır.

## Açık işler ve plan
1. Checkpoint 050 tam kaynak ağacını yeni depoya birebir aktar.
2. Checkpoint 051 delta'sını kaynak üzerinde uygula ve versionCode 53/checkpoint 051 metadata'sını doğrula.
3. GitHub Release fallback'li CI'ı etkinleştir: contents: write, Release assets, artifact upload non-fatal, Play ve Independent upload birbirinden bağımsız.
4. Signing/secrets'i yeni repo Secrets üzerinden yeniden tanımla; gizli anahtar/parola kaynak koduna commit edilmemeli.
5. Tam play/independent × lite/pro dağıtım build'i çalıştır. Play AAB, bağımsız imzalı Universal APK.
6. Çıktı dosya varlığı, boyut, imza, checksum ve 16 KB denetimini doğrula.
7. Bağımsız Pro release APK'yı gerçek cihazda test et. AspectRatioFrameLayout(Context, AttributeSet), Nova Player MP4 açma, URI okunabilirlik, MIME, başlık ve hata ekranını doğrula.
8. Build success ve distribution success ayrı raporlanmalı. Artifact kota hatası warning olmalı.
9. Media3 constructor/XML inflation smoke testi CI'a eklenmeli.
10. Diagnostics ZIP altyapısı korunmalı ve gizli/kişisel veri sızdırmadığı denetlenmeli.
11. yt-dlp anonim profil/fallback zinciri ve private/members-only kapıları zorlamama davranışı regresyon testleriyle korunmalı.
12. Dosya adlandırma, doğru kayıt konumu, yeniden adlandırma ve sabit İndir/Zamanla/İptal kontrolleri regresyon testine bağlanmalı.
13. Lite/Pro ve Play/Independent flavor farkları dokümante edilip CI matrisinde test edilmeli.

## Devir ilkesi
Bu kayıt özet amaçlı değildir; projenin devamı için kanonik hafıza/devir kaydıdır. Yeni teslimlerde geçmiş, başarısız denemeler, hata kök nedenleri, commit/run kimlikleri, yapılanlar, yapılmayanlar ve planlananlar silinmeden ileri taşınmalı; son proje kaynağı da teslim paketinin içinde bulunmalıdır.
