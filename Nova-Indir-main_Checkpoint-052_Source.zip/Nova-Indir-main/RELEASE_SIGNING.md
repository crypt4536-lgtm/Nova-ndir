# Nova İndir 041 — Release Signing

Checkpoint 041'ta release çıktılarının imzasız oluşmasına izin verilmez. Google Play AAB ve bağımsız APK aynı kullanıcıya ait kalıcı release/upload anahtarını kullanabilir.

## En kolay kurulum

Kaynak klasöründe bir kez çalıştırın:

```powershell
.\SETUP_RELEASE_SIGNING.cmd
```

Betik yeni anahtar seçilirse varsayılan olarak şunları oluşturur:

```text
D:\NovaSigning\NovaIndirRelease.p12
%USERPROFILE%\.nova-indir\release.properties
```

`release.properties` parola içerdiği için özel tutulmalıdır. Bu dosya ve keystore kaynak ZIP'ine dahil edilmez. İkisini birlikte güvenli biçimde yedekleyin. Bağımsız APK'nın gelecekteki güncellemeleri aynı anahtarla imzalanmalıdır.

Mevcut keystore varsa setup betiğinde **E** seçilerek aynı anahtar kullanılabilir.

## Manuel değişkenler

Alternatif olarak aşağıdaki Gradle özellikleri veya ortam değişkenleri kullanılabilir:

- `NOVA_KEYSTORE`
- `NOVA_KEY_ALIAS`
- `NOVA_STORE_PASSWORD`
- `NOVA_KEY_PASSWORD`

Öncelik sırası: Gradle property → ortam değişkeni → `%USERPROFILE%\.nova-indir\release.properties`.

## Google Play

Play App Signing etkinse bu anahtar upload key olarak kullanılabilir; Play son dağıtım imzasını yönetir. `BUILD_PLAY_RELEASE.cmd` ayrıca Play gizlilik URL'si ve 16 KB kontrolünü yayın kapısı olarak denetler.

## Dağıtım derlemesi

```powershell
.\BUILD_PLAY_AAB_AND_INDEPENDENT_APK.cmd
```

Bu komut yalnız imza yapılandırması mevcutsa başarıyla tamamlanır.
