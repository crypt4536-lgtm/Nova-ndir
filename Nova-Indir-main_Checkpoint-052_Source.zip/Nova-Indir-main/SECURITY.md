# Nova Downloader Güvenlik Tasarımı

## Ağ ilkeleri

- Medya, tarayıcı ve güncelleme akışlarında HTTPS zorunludur.
- HTTPS’den HTTP’ye düşüren yönlendirmeler reddedilir.
- TLS sertifika hataları aşılmaz.
- Nova Browser’da yerel dosya/içerik erişimi ve karışık içerik kapalıdır.
- JavaScript yerel köprüsü kullanılmaz; Safe Browsing etkinleştirilir.

## Güvenli güncelleme zinciri

Uygulama içi güncelleme, yalnız yapılandırılmış HTTPS bildiriminden çalışır. Bildirim RSA-SHA256 ile imzalanır ve APK SHA-256 değerini içerir.

Uygulama şunları doğrular:

- Bildirim imzası
- Full/Lite varyantı
- Sürüm kodu ve sürüm adı
- Minimum Android sürümü
- Aynı alan adına bağlı HTTPS APK adresi
- APK SHA-256
- Paket adı
- Kurulu uygulamayla imzalama sertifikası ilişkisi

APK uygulamanın özel önbelleğine indirilir ve Android paket yükleyicisi açılmadan hemen önce yeniden doğrulanır. Sessiz kurulum yapılmaz. RSA özel anahtarının kaynak koduna, APK’ya veya herkese açık depoya eklenmemesi gerekir.

## Motor güncelleme ve geri alma

- yt-dlp güncellemesi öncesinde etkin motor özel `noBackupFilesDir` alanına görüntülenir.
- Görüntü adı sürüm ve SHA-256 özeti içerir.
- Dosya kopyaları atomik geçici dosya üzerinden uygulanır.
- Geri yükleme sonrasında kaynak ve hedef SHA-256 değerleri eşit olmalıdır.
- Güncelleme sonrası `--version` sağlık denetimi başarısız olursa eski motor geri yüklenir.
- Tekrarlanan motor düzeyi hatalarda otomatik geri alma; ayrıca elle geri alma ve paketlenmiş motora dönme bulunur.
- Yalnız motor dosyası değiştirilir; indirme geçmişi ve medya dosyaları etkilenmez.

## Oturum ve eklenti güvenliği

- Çerez ve tokenlar Android Keystore destekli AES-GCM ile saklanır.
- Düz metin çerez yalnız aktif işlem için geçici oluşturulur.
- Eklenti ZIP’lerinde yol geçişi, mutlak yol, dosya türü, dosya sayısı ve boyut sınırları uygulanır.
- Haricî yt-dlp eklentileri Python kodu çalıştırabilir; yalnız güvenilen kaynaktan alınmalıdır.
- Nova DRM veya erişim kontrolü aşma amacıyla tasarlanmamıştır.

## Yerel günlük ve tanılama

- Günlükler uygulama özel alanındadır ve boyut sınırlıdır.
- Authorization, Cookie, Set-Cookie, PO Token, Visitor Data, bilinen sorgu sırları ve URL sorguları maskelenir.
- Tanılama dışa aktarımı kullanıcı eylemi gerektirir.
- Rapor medya başlığını, tam URL’yi, çerez/token değerlerini veya indirilen dosya içeriğini içermez.

## Dosya bütünlüğü

- HTML sayfası doğrudan medya dosyası gibi kaydedilmez.
- Dosya uzantısı MIME, yt-dlp çıktısı ve gerçek dosya imzasıyla düzeltilir.
- HTTP devam işlemi yalnız doğrulanmış `206 Partial Content` ve uyumlu `Content-Range` ile mevcut parçaya ekler.
- Tamamlanan/taşınan dosya hedefte SHA-256 ile tekrar okunur; doğrulanmadan kaynak silinmez.
- Aynı isimli dosyada üzerine yazma açık kullanıcı/politika kararı gerektirir.

## Süreç ve bellek izolasyonu

Python, yt-dlp, QuickJS ve isteğe bağlı FFmpeg ana uygulama işleminden ayrı `:media` işleminde çalışır. Ağır görev sayısı sınırlandırılır ve medya işlemi boş kaldığında kapatılır. Bu yaklaşım ana arayüzün bellek basıncından etkilenmesini azaltır; işletim sisteminin bellek/pil sınırlarını ortadan kaldırmaz.

## Bildirim ve özel pencere

Evcil hayvan üst pencere izni yalnız kullanıcı tarafından etkinleştirilir. Hizmet etkin olduğu sürece Android gereksinimlerine uygun kalıcı bildirim gösterilir. Zorla durdurma, güvenli sistem pencereleri ve bazı kilit ekranları Android tarafından sınırlandırılabilir.

## Bildirim

Güvenlik açığı raporunda uygulama sürümü, Android sürümü, yeniden üretme adımları ve mümkünse hassas verileri temizlenmiş tanılama raporu bulunmalıdır. Çerez, token, özel anahtar veya kişisel medya bağlantısını herkese açık hata raporuna eklemeyin.
## Arka plan çözümleme güvenliği

Arka plan çözümleme Android `dataSync` ön plan servisinde yürütülür. Görev durumu uygulamanın özel dizinine geçici dosya üzerinden yazılıp atomik yeniden adlandırmayla yayımlanır; böylece yarım JSON kaydı okunmaz. Sonuç bildirimleri yalnız uygulamanın açık etkinliğine yönlenen değiştirilemez `PendingIntent` kullanır. Zorla durdurma Android tarafından bütün servisleri durdurur ve Nova bu sistem sınırını aşmaya çalışmaz.


## APK indirici güvenliği

- Play Store bağlantıları yalnız `play.google.com/store/apps/details` biçiminden veya geçerli paket adından kabul edilir.
- Haricî sağlayıcı WebView'ı yalnız HTTPS gezinmesine izin verir; TLS hataları reddedilir.
- Yerel dosya ve içerik erişimi, karışık içerik, coğrafi konum ve JavaScript yerel köprüsü kapalıdır.
- Sağlayıcının dosya indirmesi Android DownloadManager ile yapılır; Nova ücret, DRM, hesap yetkisi veya bölge kısıtını aşmaya çalışmaz.
- Haricî sağlayıcının güvenliği ve sürekliliği Nova'nın denetiminde değildir. APK dosyası yüklenmeden önce geliştirici, paket adı, imzalayan sertifika ve mümkünse SHA-256 değeri doğrulanmalıdır.
- Split APK paketleri tek başına kurulamayabilir; yeniden imzalanmış veya birleştirilmiş paketler resmî Play Store güncellemeleriyle uyumsuz olabilir.

## Bağımsız Google Play teslimatı

- Google Play bağlantısı yalnız doğrulanmış paket adına dönüştürülür.
- Anonim oturum uç noktası derleme sırasında yapılandırılır ve HTTPS olmak zorundadır; kullanıcı Google hesabı bilgisi alınmaz.
- Uygulama ayrıntılarındaki `isFree` ve indirilebilir teklif bilgisi doğrulanmadan teslimat istenmez.
- Ücretli uygulama, lisans, hesap, cihaz uyumluluğu veya bölge kısıtlaması aşılmaz; Google Play teslimatı reddederse Nova işlemi durdurur.
- Teslimat bağlantıları yalnız HTTPS üzerinden ve sınırlı sayıda HTTPS yönlendirmesiyle indirilir.
- Her dosyanın Google Play tarafından bildirilen boyutu ve SHA-256 değeri; SHA-256 yoksa SHA-1 değeri doğrulanır.
- Tek APK doğrudan, base/split/OBB kümesi ise ayrı dosyaları koruyan APKS arşivi olarak kaydedilir; birleştirme, yeniden imzalama veya sessiz kurulum yapılmaz.
- Geçici anonim e-posta/token kalıcı depolamaya, günlük dosyasına veya tanılama raporuna yazılmaz.
- Varsayılan anonim oturum hizmeti Nova'nın kontrolünde değildir ve oran sınırlaması, kesinti veya protokol değişikliği nedeniyle çalışmayabilir.
- GPlayAPI tersine mühendislik edilmiş ve resmî olmayan bir istemci protokolüdür; bu nedenle özellik deneysel olarak sunulur.

## APK çeviri ve yeniden imzalama güvenliği

- Seçilen dosya okunabilir ZIP/APK yapısı, `AndroidManifest.xml`, `resources.arsc`, minimum boyut ve 2 GB üst sınırı açısından denetlenir.
- Özgün APK hiçbir zaman yerinde değiştirilmez; bütün işlem uygulamanın özel geçici dizinindeki kopyada yürür.
- Yalnız basit `string` kaynakları hedeflenir. Biçim belirteçleri, kaçış dizileri, XML/HTML etiketleri, varlıklar, URL'ler ve bilinen yer tutucular çeviri öncesinde maskelenip sonra geri yüklenir.
- Yeniden oluşturulan çıktı özgün geliştirici imzasını korumaya veya taklit etmeye çalışmaz. AndroidKeyStore içinde Nova'ya ait yerel RSA anahtarı oluşturulur ve cihazdan dışarı çıkarılmaz.
- APK Signature Scheme v1/v2/v3 imzası oluşturulduktan sonra çıktı `ApkVerifier` ile doğrulanmadan genel İndirilenler klasörüne yayımlanmaz.
- Yeni imza özgün uygulamayla eşleşmediğinden çıktı mevcut kurulumun üzerine güncelleme olarak kurulamaz. İmza/bütünlük denetimi yapan uygulamalar çalışmayabilir.
- Nova lisans, DRM, imza veya bütünlük denetimlerini atlatmaz; yalnız kullanıcının seçtiği APK'nın görünür metin kaynaklarını çevirmeyi dener.
- Kaynağı bilinmeyen APK'lar zararlı kod içerebilir. Çeviri işlemi APK kodunu güvenli hâle getirmez; yükleme kararı kullanıcıya aittir.

