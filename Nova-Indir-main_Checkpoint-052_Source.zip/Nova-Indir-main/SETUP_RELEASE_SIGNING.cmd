@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0SETUP_RELEASE_SIGNING.ps1"
exit /b %ERRORLEVEL%
