﻿$ErrorActionPreference = "Stop"

$ConfigDir = Join-Path $env:USERPROFILE ".nova-indir"
$ConfigFile = Join-Path $ConfigDir "release.properties"
$DefaultKeyDir = "D:\NovaSigning"
$DefaultKeyFile = Join-Path $DefaultKeyDir "NovaIndirRelease.p12"
$DefaultAlias = "nova-release"

function ConvertTo-PlainText([Security.SecureString]$Secure) {
    $ptr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($Secure)
    try { [Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr) }
    finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr) }
}

function Escape-Property([string]$Value) {
    return $Value.Replace('\','/').Replace("`r",'').Replace("`n",'')
}

$keytool = $null
if ($env:JAVA_HOME) {
    $candidate = Join-Path $env:JAVA_HOME "bin\keytool.exe"
    if (Test-Path -LiteralPath $candidate) { $keytool = $candidate }
}
if (-not $keytool) {
    $cmd = Get-Command keytool.exe -ErrorAction SilentlyContinue
    if ($cmd) { $keytool = $cmd.Source }
}
if (-not $keytool) { throw "keytool.exe bulunamadi. Android Studio/JDK 17 kurulumunu kontrol edin." }

New-Item -ItemType Directory -Force -Path $ConfigDir | Out-Null

Write-Host "Nova Indir release imza kurulumu" -ForegroundColor Cyan
Write-Host "Bu anahtar hem Google Play upload AAB hem de Bagimsiz release APK imzasi icin kullanilabilir." -ForegroundColor Yellow
Write-Host "Anahtari kaybetmeyin; Bagimsiz APK guncellemeleri ayni anahtarla imzalanmalidir." -ForegroundColor Yellow
Write-Host ""

$mode = Read-Host "Mevcut keystore kullanmak icin E, yeni anahtar olusturmak icin Y yazin [Y]"
if ([string]::IsNullOrWhiteSpace($mode)) { $mode = 'Y' }

if ($mode -match '^[Ee]') {
    $keyPath = Read-Host "Keystore tam yolu"
    if (-not (Test-Path -LiteralPath $keyPath)) { throw "Keystore bulunamadi: $keyPath" }
    $alias = Read-Host "Key alias"
    if ([string]::IsNullOrWhiteSpace($alias)) { throw "Alias bos olamaz." }
    $storePassword = ConvertTo-PlainText (Read-Host "Keystore parolasi" -AsSecureString)
    $keyPassword = ConvertTo-PlainText (Read-Host "Key parolasi" -AsSecureString)
} else {
    New-Item -ItemType Directory -Force -Path $DefaultKeyDir | Out-Null
    $keyPath = $DefaultKeyFile
    $alias = $DefaultAlias
    if (Test-Path -LiteralPath $keyPath) {
        throw "Yeni anahtar olusturulmadi; dosya zaten var: $keyPath`nMevcut anahtari kullanmak icin betigi yeniden calistirip E secin."
    }
    $bytes = New-Object byte[] 24
    $rng = [Security.Cryptography.RandomNumberGenerator]::Create()
    try {
        $rng.GetBytes($bytes)
    } finally {
        if ($null -ne $rng) { $rng.Dispose() }
    }
    $password = -join ($bytes | ForEach-Object { $_.ToString('x2') })
    $storePassword = $password
    $keyPassword = $password

    & $keytool -genkeypair -v `
        -keystore $keyPath `
        -storetype PKCS12 `
        -alias $alias `
        -keyalg RSA `
        -keysize 4096 `
        -validity 10000 `
        -dname "CN=Nova Indir, OU=Release, O=Nova Indir, C=TR" `
        -storepass $storePassword `
        -keypass $keyPassword
    if ($LASTEXITCODE -ne 0) { throw "keytool anahtar olusturma basarisiz: exit $LASTEXITCODE" }
}

$keyPathForProperties = (Resolve-Path -LiteralPath $keyPath).Path.Replace('\','/')
$lines = @(
    "# Nova Indir private release configuration - DO NOT SHARE",
    "NOVA_KEYSTORE=$keyPathForProperties",
    "NOVA_KEY_ALIAS=$alias",
    "NOVA_STORE_PASSWORD=$storePassword",
    "NOVA_KEY_PASSWORD=$keyPassword"
)
Set-Content -LiteralPath $ConfigFile -Value $lines -Encoding ASCII

Write-Host ""
Write-Host "RELEASE SIGNING READY" -ForegroundColor Green
Write-Host "Keystore : $keyPath" -ForegroundColor Green
Write-Host "Config   : $ConfigFile" -ForegroundColor Green
Write-Host ""
Write-Host "Bu iki dosyanin guvenli yedegini alin. Kaynak ZIP ile paylasmayin." -ForegroundColor Yellow
Write-Host "Sonraki derlemelerde parola sormadan ayni imza kullanilacak." -ForegroundColor Cyan
