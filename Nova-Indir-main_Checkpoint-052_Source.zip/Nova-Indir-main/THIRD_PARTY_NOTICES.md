# Üçüncü Taraf Bileşenler

- **youtubedl-android library 0.18.1** — GPL-3.0; Android uyumlu Python, yt-dlp ve QuickJS çalışma ortamını sağlar.
- **youtubedl-android ffmpeg 0.18.1** — FFmpeg tabanlı ses çıkarma, yeniden kapsülleme, dönüştürme ve ayrı akış birleştirme işlevleri.
- **yt-dlp** — desteklenen sitelerin çıkarıcıları, HLS/DASH parça indirme, biçim seçimi, oynatma listesi/canlı yayın ve oturum çerezleri desteği.
- **QuickJS** — YouTube ve diğer platformların JavaScript meydan okumalarını çalıştırmak için youtubedl-android tarafından kullanılan çalışma zamanı.
- **FFmpeg** — yerel medya birleştirme, remux ve ses dönüştürme.
- **AndroidX Core 1.17.0** — Apache License 2.0; FileProvider ve Android uyumluluk yardımcıları.
- **AndroidX Room 2.8.4** — Apache License 2.0; kalıcı indirme kuyruğu ve geçmiş veritabanı.
- **AndroidX WorkManager 2.11.2** — Apache License 2.0; ağ/şarj koşullu kurtarma işi.
- **AndroidX Test Core/Runner 1.7.0 ve JUnit Extensions 1.3.0** — Apache License 2.0; cihaz test altyapısı.
- **JUnit 4.13.2** — Eclipse Public License 1.0; yerel birim testleri.
- **GPlayAPI 3.6.4 (`com.auroraoss:gplayapi`)** — GPL-3.0-or-later; Google Play protobuf API erişimi, uygulama ayrıntıları ve ücretsiz APK/split/OBB teslimat bağlantılarının alınması için kullanılır. Kaynak dağıtımı bu projenin GPL-3.0 lisans metnini içerir.
- **ARSCLib 1.4.0 (`io.github.reandroid:ARSCLib`)** — Apache License 2.0; APK içindeki derlenmiş Android kaynak tablosunu (`resources.arsc`) okumak, hedef dil `string` girdilerini eklemek ve APK arşivini yeniden yazmak için kullanılır.
- **Google ML Kit Translation 17.0.3 (`com.google.mlkit:translate`)** — Google ML Kit kullanım koşullarına tabi Android SDK; dil modellerini gerektiğinde indirir ve seçilen metin kaynaklarını cihaz üzerinde çevirir.
- **Android apksig 8.10.1 (`com.android.tools.build:apksig`)** — Android Open Source Project/Apache License 2.0; yeniden oluşturulan APK'yı imzalamak ve imzasını doğrulamak için kullanılır.

EJS uzak bileşen seçeneği açık olduğunda yt-dlp, YouTube JavaScript meydan okumalarını çözmek için güncel çözümleyici betiklerini indirebilir. Kullanıcının içe aktardığı yt-dlp/PO Token eklentileri bu dağıtımın parçası değildir ve kendi lisans/güvenlik koşullarına tabidir.

Üçüncü taraf bileşenlerin tam lisans metinleri ve telif bildirimleri kendi kaynak dağıtımlarında geçerlidir.

## Haricî web hizmeti

- **Evozi APK Downloader** — Nova'nın bir parçası veya gömülü kütüphanesi değildir. Kullanıcı isteğiyle WebView içinde açılan bağımsız bir üçüncü taraf web hizmetidir. Hizmetin kullanılabilirliği, içeriği, gizlilik koşulları ve sunduğu APK dosyaları Evozi'nin sorumluluğundadır.
- **Anonim Play oturum dağıtıcısı** — Bağımsız Play Store indirici varsayılan olarak yapılandırılmış Aurora OSS uyumlu HTTPS oturum hizmetine cihaz uyumluluk özelliklerini gönderir ve geçici anonim hesap kimliği alır. Bu hizmet Nova'nın parçası değildir; derleyici `NOVA_PLAY_DISPENSER_URL` ile başka uyumlu bir uç nokta seçebilir. Hizmetin oran sınırları, erişilebilirliği ve gizlilik koşulları kendi işletmecisine aittir.

