# Güvenli güncelleme yapılandırması

Nova Downloader güncelleme istemcisi, aşağıdaki derleme değerleri sağlanmadıkça etkinleşmez:

- `NOVA_UPDATE_MANIFEST_URL_FULL`: Full varyantının imzalı HTTPS JSON bildirimi
- `NOVA_UPDATE_MANIFEST_URL_LITE`: Lite varyantının imzalı HTTPS JSON bildirimi
- `NOVA_UPDATE_PUBLIC_KEY_B64`: RSA açık anahtarının DER/X.509 Base64 biçimi

Checkpoint 038 bağımsız dağıtımda Full/Pro kanalı `HAS_FFMPEG=true` olduğunda `full`, Lite kanalı `HAS_FFMPEG=false` olduğunda `lite` olarak doğrulanır. İki flavor dimension nedeniyle `BuildConfig.FLAVOR` doğrudan kullanılmaz. `NOVA_UPDATE_MANIFEST_URL` yalnız Full/Lite URL'leri verilmemişse geriye dönük yapılandırma girdisi olarak kullanılır.

RSA **özel anahtarı bu projeye, APK’ya veya herkese açık depoya eklenmemelidir**. Çevrimdışı veya korumalı CI sırrı olarak saklayın.

## Gradle yapılandırması

Kullanıcı düzeyindeki `~/.gradle/gradle.properties`, korumalı CI sırları veya ortam değişkenleri kullanılabilir:

```properties
NOVA_UPDATE_MANIFEST_URL_FULL=https://updates.example.org/nova/full/update.json
NOVA_UPDATE_MANIFEST_URL_LITE=https://updates.example.org/nova/lite/update.json
NOVA_UPDATE_PUBLIC_KEY_B64=MIIBIjANBgkqh...
```

## RSA anahtarı oluşturma

OpenSSL örneği:

```bash
openssl genpkey -algorithm RSA -pkeyopt rsa_keygen_bits:3072 -out nova-update-private.pem
openssl pkey -in nova-update-private.pem -pubout -out nova-update-public.pem
```

`nova-update-private.pem` dosyasını proje dışında tutun.

## İmzalı bildirim üretme

Python `cryptography` paketi gerekir. Kurulum güncellemesinde tek APK kullanılacağı için her varyantta universal release APK yayınlamak en kolay yoldur.

Full örneği:

```bash
python tools/sign_update_manifest.py \
  --apk app-full-universal-release.apk \
  --apk-url https://updates.example.org/nova/full/app-full-universal-release.apk \
  --version-code 40 \
  --version-name 0.10.0-alpha-independent \
  --flavor full \
  --private-key /secure/nova-update-private.pem \
  --output update-full.json \
  --write-public-key-b64 nova-update-public-key.b64
```

Lite örneğinde sürüm adı Gradle varyant son ekini içermelidir:

```bash
python tools/sign_update_manifest.py \
  --apk app-lite-universal-release.apk \
  --apk-url https://updates.example.org/nova/lite/app-lite-universal-release.apk \
  --version-code 40 \
  --version-name 0.10.0-alpha-independent-lite \
  --flavor lite \
  --private-key /secure/nova-update-private.pem \
  --output update-lite.json
```

## Checkpoint 038 bağımsız kimlikleri

- Independent Pro: `applicationId = com.nova.indir.independent.pro`, `versionName = 0.10.0-alpha-independent`, manifest `flavor = full`.
- Independent Lite: `applicationId = com.nova.indir.independent.lite`, `versionName = 0.10.0-alpha-independent-lite`, manifest `flavor = lite`.

Güncelleme APK'sı kurulu varyantla aynı gerçek package/applicationId ve imza zincirine sahip olmalıdır.

## İstemci doğrulama sırası

1. Bildirim adresinde HTTPS ve en fazla üç aynı-alan yönlendirmesi
2. RSA-SHA256 imzalı kanonik bildirim gövdesi
3. Full/Lite varyantı, sürüm kodu, sürüm adı ve minimum Android sürümü
4. APK adresinde HTTPS ve bildirimle aynı alan adı
5. İndirilen APK SHA-256
6. İndirilen APK paket adının kurulu bağımsız varyantın gerçek `applicationId` değeriyle eşleşmesi
7. APK sürüm kodu ve sürüm adı
8. Kurulu Nova Downloader ile imzalayan sertifika ilişkisi
9. Kurulumdan hemen önce özel önbellekte ikinci APK doğrulaması
10. Android paket yükleyicisinde kullanıcı onayı

Uygulama sessiz kurulum yapmaz.

## Bildirim biçimi

```json
{
  "versionCode": 40,
  "versionName": "0.10.0-alpha-independent",
  "flavor": "full",
  "minSdk": 26,
  "apkUrl": "https://updates.example.org/nova/full/app-full-universal-release.apk",
  "apkSha256": "64 küçük onaltılık karakter",
  "publishedAt": "2026-07-26T12:00:00Z",
  "notes": "Sürüm notları",
  "signature": "Base64 RSA imzası"
}
```

İmza gövdesine notların kendisi yerine SHA-256 özeti eklenir. Alan sırası ve satır sonları `tools/sign_update_manifest.py` ile Android `UpdateManifest.canonicalPayload()` arasında aynıdır.
