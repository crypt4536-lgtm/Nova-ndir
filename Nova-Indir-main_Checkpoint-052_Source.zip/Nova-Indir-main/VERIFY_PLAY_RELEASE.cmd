@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0VERIFY_PLAY_RELEASE.ps1" -Root "%~dp0"
exit /b %ERRORLEVEL%
