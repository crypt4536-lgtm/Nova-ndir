﻿param(
    [string]$Root = (Get-Location).Path
)

$ErrorActionPreference = "Stop"
$resolvedRoot = (Resolve-Path -LiteralPath $Root).Path
$gradlew = Join-Path $resolvedRoot "gradlew.bat"
$audit = Join-Path $resolvedRoot "AUDIT_16KB.ps1"
$buildGradle = Join-Path $resolvedRoot "app\build.gradle.kts"
if (-not (Test-Path -LiteralPath $buildGradle)) { throw "app\build.gradle.kts bulunamadi: $buildGradle" }
$gradleText = Get-Content -LiteralPath $buildGradle -Raw
$versionMatch = [regex]::Match($gradleText, 'val\s+novaVersionName\s*=\s*"([^"]+)"')
if (-not $versionMatch.Success) { throw "novaVersionName app\build.gradle.kts icinde bulunamadi." }
$artifactVersion = ($versionMatch.Groups[1].Value -split '-')[0]
$report = Join-Path $resolvedRoot ("Nova Indir {0} 16KB Audit Report.txt" -f $artifactVersion)
$playPackages = Join-Path $resolvedRoot ("Nova İndir {0} Google Play" -f $artifactVersion)

if (-not (Test-Path -LiteralPath $gradlew)) { throw "gradlew.bat bulunamadi: $gradlew" }
if (-not (Test-Path -LiteralPath $audit)) { throw "AUDIT_16KB.ps1 bulunamadi: $audit" }

Push-Location $resolvedRoot
try {
    Write-Host "[1/3] Google Play Lite + Pro release AAB derleniyor..." -ForegroundColor Cyan
    & $gradlew :app:checkNovaPlayPublicationConfig :app:bundleNovaPlayRelease --no-daemon --console=plain
    if ($LASTEXITCODE -ne 0) { throw "Gradle Play release derlemesi basarisiz: exit $LASTEXITCODE" }

    Write-Host "[2/3] 16 KB native/page-alignment denetimi..." -ForegroundColor Cyan
    if (-not (Test-Path -LiteralPath $playPackages)) { throw "Play AAB çıktı klasörü bulunamadı: $playPackages" }
    & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $audit -Root $resolvedRoot -PackageRoot $playPackages
    if ($LASTEXITCODE -ne 0) { throw "AUDIT_16KB.ps1 calistirilamadi: exit $LASTEXITCODE" }

    if (-not (Test-Path -LiteralPath $report)) { throw "16 KB raporu uretilmedi: $report" }
    $text = Get-Content -LiteralPath $report -Raw
    if ($text -notmatch '(?m)^OVERALL RESULT:\s*PASS\s*$') {
        throw "16 KB denetimi PASS degil. Raporu inceleyin: $report"
    }

    Write-Host "[3/3] PLAY RELEASE TECHNICAL GATE: PASS" -ForegroundColor Green
    Write-Host "Rapor: $report" -ForegroundColor Green
}
finally {
    Pop-Location
}
