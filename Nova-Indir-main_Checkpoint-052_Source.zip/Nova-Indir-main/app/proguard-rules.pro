# youtubedl-android embeds Python/yt-dlp and optional native FFmpeg components.
-keep class com.yausername.** { *; }
-keep class org.apache.commons.compress.archivers.zip.** { *; }
-dontwarn org.apache.commons.compress.**

# Room database metadata and generated implementation.
-keep class * extends androidx.room.RoomDatabase
-keep @androidx.room.Entity class * { *; }
-dontwarn androidx.room.**

# Kotlin model names are inspected by Room/JSON conversion code.
-keep class com.nova.downloader.data.db.** { *; }
-keep class com.nova.downloader.data.StoredDownload { *; }
-keep class com.nova.downloader.data.ResolvedDownload { *; }

# GPlayAPI protobuf/serialization model access used by the independent Play downloader.
-keep public class com.aurora.gplayapi.** { *; }

# ARSCLib resource table APIs are intentionally reached through a compatibility
# reflection layer so minor upstream structural changes do not break Nova builds.
-keep class com.reandroid.** { *; }
-dontwarn com.reandroid.**

# APK signing and ML Kit translation runtime.
-keep class com.android.apksig.** { *; }
-dontwarn com.android.apksig.**
-dontwarn com.google.mlkit.**

# Checkpoint 051: preserve Media3 XML-inflated view constructors under R8/minify.
-keep class androidx.media3.ui.AspectRatioFrameLayout {
    public <init>(android.content.Context);
    public <init>(android.content.Context, android.util.AttributeSet);
    public <init>(android.content.Context, android.util.AttributeSet, int);
}
-keep class androidx.media3.ui.PlayerView {
    public <init>(android.content.Context);
    public <init>(android.content.Context, android.util.AttributeSet);
    public <init>(android.content.Context, android.util.AttributeSet, int);
}
-keep class androidx.media3.ui.PlayerControlView {
    public <init>(android.content.Context);
    public <init>(android.content.Context, android.util.AttributeSet);
    public <init>(android.content.Context, android.util.AttributeSet, int);
}
-keep class androidx.media3.ui.** { *; }
