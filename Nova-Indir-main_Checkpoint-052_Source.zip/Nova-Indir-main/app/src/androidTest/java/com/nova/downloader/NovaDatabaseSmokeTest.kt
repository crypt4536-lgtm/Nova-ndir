package com.nova.downloader

import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.nova.downloader.data.HistoryStore
import com.nova.downloader.data.StoredDownload
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class NovaDatabaseSmokeTest {
    @Test fun roomQueueCanPersistAndReadARecord() {
        val context = ApplicationProvider.getApplicationContext<android.content.Context>()
        val history = HistoryStore(context)
        val id = System.currentTimeMillis()
        history.add(StoredDownload(downloadId = id, url = "https://example.com/test.mp4", title = "test.mp4", createdAt = id))
        assertEquals("test.mp4", history.get(id)?.title)
        history.remove(id)
    }
}
