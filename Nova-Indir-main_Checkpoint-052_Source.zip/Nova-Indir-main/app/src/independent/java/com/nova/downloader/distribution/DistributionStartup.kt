package com.nova.downloader.distribution

import android.content.Context
import com.nova.downloader.update.UpdateScheduler

object DistributionStartup {
    fun initialize(context: Context) {
        UpdateScheduler.schedule(context.applicationContext)
    }
}
