package com.nova.downloader.distribution

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import com.nova.downloader.service.PetOverlayService

/** Independent build: owns the overlay permission and concrete pet service. */
object PetIntegration {
    fun canDrawOverlays(context: Context): Boolean = Settings.canDrawOverlays(context)

    fun requestOverlayPermission(activity: Activity) {
        activity.startActivity(
            Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:${activity.packageName}")
            )
        )
    }

    fun startOrRefresh(context: Context) = PetOverlayService.startOrRefresh(context)
    fun refreshMaybe(context: Context) = PetOverlayService.refreshMaybe(context)
    fun stop(context: Context) = PetOverlayService.stop(context)
}
