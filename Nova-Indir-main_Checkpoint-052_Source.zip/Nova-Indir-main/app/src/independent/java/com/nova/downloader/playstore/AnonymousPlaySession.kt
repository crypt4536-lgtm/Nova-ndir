package com.nova.downloader.playstore

import android.content.Context
import com.aurora.gplayapi.data.models.AuthData
import com.aurora.gplayapi.helpers.AuthHelper
import com.nova.downloader.BuildConfig
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.Properties

/** Obtains a short-lived anonymous Google Play account token without asking for user credentials. */
object AnonymousPlaySession {
    fun build(
        context: Context,
        dispenserUrl: String = BuildConfig.NOVA_PLAY_DISPENSER_URL,
        locale: Locale = Locale.getDefault()
    ): AuthData {
        require(dispenserUrl.startsWith("https://")) { "Anonymous session URL must use HTTPS" }
        val properties = PlayDeviceProfileFactory.create(context)
        val credential = requestCredential(dispenserUrl, properties)
        return AuthHelper.build(
            email = credential.email,
            token = credential.authToken,
            tokenType = AuthHelper.Token.AUTH,
            isAnonymous = true,
            properties = properties,
            locale = locale
        )
    }

    private fun requestCredential(dispenserUrl: String, properties: Properties): Credential {
        val body = JSONObject().apply {
            properties.stringPropertyNames().sorted().forEach { key -> put(key, properties.getProperty(key)) }
        }.toString().toByteArray(Charsets.UTF_8)

        val connection = (URL(dispenserUrl).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 25_000
            readTimeout = 25_000
            doOutput = true
            instanceFollowRedirects = false
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("Accept", "application/json")
            setRequestProperty("User-Agent", "${BuildConfig.APPLICATION_ID}-${BuildConfig.VERSION_NAME}-${BuildConfig.VERSION_CODE}")
            setFixedLengthStreamingMode(body.size)
        }

        return try {
            connection.outputStream.use { it.write(body) }
            val code = connection.responseCode
            val response = (if (code in 200..299) connection.inputStream else connection.errorStream)
                ?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            if (code !in 200..299) {
                val serverMessage = runCatching { JSONObject(response).optString("error") }.getOrNull().orEmpty()
                throw AnonymousSessionException(code, serverMessage.ifBlank { "Anonymous session request failed" })
            }
            val json = JSONObject(response)
            val email = json.optString("email").trim()
            val token = json.optString("auth").trim().ifBlank {
                json.optString("authToken").trim()
            }
            if (email.isBlank() || token.isBlank()) throw IOException("Anonymous session response was incomplete")
            Credential(email, token)
        } finally {
            connection.disconnect()
        }
    }

    data class Credential(val email: String, val authToken: String)
    class AnonymousSessionException(val statusCode: Int, message: String) : IOException(message)
}
