package com.nova.downloader.playstore

import android.app.ActivityManager
import android.content.Context
import android.content.res.Configuration
import android.os.Build
import java.util.Locale
import java.util.Properties
import java.util.TimeZone

/** Builds the device description sent to the anonymous session provider and Google Play. */
object PlayDeviceProfileFactory {
    private const val FALLBACK_GSF_VERSION = 251333035L
    private const val FALLBACK_VENDING_VERSION = 84582130L
    private const val FALLBACK_VENDING_STRING = "45.8.21-31 [0] [PR] 747433787"

    fun create(context: Context): Properties {
        val configuration = context.resources.configuration
        val metrics = context.resources.displayMetrics
        val activityManager = context.getSystemService(ActivityManager::class.java)
        val gsf = packageVersion(context, GOOGLE_SERVICES_PACKAGE, FALLBACK_GSF_VERSION, "")
        val vending = packageVersion(
            context,
            GOOGLE_VENDING_PACKAGE,
            FALLBACK_VENDING_VERSION,
            FALLBACK_VENDING_STRING
        )

        return Properties().apply {
            setProperty("UserReadableName", "${Build.MANUFACTURER} ${Build.MODEL}".trim())
            setProperty("Build.HARDWARE", Build.HARDWARE.ifBlank { "unknown" })
            setProperty("Build.RADIO", Build.getRadioVersion()?.ifBlank { "unknown" } ?: "unknown")
            setProperty("Build.FINGERPRINT", Build.FINGERPRINT.ifBlank { "unknown" })
            setProperty("Build.BRAND", Build.BRAND.ifBlank { "unknown" })
            setProperty("Build.DEVICE", Build.DEVICE.ifBlank { "unknown" })
            setProperty("Build.VERSION.SDK_INT", Build.VERSION.SDK_INT.toString())
            setProperty("Build.VERSION.RELEASE", Build.VERSION.RELEASE.ifBlank { Build.VERSION.SDK_INT.toString() })
            setProperty("Build.MODEL", Build.MODEL.ifBlank { "Android" })
            setProperty("Build.MANUFACTURER", Build.MANUFACTURER.ifBlank { "Android" })
            setProperty("Build.PRODUCT", Build.PRODUCT.ifBlank { Build.DEVICE.ifBlank { "unknown" } })
            setProperty("Build.ID", Build.ID.ifBlank { "unknown" })
            setProperty("Build.BOOTLOADER", Build.BOOTLOADER.ifBlank { "unknown" })

            setProperty("TouchScreen", configuration.touchscreen.toString())
            setProperty("Keyboard", configuration.keyboard.toString())
            setProperty("Navigation", configuration.navigation.toString())
            setProperty("ScreenLayout", (configuration.screenLayout and Configuration.SCREENLAYOUT_SIZE_MASK).toString())
            setProperty("HasHardKeyboard", (configuration.keyboard == Configuration.KEYBOARD_QWERTY).toString())
            setProperty("HasFiveWayNavigation", (configuration.navigation == Configuration.NAVIGATION_DPAD).toString())

            setProperty("Screen.Density", metrics.densityDpi.toString())
            setProperty("Screen.Width", metrics.widthPixels.toString())
            setProperty("Screen.Height", metrics.heightPixels.toString())
            setProperty("Platforms", Build.SUPPORTED_ABIS.joinToString(",").ifBlank { Build.CPU_ABI })
            setProperty(
                "Features",
                context.packageManager.systemAvailableFeatures.mapNotNull { it.name }.distinct().joinToString(",")
            )
            setProperty(
                "Locales",
                context.assets.locales.map { it.replace('-', '_') }.distinct().joinToString(",")
                    .ifBlank { Locale.getDefault().toString() }
            )
            setProperty(
                "SharedLibraries",
                context.packageManager.systemSharedLibraryNames?.distinct()?.joinToString(",").orEmpty()
            )
            setProperty("GL.Version", (activityManager?.deviceConfigurationInfo?.reqGlEsVersion ?: 0).toString())
            setProperty("GL.Extensions", "")

            setProperty("Client", "android-google")
            setProperty("GSF.version", gsf.versionCode.toString())
            setProperty("Vending.version", vending.versionCode.toString())
            setProperty("Vending.versionString", vending.versionName.ifBlank { FALLBACK_VENDING_STRING })
            setProperty("Roaming", "mobile-notroaming")
            setProperty("TimeZone", TimeZone.getDefault().id.ifBlank { "UTC" })
            setProperty("CellOperator", "310")
            setProperty("SimOperator", "38")
        }
    }

    @Suppress("DEPRECATION")
    private fun packageVersion(
        context: Context,
        packageName: String,
        fallbackCode: Long,
        fallbackName: String
    ): PackageVersion {
        return runCatching {
            val info = context.packageManager.getPackageInfo(packageName, 0)
            val code = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) info.longVersionCode else info.versionCode.toLong()
            PackageVersion(code.takeIf { it > 0 } ?: fallbackCode, info.versionName.orEmpty().ifBlank { fallbackName })
        }.getOrElse { PackageVersion(fallbackCode, fallbackName) }
    }

    private data class PackageVersion(val versionCode: Long, val versionName: String)

    private const val GOOGLE_SERVICES_PACKAGE = "com.google.android.gms"
    private const val GOOGLE_VENDING_PACKAGE = "com.android.vending"
}
