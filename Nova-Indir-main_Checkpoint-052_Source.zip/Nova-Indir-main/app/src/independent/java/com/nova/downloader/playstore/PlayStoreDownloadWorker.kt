package com.nova.downloader.playstore

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.ForegroundInfo
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.aurora.gplayapi.data.models.App
import com.aurora.gplayapi.data.models.PlayFile
import com.aurora.gplayapi.exceptions.GooglePlayException
import com.aurora.gplayapi.helpers.AppDetailsHelper
import com.aurora.gplayapi.helpers.PurchaseHelper
import com.nova.downloader.R
import com.nova.downloader.core.PlayStoreLinkParser
import com.nova.downloader.ui.PlayStoreApkDownloaderActivity
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.Locale
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import kotlin.coroutines.coroutineContext

/** Downloads free Google Play apps using an anonymous session and saves APK/APKS to Downloads. */
class PlayStoreDownloadWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    private val notificationManager = context.getSystemService(NotificationManager::class.java)
    private val notificationId = NOTIFICATION_BASE + (id.hashCode() and 0x0fff)

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val packageName = PlayStoreLinkParser.extractPackageId(inputData.getString(KEY_PACKAGE_NAME).orEmpty())
            ?: return@withContext failure(ERROR_INVALID_PACKAGE, "Invalid Google Play package name")
        val workDir = File(applicationContext.cacheDir, "play-apk/${id}").apply {
            deleteRecursively()
            mkdirs()
        }

        createNotificationChannel()
        setForeground(createForegroundInfo(packageName, applicationContext.getString(R.string.apk_play_step_session), 0, true))

        try {
            report(STEP_SESSION, 4, packageName, true)
            val authData = AnonymousPlaySession.build(applicationContext)

            report(STEP_DETAILS, 14, packageName, true)
            val app = AppDetailsHelper(authData).getAppByPackageName(packageName)
            validateFreeApp(app)

            report(STEP_PURCHASE, 24, app.displayName.ifBlank { packageName }, true)
            val playFiles = PurchaseHelper(authData).purchase(
                packageName = app.packageName,
                versionCode = app.versionCode,
                offerType = app.offerType
            )
            if (playFiles.none { it.type == PlayFile.Type.BASE }) {
                throw PermanentFailure(ERROR_NO_FILES, "Google Play did not return a base APK")
            }

            val downloaded = downloadAll(app, playFiles, workDir)
            report(STEP_PACKING, 92, app.displayName.ifBlank { packageName }, true)
            val artifact = buildArtifact(app, downloaded, workDir)

            report(STEP_SAVING, 97, artifact.name, true)
            val published = publishToDownloads(artifact)
            report(STEP_DONE, 100, published.displayName, false)
            showCompletedNotification(published.displayName)

            Result.success(
                workDataOf(
                    KEY_OUTPUT_NAME to published.displayName,
                    KEY_OUTPUT_URI to published.uri.toString(),
                    KEY_OUTPUT_KIND to artifact.extension.removePrefix(".")
                )
            )
        } catch (failure: PermanentFailure) {
            showFailedNotification(failure.message.orEmpty())
            failure(failure.code, failure.message.orEmpty())
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (exception: Exception) {
            val message = humanError(exception)
            val errorCode = classifyError(exception)
            if (exception is IOException && errorCode == ERROR_DOWNLOAD_FAILED && runAttemptCount < MAX_RETRIES) {
                Result.retry()
            } else {
                showFailedNotification(message)
                failure(errorCode, message)
            }
        } finally {
            workDir.deleteRecursively()
        }
    }

    private fun validateFreeApp(app: App) {
        if (app.packageName.isBlank() || app.versionCode <= 0L) {
            throw PermanentFailure(ERROR_NOT_FOUND, "The app could not be found on Google Play")
        }
        if (!app.isFree) {
            throw PermanentFailure(ERROR_PAID_APP, "Paid apps are not supported")
        }
        if (app.offerType <= 0) {
            throw PermanentFailure(ERROR_UNAVAILABLE, "The app has no downloadable public offer")
        }
    }

    private suspend fun downloadAll(
        app: App,
        playFiles: List<PlayFile>,
        workDir: File
    ): List<DownloadedFile> {
        val selected = playFiles.filter { it.type != PlayFile.Type.PATCH || it.name.endsWith(".obb", true) }
        val totalExpected = selected.sumOf { it.size.coerceAtLeast(0L) }.coerceAtLeast(1L)
        var completedBytes = 0L
        val result = ArrayList<DownloadedFile>(selected.size)

        selected.forEachIndexed { index, playFile ->
            coroutineContext.ensureActive()
            if (isStopped) throw IOException("Download was cancelled")
            val fileName = safePackageFileName(playFile.name, index)
            val output = File(workDir, fileName)
            val baseBefore = completedBytes
            downloadOne(playFile, output) { current ->
                val aggregate = (baseBefore + current).coerceAtMost(totalExpected)
                val percent = 25 + ((aggregate * 65L) / totalExpected).toInt().coerceIn(0, 65)
                reportBlocking(
                    STEP_DOWNLOADING,
                    percent,
                    applicationContext.getString(
                        R.string.apk_play_progress_file,
                        index + 1,
                        selected.size,
                        fileName
                    )
                )
            }
            completedBytes += output.length()
            result += DownloadedFile(playFile, output)
        }
        return result
    }

    private fun downloadOne(playFile: PlayFile, destination: File, onProgress: (Long) -> Unit) {
        var current = URL(playFile.url)
        repeat(MAX_REDIRECTS + 1) { redirectCount ->
            if (!current.protocol.equals("https", true)) throw IOException("Google Play returned a non-HTTPS download URL")
            val connection = (current.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 30_000
                readTimeout = 45_000
                instanceFollowRedirects = false
                setRequestProperty("Accept-Encoding", "identity")
                setRequestProperty("User-Agent", DOWNLOAD_USER_AGENT)
            }
            try {
                val code = connection.responseCode
                if (code in 300..399) {
                    val location = connection.getHeaderField("Location") ?: throw IOException("Redirect without a target")
                    if (redirectCount >= MAX_REDIRECTS) throw IOException("Too many download redirects")
                    current = URL(current, location)
                    return@repeat
                }
                if (code !in 200..299) throw IOException("Download server returned HTTP $code")

                val sha256 = MessageDigest.getInstance("SHA-256")
                val sha1 = MessageDigest.getInstance("SHA-1")
                var copied = 0L
                BufferedInputStream(connection.inputStream, BUFFER_SIZE).use { input ->
                    BufferedOutputStream(FileOutputStream(destination), BUFFER_SIZE).use { output ->
                        val buffer = ByteArray(BUFFER_SIZE)
                        var lastReport = 0L
                        while (true) {
                            if (isStopped) throw IOException("Download was cancelled")
                            val read = input.read(buffer)
                            if (read < 0) break
                            output.write(buffer, 0, read)
                            sha256.update(buffer, 0, read)
                            sha1.update(buffer, 0, read)
                            copied += read
                            if (copied - lastReport >= PROGRESS_GRANULARITY) {
                                onProgress(copied)
                                lastReport = copied
                            }
                        }
                        output.flush()
                    }
                }
                onProgress(copied)
                verifyFile(playFile, copied, sha256.digest().toHex(), sha1.digest().toHex())
                return
            } finally {
                connection.disconnect()
            }
        }
        throw IOException("Too many download redirects")
    }

    private fun verifyFile(playFile: PlayFile, actualSize: Long, actualSha256: String, actualSha1: String) {
        if (playFile.size > 0L && actualSize != playFile.size) {
            throw IOException("Size verification failed for ${playFile.name}")
        }
        if (playFile.sha256.isNotBlank() && !actualSha256.equals(playFile.sha256, true)) {
            throw IOException("SHA-256 verification failed for ${playFile.name}")
        }
        if (playFile.sha256.isBlank() && playFile.sha1.isNotBlank() && !actualSha1.equals(playFile.sha1, true)) {
            throw IOException("SHA-1 verification failed for ${playFile.name}")
        }
    }

    private fun buildArtifact(app: App, downloaded: List<DownloadedFile>, workDir: File): Artifact {
        val apks = downloaded.filter { it.playFile.type == PlayFile.Type.BASE || it.playFile.type == PlayFile.Type.SPLIT }
        val extra = downloaded.filterNot { it in apks }
        val baseOnly = apks.size == 1 && apks.single().playFile.type == PlayFile.Type.BASE && extra.isEmpty()
        val baseName = safeDisplayName(
            listOf(app.displayName, app.versionName, app.packageName)
                .filter { it.isNotBlank() }
                .joinToString("-")
        )

        if (baseOnly) {
            val output = File(workDir, "$baseName.apk")
            apks.single().file.copyTo(output, overwrite = true)
            return Artifact(output, ".apk", "application/vnd.android.package-archive")
        }

        val output = File(workDir, "$baseName.apks")
        ZipOutputStream(BufferedOutputStream(FileOutputStream(output), BUFFER_SIZE)).use { zip ->
            downloaded.forEach { item ->
                val prefix = when (item.playFile.type) {
                    PlayFile.Type.BASE, PlayFile.Type.SPLIT -> ""
                    PlayFile.Type.OBB, PlayFile.Type.PATCH -> "obb/"
                }
                zip.putNextEntry(ZipEntry(prefix + safeZipEntry(item.file.name)))
                FileInputStream(item.file).use { it.copyTo(zip, BUFFER_SIZE) }
                zip.closeEntry()
            }
            zip.putNextEntry(ZipEntry("nova-manifest.json"))
            zip.write(buildManifest(app, downloaded).toString(2).toByteArray(Charsets.UTF_8))
            zip.closeEntry()
        }
        return Artifact(output, ".apks", "application/zip")
    }

    private fun buildManifest(app: App, downloaded: List<DownloadedFile>): JSONObject = JSONObject().apply {
        put("format", "nova-apks-v1")
        put("packageName", app.packageName)
        put("displayName", app.displayName)
        put("versionName", app.versionName)
        put("versionCode", app.versionCode)
        put("createdAt", System.currentTimeMillis())
        put("source", "Google Play")
        put("files", JSONArray().apply {
            downloaded.forEach { item ->
                put(JSONObject().apply {
                    put("name", item.file.name)
                    put("type", item.playFile.type.name.lowercase(Locale.ROOT))
                    put("size", item.file.length())
                    put("sha256", item.playFile.sha256)
                    put("sha1", item.playFile.sha1)
                })
            }
        })
    }

    private fun publishToDownloads(artifact: Artifact): PublishedFile {
        val displayName = artifact.file.name
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, displayName)
                put(MediaStore.Downloads.MIME_TYPE, artifact.mimeType)
                put(MediaStore.Downloads.RELATIVE_PATH, "${Environment.DIRECTORY_DOWNLOADS}/$DOWNLOAD_SUBDIRECTORY")
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val resolver = applicationContext.contentResolver
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IOException("Could not create the Downloads file")
            try {
                resolver.openOutputStream(uri, "w")?.use { output ->
                    FileInputStream(artifact.file).use { it.copyTo(output, BUFFER_SIZE) }
                } ?: throw IOException("Could not open the Downloads file")
                values.clear()
                values.put(MediaStore.Downloads.IS_PENDING, 0)
                resolver.update(uri, values, null, null)
                PublishedFile(displayName, uri)
            } catch (exception: Exception) {
                resolver.delete(uri, null, null)
                throw exception
            }
        } else {
            @Suppress("DEPRECATION")
            val directory = File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
                DOWNLOAD_SUBDIRECTORY
            ).apply { mkdirs() }
            val output = uniqueFile(directory, displayName)
            artifact.file.copyTo(output, overwrite = false)
            PublishedFile(output.name, Uri.fromFile(output))
        }
    }

    private suspend fun report(step: String, percent: Int, detail: String, indeterminate: Boolean) {
        setProgress(workDataOf(KEY_STEP to step, KEY_PROGRESS to percent, KEY_DETAIL to detail))
        updateNotification(detail, percent, indeterminate)
    }

    private fun reportBlocking(step: String, percent: Int, detail: String) {
        setProgressAsync(workDataOf(KEY_STEP to step, KEY_PROGRESS to percent, KEY_DETAIL to detail))
        updateNotification(detail, percent, false)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            notificationManager.createNotificationChannel(
                NotificationChannel(
                    CHANNEL_ID,
                    applicationContext.getString(R.string.apk_play_channel_name),
                    NotificationManager.IMPORTANCE_LOW
                )
            )
        }
    }

    private fun createForegroundInfo(
        packageName: String,
        text: String,
        progress: Int,
        indeterminate: Boolean
    ): ForegroundInfo {
        val notification = buildProgressNotification(packageName, text, progress, indeterminate)
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ForegroundInfo(notificationId, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            ForegroundInfo(notificationId, notification)
        }
    }

    private fun updateNotification(text: String, progress: Int, indeterminate: Boolean) {
        val packageName = inputData.getString(KEY_PACKAGE_NAME).orEmpty()
        notificationManager.notify(notificationId, buildProgressNotification(packageName, text, progress, indeterminate))
    }

    private fun buildProgressNotification(
        packageName: String,
        text: String,
        progress: Int,
        indeterminate: Boolean
    ) = NotificationCompat.Builder(applicationContext, CHANNEL_ID)
        .setSmallIcon(android.R.drawable.stat_sys_download)
        .setContentTitle(applicationContext.getString(R.string.apk_play_notification_title))
        .setContentText(text)
        .setContentIntent(activityPendingIntent(packageName))
        .setOnlyAlertOnce(true)
        .setOngoing(true)
        .setProgress(100, progress.coerceIn(0, 100), indeterminate)
        .build()

    private fun showCompletedNotification(fileName: String) {
        notificationManager.notify(
            notificationId + DONE_NOTIFICATION_OFFSET,
            NotificationCompat.Builder(applicationContext, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.stat_sys_download_done)
                .setContentTitle(applicationContext.getString(R.string.apk_play_completed_title))
                .setContentText(fileName)
                .setContentIntent(activityPendingIntent(inputData.getString(KEY_PACKAGE_NAME).orEmpty()))
                .setAutoCancel(true)
                .build()
        )
    }

    private fun showFailedNotification(message: String) {
        notificationManager.notify(
            notificationId + FAILED_NOTIFICATION_OFFSET,
            NotificationCompat.Builder(applicationContext, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.stat_notify_error)
                .setContentTitle(applicationContext.getString(R.string.apk_play_failed_title))
                .setContentText(message.take(180))
                .setContentIntent(activityPendingIntent(inputData.getString(KEY_PACKAGE_NAME).orEmpty()))
                .setAutoCancel(true)
                .build()
        )
    }

    private fun activityPendingIntent(packageName: String): PendingIntent = PendingIntent.getActivity(
        applicationContext,
        notificationId,
        Intent(applicationContext, PlayStoreApkDownloaderActivity::class.java).apply {
            putExtra(PlayStoreApkDownloaderActivity.EXTRA_INPUT, packageName)
            addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        },
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    private fun failure(code: String, message: String): Result = Result.failure(
        workDataOf(KEY_ERROR_CODE to code, KEY_ERROR to message.take(900))
    )

    private fun classifyError(exception: Throwable): String {
        val raw = exception.message.orEmpty()
        return when {
            exception is AnonymousPlaySession.AnonymousSessionException && exception.statusCode == 429 -> ERROR_RATE_LIMITED
            exception is GooglePlayException.AppNotSupported -> ERROR_INCOMPATIBLE
            exception is GooglePlayException.AppNotPurchased -> ERROR_UNAVAILABLE
            exception is GooglePlayException.NotFound || exception is GooglePlayException.AppRemoved -> ERROR_NOT_FOUND
            exception is GooglePlayException.EmptyDownloads -> ERROR_NO_FILES
            raw.contains("not supported", true) || raw.contains("incompatible", true) -> ERROR_INCOMPATIBLE
            raw.contains("not purchased", true) || raw.contains("not available", true) -> ERROR_UNAVAILABLE
            raw.contains("not found", true) || raw.contains("removed", true) -> ERROR_NOT_FOUND
            else -> ERROR_DOWNLOAD_FAILED
        }
    }

    private fun humanError(exception: Throwable): String {
        val raw = exception.message.orEmpty().trim()
        return when {
            exception is AnonymousPlaySession.AnonymousSessionException && exception.statusCode == 429 ->
                applicationContext.getString(R.string.apk_play_error_rate_limited)
            raw.contains("not supported", true) -> applicationContext.getString(R.string.apk_play_error_incompatible)
            raw.contains("not purchased", true) -> applicationContext.getString(R.string.apk_play_error_unavailable)
            raw.isNotBlank() -> raw
            else -> exception.javaClass.simpleName
        }
    }

    private fun safePackageFileName(name: String, index: Int): String {
        val fallback = if (index == 0) "base.apk" else "split_$index.apk"
        val cleaned = name.substringAfterLast('/').replace(INVALID_FILE_CHARS, "_").trim('.', ' ')
        return cleaned.takeIf { it.endsWith(".apk", true) || it.endsWith(".obb", true) } ?: fallback
    }

    private fun safeDisplayName(raw: String): String {
        val cleaned = raw.replace(INVALID_FILE_CHARS, "_").replace(Regex("\\s+"), " ").trim('.', ' ')
        return cleaned.ifBlank { "GooglePlay-${UUID.randomUUID()}" }.take(100)
    }

    private fun safeZipEntry(raw: String): String = raw.replace(INVALID_FILE_CHARS, "_").trim('.', ' ').ifBlank { "file.bin" }

    private fun uniqueFile(directory: File, displayName: String): File {
        val direct = File(directory, displayName)
        if (!direct.exists()) return direct
        val extension = displayName.substringAfterLast('.', "")
        val stem = if (extension.isBlank()) displayName else displayName.removeSuffix(".$extension")
        var index = 2
        while (true) {
            val candidate = File(directory, "$stem ($index)${if (extension.isBlank()) "" else ".$extension"}")
            if (!candidate.exists()) return candidate
            index++
        }
    }

    private fun ByteArray.toHex(): String = joinToString("") { "%02x".format(it.toInt() and 0xff) }

    private data class DownloadedFile(val playFile: PlayFile, val file: File)
    private data class Artifact(val file: File, val extension: String, val mimeType: String) {
        val name: String get() = file.name
    }
    private data class PublishedFile(val displayName: String, val uri: Uri)
    private class PermanentFailure(val code: String, message: String) : Exception(message)

    companion object {
        const val KEY_PACKAGE_NAME = "play_package_name"
        const val KEY_STEP = "play_step"
        const val KEY_PROGRESS = "play_progress"
        const val KEY_DETAIL = "play_detail"
        const val KEY_OUTPUT_NAME = "play_output_name"
        const val KEY_OUTPUT_URI = "play_output_uri"
        const val KEY_OUTPUT_KIND = "play_output_kind"
        const val KEY_ERROR_CODE = "play_error_code"
        const val KEY_ERROR = "play_error"

        const val STEP_SESSION = "session"
        const val STEP_DETAILS = "details"
        const val STEP_PURCHASE = "purchase"
        const val STEP_DOWNLOADING = "downloading"
        const val STEP_PACKING = "packing"
        const val STEP_SAVING = "saving"
        const val STEP_DONE = "done"

        const val ERROR_INVALID_PACKAGE = "invalid_package"
        const val ERROR_NOT_FOUND = "not_found"
        const val ERROR_PAID_APP = "paid_app"
        const val ERROR_UNAVAILABLE = "unavailable"
        const val ERROR_NO_FILES = "no_files"
        const val ERROR_RATE_LIMITED = "rate_limited"
        const val ERROR_INCOMPATIBLE = "incompatible"
        const val ERROR_DOWNLOAD_FAILED = "download_failed"

        const val DOWNLOAD_SUBDIRECTORY = "NovaDownloader/APK/PlayStore"
        private const val CHANNEL_ID = "nova_play_apk_downloads"
        private const val NOTIFICATION_BASE = 9200
        private const val DONE_NOTIFICATION_OFFSET = 20000
        private const val FAILED_NOTIFICATION_OFFSET = 30000
        private const val BUFFER_SIZE = 64 * 1024
        private const val PROGRESS_GRANULARITY = 512 * 1024L
        private const val MAX_REDIRECTS = 6
        private const val MAX_RETRIES = 2
        private const val DOWNLOAD_USER_AGENT = "Mozilla/5.0 (Linux; Android) NovaDownloader/PlayAPK"
        private val INVALID_FILE_CHARS = Regex("[\\\\/:*?\"<>|\\p{Cntrl}]")
    }
}
