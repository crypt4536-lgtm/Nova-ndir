package com.nova.downloader.service

import com.nova.downloader.i18n.AppText
import com.nova.downloader.BuildConfig
import com.nova.downloader.R

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Drawable
import android.graphics.ImageDecoder
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.nova.downloader.core.PetCatalog
import com.nova.downloader.data.AppSettings
import com.nova.downloader.data.CustomPetVault
import com.nova.downloader.data.DownloadState
import com.nova.downloader.data.DownloadEngine
import com.nova.downloader.data.HistoryStore
import com.nova.downloader.data.ResolutionTaskStore
import com.nova.downloader.ui.MainActivity
import com.nova.downloader.ui.PetMenuActivity
import kotlin.math.abs

class PetOverlayService : Service() {
    private lateinit var windowManager: WindowManager
    private lateinit var settings: AppSettings
    private lateinit var history: HistoryStore
    private lateinit var resolutionTasks: ResolutionTaskStore
    private var root: LinearLayout? = null
    private var petView: TextView? = null
    private var petImageView: ImageView? = null
    private var statusView: TextView? = null
    private var params: WindowManager.LayoutParams? = null
    private val handler = Handler(Looper.getMainLooper())

    private val refresher = object : Runnable {
        override fun run() {
            refreshAppearanceAndStatus()
            handler.postDelayed(this, if (settings.petLowPower) 3_000L else 1_000L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        settings = AppSettings(this)
        history = HistoryStore(this)
        resolutionTasks = ResolutionTaskStore(this)
        windowManager = getSystemService(WindowManager::class.java)
        createNotificationChannel()
        startForeground(PET_NOTIFICATION_ID, buildForegroundNotification())
        if (!Settings.canDrawOverlays(this) || !settings.petEnabled) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return
        }
        addOverlay()
        handler.post(refresher)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            settings.petEnabled = false
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        if (!settings.petEnabled || !Settings.canDrawOverlays(this)) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        if (root == null) addOverlay()
        refreshAppearanceAndStatus()
        return START_STICKY
    }

    override fun onDestroy() {
        // Cancel refresh + any pending tap/long-press callbacks so a stopped pet
        // cannot launch an activity after the overlay has already been removed.
        handler.removeCallbacksAndMessages(null)
        root?.let { runCatching { windowManager.removeView(it) } }
        root = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(
            NotificationChannel(
                PET_CHANNEL_ID,
                getString(com.nova.downloader.R.string.pet_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(com.nova.downloader.R.string.pet_channel_description)
                setShowBadge(false)
            }
        )
    }

    private fun buildForegroundNotification(): android.app.Notification {
        val openMenu = PendingIntent.getActivity(
            this,
            6202,
            Intent(this, PetMenuActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stopPet = PendingIntent.getService(
            this,
            6203,
            Intent(this, PetOverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, PET_CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setContentTitle(getString(com.nova.downloader.R.string.pet_notification_title))
            .setContentText(getString(com.nova.downloader.R.string.pet_notification_text))
            .setContentIntent(openMenu)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .addAction(0, getString(com.nova.downloader.R.string.pet_notification_open), openMenu)
            .addAction(0, getString(com.nova.downloader.R.string.pet_notification_disable), stopPet)
            .build()
    }

    private fun addOverlay() {
        if (root != null) return
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }
        val pet = TextView(this).apply {
            gravity = Gravity.CENTER
            textSize = 27f
            minWidth = dp(62)
            minHeight = dp(62)
            setPadding(dp(9), dp(7), dp(9), dp(7))
            elevation = dp(8).toFloat()
            contentDescription = AppText.get(R.string.pet_content_description)
        }
        val petImage = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            contentDescription = AppText.get(R.string.custom_pet_content_description)
            visibility = View.GONE
            elevation = dp(8).toFloat()
        }
        val status = TextView(this).apply {
            gravity = Gravity.CENTER
            textSize = 11f
            setTextColor(Color.WHITE)
            setPadding(dp(8), dp(4), dp(8), dp(4))
            background = GradientDrawable().apply {
                setColor(Color.argb(225, 9, 20, 39))
                cornerRadius = dp(12).toFloat()
            }
            visibility = View.GONE
        }
        container.addView(pet)
        container.addView(petImage, LinearLayout.LayoutParams(dp(72), dp(72)))
        container.addView(status, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(4) })

        val layoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            } else {
                @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
            },
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = settings.petX
            y = settings.petY
        }

        val dragListener = PetDragTouchListener(layoutParams)
        pet.setOnTouchListener(dragListener)
        petImage.setOnTouchListener(dragListener)
        root = container
        petView = pet
        petImageView = petImage
        statusView = status
        params = layoutParams
        windowManager.addView(container, layoutParams)
        refreshAppearanceAndStatus()
    }

    private fun refreshAppearanceAndStatus() {
        if (!settings.petEnabled || !Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        val pet = petView ?: return
        val image = petImageView ?: return
        val size = dp(62 * settings.petSizePercent / 100)
        pet.minWidth = size; pet.minHeight = size; pet.alpha = settings.petOpacityPercent / 100f
        image.layoutParams = (image.layoutParams ?: LinearLayout.LayoutParams(size, size)).apply { width = size; height = size }
        image.alpha = settings.petOpacityPercent / 100f
        val custom = settings.petType == AppSettings.PET_CUSTOM
        if (custom) {
            val state = currentPetState()
            val file = CustomPetVault.fileForState(this, state)
            val drawable = file?.let(::loadPetDrawable)
            image.setImageDrawable(drawable)
            image.visibility = if (drawable != null) View.VISIBLE else View.GONE
            pet.visibility = if (drawable == null) View.VISIBLE else View.GONE
            pet.text = if (drawable == null) "✦" else ""
        } else {
            image.visibility = View.GONE; pet.visibility = View.VISIBLE
            pet.text = PetCatalog.byId(settings.petType).glyph
        }
        pet.setTextColor(contrastText(settings.petColor))
        pet.background = petBackground(settings.petColor, settings.petShell)
        image.background = petBackground(settings.petColor, settings.petShell)

        val status = statusView ?: return
        if (!settings.petShowStatus) {
            status.visibility = View.GONE
            return
        }
        val activeResolution = resolutionTasks.latestActive()
        if (activeResolution != null) {
            status.text = AppText.get(R.string.pet_status_resolving)
            status.visibility = View.VISIBLE
            return
        }
        val readyResolution = resolutionTasks.latestReady()
        if (readyResolution != null && System.currentTimeMillis() - readyResolution.updatedAt < 60_000L) {
            status.text = AppText.get(R.string.pet_status_video_ready)
            status.visibility = View.VISIBLE
            return
        }
        val active = history.latestActive()
        if (active != null) {
            status.text = when {
                active.status == DownloadState.PENDING -> AppText.get(R.string.pet_status_queued)
                active.engine == DownloadEngine.YT_DLP && active.reason in 0..100 ->
                    AppText.get(R.string.pet_status_downloading_percent, active.reason)
                active.totalBytes > 0L -> {
                    val percent = ((active.bytesDownloaded * 100L) / active.totalBytes)
                        .coerceIn(0L, 100L)
                    AppText.get(R.string.pet_status_downloading_percent, percent)
                }
                else -> AppText.get(R.string.pet_status_downloading)
            }
            status.visibility = View.VISIBLE
            return
        }
        val completed = history.latestCompleted()
        if (settings.petCompletionAlerts && completed != null && System.currentTimeMillis() - completed.updatedAt < 60_000L) {
            status.text = AppText.get(R.string.pet_status_completed_short)
            status.visibility = View.VISIBLE
        } else {
            status.visibility = View.GONE
        }
    }

    private fun petBackground(color: Int, shell: String): GradientDrawable {
        return GradientDrawable().apply {
            when (shell) {
                AppSettings.SHELL_CIRCLE -> shape = GradientDrawable.OVAL
                else -> {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = when (shell) {
                        AppSettings.SHELL_SQUARE -> dp(7).toFloat()
                        AppSettings.SHELL_OUTLINE -> dp(22).toFloat()
                        else -> dp(22).toFloat()
                    }
                }
            }
            if (shell == AppSettings.SHELL_OUTLINE) {
                setColor(Color.argb(80, Color.red(color), Color.green(color), Color.blue(color)))
                setStroke(dp(3), color)
            } else {
                setColor(color)
                setStroke(dp(2), Color.argb(90, 255, 255, 255))
            }
        }
    }


    private fun currentPetState(): String {
        if (resolutionTasks.latestActive() != null) return "downloading"
        val ready = resolutionTasks.latestReady()
        if (ready != null && System.currentTimeMillis() - ready.updatedAt < 60_000L) return "completed"
        val active = history.latestActive()
        if (active != null) return "downloading"
        val recent = history.list().maxByOrNull { it.updatedAt }
        if (recent != null && System.currentTimeMillis() - recent.updatedAt < 25_000L) {
            return when (recent.status) {
                DownloadState.SUCCESSFUL -> "completed"
                DownloadState.FAILED, DownloadState.INVALID_CONTENT -> "error"
                else -> "idle"
            }
        }
        return "idle"
    }

    private fun loadPetDrawable(file: java.io.File): Drawable? = runCatching {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            ImageDecoder.decodeDrawable(ImageDecoder.createSource(file))
        } else {
            file.inputStream().use { Drawable.createFromStream(it, file.name) }
        }
    }.getOrNull()

    private fun contrastText(color: Int): Int {
        val luminance = (Color.red(color) * 299 + Color.green(color) * 587 + Color.blue(color) * 114) / 1000
        return if (luminance >= 155) Color.BLACK else Color.WHITE
    }

    /**
     * Checkpoint 047 pet gesture contract:
     * - single tap: open Nova main window
     * - drag beyond Android touch slop: move pet (cancels long-press)
     * - stationary long press: open pet menu with haptic feedback
     * - double tap: alternate shortcut to the pet menu
     *
     * Single tap is intentionally confirmed after the platform double-tap window so
     * the first tap of a double-tap never launches Nova and then immediately opens
     * the menu. Dragging remains immediate once touch slop is crossed.
     */
    private inner class PetDragTouchListener(
        private val layoutParams: WindowManager.LayoutParams
    ) : View.OnTouchListener {
        private val touchSlop = ViewConfiguration.get(this@PetOverlayService).scaledTouchSlop
        private val longPressTimeoutMs = ViewConfiguration.getLongPressTimeout().toLong()
        private val doubleTapTimeoutMs = ViewConfiguration.getDoubleTapTimeout().toLong()

        private var initialX = 0
        private var initialY = 0
        private var initialTouchX = 0f
        private var initialTouchY = 0f
        private var moved = false
        private var longPressTriggered = false
        private var secondTapCandidate = false
        private var lastTapUpTime = 0L
        private var pendingSingleTap: Runnable? = null
        private var pendingLongPress: Runnable? = null

        override fun onTouch(view: View, event: MotionEvent): Boolean {
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = layoutParams.x
                    initialY = layoutParams.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    moved = false
                    longPressTriggered = false

                    secondTapCandidate =
                        lastTapUpTime > 0L && event.eventTime - lastTapUpTime <= doubleTapTimeoutMs
                    if (secondTapCandidate) cancelPendingSingleTap()

                    pendingLongPress = Runnable {
                        if (!moved && !longPressTriggered) {
                            longPressTriggered = true
                            cancelPendingSingleTap()
                            view.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                            openPetMenu()
                        }
                    }.also { handler.postDelayed(it, longPressTimeoutMs) }
                    return true
                }

                MotionEvent.ACTION_MOVE -> {
                    val dxPixels = initialTouchX - event.rawX
                    val dyPixels = event.rawY - initialTouchY
                    if (!moved && (abs(dxPixels) > touchSlop || abs(dyPixels) > touchSlop)) {
                        moved = true
                        secondTapCandidate = false
                        cancelPendingLongPress()
                        cancelPendingSingleTap()
                    }
                    if (moved) {
                        layoutParams.x = (initialX + dxPixels.toInt()).coerceAtLeast(0)
                        layoutParams.y = (initialY + dyPixels.toInt()).coerceAtLeast(0)
                        root?.let { windowManager.updateViewLayout(it, layoutParams) }
                    }
                    return true
                }

                MotionEvent.ACTION_UP -> {
                    cancelPendingLongPress()

                    if (moved) {
                        if (settings.petSnapEdge) {
                            val screenWidth = resources.displayMetrics.widthPixels
                            layoutParams.x = if (event.rawX >= screenWidth / 2f) {
                                0
                            } else {
                                (screenWidth - (root?.width ?: dp(72))).coerceAtLeast(0)
                            }
                            root?.let { windowManager.updateViewLayout(it, layoutParams) }
                        }
                        settings.petX = layoutParams.x
                        settings.petY = layoutParams.y
                        lastTapUpTime = 0L
                        secondTapCandidate = false
                        return true
                    }

                    if (longPressTriggered) {
                        lastTapUpTime = 0L
                        secondTapCandidate = false
                        return true
                    }

                    if (secondTapCandidate) {
                        lastTapUpTime = 0L
                        secondTapCandidate = false
                        cancelPendingSingleTap()
                        openPetMenu()
                    } else {
                        lastTapUpTime = event.eventTime
                        scheduleConfirmedSingleTap()
                    }
                    return true
                }

                MotionEvent.ACTION_CANCEL -> {
                    cancelPendingLongPress()
                    cancelPendingSingleTap()
                    moved = false
                    longPressTriggered = false
                    secondTapCandidate = false
                    lastTapUpTime = 0L
                    return true
                }
            }
            return false
        }

        private fun scheduleConfirmedSingleTap() {
            cancelPendingSingleTap()
            pendingSingleTap = Runnable {
                pendingSingleTap = null
                lastTapUpTime = 0L
                if (!moved && !longPressTriggered) openNovaMain()
            }.also { handler.postDelayed(it, doubleTapTimeoutMs) }
        }

        private fun cancelPendingSingleTap() {
            pendingSingleTap?.let(handler::removeCallbacks)
            pendingSingleTap = null
        }

        private fun cancelPendingLongPress() {
            pendingLongPress?.let(handler::removeCallbacks)
            pendingLongPress = null
        }
    }

    private fun openNovaMain() {
        val pendingIntent = PendingIntent.getActivity(
            this,
            6204,
            Intent(this, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        runCatching { pendingIntent.send() }
    }

    private fun openPetMenu() {
        val pendingIntent = PendingIntent.getActivity(
            this,
            6201,
            Intent(this, PetMenuActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        runCatching { pendingIntent.send() }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    companion object {
        private const val PET_CHANNEL_ID = "nova_pet_overlay"
        private const val PET_NOTIFICATION_ID = 6200
        private const val ACTION_STOP = "com.nova.downloader.pet.STOP"
        fun startOrRefresh(context: Context) {
            if (!BuildConfig.HAS_PET_OVERLAY) return
            val settings = AppSettings(context)
            if (!settings.petEnabled || !Settings.canDrawOverlays(context)) return
            val intent = Intent(context, PetOverlayService::class.java)
            runCatching {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(intent)
                } else {
                    context.startService(intent)
                }
            }
        }

        fun refreshMaybe(context: Context) {
            if (!BuildConfig.HAS_PET_OVERLAY) return
            if (AppSettings(context).petEnabled && Settings.canDrawOverlays(context)) {
                startOrRefresh(context)
            }
        }

        fun stop(context: Context) {
            if (!BuildConfig.HAS_PET_OVERLAY) return
            context.stopService(Intent(context, PetOverlayService::class.java))
        }
    }
}
