package com.nova.downloader.translation

import java.util.Locale

/** Pure helpers used by the APK resource translator. */
object ApkTranslationCore {
    private val protectedPatterns = listOf(
        Regex("%(?:\\d+\\$)?[-#+ 0,(<]*\\d*(?:\\.\\d+)?[a-zA-Z%]"),
        Regex("\\\\[ntr'\"]"),
        Regex("</?[^>]+>"),
        Regex("&(?:[a-zA-Z]+|#\\d+|#x[0-9a-fA-F]+);"),
        Regex("\\$\\{[^}]+}"),
        Regex("\\{[a-zA-Z_][a-zA-Z0-9_.-]*}"),
        Regex("https?://\\S+", RegexOption.IGNORE_CASE),
        Regex("mailto:\\S+", RegexOption.IGNORE_CASE)
    )

    data class MaskedText(val text: String, val tokens: Map<String, String>) {
        fun restore(translated: String): String {
            var result = translated
            tokens.forEach { (token, original) ->
                result = result.replace(token, original, ignoreCase = false)
                // Some translation models insert spaces around the marker.
                result = result.replace(token.replace("_", " "), original, ignoreCase = false)
            }
            return result
        }
    }

    fun mask(text: String): MaskedText {
        var working = text
        val tokens = linkedMapOf<String, String>()
        protectedPatterns.forEach { pattern ->
            working = pattern.replace(working) { match ->
                val token = "ZXQNOVA_${tokens.size.toString().padStart(4, '0')}_QXZ"
                tokens[token] = match.value
                token
            }
        }
        return MaskedText(working, tokens)
    }

    fun shouldTranslate(name: String, value: String, includeAppName: Boolean): Boolean {
        val trimmed = value.trim()
        if (trimmed.length !in 2..4_500) return false
        if (!includeAppName && name in setOf("app_name", "application_name", "launcher_name")) return false
        if (trimmed.startsWith("@") || trimmed.startsWith("?")) return false
        if (trimmed.matches(Regex("(?i)^(https?://|mailto:|content://|file://|[a-z0-9_.-]+/[a-z0-9_./-]+).*$"))) return false
        if (trimmed.matches(Regex("^[A-Z0-9_.:/+-]{2,}$")) && !trimmed.contains(' ')) return false
        if (trimmed.none { it.isLetter() }) return false
        if (name.startsWith("google_", true)) return false
        return true
    }

    fun outputName(inputName: String, targetLanguage: String): String {
        val stem = inputName.substringBeforeLast('.', inputName)
            .replace(Regex("[\\/:*?\"<>|\\p{Cntrl}]"), "_")
            .trim('.', ' ')
            .ifBlank { "translated-app" }
            .take(110)
        val tag = targetLanguage.lowercase(Locale.ROOT).replace(Regex("[^a-z0-9-]"), "")
            .ifBlank { "translated" }
        return "$stem-$tag-translated.apk"
    }

    fun targetQualifier(languageTag: String): String = when (languageTag.lowercase(Locale.ROOT)) {
        "zh" -> "-zh-rCN"
        "zh-tw" -> "-zh-rTW"
        "pt-br" -> "-pt-rBR"
        else -> "-${languageTag.lowercase(Locale.ROOT)}"
    }

    fun sourceQualifierMatches(qualifier: String, sourceTag: String): Int {
        val q = qualifier.lowercase(Locale.ROOT)
        val source = sourceTag.lowercase(Locale.ROOT)
        if (q.isBlank()) return 1
        if (q == "-$source" || q.startsWith("-$source-r")) return 2
        return 0
    }
}
