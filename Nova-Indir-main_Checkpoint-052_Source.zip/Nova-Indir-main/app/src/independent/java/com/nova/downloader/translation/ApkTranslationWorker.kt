package com.nova.downloader.translation

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import androidx.core.app.NotificationCompat
import androidx.core.content.FileProvider
import androidx.work.CoroutineWorker
import androidx.work.ForegroundInfo
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.android.apksig.ApkSigner
import com.android.apksig.ApkVerifier
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import com.nova.downloader.R
import com.nova.downloader.ui.ApkTranslationActivity
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.lang.reflect.Array as ReflectArray
import java.lang.reflect.Method
import java.lang.reflect.Modifier
import java.math.BigInteger
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.cert.X509Certificate
import java.util.Collections
import java.util.Date
import java.util.IdentityHashMap
import java.util.Locale
import java.util.concurrent.TimeUnit
import java.util.zip.ZipFile
import javax.security.auth.x500.X500Principal

/**
 * Adds a translated Android string-resource locale to a user-selected APK,
 * rebuilds the resource archive with ARSCLib and signs the result with a
 * Nova-owned AndroidKeyStore key. The original APK is never modified.
 */
class ApkTranslationWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    private val notificationManager = context.getSystemService(NotificationManager::class.java)
    private val notificationId = NOTIFICATION_BASE + (id.hashCode() and 0x0fff)

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val sourceUri = inputData.getString(KEY_INPUT_URI)?.let(Uri::parse)
            ?: return@withContext failure(ERROR_INVALID_INPUT, "Missing APK document")
        val inputName = inputData.getString(KEY_INPUT_NAME).orEmpty().ifBlank { "application.apk" }
        val sourceLanguage = inputData.getString(KEY_SOURCE_LANGUAGE).orEmpty()
        val targetLanguage = inputData.getString(KEY_TARGET_LANGUAGE).orEmpty()
        val includeAppName = inputData.getBoolean(KEY_INCLUDE_APP_NAME, false)
        val wifiOnly = inputData.getBoolean(KEY_WIFI_ONLY, false)

        if (!inputName.endsWith(".apk", true)) {
            return@withContext failure(ERROR_SPLIT_UNSUPPORTED, "Select one installable .apk file, not an APKS/XAPK/APKM bundle")
        }
        if (sourceLanguage == targetLanguage || mlLanguage(sourceLanguage) == null || mlLanguage(targetLanguage) == null) {
            return@withContext failure(ERROR_LANGUAGE, "Invalid source or target language")
        }

        val workDir = File(applicationContext.cacheDir, "apk-translation/$id").apply {
            deleteRecursively()
            mkdirs()
        }
        val inputApk = File(workDir, "input.apk")
        val rebuiltApk = File(workDir, "rebuilt-unsigned.apk")
        val signedApk = File(workDir, ApkTranslationCore.outputName(inputName, targetLanguage))

        createNotificationChannel()
        setForeground(createForegroundInfo(applicationContext.getString(R.string.apk_translation_step_copying), 1, true))

        try {
            report(STEP_COPYING, 3, applicationContext.getString(R.string.apk_translation_step_copying), true)
            copyAndValidate(sourceUri, inputApk)

            report(STEP_MODEL, 8, applicationContext.getString(R.string.apk_translation_step_model), true)
            val translator = createTranslator(sourceLanguage, targetLanguage)
            try {
                val conditions = DownloadConditions.Builder().apply {
                    if (wifiOnly) requireWifi()
                }.build()
                Tasks.await(translator.downloadModelIfNeeded(conditions), MODEL_TIMEOUT_MINUTES, TimeUnit.MINUTES)

                report(STEP_READING, 14, applicationContext.getString(R.string.apk_translation_step_reading), true)
                val stats = ArscEditor().translate(
                    inputApk = inputApk,
                    outputApk = rebuiltApk,
                    sourceLanguage = sourceLanguage,
                    targetLanguage = targetLanguage,
                    includeAppName = includeAppName
                ) { index, total, name, original ->
                    if (isStopped) throw CancellationException("APK translation cancelled")
                    val masked = ApkTranslationCore.mask(original)
                    val translated = Tasks.await(
                        translator.translate(masked.text),
                        TRANSLATION_TIMEOUT_SECONDS,
                        TimeUnit.SECONDS
                    )
                    val restored = masked.restore(translated).trim()
                    val progress = 18 + ((index.toLong() * 57L) / total.coerceAtLeast(1)).toInt().coerceIn(0, 57)
                    reportBlocking(
                        STEP_TRANSLATING,
                        progress,
                        applicationContext.getString(R.string.apk_translation_progress, index, total, name)
                    )
                    restored
                }

                if (stats.translated == 0) {
                    throw PermanentFailure(ERROR_NO_STRINGS, "No translatable simple string resources were found")
                }

                report(STEP_SIGNING, 82, applicationContext.getString(R.string.apk_translation_step_signing), true)
                signAndVerify(rebuiltApk, signedApk)

                report(STEP_SAVING, 94, applicationContext.getString(R.string.apk_translation_step_saving), true)
                val published = publishToDownloads(signedApk)
                report(STEP_DONE, 100, published.displayName, false)
                showCompletedNotification(published.displayName)

                Result.success(
                    workDataOf(
                        KEY_OUTPUT_URI to published.uri.toString(),
                        KEY_OUTPUT_NAME to published.displayName,
                        KEY_TRANSLATED_COUNT to stats.translated,
                        KEY_SKIPPED_COUNT to stats.skipped,
                        KEY_TARGET_QUALIFIER to ApkTranslationCore.targetQualifier(targetLanguage)
                    )
                )
            } finally {
                translator.close()
            }
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (failure: PermanentFailure) {
            showFailedNotification(failure.message.orEmpty())
            failure(failure.code, failure.message.orEmpty())
        } catch (exception: Exception) {
            val message = humanError(exception)
            showFailedNotification(message)
            failure(classify(exception), message)
        } finally {
            workDir.deleteRecursively()
        }
    }

    private fun createTranslator(source: String, target: String) = Translation.getClient(
        TranslatorOptions.Builder()
            .setSourceLanguage(mlLanguage(source) ?: error("Unsupported source language"))
            .setTargetLanguage(mlLanguage(target) ?: error("Unsupported target language"))
            .build()
    )

    private fun mlLanguage(tag: String): String? = when (tag.lowercase(Locale.ROOT)) {
        "en" -> TranslateLanguage.ENGLISH
        "tr" -> TranslateLanguage.TURKISH
        "de" -> TranslateLanguage.GERMAN
        "es" -> TranslateLanguage.SPANISH
        "fr" -> TranslateLanguage.FRENCH
        "it" -> TranslateLanguage.ITALIAN
        "pt" -> TranslateLanguage.PORTUGUESE
        "ru" -> TranslateLanguage.RUSSIAN
        "ar" -> TranslateLanguage.ARABIC
        "ja" -> TranslateLanguage.JAPANESE
        "ko" -> TranslateLanguage.KOREAN
        "zh" -> TranslateLanguage.CHINESE
        else -> null
    }

    private fun copyAndValidate(uri: Uri, destination: File) {
        var copied = 0L
        applicationContext.contentResolver.openInputStream(uri)?.use { input ->
            FileOutputStream(destination).use { output ->
                val buffer = ByteArray(256 * 1024)
                while (true) {
                    if (isStopped) throw CancellationException("APK translation cancelled")
                    val read = input.read(buffer)
                    if (read < 0) break
                    copied += read
                    if (copied > MAX_APK_BYTES) throw PermanentFailure(ERROR_INVALID_INPUT, "APK is larger than the supported limit")
                    output.write(buffer, 0, read)
                }
            }
        } ?: throw PermanentFailure(ERROR_INVALID_INPUT, "The selected APK could not be opened")
        if (copied < MIN_APK_BYTES) throw PermanentFailure(ERROR_INVALID_INPUT, "The selected file is not a valid APK")
        runCatching {
            ZipFile(destination).use { zip ->
                if (zip.getEntry("AndroidManifest.xml") == null || zip.getEntry("resources.arsc") == null) {
                    throw PermanentFailure(ERROR_NO_RESOURCES, "The APK has no compiled Android string resource table")
                }
            }
        }.getOrElse { error ->
            if (error is PermanentFailure) throw error
            throw PermanentFailure(ERROR_INVALID_INPUT, "The selected file is not a readable APK archive")
        }
    }

    private fun signAndVerify(input: File, output: File) {
        val entry = signingEntry()
        val signer = ApkSigner.SignerConfig.Builder(
            "NOVA_APK_TRANSLATOR",
            entry.privateKey,
            listOf(entry.certificate as X509Certificate)
        ).build()
        output.delete()
        ApkSigner.Builder(listOf(signer))
            .setInputApk(input)
            .setOutputApk(output)
            .setV1SigningEnabled(true)
            .setV2SigningEnabled(true)
            .setV3SigningEnabled(true)
            .build()
            .sign()
        val verification = ApkVerifier.Builder(output).build().verify()
        if (!verification.isVerified) {
            throw PermanentFailure(ERROR_SIGNING, "The rebuilt APK signature could not be verified")
        }
    }

    private fun signingEntry(): KeyStore.PrivateKeyEntry {
        val keyStore = KeyStore.getInstance(KEYSTORE_PROVIDER).apply { load(null) }
        val existing = keyStore.getEntry(KEY_ALIAS, null) as? KeyStore.PrivateKeyEntry
        if (existing != null) return existing

        val now = System.currentTimeMillis()
        val specification = KeyGenParameterSpec.Builder(
            KEY_ALIAS,
            KeyProperties.PURPOSE_SIGN or KeyProperties.PURPOSE_VERIFY
        )
            .setKeySize(2048)
            .setDigests(KeyProperties.DIGEST_SHA256, KeyProperties.DIGEST_SHA512)
            .setSignaturePaddings(KeyProperties.SIGNATURE_PADDING_RSA_PKCS1)
            .setCertificateSubject(X500Principal("CN=Nova APK Translator, O=Nova Downloader"))
            .setCertificateSerialNumber(BigInteger.valueOf(now.coerceAtLeast(1L)))
            .setCertificateNotBefore(Date(now - DAY_MS))
            .setCertificateNotAfter(Date(now + CERTIFICATE_LIFETIME_MS))
            .setUserAuthenticationRequired(false)
            .build()
        KeyPairGenerator.getInstance(KeyProperties.KEY_ALGORITHM_RSA, KEYSTORE_PROVIDER).apply {
            initialize(specification)
            generateKeyPair()
        }
        return keyStore.getEntry(KEY_ALIAS, null) as? KeyStore.PrivateKeyEntry
            ?: throw PermanentFailure(ERROR_SIGNING, "Could not create the local APK signing key")
    }

    private fun publishToDownloads(file: File): PublishedFile {
        val displayName = file.name
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val resolver = applicationContext.contentResolver
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, displayName)
                put(MediaStore.Downloads.MIME_TYPE, APK_MIME)
                put(MediaStore.Downloads.RELATIVE_PATH, "${Environment.DIRECTORY_DOWNLOADS}/$DOWNLOAD_SUBDIRECTORY")
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IOException("Could not create the translated APK in Downloads")
            try {
                resolver.openOutputStream(uri, "w")?.use { output ->
                    FileInputStream(file).use { it.copyTo(output, 256 * 1024) }
                } ?: throw IOException("Could not write the translated APK")
                values.clear()
                values.put(MediaStore.Downloads.IS_PENDING, 0)
                resolver.update(uri, values, null, null)
                PublishedFile(displayName, uri)
            } catch (exception: Exception) {
                resolver.delete(uri, null, null)
                throw exception
            }
        } else {
            @Suppress("DEPRECATION")
            val folder = File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
                DOWNLOAD_SUBDIRECTORY
            ).apply { mkdirs() }
            val target = uniqueFile(folder, displayName)
            file.copyTo(target, overwrite = false)
            PublishedFile(target.name, FileProvider.getUriForFile(applicationContext, "${applicationContext.packageName}.files", target))
        }
    }

    private suspend fun report(step: String, progress: Int, detail: String, indeterminate: Boolean) {
        setProgress(workDataOf(KEY_STEP to step, KEY_PROGRESS to progress, KEY_DETAIL to detail))
        updateNotification(detail, progress, indeterminate)
    }

    private fun reportBlocking(step: String, progress: Int, detail: String) {
        setProgressAsync(workDataOf(KEY_STEP to step, KEY_PROGRESS to progress, KEY_DETAIL to detail))
        updateNotification(detail, progress, false)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            notificationManager.createNotificationChannel(
                NotificationChannel(
                    CHANNEL_ID,
                    applicationContext.getString(R.string.apk_translation_channel),
                    NotificationManager.IMPORTANCE_LOW
                )
            )
        }
    }

    private fun createForegroundInfo(text: String, progress: Int, indeterminate: Boolean): ForegroundInfo {
        val notification = progressNotification(text, progress, indeterminate)
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ForegroundInfo(notificationId, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            ForegroundInfo(notificationId, notification)
        }
    }

    private fun updateNotification(text: String, progress: Int, indeterminate: Boolean) {
        notificationManager.notify(notificationId, progressNotification(text, progress, indeterminate))
    }

    private fun progressNotification(text: String, progress: Int, indeterminate: Boolean) =
        NotificationCompat.Builder(applicationContext, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle(applicationContext.getString(R.string.apk_translation_notification_title))
            .setContentText(text)
            .setContentIntent(activityPendingIntent())
            .setOnlyAlertOnce(true)
            .setOngoing(true)
            .setProgress(100, progress.coerceIn(0, 100), indeterminate)
            .build()

    private fun showCompletedNotification(name: String) {
        notificationManager.notify(
            notificationId + 20_000,
            NotificationCompat.Builder(applicationContext, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.stat_sys_download_done)
                .setContentTitle(applicationContext.getString(R.string.apk_translation_completed_title))
                .setContentText(name)
                .setContentIntent(activityPendingIntent())
                .setAutoCancel(true)
                .build()
        )
    }

    private fun showFailedNotification(message: String) {
        notificationManager.notify(
            notificationId + 30_000,
            NotificationCompat.Builder(applicationContext, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.stat_notify_error)
                .setContentTitle(applicationContext.getString(R.string.apk_translation_failed_title))
                .setContentText(message.take(180))
                .setContentIntent(activityPendingIntent())
                .setAutoCancel(true)
                .build()
        )
    }

    private fun activityPendingIntent(): PendingIntent = PendingIntent.getActivity(
        applicationContext,
        notificationId,
        Intent(applicationContext, ApkTranslationActivity::class.java).addFlags(
            Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
        ),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    private fun failure(code: String, message: String): Result = Result.failure(
        workDataOf(KEY_ERROR_CODE to code, KEY_ERROR to message.take(900))
    )

    private fun classify(exception: Exception): String = when {
        exception.javaClass.name.contains("MlKit", true) -> ERROR_MODEL
        exception.message.orEmpty().contains("model", true) -> ERROR_MODEL
        exception.message.orEmpty().contains("sign", true) -> ERROR_SIGNING
        exception.message.orEmpty().contains("resource", true) -> ERROR_RESOURCES
        else -> ERROR_UNKNOWN
    }

    private fun humanError(exception: Exception): String {
        var current: Throwable? = exception
        repeat(5) {
            val message = current?.message?.trim().orEmpty()
            if (message.isNotBlank()) return message
            current = current?.cause
        }
        return exception.javaClass.simpleName.ifBlank { "Unknown translation error" }
    }

    private fun uniqueFile(folder: File, requested: String): File {
        val direct = File(folder, requested)
        if (!direct.exists()) return direct
        val stem = requested.substringBeforeLast('.', requested)
        val extension = requested.substringAfterLast('.', "")
        var index = 1
        while (true) {
            val candidate = File(folder, "$stem ($index)${if (extension.isBlank()) "" else ".$extension"}")
            if (!candidate.exists()) return candidate
            index++
        }
    }

    private data class PublishedFile(val displayName: String, val uri: Uri)
    private data class TranslationStats(val translated: Int, val skipped: Int)
    private class PermanentFailure(val code: String, message: String) : IOException(message)

    /** Reflection keeps the APK editor isolated from ARSCLib implementation details. */
    private class ArscEditor {
        fun translate(
            inputApk: File,
            outputApk: File,
            sourceLanguage: String,
            targetLanguage: String,
            includeAppName: Boolean,
            translateText: (index: Int, total: Int, name: String, text: String) -> String
        ): TranslationStats {
            val moduleClass = Class.forName("com.reandroid.apk.ApkModule")
            val load = moduleClass.methods.firstOrNull {
                Modifier.isStatic(it.modifiers) && it.name == "loadApkFile" &&
                    it.parameterCount == 1 && it.parameterTypes[0] == File::class.java
            } ?: throw PermanentFailure(ERROR_RESOURCES, "ARSCLib APK loader is unavailable")
            val module = load.invoke(null, inputApk)
                ?: throw PermanentFailure(ERROR_RESOURCES, "Could not load the APK resource table")
            try {
                val table = invokeNoArgs(module, "getTableBlock")
                    ?: throw PermanentFailure(ERROR_NO_RESOURCES, "The APK has no resources.arsc table")
                val packages = collectBySimpleName(table, "PackageBlock")
                if (packages.isEmpty()) throw PermanentFailure(ERROR_NO_RESOURCES, "No Android resource packages were found")

                val candidates = ArrayList<Candidate>()
                packages.forEach { packageBlock ->
                    val best = linkedMapOf<String, Candidate>()
                    collectBySimpleName(packageBlock, "Entry").forEach { entry ->
                        if (invokeBoolean(entry, "isComplex") == true) return@forEach
                        val type = entryType(entry)
                        if (!type.equals("string", true)) return@forEach
                        val name = invokeString(entry, "getName")?.trim().orEmpty()
                        val value = invokeString(entry, "getValueAsString")?.trim().orEmpty()
                        if (name.isBlank() || !ApkTranslationCore.shouldTranslate(name, value, includeAppName)) return@forEach
                        val priority = ApkTranslationCore.sourceQualifierMatches(entryQualifier(entry), sourceLanguage)
                        if (priority == 0) return@forEach
                        val current = best[name]
                        if (current == null || priority > current.priority) {
                            best[name] = Candidate(packageBlock, name, value, priority)
                        }
                    }
                    candidates += best.values
                }

                if (candidates.isEmpty()) throw PermanentFailure(ERROR_NO_STRINGS, "No translatable simple string resources were found")
                val qualifier = ApkTranslationCore.targetQualifier(targetLanguage)
                val translatedCache = linkedMapOf<String, String>()
                var translatedCount = 0
                var skippedCount = 0

                candidates.forEachIndexed { index, candidate ->
                    val translated = translatedCache[candidate.value] ?: try {
                        translateText(index + 1, candidates.size, candidate.name, candidate.value)
                            .takeIf { it.isNotBlank() }
                            ?.also { translatedCache[candidate.value] = it }
                    } catch (cancelled: CancellationException) {
                        throw cancelled
                    } catch (_: Exception) {
                        null
                    }
                    if (translated.isNullOrBlank() || translated == candidate.value) {
                        skippedCount++
                        return@forEachIndexed
                    }
                    val targetEntry = invoke(
                        candidate.packageBlock,
                        "getOrCreate",
                        arrayOf<Class<*>>(String::class.java, String::class.java, String::class.java),
                        arrayOf<Any>(qualifier, "string", candidate.name)
                    ) ?: run {
                        skippedCount++
                        return@forEachIndexed
                    }
                    val updated = runCatching {
                        invoke(
                            targetEntry,
                            "setValueAsString",
                            arrayOf<Class<*>>(String::class.java),
                            arrayOf<Any>(translated)
                        )
                    }.isSuccess
                    if (updated) translatedCount++ else skippedCount++
                }

                invokeNoArgs(table, "refresh")
                invokeNoArgs(module, "refreshTable")
                outputApk.delete()
                invoke(
                    module,
                    "writeApk",
                    arrayOf<Class<*>>(File::class.java),
                    arrayOf<Any>(outputApk)
                )
                if (!outputApk.isFile) {
                    throw PermanentFailure(ERROR_RESOURCES, "ARSCLib did not produce a rebuilt APK")
                }
                if (!outputApk.isFile || outputApk.length() < MIN_APK_BYTES) {
                    throw PermanentFailure(ERROR_RESOURCES, "The rebuilt APK is empty or invalid")
                }
                return TranslationStats(translatedCount, skippedCount)
            } finally {
                runCatching { invokeNoArgs(module, "destroy") }
            }
        }

        private data class Candidate(
            val packageBlock: Any,
            val name: String,
            val value: String,
            val priority: Int
        )

        private fun entryType(entry: Any): String? =
            invokeString(entry, "getTypeName")
                ?: invokeNoArgs(entry, "getTypeBlock")?.let { invokeString(it, "getTypeName") }

        private fun entryQualifier(entry: Any): String {
            val direct = invokeNoArgs(entry, "getResConfig")
            val config = direct ?: invokeNoArgs(entry, "getTypeBlock")?.let { invokeNoArgs(it, "getResConfig") }
            return config?.let {
                invokeString(it, "getQualifiers")
                    ?: invokeString(it, "getQualifier")
                    ?: invokeString(it, "toString")
            }.orEmpty()
        }

        private fun collectBySimpleName(root: Any, expected: String): List<Any> {
            val result = ArrayList<Any>()
            val visited = Collections.newSetFromMap(IdentityHashMap<Any, Boolean>())

            fun walk(value: Any?, depth: Int) {
                if (value == null || depth > MAX_REFLECTION_DEPTH) return
                if (value is String || value is Number || value is Boolean || value is Enum<*>) return
                if (!visited.add(value)) return
                if (value.javaClass.simpleName == expected && value.javaClass.name.startsWith("com.reandroid.")) {
                    result += value
                    return
                }
                when (value) {
                    is Map<*, *> -> value.values.forEach { walk(it, depth + 1) }
                    is Iterable<*> -> value.forEach { walk(it, depth + 1) }
                    is Iterator<*> -> while (value.hasNext()) walk(value.next(), depth + 1)
                    else -> {
                        if (value.javaClass.isArray) {
                            val length = ReflectArray.getLength(value)
                            for (index in 0 until length) walk(ReflectArray.get(value, index), depth + 1)
                            return
                        }
                        if (!value.javaClass.name.startsWith("com.reandroid.")) return
                        value.javaClass.methods.asSequence()
                            .filter(::isTraversalMethod)
                            .take(MAX_METHODS_PER_OBJECT)
                            .forEach { method ->
                                runCatching { walk(method.invoke(value), depth + 1) }
                            }
                    }
                }
            }
            walk(root, 0)
            return result.distinctBy { System.identityHashCode(it) }
        }

        private fun isTraversalMethod(method: Method): Boolean {
            if (method.parameterCount != 0 || Modifier.isStatic(method.modifiers)) return false
            if (method.declaringClass == Any::class.java || method.name in TRAVERSAL_EXCLUDES) return false
            val name = method.name.lowercase(Locale.ROOT)
            val returnType = method.returnType
            val container = returnType.isArray || Iterable::class.java.isAssignableFrom(returnType) ||
                Iterator::class.java.isAssignableFrom(returnType) || Map::class.java.isAssignableFrom(returnType)
            val structural = returnType.name.startsWith("com.reandroid.") &&
                STRUCTURAL_WORDS.any(name::contains)
            return (container && (name.startsWith("get") || name.startsWith("list") || name == "iterator")) || structural
        }

        private fun invokeNoArgs(target: Any, name: String): Any? = invoke(target, name, emptyArray(), emptyArray())

        private fun invokeString(target: Any, name: String): String? =
            runCatching { invokeNoArgs(target, name) as? String }.getOrNull()

        private fun invokeBoolean(target: Any, name: String): Boolean? =
            runCatching { invokeNoArgs(target, name) as? Boolean }.getOrNull()

        private fun invoke(target: Any, name: String, types: Array<Class<*>>, args: Array<Any>): Any? {
            val method = target.javaClass.methods.firstOrNull {
                it.name == name && it.parameterTypes.contentEquals(types)
            } ?: return null
            return method.invoke(target, *args)
        }

        companion object {
            private const val MAX_REFLECTION_DEPTH = 9
            private const val MAX_METHODS_PER_OBJECT = 160
            private val STRUCTURAL_WORDS = listOf("entry", "entries", "typeblock", "spectype", "package", "array", "items")
            private val TRAVERSAL_EXCLUDES = setOf(
                "getParent", "getTableBlock", "getPackageBlock", "getHeaderBlock", "getStringPool",
                "getSpecStringPool", "getTypeStringPool", "getBlockLoad", "getArchive", "getManifest",
                "getResourceIds", "getResourceId", "getReferences", "getReferencedEntries", "getValue"
            )
        }
    }

    companion object {
        const val KEY_INPUT_URI = "input_uri"
        const val KEY_INPUT_NAME = "input_name"
        const val KEY_SOURCE_LANGUAGE = "source_language"
        const val KEY_TARGET_LANGUAGE = "target_language"
        const val KEY_INCLUDE_APP_NAME = "include_app_name"
        const val KEY_WIFI_ONLY = "wifi_only"
        const val KEY_OUTPUT_URI = "output_uri"
        const val KEY_OUTPUT_NAME = "output_name"
        const val KEY_TRANSLATED_COUNT = "translated_count"
        const val KEY_SKIPPED_COUNT = "skipped_count"
        const val KEY_TARGET_QUALIFIER = "target_qualifier"
        const val KEY_STEP = "step"
        const val KEY_PROGRESS = "progress"
        const val KEY_DETAIL = "detail"
        const val KEY_ERROR_CODE = "error_code"
        const val KEY_ERROR = "error"

        const val STEP_COPYING = "copying"
        const val STEP_MODEL = "model"
        const val STEP_READING = "reading"
        const val STEP_TRANSLATING = "translating"
        const val STEP_SIGNING = "signing"
        const val STEP_SAVING = "saving"
        const val STEP_DONE = "done"

        const val ERROR_INVALID_INPUT = "invalid_input"
        const val ERROR_SPLIT_UNSUPPORTED = "split_unsupported"
        const val ERROR_LANGUAGE = "language"
        const val ERROR_NO_RESOURCES = "no_resources"
        const val ERROR_NO_STRINGS = "no_strings"
        const val ERROR_MODEL = "model"
        const val ERROR_RESOURCES = "resources"
        const val ERROR_SIGNING = "signing"
        const val ERROR_UNKNOWN = "unknown"

        private const val CHANNEL_ID = "nova_apk_translation"
        private const val NOTIFICATION_BASE = 38_000
        private const val APK_MIME = "application/vnd.android.package-archive"
        private const val DOWNLOAD_SUBDIRECTORY = "NovaDownloader/APK/Translated"
        private const val KEYSTORE_PROVIDER = "AndroidKeyStore"
        private const val KEY_ALIAS = "nova_apk_translation_signer_v1"
        private const val MIN_APK_BYTES = 1_024L
        private const val MAX_APK_BYTES = 2_000_000_000L
        private const val MODEL_TIMEOUT_MINUTES = 20L
        private const val TRANSLATION_TIMEOUT_SECONDS = 120L
        private const val DAY_MS = 86_400_000L
        private const val CERTIFICATE_LIFETIME_MS = DAY_MS * 365L * 25L
    }
}
