package com.nova.downloader.ui

import android.Manifest
import android.app.DownloadManager
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Typeface
import android.net.Uri
import android.net.http.SslError
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.webkit.CookieManager
import android.webkit.DownloadListener
import android.webkit.SslErrorHandler
import android.webkit.URLUtil
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import com.nova.downloader.R
import com.nova.downloader.i18n.LocalizedActivity
import com.nova.downloader.core.DirectApkLinkParser
import com.nova.downloader.core.PlayStoreLinkParser
import org.json.JSONObject
import java.net.URI

/**
 * Converts a Google Play app link to a package id, then drives an external APK
 * provider inside a hardened WebView. File delivery is delegated to Android's
 * DownloadManager and saved under Downloads/NovaDownloader/APK.
 *
 * Nova never attempts to bypass payment, DRM, account or regional access rules.
 */
class ApkDownloaderActivity : LocalizedActivity() {
    private lateinit var input: EditText
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private lateinit var webView: WebView
    private lateinit var convertButton: Button

    private val handler = Handler(Looper.getMainLooper())
    private var pendingPlayUrl: String? = null
    private var pendingPackageId: String? = null
    private var pendingDownload: PendingDownload? = null
    private var destroyed = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(buildContent())
        configureWebView()

        val initial = intent.getStringExtra(EXTRA_INPUT).orEmpty()
        if (initial.isNotBlank()) {
            input.setText(initial)
            input.setSelection(input.text.length)
        }

        if (savedInstanceState == null || webView.restoreState(savedInstanceState) == null) {
            webView.loadUrl(PROVIDER_URL)
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        webView.saveState(outState)
        super.onSaveInstanceState(outState)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        destroyed = true
        handler.removeCallbacksAndMessages(null)
        if (::webView.isInitialized) {
            webView.stopLoading()
            webView.removeAllViews()
            webView.destroy()
        }
        super.onDestroy()
    }

    private fun buildContent(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setBackgroundColor(UiPalette.screenBackground(this@ApkDownloaderActivity))
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(Button(this).apply {
            setText(R.string.back)
            isAllCaps = false
            setOnClickListener { finish() }
        })
        header.addView(TextView(this).apply {
            setText(R.string.apk_downloader_title)
            textSize = 20f
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(Button(this).apply {
            text = "↻"
            textSize = 20f
            isAllCaps = false
            contentDescription = getString(R.string.apk_provider_reload)
            setOnClickListener { webView.reload() }
        })
        root.addView(header)

        root.addView(TextView(this).apply {
            setText(R.string.apk_downloader_description)
            textSize = 12.5f
            alpha = 0.82f
            setPadding(dp(4), dp(7), dp(4), dp(5))
        })

        input = EditText(this).apply {
            setHint(R.string.apk_play_link_hint)
            minLines = 2
            maxLines = 3
            inputType = android.text.InputType.TYPE_CLASS_TEXT or
                android.text.InputType.TYPE_TEXT_VARIATION_URI or
                android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        }
        root.addView(input, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ))

        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        actions.addView(Button(this).apply {
            setText(R.string.paste)
            isAllCaps = false
            setOnClickListener { pasteFromClipboard() }
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        convertButton = Button(this).apply {
            setText(R.string.apk_convert_download)
            isAllCaps = false
            setTypeface(typeface, Typeface.BOLD)
            setOnClickListener { convertAndDownload() }
        }
        actions.addView(convertButton, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.25f).apply {
            marginStart = dp(7)
        })
        root.addView(actions)

        root.addView(TextView(this).apply {
            setText(R.string.apk_play_section_description)
            textSize = 12.5f
            alpha = 0.86f
            setPadding(dp(4), dp(10), dp(4), dp(4))
        })
        root.addView(Button(this).apply {
            setText(R.string.apk_play_open)
            isAllCaps = false
            setTypeface(typeface, Typeface.BOLD)
            setOnClickListener {
                startActivity(Intent(this@ApkDownloaderActivity, PlayStoreApkDownloaderActivity::class.java).apply {
                    PlayStoreLinkParser.extractPackageId(input.text?.toString().orEmpty())
                        ?.let { putExtra(PlayStoreApkDownloaderActivity.EXTRA_INPUT, it) }
                })
            }
        }, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ))

        root.addView(TextView(this).apply {
            setText(R.string.apk_direct_section_description)
            textSize = 12.5f
            alpha = 0.82f
            setPadding(dp(4), dp(8), dp(4), dp(4))
        })
        root.addView(Button(this).apply {
            setText(R.string.apk_direct_open)
            isAllCaps = false
            setTypeface(typeface, Typeface.BOLD)
            setOnClickListener {
                startActivity(Intent(this@ApkDownloaderActivity, DirectApkDownloaderActivity::class.java).apply {
                    DirectApkLinkParser.extractHttpsUrl(input.text?.toString().orEmpty())
                        ?.takeIf(DirectApkLinkParser::isLikelyPackageUrl)
                        ?.let { putExtra(DirectApkDownloaderActivity.EXTRA_INPUT, it) }
                })
            }
        }, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ))

        root.addView(TextView(this).apply {
            setText(R.string.apk_translation_section_description)
            textSize = 12.5f
            alpha = 0.86f
            setPadding(dp(4), dp(10), dp(4), dp(4))
        })
        root.addView(Button(this).apply {
            setText(R.string.apk_translation_open)
            isAllCaps = false
            setTypeface(typeface, Typeface.BOLD)
            setOnClickListener {
                startActivity(Intent(this@ApkDownloaderActivity, ApkTranslationActivity::class.java))
            }
        }, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ))

        status = TextView(this).apply {
            setText(R.string.apk_status_ready)
            textSize = 12f
            setPadding(dp(4), dp(4), dp(4), dp(5))
        }
        root.addView(status)

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            visibility = View.GONE
        }
        root.addView(progress, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(3)))

        webView = WebView(this)
        root.addView(webView, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            0,
            1f
        ))

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(5), 0, 0)
        }
        bottom.addView(Button(this).apply {
            setText(R.string.apk_open_downloads)
            isAllCaps = false
            setOnClickListener { openSystemDownloads() }
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        bottom.addView(Button(this).apply {
            setText(R.string.apk_open_provider)
            isAllCaps = false
            setOnClickListener { webView.loadUrl(PROVIDER_URL) }
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
            marginStart = dp(7)
        })
        root.addView(bottom)
        return root
    }

    private fun configureWebView() {
        WebView.setWebContentsDebuggingEnabled(false)
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            allowFileAccessFromFileURLs = false
            allowUniversalAccessFromFileURLs = false
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(false)
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            mediaPlaybackRequiresUserGesture = true
            builtInZoomControls = true
            displayZoomControls = false
            loadWithOverviewMode = true
            useWideViewPort = true
            setGeolocationEnabled(false)
            safeBrowsingEnabled = true
        }

        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(webView, true)
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                progress.progress = newProgress
                progress.visibility = if (newProgress >= 100) View.GONE else View.VISIBLE
            }
        }

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val target = request?.url ?: return true
                if (target.scheme.equals("https", true)) return false
                toast(getString(R.string.apk_https_only))
                return true
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                status.text = getString(R.string.apk_provider_loading)
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                if (destroyed) return
                status.text = getString(R.string.apk_provider_ready)
                if (pendingPlayUrl != null) scheduleProviderInjection()
            }

            override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                if (request?.isForMainFrame == true) {
                    status.text = getString(R.string.apk_provider_error, error?.description?.toString().orEmpty())
                }
            }

            override fun onReceivedSslError(view: WebView?, handler: SslErrorHandler?, error: SslError?) {
                handler?.cancel()
                status.setText(R.string.apk_tls_error)
            }
        }

        webView.setDownloadListener(DownloadListener { url, userAgent, contentDisposition, mimeType, contentLength ->
            val target = url?.trim().orEmpty()
            if (!isSafeHttps(target)) {
                toast(getString(R.string.apk_invalid_download_url))
                return@DownloadListener
            }
            val request = PendingDownload(
                url = target,
                userAgent = userAgent.orEmpty(),
                contentDisposition = contentDisposition.orEmpty(),
                mimeType = mimeType.orEmpty(),
                contentLength = contentLength
            )
            if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P &&
                checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
            ) {
                pendingDownload = request
                requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), REQUEST_STORAGE)
            } else {
                enqueueDownload(request)
            }
        })
    }

    private fun convertAndDownload() {
        val raw = input.text?.toString().orEmpty()
        val packageId = PlayStoreLinkParser.extractPackageId(raw)
        if (packageId == null) {
            input.error = getString(R.string.apk_invalid_play_link)
            return
        }
        val canonical = PlayStoreLinkParser.canonicalUrl(packageId) ?: return
        input.setText(canonical)
        input.setSelection(input.text.length)
        pendingPackageId = packageId
        pendingPlayUrl = canonical
        convertButton.isEnabled = false
        status.text = getString(R.string.apk_package_detected, packageId)

        val currentHost = runCatching { URI(webView.url.orEmpty()).host.orEmpty() }.getOrDefault("")
        if (!currentHost.endsWith("evozi.com", ignoreCase = true)) {
            webView.loadUrl(PROVIDER_URL)
        } else {
            scheduleProviderInjection()
        }
    }

    private fun scheduleProviderInjection() {
        val playUrl = pendingPlayUrl ?: return
        val packageId = pendingPackageId ?: return
        handler.removeCallbacksAndMessages(INJECTION_TOKEN)
        listOf(250L, 900L, 1_800L).forEach { delay ->
            handler.postAtTime({ injectAndSubmit(playUrl, packageId) }, INJECTION_TOKEN, SystemClock.uptimeMillis() + delay)
        }
    }

    private fun injectAndSubmit(playUrl: String, packageId: String) {
        if (destroyed || pendingPlayUrl == null) return
        val script = """
            (() => {
              const playUrl = ${JSONObject.quote(playUrl)};
              const packageId = ${JSONObject.quote(packageId)};
              const visible = el => !!(el && (el.offsetWidth || el.offsetHeight || el.getClientRects().length));
              const inputs = Array.from(document.querySelectorAll('input')).filter(visible);
              const score = el => {
                const text = [el.name, el.id, el.placeholder, el.getAttribute('aria-label')]
                  .filter(Boolean).join(' ').toLowerCase();
                return (/package|play|google|url|link|apk/.test(text) ? 10 : 0) +
                  ((el.type === 'url' || el.type === 'text' || !el.type) ? 3 : 0);
              };
              const target = inputs.sort((a, b) => score(b) - score(a))[0];
              if (!target || score(target) < 3) return 'input-not-found';
              const label = [target.name, target.id, target.placeholder].filter(Boolean).join(' ').toLowerCase();
              target.focus();
              target.value = /package|id/.test(label) && !/url|link|play/.test(label) ? packageId : playUrl;
              target.dispatchEvent(new Event('input', { bubbles: true }));
              target.dispatchEvent(new Event('change', { bubbles: true }));
              const form = target.closest('form');
              if (!form) return 'filled';
              const candidates = Array.from(form.querySelectorAll('button,input[type="submit"]')).filter(visible);
              const submit = candidates.find(el => {
                const text = (el.innerText || el.value || el.getAttribute('aria-label') || '').toLowerCase();
                return /download|generate|convert|submit|apk|fetch/.test(text);
              }) || candidates[0];
              if (submit) { submit.click(); return 'submitted'; }
              if (form.requestSubmit) { form.requestSubmit(); return 'submitted-form'; }
              return 'filled';
            })();
        """.trimIndent()
        webView.evaluateJavascript(script) { rawResult ->
            val result = rawResult.orEmpty()
            when {
                result.contains("submitted") -> {
                    pendingPlayUrl = null
                    pendingPackageId = null
                    convertButton.isEnabled = true
                    status.setText(R.string.apk_request_submitted)
                    handler.removeCallbacksAndMessages(INJECTION_TOKEN)
                }
                result.contains("filled") -> {
                    convertButton.isEnabled = true
                    status.setText(R.string.apk_form_filled)
                }
                result.contains("input-not-found") -> {
                    convertButton.isEnabled = true
                    status.setText(R.string.apk_form_not_found)
                }
            }
        }
    }

    private fun enqueueDownload(item: PendingDownload) {
        val manager = getSystemService(DownloadManager::class.java)
        val fileName = safeFileName(
            URLUtil.guessFileName(item.url, item.contentDisposition, item.mimeType),
            item.mimeType
        )
        val request = DownloadManager.Request(Uri.parse(item.url)).apply {
            setAllowedOverMetered(true)
            setAllowedOverRoaming(false)
            setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            setTitle(fileName)
            setDescription(getString(R.string.apk_download_description))
            if (item.mimeType.isNotBlank()) setMimeType(item.mimeType)
            if (item.userAgent.isNotBlank()) addRequestHeader("User-Agent", item.userAgent)
            webView.url?.takeIf(::isSafeHttps)?.let { addRequestHeader("Referer", it) }
            CookieManager.getInstance().getCookie(item.url)?.takeIf { it.isNotBlank() }?.let {
                addRequestHeader("Cookie", it)
            }
            setDestinationInExternalPublicDir(
                Environment.DIRECTORY_DOWNLOADS,
                "NovaDownloader/APK/$fileName"
            )
        }
        runCatching { manager.enqueue(request) }
            .onSuccess {
                val size = if (item.contentLength > 0L) " • ${formatBytes(item.contentLength)}" else ""
                status.text = getString(R.string.apk_download_started, fileName) + size
                toast(getString(R.string.apk_download_started, fileName))
            }
            .onFailure {
                status.text = getString(R.string.apk_download_failed, it.message.orEmpty())
            }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != REQUEST_STORAGE) return
        val item = pendingDownload
        pendingDownload = null
        if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED && item != null) {
            enqueueDownload(item)
        } else {
            toast(getString(R.string.apk_storage_permission_required))
        }
    }

    private fun pasteFromClipboard() {
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val text = clipboard.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString().orEmpty()
        if (text.isBlank()) {
            toast(getString(R.string.clipboard_empty))
            return
        }
        input.setText(text)
        input.setSelection(input.text.length)
    }

    private fun openSystemDownloads() {
        runCatching { startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS)) }
            .onFailure { toast(getString(R.string.apk_open_downloads_failed)) }
    }

    private fun isSafeHttps(value: String): Boolean = runCatching {
        val uri = URI(value)
        uri.scheme.equals("https", true) && !uri.host.isNullOrBlank()
    }.getOrDefault(false)

    private fun safeFileName(raw: String, mimeType: String): String {
        var name = raw.substringAfterLast('/').replace(Regex("[\\\\/:*?\"<>|\\p{Cntrl}]"), "_").trim('.',' ')
        if (name.isBlank()) name = "${pendingPackageId ?: "application"}.apk"
        val lower = name.lowercase()
        val accepted = listOf(".apk", ".apks", ".xapk", ".zip")
        if (accepted.none(lower::endsWith) && mimeType.contains("android.package", true)) name += ".apk"
        return name.take(180)
    }

    private fun formatBytes(bytes: Long): String {
        if (bytes < 1024L) return "$bytes B"
        val units = arrayOf("KB", "MB", "GB")
        var value = bytes.toDouble()
        var index = -1
        do {
            value /= 1024.0
            index++
        } while (value >= 1024.0 && index < units.lastIndex)
        return String.format(java.util.Locale.getDefault(), "%.1f %s", value, units[index])
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    private data class PendingDownload(
        val url: String,
        val userAgent: String,
        val contentDisposition: String,
        val mimeType: String,
        val contentLength: Long
    )

    companion object {
        const val EXTRA_INPUT = "apk_input"
        private const val PROVIDER_URL = "https://apps.evozi.com/apk-downloader/"
        private const val REQUEST_STORAGE = 91
        private val INJECTION_TOKEN = Any()

    }
}
