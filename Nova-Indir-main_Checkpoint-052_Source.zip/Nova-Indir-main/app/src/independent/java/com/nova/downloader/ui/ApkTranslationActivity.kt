package com.nova.downloader.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.database.Cursor
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.lifecycle.LiveData
import androidx.lifecycle.Observer
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkInfo
import androidx.work.WorkManager
import androidx.work.workDataOf
import com.nova.downloader.R
import com.nova.downloader.i18n.LocalizedActivity
import com.nova.downloader.translation.ApkTranslationWorker
import java.util.UUID

/** Selects an APK and runs the compiled-resource translation/rebuild/sign pipeline. */
class ApkTranslationActivity : LocalizedActivity() {
    private lateinit var selectedFile: TextView
    private lateinit var sourceSpinner: Spinner
    private lateinit var targetSpinner: Spinner
    private lateinit var includeAppName: CheckBox
    private lateinit var wifiOnly: CheckBox
    private lateinit var progress: ProgressBar
    private lateinit var status: TextView
    private lateinit var selectButton: Button
    private lateinit var translateButton: Button
    private lateinit var cancelButton: Button
    private lateinit var openOutputButton: Button

    private val workManager by lazy { WorkManager.getInstance(applicationContext) }
    private lateinit var languages: List<LanguageOption>
    private var selectedUri: Uri? = null
    private var selectedName: String? = null
    private var outputUri: Uri? = null
    private var activeWorkId: UUID? = null
    private var workObserver: Observer<WorkInfo?>? = null
    private var workInfoLiveData: LiveData<WorkInfo?>? = null
    private var waitingForStoragePermission = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        languages = buildLanguages()
        setContentView(buildContent())

        selectedUri = savedInstanceState?.getString(STATE_INPUT_URI)?.let(Uri::parse)
        selectedName = savedInstanceState?.getString(STATE_INPUT_NAME)
        outputUri = savedInstanceState?.getString(STATE_OUTPUT_URI)?.let(Uri::parse)
        val sourceTag = savedInstanceState?.getString(STATE_SOURCE) ?: "en"
        val targetTag = savedInstanceState?.getString(STATE_TARGET) ?: "tr"
        sourceSpinner.setSelection(languages.indexOfFirst { it.tag == sourceTag }.coerceAtLeast(0))
        targetSpinner.setSelection(languages.indexOfFirst { it.tag == targetTag }.coerceAtLeast(0))
        includeAppName.isChecked = savedInstanceState?.getBoolean(STATE_INCLUDE_APP_NAME) ?: false
        wifiOnly.isChecked = savedInstanceState?.getBoolean(STATE_WIFI_ONLY) ?: false
        renderSelectedFile()
        openOutputButton.visibility = if (outputUri != null) View.VISIBLE else View.GONE

        savedInstanceState?.getString(STATE_WORK_ID)?.let { raw ->
            runCatching { UUID.fromString(raw) }.getOrNull()?.let(::observeWork)
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        outState.putString(STATE_INPUT_URI, selectedUri?.toString())
        outState.putString(STATE_INPUT_NAME, selectedName)
        outState.putString(STATE_OUTPUT_URI, outputUri?.toString())
        outState.putString(STATE_SOURCE, selectedLanguage(sourceSpinner).tag)
        outState.putString(STATE_TARGET, selectedLanguage(targetSpinner).tag)
        outState.putBoolean(STATE_INCLUDE_APP_NAME, includeAppName.isChecked)
        outState.putBoolean(STATE_WIFI_ONLY, wifiOnly.isChecked)
        outState.putString(STATE_WORK_ID, activeWorkId?.toString())
        super.onSaveInstanceState(outState)
    }

    override fun onDestroy() {
        detachObserver()
        super.onDestroy()
    }

    private fun buildContent(): View {
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            setBackgroundColor(UiPalette.screenBackground(this@ApkTranslationActivity))
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(18))
        }
        scroll.addView(root, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.WRAP_CONTENT
        ))

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(Button(this).apply {
            setText(R.string.back)
            isAllCaps = false
            setOnClickListener { finish() }
        })
        header.addView(TextView(this).apply {
            setText(R.string.apk_translation_title)
            textSize = 20f
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(header)

        root.addView(TextView(this).apply {
            setText(R.string.apk_translation_description)
            textSize = 13f
            alpha = 0.88f
            setPadding(dp(4), dp(10), dp(4), dp(10))
        })

        selectButton = Button(this).apply {
            setText(R.string.apk_translation_select)
            isAllCaps = false
            setTypeface(typeface, Typeface.BOLD)
            setOnClickListener { selectApk() }
        }
        root.addView(selectButton, matchWrap())

        selectedFile = TextView(this).apply {
            setText(R.string.apk_translation_no_file)
            textSize = 13f
            setPadding(dp(5), dp(8), dp(5), dp(12))
        }
        root.addView(selectedFile)

        root.addView(label(R.string.apk_translation_source_language))
        sourceSpinner = Spinner(this)
        sourceSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, languages)
        root.addView(sourceSpinner, matchWrap())

        root.addView(label(R.string.apk_translation_target_language).apply {
            setPadding(dp(4), dp(12), dp(4), dp(4))
        })
        targetSpinner = Spinner(this)
        targetSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, languages)
        root.addView(targetSpinner, matchWrap())

        includeAppName = CheckBox(this).apply {
            setText(R.string.apk_translation_include_app_name)
            isChecked = false
        }
        root.addView(includeAppName)

        wifiOnly = CheckBox(this).apply {
            setText(R.string.apk_translation_wifi_only)
            isChecked = false
        }
        root.addView(wifiOnly)

        translateButton = Button(this).apply {
            setText(R.string.apk_translation_start)
            isAllCaps = false
            setTypeface(typeface, Typeface.BOLD)
            setOnClickListener { requestTranslation() }
        }
        root.addView(translateButton, matchWrap().apply { topMargin = dp(10) })

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = 0
            visibility = View.GONE
        }
        root.addView(progress, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            dp(6)
        ).apply { topMargin = dp(12) })

        status = TextView(this).apply {
            setText(R.string.apk_translation_ready)
            textSize = 13f
            setPadding(dp(4), dp(9), dp(4), dp(8))
        }
        root.addView(status)

        cancelButton = Button(this).apply {
            setText(R.string.cancel)
            isAllCaps = false
            visibility = View.GONE
            setOnClickListener { activeWorkId?.let(workManager::cancelWorkById) }
        }
        root.addView(cancelButton, matchWrap())

        openOutputButton = Button(this).apply {
            setText(R.string.apk_translation_open_install)
            isAllCaps = false
            visibility = View.GONE
            setOnClickListener { openOutput() }
        }
        root.addView(openOutputButton, matchWrap().apply { topMargin = dp(8) })

        root.addView(Button(this).apply {
            setText(R.string.apk_open_downloads)
            isAllCaps = false
            setOnClickListener { openDownloads() }
        }, matchWrap().apply { topMargin = dp(8) })

        root.addView(TextView(this).apply {
            setText(R.string.apk_translation_engine_note)
            textSize = 12f
            alpha = 0.78f
            setPadding(dp(4), dp(14), dp(4), dp(4))
        })
        root.addView(TextView(this).apply {
            setText(R.string.apk_translation_signature_warning)
            textSize = 12f
            alpha = 0.78f
            setPadding(dp(4), dp(5), dp(4), dp(4))
        })
        root.addView(TextView(this).apply {
            setText(R.string.apk_translation_limitations)
            textSize = 12f
            alpha = 0.74f
            setPadding(dp(4), dp(5), dp(4), dp(4))
        })
        return scroll
    }

    private fun selectApk() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = APK_MIME
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf(APK_MIME, "application/octet-stream"))
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(intent, REQUEST_APK)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQUEST_APK || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        val name = queryDisplayName(uri) ?: "application.apk"
        if (!name.endsWith(".apk", true)) {
            toast(getString(R.string.apk_translation_split_unsupported))
            return
        }
        runCatching {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        selectedUri = uri
        selectedName = name
        outputUri = null
        openOutputButton.visibility = View.GONE
        renderSelectedFile()
        status.setText(R.string.apk_translation_ready)
    }

    private fun requestTranslation() {
        val uri = selectedUri
        if (uri == null) {
            toast(getString(R.string.apk_translation_select_required))
            return
        }
        val source = selectedLanguage(sourceSpinner)
        val target = selectedLanguage(targetSpinner)
        if (source.tag == target.tag) {
            toast(getString(R.string.apk_translation_same_language))
            return
        }
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P &&
            checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        ) {
            waitingForStoragePermission = true
            requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), REQUEST_STORAGE)
            return
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQUEST_NOTIFICATIONS)
        }
        enqueue(uri, source.tag, target.tag)
    }

    private fun enqueue(uri: Uri, source: String, target: String) {
        val request = OneTimeWorkRequestBuilder<ApkTranslationWorker>()
            .setInputData(
                workDataOf(
                    ApkTranslationWorker.KEY_INPUT_URI to uri.toString(),
                    ApkTranslationWorker.KEY_INPUT_NAME to selectedName.orEmpty(),
                    ApkTranslationWorker.KEY_SOURCE_LANGUAGE to source,
                    ApkTranslationWorker.KEY_TARGET_LANGUAGE to target,
                    ApkTranslationWorker.KEY_INCLUDE_APP_NAME to includeAppName.isChecked,
                    ApkTranslationWorker.KEY_WIFI_ONLY to wifiOnly.isChecked
                )
            )
            .addTag("apk-translation")
            .build()
        workManager.enqueueUniqueWork(
            "apk-translation:${uri.hashCode()}",
            ExistingWorkPolicy.REPLACE,
            request
        )
        outputUri = null
        openOutputButton.visibility = View.GONE
        observeWork(request.id)
        status.setText(R.string.apk_translation_queued)
    }

    private fun observeWork(id: UUID) {
        detachObserver()
        activeWorkId = id
        setRunning(true)
        val observer = Observer<WorkInfo?> { info -> info?.let(::renderWork) }
        val liveData = workManager.getWorkInfoByIdLiveData(id)
        workObserver = observer
        workInfoLiveData = liveData
        liveData.observeForever(observer)
    }

    private fun renderWork(info: WorkInfo) {
        when (info.state) {
            WorkInfo.State.ENQUEUED, WorkInfo.State.BLOCKED -> {
                progress.visibility = View.VISIBLE
                progress.isIndeterminate = true
                status.setText(R.string.apk_translation_queued)
            }
            WorkInfo.State.RUNNING -> {
                val value = info.progress.getInt(ApkTranslationWorker.KEY_PROGRESS, 0)
                val step = info.progress.getString(ApkTranslationWorker.KEY_STEP).orEmpty()
                val detail = info.progress.getString(ApkTranslationWorker.KEY_DETAIL).orEmpty()
                progress.visibility = View.VISIBLE
                progress.isIndeterminate = step != ApkTranslationWorker.STEP_TRANSLATING && value < 90
                progress.progress = value
                status.text = detail.ifBlank { stepText(step) }
            }
            WorkInfo.State.SUCCEEDED -> {
                val name = info.outputData.getString(ApkTranslationWorker.KEY_OUTPUT_NAME).orEmpty()
                val translated = info.outputData.getInt(ApkTranslationWorker.KEY_TRANSLATED_COUNT, 0)
                val skipped = info.outputData.getInt(ApkTranslationWorker.KEY_SKIPPED_COUNT, 0)
                outputUri = info.outputData.getString(ApkTranslationWorker.KEY_OUTPUT_URI)?.let(Uri::parse)
                progress.visibility = View.VISIBLE
                progress.isIndeterminate = false
                progress.progress = 100
                status.text = getString(R.string.apk_translation_completed, name, translated, skipped)
                openOutputButton.visibility = if (outputUri != null) View.VISIBLE else View.GONE
                toast(getString(R.string.apk_translation_saved, name))
                finishObservation()
            }
            WorkInfo.State.FAILED -> {
                val code = info.outputData.getString(ApkTranslationWorker.KEY_ERROR_CODE).orEmpty()
                val raw = info.outputData.getString(ApkTranslationWorker.KEY_ERROR).orEmpty()
                val message = errorText(code, raw)
                progress.visibility = View.GONE
                status.text = message
                toast(message)
                finishObservation()
            }
            WorkInfo.State.CANCELLED -> {
                progress.visibility = View.GONE
                status.setText(R.string.apk_translation_cancelled)
                finishObservation()
            }
        }
    }

    private fun stepText(step: String): String = when (step) {
        ApkTranslationWorker.STEP_COPYING -> getString(R.string.apk_translation_step_copying)
        ApkTranslationWorker.STEP_MODEL -> getString(R.string.apk_translation_step_model)
        ApkTranslationWorker.STEP_READING -> getString(R.string.apk_translation_step_reading)
        ApkTranslationWorker.STEP_TRANSLATING -> getString(R.string.apk_translation_step_translating)
        ApkTranslationWorker.STEP_SIGNING -> getString(R.string.apk_translation_step_signing)
        ApkTranslationWorker.STEP_SAVING -> getString(R.string.apk_translation_step_saving)
        else -> getString(R.string.apk_translation_queued)
    }

    private fun errorText(code: String, raw: String): String = when (code) {
        ApkTranslationWorker.ERROR_INVALID_INPUT -> getString(R.string.apk_translation_error_invalid)
        ApkTranslationWorker.ERROR_SPLIT_UNSUPPORTED -> getString(R.string.apk_translation_split_unsupported)
        ApkTranslationWorker.ERROR_LANGUAGE -> getString(R.string.apk_translation_error_language)
        ApkTranslationWorker.ERROR_NO_RESOURCES -> getString(R.string.apk_translation_error_no_resources)
        ApkTranslationWorker.ERROR_NO_STRINGS -> getString(R.string.apk_translation_error_no_strings)
        ApkTranslationWorker.ERROR_MODEL -> getString(R.string.apk_translation_error_model, raw)
        ApkTranslationWorker.ERROR_RESOURCES -> getString(R.string.apk_translation_error_rebuild, raw)
        ApkTranslationWorker.ERROR_SIGNING -> getString(R.string.apk_translation_error_signing, raw)
        else -> getString(R.string.apk_translation_error_generic, raw.ifBlank { getString(R.string.unknown_error) })
    }

    private fun openOutput() {
        val uri = outputUri ?: return
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, APK_MIME)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        runCatching { startActivity(intent) }
            .onFailure { toast(getString(R.string.apk_translation_open_failed)) }
    }

    private fun openDownloads() {
        val intent = Intent(DownloadIntentAction).apply {
            addCategory(Intent.CATEGORY_DEFAULT)
        }
        runCatching { startActivity(intent) }
            .recoverCatching {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("content://downloads/my_downloads")))
            }
    }

    private fun renderSelectedFile() {
        selectedFile.text = selectedName?.let { getString(R.string.apk_translation_selected_file, it) }
            ?: getString(R.string.apk_translation_no_file)
    }

    private fun queryDisplayName(uri: Uri): String? {
        var cursor: Cursor? = null
        return try {
            cursor = contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            if (cursor?.moveToFirst() == true) cursor.getString(0) else null
        } finally {
            cursor?.close()
        }
    }

    private fun setRunning(running: Boolean) {
        selectButton.isEnabled = !running
        translateButton.isEnabled = !running
        sourceSpinner.isEnabled = !running
        targetSpinner.isEnabled = !running
        includeAppName.isEnabled = !running
        wifiOnly.isEnabled = !running
        cancelButton.visibility = if (running) View.VISIBLE else View.GONE
    }

    private fun finishObservation() {
        setRunning(false)
        detachObserver()
        activeWorkId = null
    }

    private fun detachObserver() {
        val observer = workObserver
        val liveData = workInfoLiveData
        if (observer != null && liveData != null) liveData.removeObserver(observer)
        workObserver = null
        workInfoLiveData = null
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_STORAGE) {
            val continueWork = waitingForStoragePermission && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED
            waitingForStoragePermission = false
            if (continueWork) requestTranslation() else toast(getString(R.string.apk_storage_permission_required))
        }
    }

    private fun buildLanguages(): List<LanguageOption> = listOf(
        LanguageOption("en", getString(R.string.language_english)),
        LanguageOption("tr", getString(R.string.language_turkish)),
        LanguageOption("de", getString(R.string.language_german)),
        LanguageOption("es", getString(R.string.apk_language_spanish)),
        LanguageOption("fr", getString(R.string.apk_language_french)),
        LanguageOption("it", getString(R.string.apk_language_italian)),
        LanguageOption("pt", getString(R.string.apk_language_portuguese)),
        LanguageOption("ru", getString(R.string.apk_language_russian)),
        LanguageOption("ar", getString(R.string.apk_language_arabic)),
        LanguageOption("ja", getString(R.string.apk_language_japanese)),
        LanguageOption("ko", getString(R.string.apk_language_korean)),
        LanguageOption("zh", getString(R.string.apk_language_chinese))
    )

    private fun selectedLanguage(spinner: Spinner): LanguageOption =
        spinner.selectedItem as? LanguageOption ?: languages.first()

    private fun label(textRes: Int) = TextView(this).apply {
        setText(textRes)
        textSize = 13f
        setTypeface(typeface, Typeface.BOLD)
        setPadding(dp(4), dp(4), dp(4), dp(4))
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT,
        LinearLayout.LayoutParams.WRAP_CONTENT
    )

    private fun toast(text: String) = Toast.makeText(this, text, Toast.LENGTH_LONG).show()
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    private data class LanguageOption(val tag: String, val label: String) {
        override fun toString(): String = label
    }

    companion object {
        private const val REQUEST_APK = 7031
        private const val REQUEST_STORAGE = 7032
        private const val REQUEST_NOTIFICATIONS = 7033
        private const val APK_MIME = "application/vnd.android.package-archive"
        private const val DownloadIntentAction = "android.intent.action.VIEW_DOWNLOADS"
        private const val STATE_INPUT_URI = "input_uri"
        private const val STATE_INPUT_NAME = "input_name"
        private const val STATE_OUTPUT_URI = "output_uri"
        private const val STATE_SOURCE = "source_language"
        private const val STATE_TARGET = "target_language"
        private const val STATE_INCLUDE_APP_NAME = "include_app_name"
        private const val STATE_WIFI_ONLY = "wifi_only"
        private const val STATE_WORK_ID = "work_id"
    }
}
