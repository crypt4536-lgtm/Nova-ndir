package com.nova.downloader.ui

import android.Manifest
import android.app.DownloadManager
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.view.Gravity
import android.view.View
import android.webkit.URLUtil
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import com.nova.downloader.R
import com.nova.downloader.core.DirectApkLinkParser
import com.nova.downloader.i18n.LocalizedActivity
import java.net.HttpURLConnection
import java.net.Inet4Address
import java.net.Inet6Address
import java.net.InetAddress
import java.net.URI
import java.net.URL
import java.util.Locale

/**
 * Provider-independent package downloader for direct HTTPS file URLs.
 * It does not scrape a web page and does not use Evozi or another APK mirror.
 */
class DirectApkDownloaderActivity : LocalizedActivity() {
    private lateinit var input: EditText
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private lateinit var downloadButton: Button

    @Volatile private var destroyed = false
    private var pendingDownload: DownloadCandidate? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(buildContent())
        intent.getStringExtra(EXTRA_INPUT)?.takeIf { it.isNotBlank() }?.let {
            input.setText(it)
            input.setSelection(input.text.length)
        }
    }

    override fun onDestroy() {
        destroyed = true
        super.onDestroy()
    }

    private fun buildContent(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setBackgroundColor(UiPalette.screenBackground(this@DirectApkDownloaderActivity))
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(Button(this).apply {
            setText(R.string.back)
            isAllCaps = false
            setOnClickListener { finish() }
        })
        header.addView(TextView(this).apply {
            setText(R.string.apk_direct_title)
            textSize = 20f
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(header)

        root.addView(TextView(this).apply {
            setText(R.string.apk_direct_description)
            textSize = 13f
            alpha = 0.84f
            setPadding(dp(4), dp(10), dp(4), dp(8))
        })

        input = EditText(this).apply {
            setHint(R.string.apk_direct_hint)
            minLines = 3
            maxLines = 5
            inputType = android.text.InputType.TYPE_CLASS_TEXT or
                android.text.InputType.TYPE_TEXT_VARIATION_URI or
                android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        }
        root.addView(input, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ))

        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        actions.addView(Button(this).apply {
            setText(R.string.paste)
            isAllCaps = false
            setOnClickListener { pasteFromClipboard() }
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        downloadButton = Button(this).apply {
            setText(R.string.apk_direct_download)
            isAllCaps = false
            setTypeface(typeface, Typeface.BOLD)
            setOnClickListener { inspectAndDownload() }
        }
        actions.addView(downloadButton, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.35f).apply {
            marginStart = dp(7)
        })
        root.addView(actions)

        progress = ProgressBar(this).apply { visibility = View.GONE }
        root.addView(progress, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { gravity = Gravity.CENTER_HORIZONTAL })

        status = TextView(this).apply {
            setText(R.string.apk_direct_ready)
            textSize = 13f
            setPadding(dp(4), dp(8), dp(4), dp(8))
        }
        root.addView(status)

        root.addView(TextView(this).apply {
            setText(R.string.apk_direct_security_note)
            textSize = 12f
            alpha = 0.78f
            setPadding(dp(4), dp(6), dp(4), dp(10))
        })

        root.addView(Button(this).apply {
            setText(R.string.apk_open_downloads)
            isAllCaps = false
            setOnClickListener { openSystemDownloads() }
        })
        return root
    }

    private fun inspectAndDownload() {
        val normalized = DirectApkLinkParser.extractHttpsUrl(input.text?.toString().orEmpty())
        if (normalized == null) {
            input.error = getString(R.string.apk_direct_invalid_url)
            return
        }
        if (DirectApkLinkParser.isGooglePlayPage(normalized)) {
            input.error = getString(R.string.apk_direct_play_page_error)
            return
        }

        input.setText(normalized)
        input.setSelection(input.text.length)
        setBusy(true, getString(R.string.apk_direct_inspecting))
        Thread {
            val result = runCatching { probe(normalized) }
            runOnUiThread {
                if (destroyed) return@runOnUiThread
                result.onSuccess { candidate ->
                    setBusy(false, getString(R.string.apk_direct_verified, candidate.fileName))
                    requestOrEnqueue(candidate)
                }.onFailure { error ->
                    setBusy(false, getString(R.string.apk_direct_probe_failed, humanError(error)))
                }
            }
        }.start()
    }

    private fun probe(initialUrl: String): DownloadCandidate {
        var current = initialUrl
        repeat(MAX_REDIRECTS + 1) { redirectCount ->
            val uri = URI(current)
            requireSafePublicHost(uri.host)
            val connection = (URL(current).openConnection() as HttpURLConnection).apply {
                instanceFollowRedirects = false
                connectTimeout = CONNECT_TIMEOUT_MS
                readTimeout = READ_TIMEOUT_MS
                requestMethod = "GET"
                setRequestProperty("User-Agent", USER_AGENT)
                setRequestProperty("Accept", APK_ACCEPT)
                setRequestProperty("Range", "bytes=0-0")
            }
            try {
                val code = connection.responseCode
                if (code in REDIRECT_CODES) {
                    if (redirectCount >= MAX_REDIRECTS) error("too-many-redirects")
                    val location = connection.getHeaderField("Location")?.trim().orEmpty()
                    if (location.isBlank()) error("redirect-without-location")
                    val next = uri.resolve(location).toString()
                    current = DirectApkLinkParser.normalize(next) ?: error("unsafe-redirect")
                    return@repeat
                }
                if (code !in 200..299 && code != HttpURLConnection.HTTP_PARTIAL) {
                    error("HTTP $code")
                }

                val disposition = connection.getHeaderField("Content-Disposition").orEmpty()
                val mime = connection.contentType.orEmpty().substringBefore(';').trim().lowercase(Locale.ROOT)
                val guessed = URLUtil.guessFileName(current, disposition, mime)
                val fileName = safeFileName(guessed, current, mime)
                if (!isAllowedPackage(fileName, mime)) error("unsupported-file-type")
                val length = contentLength(connection)
                return DownloadCandidate(current, fileName, mime, length)
            } finally {
                connection.disconnect()
            }
        }
        error("too-many-redirects")
    }


    private fun contentLength(connection: HttpURLConnection): Long {
        val range = connection.getHeaderField("Content-Range").orEmpty()
        val total = range.substringAfterLast('/', "").toLongOrNull()
        if (total != null && total > 0L) return total
        return connection.contentLengthLong
    }

    private fun requestOrEnqueue(candidate: DownloadCandidate) {
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P &&
            checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        ) {
            pendingDownload = candidate
            requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), REQUEST_STORAGE)
        } else {
            enqueue(candidate)
        }
    }

    private fun enqueue(candidate: DownloadCandidate) {
        val request = DownloadManager.Request(Uri.parse(candidate.url)).apply {
            setAllowedOverMetered(true)
            setAllowedOverRoaming(false)
            setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            setTitle(candidate.fileName)
            setDescription(getString(R.string.apk_direct_download_description))
            addRequestHeader("User-Agent", USER_AGENT)
            addRequestHeader("Accept", APK_ACCEPT)
            if (candidate.mimeType.isNotBlank()) setMimeType(candidate.mimeType)
            setDestinationInExternalPublicDir(
                Environment.DIRECTORY_DOWNLOADS,
                "NovaDownloader/APK/Direct/${candidate.fileName}"
            )
        }
        runCatching { getSystemService(DownloadManager::class.java).enqueue(request) }
            .onSuccess {
                val size = candidate.contentLength.takeIf { it > 0L }?.let { " • ${formatBytes(it)}" }.orEmpty()
                val message = getString(R.string.apk_direct_started, candidate.fileName) + size
                status.text = message
                toast(message)
            }
            .onFailure {
                status.text = getString(R.string.apk_download_failed, humanError(it))
            }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != REQUEST_STORAGE) return
        val candidate = pendingDownload
        pendingDownload = null
        if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED && candidate != null) {
            enqueue(candidate)
        } else {
            toast(getString(R.string.apk_storage_permission_required))
        }
    }

    private fun requireSafePublicHost(host: String?) {
        if (host.isNullOrBlank()) error("invalid-host")
        val lower = host.lowercase(Locale.ROOT)
        if (lower == "localhost" || lower.endsWith(".local") || lower.endsWith(".localhost")) error("local-host-blocked")
        val addresses = InetAddress.getAllByName(host)
        if (addresses.isEmpty()) error("host-not-found")
        addresses.forEach { address ->
            val blocked = address.isAnyLocalAddress || address.isLoopbackAddress || address.isLinkLocalAddress ||
                address.isSiteLocalAddress || address.isMulticastAddress || isCarrierGradeNat(address) ||
                isUniqueLocalIpv6(address)
            if (blocked) error("local-address-blocked")
        }
    }

    private fun isCarrierGradeNat(address: InetAddress): Boolean {
        val bytes = (address as? Inet4Address)?.address ?: return false
        val first = bytes[0].toInt() and 0xff
        val second = bytes[1].toInt() and 0xff
        return first == 100 && second in 64..127
    }

    private fun isUniqueLocalIpv6(address: InetAddress): Boolean {
        val bytes = (address as? Inet6Address)?.address ?: return false
        return (bytes[0].toInt() and 0xfe) == 0xfc
    }

    private fun isAllowedPackage(fileName: String, mimeType: String): Boolean {
        if (DirectApkLinkParser.isSupportedFileName(fileName)) return true
        return mimeType in setOf(
            "application/vnd.android.package-archive",
            "application/zip",
            "application/x-zip-compressed"
        )
    }

    private fun safeFileName(guessed: String, url: String, mimeType: String): String {
        var name = guessed.substringAfterLast('/')
            .replace(Regex("[\\\\/:*?\"<>|\\p{Cntrl}]"), "_")
            .trim('.', ' ')
        val hint = DirectApkLinkParser.fileNameHint(url)
        if (!DirectApkLinkParser.isSupportedFileName(name) && hint != null) name = hint
        if (name.isBlank()) name = URI(url).path.orEmpty().substringAfterLast('/').ifBlank { "application.apk" }
        if (!DirectApkLinkParser.isSupportedFileName(name)) {
            name += when {
                mimeType == "application/vnd.android.package-archive" -> ".apk"
                mimeType.contains("zip") -> ".zip"
                else -> ""
            }
        }
        return name.take(180)
    }

    private fun humanError(error: Throwable): String = when (error.message.orEmpty()) {
        "unsupported-file-type" -> getString(R.string.apk_direct_unsupported_type)
        "local-host-blocked", "local-address-blocked" -> getString(R.string.apk_direct_local_blocked)
        "unsafe-redirect" -> getString(R.string.apk_direct_unsafe_redirect)
        "too-many-redirects" -> getString(R.string.apk_direct_redirect_limit)
        else -> error.message?.takeIf { it.isNotBlank() } ?: error.javaClass.simpleName
    }

    private fun setBusy(busy: Boolean, message: String) {
        downloadButton.isEnabled = !busy
        progress.visibility = if (busy) View.VISIBLE else View.GONE
        status.text = message
    }

    private fun pasteFromClipboard() {
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val text = clipboard.primaryClip?.takeIf { it.itemCount > 0 }
            ?.getItemAt(0)?.coerceToText(this)?.toString().orEmpty()
        if (text.isBlank()) {
            toast(getString(R.string.clipboard_empty))
            return
        }
        input.setText(text)
        input.setSelection(input.text.length)
    }

    private fun openSystemDownloads() {
        runCatching { startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS)) }
            .onFailure { toast(getString(R.string.apk_open_downloads_failed)) }
    }

    private fun formatBytes(bytes: Long): String {
        if (bytes < 1024L) return "$bytes B"
        val units = arrayOf("KB", "MB", "GB")
        var value = bytes.toDouble()
        var index = -1
        do {
            value /= 1024.0
            index++
        } while (value >= 1024.0 && index < units.lastIndex)
        return String.format(Locale.getDefault(), "%.1f %s", value, units[index])
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    private data class DownloadCandidate(
        val url: String,
        val fileName: String,
        val mimeType: String,
        val contentLength: Long
    )

    companion object {
        const val EXTRA_INPUT = "direct_apk_input"
        private const val REQUEST_STORAGE = 92
        private const val MAX_REDIRECTS = 7
        private const val CONNECT_TIMEOUT_MS = 15_000
        private const val READ_TIMEOUT_MS = 20_000
        private const val USER_AGENT = "NovaDownloader/0.9.6 Android"
        private const val APK_ACCEPT = "application/vnd.android.package-archive, application/zip, application/octet-stream;q=0.9, */*;q=0.5"
        private val REDIRECT_CODES = setOf(301, 302, 303, 307, 308)
    }
}
