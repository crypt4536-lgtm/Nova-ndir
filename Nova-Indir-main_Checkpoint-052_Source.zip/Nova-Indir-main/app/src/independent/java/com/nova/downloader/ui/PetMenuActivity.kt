package com.nova.downloader.ui

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.nova.downloader.i18n.LocalizedActivity
import com.nova.downloader.R
import com.nova.downloader.core.PetCatalog
import com.nova.downloader.data.AppSettings
import com.nova.downloader.data.DownloadRepository
import com.nova.downloader.data.StorageHelper
import com.nova.downloader.service.PetOverlayService

class PetMenuActivity : LocalizedActivity() {
    private lateinit var repository: DownloadRepository
    private lateinit var settings: AppSettings

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        repository = DownloadRepository(this)
        settings = AppSettings(this)
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(16))
            setBackgroundColor(UiPalette.screenBackground(this@PetMenuActivity))
            addView(TextView(this@PetMenuActivity).apply {
                text = getString(R.string.pet_menu_title)
                textSize = 20f
                setPadding(0, 0, 0, dp(8))
            })
            addMenuButton(getString(R.string.pet_latest_location)) {
                val latest = repository.latestCompleted()
                if (latest == null) toast(getString(R.string.no_completed_download))
                else StorageHelper.openLocation(this@PetMenuActivity, latest)
            }
            addMenuButton(getString(R.string.bring_nova_to_front)) {
                startActivity(Intent(this@PetMenuActivity, MainActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                })
                finish()
            }
            addMenuButton(getString(R.string.send_nova_to_background)) {
                moveTaskToBack(true)
            }
            addMenuButton(getString(R.string.change_pet)) { choosePetType() }
            addMenuButton(getString(R.string.customize_pet)) { openSettings() }
            addMenuButton(getString(R.string.add_custom_pet)) { openSettings() }
            addMenuButton(getString(R.string.disable_pet)) {
                settings.petEnabled = false
                PetOverlayService.stop(this@PetMenuActivity)
                finish()
            }
            addMenuButton(getString(R.string.close)) { finish() }
        })
    }

    private fun LinearLayout.addMenuButton(label: String, action: () -> Unit) {
        addView(Button(this@PetMenuActivity).apply {
            text = label
            isAllCaps = false
            setOnClickListener { action() }
        })
    }

    private fun choosePetType() {
        val labels = (PetCatalog.all.map { getString(it.labelRes) } + getString(R.string.pet_custom_package)).toTypedArray()
        val values = (PetCatalog.all.map { it.id } + AppSettings.PET_CUSTOM).toTypedArray()
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.change_pet))
            .setSingleChoiceItems(labels, values.indexOf(settings.petType)) { dialog, which ->
                settings.petType = values[which]
                PetOverlayService.startOrRefresh(this)
                dialog.dismiss()
                finish()
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }

    private fun openSettings() {
        startActivity(Intent(this, SettingsActivity::class.java))
        finish()
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
