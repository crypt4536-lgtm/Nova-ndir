package com.nova.downloader.ui

import android.Manifest
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.lifecycle.LiveData
import androidx.lifecycle.Observer
import androidx.work.Constraints
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkInfo
import androidx.work.WorkManager
import androidx.work.workDataOf
import com.nova.downloader.R
import com.nova.downloader.core.PlayStoreLinkParser
import com.nova.downloader.i18n.LocalizedActivity
import com.nova.downloader.playstore.PlayStoreDownloadWorker
import java.util.UUID

/** UI for Evozi-independent Google Play downloads through an anonymous Play session. */
class PlayStoreApkDownloaderActivity : LocalizedActivity() {
    private lateinit var input: EditText
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private lateinit var downloadButton: Button
    private lateinit var cancelButton: Button

    private val workManager by lazy { WorkManager.getInstance(applicationContext) }
    private var activeWorkId: UUID? = null
    private var workObserver: Observer<WorkInfo?>? = null
    private var workInfoLiveData: LiveData<WorkInfo?>? = null
    private var pendingPackageName: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(buildContent())

        val initial = savedInstanceState?.getString(STATE_INPUT)
            ?: intent.getStringExtra(EXTRA_INPUT).orEmpty()
        if (initial.isNotBlank()) {
            input.setText(initial)
            input.setSelection(input.text.length)
        }

        savedInstanceState?.getString(STATE_WORK_ID)?.let { raw ->
            runCatching { UUID.fromString(raw) }.getOrNull()?.let(::observeWork)
        }
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        val incoming = intent?.getStringExtra(EXTRA_INPUT).orEmpty()
        if (incoming.isNotBlank()) {
            input.setText(incoming)
            input.setSelection(input.text.length)
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        outState.putString(STATE_INPUT, input.text?.toString().orEmpty())
        activeWorkId?.let { outState.putString(STATE_WORK_ID, it.toString()) }
        super.onSaveInstanceState(outState)
    }

    override fun onDestroy() {
        detachObserver()
        super.onDestroy()
    }

    private fun buildContent(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            setBackgroundColor(UiPalette.screenBackground(this@PlayStoreApkDownloaderActivity))
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(Button(this).apply {
            setText(R.string.back)
            isAllCaps = false
            setOnClickListener { finish() }
        })
        header.addView(TextView(this).apply {
            setText(R.string.apk_play_title)
            textSize = 20f
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(header)

        root.addView(TextView(this).apply {
            setText(R.string.apk_play_description)
            textSize = 13f
            alpha = 0.86f
            setPadding(dp(4), dp(10), dp(4), dp(8))
        })

        input = EditText(this).apply {
            setHint(R.string.apk_play_link_hint)
            minLines = 2
            maxLines = 4
            inputType = android.text.InputType.TYPE_CLASS_TEXT or
                android.text.InputType.TYPE_TEXT_VARIATION_URI or
                android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        }
        root.addView(input, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ))

        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        actions.addView(Button(this).apply {
            setText(R.string.paste)
            isAllCaps = false
            setOnClickListener { pasteFromClipboard() }
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        downloadButton = Button(this).apply {
            setText(R.string.apk_play_download)
            isAllCaps = false
            setTypeface(typeface, Typeface.BOLD)
            setOnClickListener { startDownload() }
        }
        actions.addView(downloadButton, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.55f).apply {
            marginStart = dp(8)
        })
        root.addView(actions)

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = 0
            visibility = View.GONE
        }
        root.addView(progress, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            dp(5)
        ).apply { topMargin = dp(10) })

        status = TextView(this).apply {
            setText(R.string.apk_play_ready)
            textSize = 13f
            setPadding(dp(4), dp(8), dp(4), dp(8))
        }
        root.addView(status)

        cancelButton = Button(this).apply {
            setText(R.string.cancel)
            isAllCaps = false
            visibility = View.GONE
            setOnClickListener {
                activeWorkId?.let(workManager::cancelWorkById)
            }
        }
        root.addView(cancelButton, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ))

        root.addView(TextView(this).apply {
            setText(R.string.apk_play_security_note)
            textSize = 12.5f
            alpha = 0.76f
            setPadding(dp(4), dp(10), dp(4), dp(8))
        })

        root.addView(Button(this).apply {
            setText(R.string.apk_open_downloads)
            isAllCaps = false
            setOnClickListener { openDownloads() }
        }, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ))

        return root
    }

    private fun startDownload() {
        val packageName = PlayStoreLinkParser.extractPackageId(input.text?.toString().orEmpty())
        if (packageName == null) {
            status.setText(R.string.apk_invalid_play_link)
            toast(getString(R.string.apk_invalid_play_link))
            return
        }
        input.setText(PlayStoreLinkParser.canonicalUrl(packageName).orEmpty())
        input.setSelection(input.text.length)

        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P &&
            checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        ) {
            pendingPackageName = packageName
            requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), REQUEST_STORAGE)
            return
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQUEST_NOTIFICATIONS)
        }
        enqueue(packageName)
    }

    private fun enqueue(packageName: String) {
        val request = OneTimeWorkRequestBuilder<PlayStoreDownloadWorker>()
            .setConstraints(
                Constraints.Builder()
                    .setRequiredNetworkType(NetworkType.CONNECTED)
                    .build()
            )
            .setInputData(workDataOf(PlayStoreDownloadWorker.KEY_PACKAGE_NAME to packageName))
            .addTag("play-apk")
            .addTag("play-apk:$packageName")
            .build()

        workManager.enqueueUniqueWork(
            "play-apk:$packageName",
            ExistingWorkPolicy.REPLACE,
            request
        )
        observeWork(request.id)
        status.setText(R.string.apk_play_queued)
    }

    private fun observeWork(id: UUID) {
        detachObserver()
        activeWorkId = id
        setRunning(true)
        val observer = Observer<WorkInfo?> { info -> info?.let(::renderWork) }
        val liveData = workManager.getWorkInfoByIdLiveData(id)
        workObserver = observer
        workInfoLiveData = liveData
        liveData.observeForever(observer)
    }

    private fun renderWork(info: WorkInfo) {
        when (info.state) {
            WorkInfo.State.ENQUEUED, WorkInfo.State.BLOCKED -> {
                status.setText(R.string.apk_play_queued)
                progress.visibility = View.VISIBLE
                progress.isIndeterminate = true
            }
            WorkInfo.State.RUNNING -> {
                val value = info.progress.getInt(PlayStoreDownloadWorker.KEY_PROGRESS, 0)
                val step = info.progress.getString(PlayStoreDownloadWorker.KEY_STEP).orEmpty()
                val detail = info.progress.getString(PlayStoreDownloadWorker.KEY_DETAIL).orEmpty()
                progress.visibility = View.VISIBLE
                progress.isIndeterminate = step != PlayStoreDownloadWorker.STEP_DOWNLOADING && value < 90
                progress.progress = value
                status.text = stepText(step, detail)
            }
            WorkInfo.State.SUCCEEDED -> {
                val name = info.outputData.getString(PlayStoreDownloadWorker.KEY_OUTPUT_NAME).orEmpty()
                progress.visibility = View.VISIBLE
                progress.isIndeterminate = false
                progress.progress = 100
                status.text = getString(R.string.apk_play_completed, name)
                toast(getString(R.string.apk_play_completed, name))
                finishObservation()
            }
            WorkInfo.State.FAILED -> {
                val code = info.outputData.getString(PlayStoreDownloadWorker.KEY_ERROR_CODE).orEmpty()
                val raw = info.outputData.getString(PlayStoreDownloadWorker.KEY_ERROR).orEmpty()
                val message = errorText(code, raw)
                progress.visibility = View.GONE
                status.text = message
                toast(message)
                finishObservation()
            }
            WorkInfo.State.CANCELLED -> {
                progress.visibility = View.GONE
                status.setText(R.string.apk_play_cancelled)
                finishObservation()
            }
        }
    }

    private fun stepText(step: String, detail: String): String = when (step) {
        PlayStoreDownloadWorker.STEP_SESSION -> getString(R.string.apk_play_step_session)
        PlayStoreDownloadWorker.STEP_DETAILS -> getString(R.string.apk_play_step_details)
        PlayStoreDownloadWorker.STEP_PURCHASE -> getString(R.string.apk_play_step_purchase)
        PlayStoreDownloadWorker.STEP_DOWNLOADING -> detail.ifBlank { getString(R.string.apk_play_step_downloading) }
        PlayStoreDownloadWorker.STEP_PACKING -> getString(R.string.apk_play_step_packing)
        PlayStoreDownloadWorker.STEP_SAVING -> getString(R.string.apk_play_step_saving)
        PlayStoreDownloadWorker.STEP_DONE -> getString(R.string.apk_play_completed, detail)
        else -> detail.ifBlank { getString(R.string.apk_play_queued) }
    }

    private fun errorText(code: String, raw: String): String = when (code) {
        PlayStoreDownloadWorker.ERROR_PAID_APP -> getString(R.string.apk_play_error_paid)
        PlayStoreDownloadWorker.ERROR_NOT_FOUND -> getString(R.string.apk_play_error_not_found)
        PlayStoreDownloadWorker.ERROR_UNAVAILABLE -> getString(R.string.apk_play_error_unavailable)
        PlayStoreDownloadWorker.ERROR_NO_FILES -> getString(R.string.apk_play_error_no_files)
        PlayStoreDownloadWorker.ERROR_INVALID_PACKAGE -> getString(R.string.apk_invalid_play_link)
        PlayStoreDownloadWorker.ERROR_RATE_LIMITED -> getString(R.string.apk_play_error_rate_limited)
        PlayStoreDownloadWorker.ERROR_INCOMPATIBLE -> getString(R.string.apk_play_error_incompatible)
        else -> getString(R.string.apk_play_error_generic, raw.ifBlank { getString(R.string.unknown_error) })
    }

    private fun setRunning(running: Boolean) {
        downloadButton.isEnabled = !running
        cancelButton.visibility = if (running) View.VISIBLE else View.GONE
    }

    private fun finishObservation() {
        setRunning(false)
        detachObserver()
        activeWorkId = null
    }

    private fun detachObserver() {
        val observer = workObserver
        val liveData = workInfoLiveData
        if (observer != null && liveData != null) liveData.removeObserver(observer)
        workObserver = null
        workInfoLiveData = null
    }

    private fun pasteFromClipboard() {
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val text = clipboard.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString().orEmpty()
        if (text.isNotBlank()) {
            input.setText(text)
            input.setSelection(input.text.length)
        }
    }

    private fun openDownloads() {
        val intents = listOf(
            Intent(DownloadManagerIntent.ACTION_VIEW_DOWNLOADS),
            Intent(Intent.ACTION_VIEW, Uri.parse("content://downloads/my_downloads")),
            Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS)
        )
        val opened = intents.any { intent ->
            runCatching {
                startActivity(intent)
                true
            }.getOrDefault(false)
        }
        if (!opened) toast(getString(R.string.apk_open_downloads_failed))
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_STORAGE) {
            val packageName = pendingPackageName
            pendingPackageName = null
            if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED && packageName != null) {
                enqueue(packageName)
            } else {
                toast(getString(R.string.apk_storage_permission_required))
            }
        }
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private object DownloadManagerIntent {
        const val ACTION_VIEW_DOWNLOADS = "android.intent.action.VIEW_DOWNLOADS"
    }

    companion object {
        const val EXTRA_INPUT = "play_apk_input"
        private const val STATE_INPUT = "play_apk_state_input"
        private const val STATE_WORK_ID = "play_apk_state_work_id"
        private const val REQUEST_STORAGE = 9471
        private const val REQUEST_NOTIFICATIONS = 9472
    }
}
