package com.nova.downloader.ui

import android.graphics.Typeface
import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.nova.downloader.BuildConfig
import com.nova.downloader.R
import com.nova.downloader.data.AppSettings
import com.nova.downloader.i18n.LocalizedActivity
import com.nova.downloader.update.SecureUpdateManager
import com.nova.downloader.update.UpdateDownloadService
import com.nova.downloader.update.UpdateScheduler

class UpdateCenterActivity : LocalizedActivity() {
    private lateinit var status: TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val settings = AppSettings(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(24))
            setBackgroundColor(UiPalette.screenBackground(this@UpdateCenterActivity))
            addView(Button(this@UpdateCenterActivity).apply {
                text = getString(R.string.back); isAllCaps = false; setOnClickListener { finish() }
            })
            addView(TextView(this@UpdateCenterActivity).apply {
                text = getString(R.string.independent_update_center_title)
                textSize = 22f; setTypeface(typeface, Typeface.BOLD); setPadding(0, dp(14), 0, dp(8))
            })
            addView(TextView(this@UpdateCenterActivity).apply {
                text = getString(R.string.independent_update_center_info)
                textSize = 13f; alpha = .78f
            })
            addView(CheckBox(this@UpdateCenterActivity).apply {
                text = getString(R.string.automatic_update_checks)
                isChecked = settings.automaticUpdateChecks
                setOnCheckedChangeListener { _, checked ->
                    settings.automaticUpdateChecks = checked
                    UpdateScheduler.schedule(this@UpdateCenterActivity)
                }
            })
            addView(Button(this@UpdateCenterActivity).apply {
                text = getString(R.string.check_updates_now); isAllCaps = false
                setOnClickListener { checkNow() }
            })
            status = TextView(this@UpdateCenterActivity).apply {
                text = if (SecureUpdateManager.configuredManifestUrl().isBlank() || BuildConfig.NOVA_UPDATE_PUBLIC_KEY_B64.isBlank())
                    getString(R.string.update_not_configured) else getString(R.string.configured)
                setPadding(0, dp(10), 0, 0)
            }
            addView(status)
        }
        setContentView(root)
    }

    private fun checkNow() {
        status.text = getString(R.string.update_checking)
        Thread {
            val result = SecureUpdateManager(this).check()
            runOnUiThread {
                when (result) {
                    is SecureUpdateManager.CheckResult.Available -> {
                        status.text = getString(R.string.update_available_title, result.manifest.versionName)
                        UpdateDownloadService.start(this, result.manifest)
                    }
                    SecureUpdateManager.CheckResult.UpToDate -> status.text = getString(R.string.update_up_to_date)
                    is SecureUpdateManager.CheckResult.Unavailable -> status.text = result.message
                    is SecureUpdateManager.CheckResult.Error -> status.text = getString(R.string.update_check_failed, result.message)
                }
            }
        }.start()
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
