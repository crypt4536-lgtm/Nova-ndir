package com.nova.downloader.update

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import com.nova.downloader.R
import com.nova.downloader.i18n.AppText
import java.io.File
import java.io.FileInputStream
import java.security.MessageDigest

object ApkVerifier {
    fun verify(context: Context, apk: File, manifest: UpdateManifest) {
        require(apk.isFile && apk.length() > 0L) { AppText.get(R.string.update_apk_missing) }
        require(sha256(apk).equals(manifest.apkSha256, true)) { AppText.get(R.string.update_apk_hash_mismatch) }
        val flags = PackageManager.GET_SIGNING_CERTIFICATES
        val archive = context.packageManager.getPackageArchiveInfo(apk.absolutePath, flags)
            ?: error(AppText.get(R.string.update_apk_invalid))
        require(archive.packageName == context.packageName) { AppText.get(R.string.update_package_mismatch) }
        val archiveVersion = packageVersionCode(archive)
        require(archiveVersion == manifest.versionCode) { AppText.get(R.string.update_version_mismatch) }
        require(archive.versionName == manifest.versionName) { AppText.get(R.string.update_version_name_mismatch) }
        val current = installedPackageInfo(context, flags)
        val currentDigests = signerDigests(current)
        val archiveDigests = signerDigests(archive)
        require(currentDigests.intersect(archiveDigests).isNotEmpty()) { AppText.get(R.string.update_signer_mismatch) }
    }

    private fun signerDigests(info: android.content.pm.PackageInfo): Set<String> {
        val signatures = if (Build.VERSION.SDK_INT >= 28) {
            val signingInfo = info.signingInfo ?: return emptySet()
            if (signingInfo.hasMultipleSigners()) signingInfo.apkContentsSigners else signingInfo.signingCertificateHistory
        } else legacySignatures(info)
        return signatures.orEmpty().map { signature ->
            MessageDigest.getInstance("SHA-256").digest(signature.toByteArray()).joinToString("") { "%02x".format(it) }
        }.toSet()
    }

    @Suppress("DEPRECATION")
    private fun packageVersionCode(info: android.content.pm.PackageInfo): Long =
        if (Build.VERSION.SDK_INT >= 28) info.longVersionCode else info.versionCode.toLong()

    @Suppress("DEPRECATION")
    private fun installedPackageInfo(context: Context, flags: Int): android.content.pm.PackageInfo =
        if (Build.VERSION.SDK_INT >= 33) {
            context.packageManager.getPackageInfo(
                context.packageName,
                PackageManager.PackageInfoFlags.of(flags.toLong())
            )
        } else {
            context.packageManager.getPackageInfo(context.packageName, flags)
        }

    @Suppress("DEPRECATION")
    private fun legacySignatures(info: android.content.pm.PackageInfo) = info.signatures

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        FileInputStream(file).use { input ->
            val buffer = ByteArray(64 * 1024)
            while (true) {
                val read = input.read(buffer)
                if (read <= 0) break
                digest.update(buffer, 0, read)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }
}
