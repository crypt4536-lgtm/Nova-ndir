package com.nova.downloader.update

import android.content.Context
import android.os.Build
import com.nova.downloader.BuildConfig
import com.nova.downloader.R
import com.nova.downloader.diagnostics.LocalLog
import com.nova.downloader.i18n.AppText
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URI
import java.net.URL
import java.security.KeyFactory
import java.security.Signature
import java.security.spec.X509EncodedKeySpec
import java.util.Base64

class SecureUpdateManager(private val context: Context) {
    sealed class CheckResult {
        data class Available(val manifest: UpdateManifest) : CheckResult()
        data object UpToDate : CheckResult()
        data class Unavailable(val message: String) : CheckResult()
        data class Error(val message: String) : CheckResult()
    }

    fun check(): CheckResult {
        val endpoint = configuredManifestUrl().trim()
        val publicKey = BuildConfig.NOVA_UPDATE_PUBLIC_KEY_B64.trim()
        if (endpoint.isBlank() || publicKey.isBlank()) return CheckResult.Unavailable(AppText.get(R.string.update_not_configured))
        return runCatching {
            val endpointUri = URI(endpoint)
            require(endpointUri.scheme.equals("https", true) && !endpointUri.host.isNullOrBlank()) {
                AppText.get(R.string.update_https_required)
            }
            val raw = fetch(endpoint)
            val manifest = UpdateManifest.parse(raw)
            validateManifest(endpointUri, manifest, publicKey)
            if (manifest.versionCode > BuildConfig.VERSION_CODE) CheckResult.Available(manifest) else CheckResult.UpToDate
        }.getOrElse { error ->
            LocalLog.error("Update", "Update check failed", error)
            CheckResult.Error(error.message ?: AppText.get(R.string.update_check_failed_generic))
        }
    }

    private fun validateManifest(endpoint: URI, manifest: UpdateManifest, publicKeyBase64: String) {
        require(manifest.versionCode > 0 && manifest.versionName.length in 1..80 && manifest.flavor in setOf("full", "lite")) { AppText.get(R.string.update_manifest_invalid) }
        require(manifest.flavor == expectedEngineFlavor()) { AppText.get(R.string.update_flavor_mismatch) }
        require(manifest.minSdk <= Build.VERSION.SDK_INT) { AppText.get(R.string.update_requires_newer_android, manifest.minSdk) }
        require(manifest.apkSha256.matches(Regex("[0-9a-f]{64}"))) { AppText.get(R.string.update_hash_invalid) }
        val apk = URI(manifest.apkUrl)
        require(apk.scheme.equals("https", true) && !apk.host.isNullOrBlank()) { AppText.get(R.string.update_https_required) }
        require(apk.host.equals(endpoint.host, true)) { AppText.get(R.string.update_host_mismatch) }
        val key = KeyFactory.getInstance("RSA").generatePublic(X509EncodedKeySpec(Base64.getDecoder().decode(publicKeyBase64)))
        val verifier = Signature.getInstance("SHA256withRSA")
        verifier.initVerify(key)
        verifier.update(manifest.canonicalPayload().toByteArray(Charsets.UTF_8))
        require(verifier.verify(Base64.getDecoder().decode(manifest.signature))) { AppText.get(R.string.update_signature_invalid) }
    }

    private fun fetch(url: String): String {
        var current = url
        val originalHost = URI(url).host
        repeat(MAX_REDIRECTS + 1) { hop ->
            val connection = URL(current).openConnection() as HttpURLConnection
            try {
                connection.instanceFollowRedirects = false
                connection.connectTimeout = 15_000
                connection.readTimeout = 20_000
                connection.setRequestProperty("Accept", "application/json")
                connection.setRequestProperty("User-Agent", "NovaDownloader/${BuildConfig.VERSION_NAME}")
                val code = connection.responseCode
                if (code in 300..399) {
                    require(hop < MAX_REDIRECTS) { AppText.get(R.string.update_too_many_redirects) }
                    val location = connection.getHeaderField("Location") ?: error(AppText.get(R.string.update_redirect_invalid))
                    val next = URI(current).resolve(location)
                    require(next.scheme.equals("https", true) && next.host.equals(originalHost, true)) { AppText.get(R.string.update_redirect_rejected) }
                    current = next.toString()
                    return@repeat
                }
                require(code in 200..299) { AppText.get(R.string.update_http_error, code) }
                val output = ByteArrayOutputStream()
                connection.inputStream.use { input ->
                    val buffer = ByteArray(16 * 1024)
                    var total = 0
                    while (true) {
                        val read = input.read(buffer)
                        if (read <= 0) break
                        total += read
                        require(total <= MAX_MANIFEST_BYTES) { AppText.get(R.string.update_manifest_too_large) }
                        output.write(buffer, 0, read)
                    }
                }
                return output.toString(Charsets.UTF_8.name())
            } finally { connection.disconnect() }
        }
        error(AppText.get(R.string.update_check_failed_generic))
    }

    companion object {
        fun expectedEngineFlavor(): String = if (BuildConfig.HAS_FFMPEG) "full" else "lite"

        fun configuredManifestUrl(): String = if (BuildConfig.HAS_FFMPEG) {
            BuildConfig.NOVA_UPDATE_MANIFEST_URL_FULL
        } else {
            BuildConfig.NOVA_UPDATE_MANIFEST_URL_LITE
        }

        private const val MAX_REDIRECTS = 3
        private const val MAX_MANIFEST_BYTES = 512 * 1024
    }
}
