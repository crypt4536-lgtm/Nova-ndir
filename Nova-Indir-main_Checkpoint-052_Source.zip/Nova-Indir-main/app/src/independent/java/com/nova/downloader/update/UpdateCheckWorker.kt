package com.nova.downloader.update

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.Worker
import androidx.work.WorkerParameters
import com.nova.downloader.R
import com.nova.downloader.data.AppSettings
import com.nova.downloader.i18n.AppText
import com.nova.downloader.ui.SettingsActivity

class UpdateCheckWorker(context: Context, params: WorkerParameters) : Worker(context, params) {
    override fun doWork(): Result {
        if (!AppSettings(applicationContext).automaticUpdateChecks) return Result.success()
        val result = SecureUpdateManager(applicationContext).check()
        if (result is SecureUpdateManager.CheckResult.Available) showNotification(result.manifest)
        return if (result is SecureUpdateManager.CheckResult.Error) Result.retry() else Result.success()
    }

    private fun showNotification(manifest: UpdateManifest) {
        val manager = applicationContext.getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) manager.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, AppText.get(R.string.update_channel_name), NotificationManager.IMPORTANCE_DEFAULT)
        )
        val pending = PendingIntent.getActivity(applicationContext, 402, Intent(applicationContext, SettingsActivity::class.java).apply {
            putExtra(SettingsActivity.EXTRA_OPEN_UPDATE, true)
        }, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        manager.notify(NOTIFICATION_ID, NotificationCompat.Builder(applicationContext, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setContentTitle(AppText.get(R.string.update_available_title, manifest.versionName))
            .setContentText(AppText.get(R.string.update_available_text, manifest.versionName))
            .setAutoCancel(true).setContentIntent(pending).build())
    }

    companion object { private const val CHANNEL_ID = "nova_secure_updates"; private const val NOTIFICATION_ID = 6802 }
}
