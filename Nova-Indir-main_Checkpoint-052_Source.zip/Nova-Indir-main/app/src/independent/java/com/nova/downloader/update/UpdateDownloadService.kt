package com.nova.downloader.update

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.nova.downloader.R
import com.nova.downloader.diagnostics.LocalLog
import com.nova.downloader.i18n.AppText
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URI
import java.net.URL
import java.util.concurrent.Executors

class UpdateDownloadService : Service() {
    private val executor = Executors.newSingleThreadExecutor()
    private lateinit var notifications: NotificationManager

    override fun onCreate() {
        super.onCreate()
        notifications = getSystemService(NotificationManager::class.java)
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val manifestRaw = intent?.getStringExtra(EXTRA_MANIFEST) ?: return START_NOT_STICKY
        val manifest = runCatching { UpdateManifest.parse(manifestRaw) }.getOrElse { return START_NOT_STICKY }
        startForeground(NOTIFICATION_ID, progressNotification(0, true))
        executor.execute {
            runCatching { downloadAndVerify(manifest) }
                .onSuccess { file -> notifications.notify(NOTIFICATION_ID, readyNotification(file, manifest)) }
                .onFailure { error ->
                    LocalLog.error("Update", "Update download failed", error)
                    notifications.notify(NOTIFICATION_ID, failureNotification(error.message.orEmpty()))
                }
            stopForeground(STOP_FOREGROUND_DETACH)
            stopSelf(startId)
        }
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null
    override fun onDestroy() { executor.shutdownNow(); super.onDestroy() }

    private fun downloadAndVerify(manifest: UpdateManifest): File {
        val dir = File(cacheDir, "updates").apply { mkdirs() }
        dir.listFiles()?.filter { it.name.endsWith(".apk") }?.forEach { it.delete() }
        val part = File(dir, "nova-${manifest.versionCode}.apk.part")
        val target = File(dir, "nova-${manifest.versionCode}.apk")
        var current = manifest.apkUrl
        val originalHost = URI(current).host
        repeat(MAX_REDIRECTS + 1) { hop ->
            val connection = URL(current).openConnection() as HttpURLConnection
            try {
                connection.instanceFollowRedirects = false
                connection.connectTimeout = 20_000
                connection.readTimeout = 45_000
                connection.setRequestProperty("Accept", "application/vnd.android.package-archive")
                val code = connection.responseCode
                if (code in 300..399) {
                    require(hop < MAX_REDIRECTS) { AppText.get(R.string.update_too_many_redirects) }
                    val next = URI(current).resolve(connection.getHeaderField("Location") ?: error(AppText.get(R.string.update_redirect_invalid)))
                    require(next.scheme.equals("https", true) && next.host.equals(originalHost, true)) { AppText.get(R.string.update_redirect_rejected) }
                    current = next.toString()
                    return@repeat
                }
                require(code in 200..299) { AppText.get(R.string.update_http_error, code) }
                val total = connection.contentLengthLong
                var downloaded = 0L
                FileOutputStream(part).use { output ->
                    connection.inputStream.use { input ->
                        val buffer = ByteArray(64 * 1024)
                        var lastPercent = -1
                        while (true) {
                            val read = input.read(buffer)
                            if (read <= 0) break
                            downloaded += read
                            require(downloaded <= MAX_APK_BYTES) { AppText.get(R.string.update_apk_too_large) }
                            output.write(buffer, 0, read)
                            val percent = if (total > 0L) ((downloaded * 100L) / total).toInt().coerceIn(0, 100) else 0
                            if (percent != lastPercent && (percent % 2 == 0 || percent == 100)) {
                                notifications.notify(NOTIFICATION_ID, progressNotification(percent, total <= 0L))
                                lastPercent = percent
                            }
                        }
                        output.fd.sync()
                    }
                }
                if (target.exists()) target.delete()
                require(part.renameTo(target)) { AppText.get(R.string.update_apk_move_failed) }
                ApkVerifier.verify(this, target, manifest)
                LocalLog.info("Update", "Verified update version=${manifest.versionCode}")
                return target
            } finally { connection.disconnect() }
        }
        error(AppText.get(R.string.update_download_failed_title))
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            notifications.createNotificationChannel(NotificationChannel(CHANNEL_ID, AppText.get(R.string.update_channel_name), NotificationManager.IMPORTANCE_LOW))
        }
    }

    private fun progressNotification(progress: Int, indeterminate: Boolean) = NotificationCompat.Builder(this, CHANNEL_ID)
        .setSmallIcon(android.R.drawable.stat_sys_download)
        .setContentTitle(AppText.get(R.string.update_downloading))
        .setContentText(if (indeterminate) AppText.get(R.string.update_downloading_wait) else AppText.get(R.string.update_progress, progress))
        .setOngoing(true).setOnlyAlertOnce(true).setProgress(100, progress, indeterminate).build()

    private fun readyNotification(file: File, manifest: UpdateManifest): android.app.Notification {
        val pending = PendingIntent.getActivity(this, 401, Intent(this, UpdateInstallerActivity::class.java).apply {
            putExtra(UpdateInstallerActivity.EXTRA_PATH, file.absolutePath)
            putExtra(UpdateInstallerActivity.EXTRA_VERSION, manifest.versionName)
            putExtra(UpdateInstallerActivity.EXTRA_MANIFEST, manifest.toJson())
        }, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setContentTitle(AppText.get(R.string.update_verified_ready))
            .setContentText(AppText.get(R.string.update_tap_to_install, manifest.versionName))
            .setAutoCancel(true).setContentIntent(pending).build()
    }

    private fun failureNotification(message: String) = NotificationCompat.Builder(this, CHANNEL_ID)
        .setSmallIcon(android.R.drawable.stat_notify_error)
        .setContentTitle(AppText.get(R.string.update_download_failed_title))
        .setContentText(message.take(120).ifBlank { AppText.get(R.string.update_check_failed_generic) })
        .setAutoCancel(true).build()

    companion object {
        const val EXTRA_MANIFEST = "manifest"
        private const val CHANNEL_ID = "nova_secure_updates"
        private const val NOTIFICATION_ID = 6801
        private const val MAX_REDIRECTS = 3
        private const val MAX_APK_BYTES = 500L * 1024L * 1024L

        fun start(context: android.content.Context, manifest: UpdateManifest) {
            val intent = Intent(context, UpdateDownloadService::class.java).putExtra(EXTRA_MANIFEST, manifest.toJson())
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(intent) else context.startService(intent)
        }
    }
}
