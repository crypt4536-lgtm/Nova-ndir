package com.nova.downloader.update

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.core.content.FileProvider
import com.nova.downloader.R
import com.nova.downloader.i18n.LocalizedActivity
import java.io.File

class UpdateInstallerActivity : LocalizedActivity() {
    private var path: String = ""
    private var manifestRaw: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        path = intent.getStringExtra(EXTRA_PATH).orEmpty()
        manifestRaw = intent.getStringExtra(EXTRA_MANIFEST).orEmpty()
        continueInstall()
    }

    override fun onResume() {
        super.onResume()
        if (path.isNotBlank() && packageManager.canRequestPackageInstalls()) continueInstall()
    }

    private fun continueInstall() {
        val file = File(path)
        if (!file.isFile) { finish(); return }
        val verified = runCatching {
            val manifest = UpdateManifest.parse(manifestRaw)
            ApkVerifier.verify(this, file, manifest)
        }.isSuccess
        if (!verified) {
            file.delete()
            android.widget.Toast.makeText(this, getString(R.string.update_reverification_failed), android.widget.Toast.LENGTH_LONG).show()
            path = ""
            finish()
            return
        }
        if (!packageManager.canRequestPackageInstalls()) {
            startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName")))
            return
        }
        val uri = FileProvider.getUriForFile(this, "$packageName.files", file)
        runCatching {
            startActivity(Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "application/vnd.android.package-archive")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            })
        }.onFailure {
            android.widget.Toast.makeText(this, getString(R.string.update_installer_open_failed), android.widget.Toast.LENGTH_LONG).show()
        }
        path = ""
        finish()
    }

    companion object {
        const val EXTRA_PATH = "path"
        const val EXTRA_VERSION = "version"
        const val EXTRA_MANIFEST = "manifest"
    }
}
