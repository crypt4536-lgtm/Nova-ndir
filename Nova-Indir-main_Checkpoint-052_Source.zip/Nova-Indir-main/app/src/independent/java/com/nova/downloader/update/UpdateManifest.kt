package com.nova.downloader.update

import org.json.JSONObject

data class UpdateManifest(
    val versionCode: Long,
    val versionName: String,
    val flavor: String,
    val minSdk: Int,
    val apkUrl: String,
    val apkSha256: String,
    val publishedAt: String,
    val notes: String,
    val signature: String
) {
    fun canonicalPayload(): String = listOf(
        versionCode.toString(), versionName, flavor, minSdk.toString(), apkUrl,
        apkSha256.lowercase(), publishedAt, sha256Text(notes)
    ).joinToString("\n")

    fun toJson(): String = JSONObject().apply {
        put("versionCode", versionCode); put("versionName", versionName); put("flavor", flavor); put("minSdk", minSdk)
        put("apkUrl", apkUrl); put("apkSha256", apkSha256); put("publishedAt", publishedAt)
        put("notes", notes); put("signature", signature)
    }.toString()

    companion object {
        fun parse(raw: String): UpdateManifest {
            val root = JSONObject(raw)
            return UpdateManifest(
                versionCode = root.getLong("versionCode"),
                versionName = root.getString("versionName"),
                flavor = root.getString("flavor"),
                minSdk = root.optInt("minSdk", 26),
                apkUrl = root.getString("apkUrl"),
                apkSha256 = root.getString("apkSha256").lowercase(),
                publishedAt = root.optString("publishedAt"),
                notes = root.optString("notes"),
                signature = root.getString("signature")
            )
        }

        private fun sha256Text(text: String): String = java.security.MessageDigest.getInstance("SHA-256")
            .digest(text.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }
    }
}
