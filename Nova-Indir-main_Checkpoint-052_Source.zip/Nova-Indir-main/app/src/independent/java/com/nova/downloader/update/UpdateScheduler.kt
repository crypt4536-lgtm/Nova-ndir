package com.nova.downloader.update

import android.content.Context
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.nova.downloader.data.AppSettings
import java.util.concurrent.TimeUnit

object UpdateScheduler {
    private const val WORK_NAME = "nova-secure-update-check"
    fun schedule(context: Context) {
        val manager = WorkManager.getInstance(context.applicationContext)
        if (!AppSettings(context).automaticUpdateChecks) {
            manager.cancelUniqueWork(WORK_NAME)
            return
        }
        val request = PeriodicWorkRequestBuilder<UpdateCheckWorker>(24, TimeUnit.HOURS)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        manager.enqueueUniquePeriodicWork(WORK_NAME, ExistingPeriodicWorkPolicy.UPDATE, request)
    }
}
