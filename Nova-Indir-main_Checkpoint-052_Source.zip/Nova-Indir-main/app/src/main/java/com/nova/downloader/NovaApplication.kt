package com.nova.downloader

import android.app.ActivityManager
import android.app.Application
import android.os.Build
import android.os.Process
import com.nova.downloader.diagnostics.LocalLog
import com.nova.downloader.distribution.DistributionStartup
import com.nova.downloader.i18n.AppText
import com.nova.downloader.i18n.LocaleController

class NovaApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= 33) {
            LocaleController.setLanguage(this, LocaleController.selectedLanguage(this))
        }
        AppText.init(this)
        LocalLog.initialize(this)
        if (isMainProcess()) DistributionStartup.initialize(this)
    }

    private fun isMainProcess(): Boolean {
        val processName = if (Build.VERSION.SDK_INT >= 28) {
            getProcessName()
        } else {
            @Suppress("DEPRECATION")
            val manager = getSystemService(ACTIVITY_SERVICE) as ActivityManager
            manager.runningAppProcesses
                ?.firstOrNull { it.pid == Process.myPid() }
                ?.processName
        }
        return processName == packageName
    }
}
