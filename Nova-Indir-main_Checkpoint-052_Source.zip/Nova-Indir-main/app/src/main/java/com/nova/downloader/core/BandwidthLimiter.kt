package com.nova.downloader.core

/** Simple token-bucket style limiter for direct HTTP downloads. */
class BandwidthLimiter(private val bytesPerSecond: Long) {
    private var windowStartedAt = System.nanoTime()
    private var bytesInWindow = 0L

    fun onBytesTransferred(byteCount: Int) {
        if (bytesPerSecond <= 0L || byteCount <= 0) return
        bytesInWindow += byteCount
        val expectedNanos = bytesInWindow * 1_000_000_000L / bytesPerSecond
        val elapsed = System.nanoTime() - windowStartedAt
        val waitNanos = expectedNanos - elapsed
        if (waitNanos > 0L) {
            val millis = waitNanos / 1_000_000L
            val nanos = (waitNanos % 1_000_000L).toInt()
            try {
                Thread.sleep(millis, nanos)
            } catch (interrupted: InterruptedException) {
                Thread.currentThread().interrupt()
            }
        }
        if (System.nanoTime() - windowStartedAt >= 1_000_000_000L) {
            windowStartedAt = System.nanoTime()
            bytesInWindow = 0L
        }
    }
}
