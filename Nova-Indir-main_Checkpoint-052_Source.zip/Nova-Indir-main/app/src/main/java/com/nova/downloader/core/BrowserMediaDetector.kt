package com.nova.downloader.core

import com.nova.downloader.R

import java.net.URI
import java.net.URLDecoder
import java.nio.charset.StandardCharsets

/**
 * Filters noisy WebView traffic and keeps only useful media/page candidates.
 * Segment files are intentionally ignored; their HLS/DASH manifest is the useful target.
 */
object BrowserMediaDetector {
    enum class Kind { PAGE, VIDEO, AUDIO, HLS, DASH }

    data class Match(val kind: Kind, val mimeType: String?)

    private val videoExtensions = setOf("mp4", "m4v", "mov", "webm", "mkv", "avi", "3gp", "3g2", "flv", "f4v")
    private val audioExtensions = setOf("mp3", "m4a", "aac", "ogg", "oga", "opus", "wav", "flac")
    private val ignoredSegmentExtensions = setOf("ts", "m4s", "cmfv", "cmfa", "aacp", "vtt", "srt")

    fun classify(url: String, rawMimeType: String? = null, allowPage: Boolean = false): Match? {
        val normalized = normalizeHttpsUrl(url) ?: return null
        val mime = MediaTypePolicy.normalizedMimeType(rawMimeType)
        val queryMime = mimeFromQuery(normalized)
        val effectiveMime = mime ?: queryMime
        val extension = MediaTypePolicy.extensionOf(normalized)

        if (extension in ignoredSegmentExtensions) return null
        if (effectiveMime in setOf("application/vnd.apple.mpegurl", "application/x-mpegurl", "audio/mpegurl", "audio/x-mpegurl") || extension == "m3u8") {
            return Match(Kind.HLS, effectiveMime ?: "application/vnd.apple.mpegurl")
        }
        if (effectiveMime == "application/dash+xml" || extension == "mpd") {
            return Match(Kind.DASH, effectiveMime ?: "application/dash+xml")
        }
        if (effectiveMime?.startsWith("video/") == true || extension in videoExtensions) {
            return Match(Kind.VIDEO, effectiveMime ?: MediaTypePolicy.mimeTypeForExtension(extension))
        }
        if (effectiveMime?.startsWith("audio/") == true || extension in audioExtensions) {
            return Match(Kind.AUDIO, effectiveMime ?: MediaTypePolicy.mimeTypeForExtension(extension))
        }

        val lower = normalized.lowercase()
        if ("mime=video" in lower || "content-type=video" in lower || "type=video" in lower) {
            return Match(Kind.VIDEO, effectiveMime)
        }
        if ("mime=audio" in lower || "content-type=audio" in lower || "type=audio" in lower) {
            return Match(Kind.AUDIO, effectiveMime)
        }
        return if (allowPage) Match(Kind.PAGE, mime) else null
    }

    private fun mimeFromQuery(url: String): String? = runCatching {
        val rawQuery = URI(url).rawQuery.orEmpty()
        rawQuery.split('&').firstNotNullOfOrNull { part ->
            val key = part.substringBefore('=').lowercase()
            if (key !in setOf("mime", "content-type", "type")) return@firstNotNullOfOrNull null
            val decoded = URLDecoder.decode(part.substringAfter('=', ""), StandardCharsets.UTF_8.name())
            MediaTypePolicy.normalizedMimeType(decoded)
        }
    }.getOrNull()

    fun normalizeHttpsUrl(raw: String?): String? {
        val value = raw?.trim().orEmpty()
        if (value.isBlank() || value.startsWith("blob:", true) || value.startsWith("data:", true)) return null
        return runCatching {
            val uri = URI(value)
            if (!uri.scheme.equals("https", true) || uri.host.isNullOrBlank() || uri.userInfo != null) null
            else URI(uri.scheme.lowercase(), uri.authority, uri.path, uri.query, null).toASCIIString()
        }.getOrNull()
    }

    fun labelRes(kind: Kind): Int = when (kind) {
        Kind.PAGE -> R.string.media_kind_page
        Kind.VIDEO -> R.string.media_kind_video
        Kind.AUDIO -> R.string.media_kind_audio
        Kind.HLS -> R.string.media_kind_hls
        Kind.DASH -> R.string.media_kind_dash
    }
}
