package com.nova.downloader.core

import java.net.URI
import java.net.URLDecoder
import java.nio.charset.StandardCharsets

/** Pure URL policy used by the provider-independent APK downloader. */
object DirectApkLinkParser {
    private val httpsPattern = Regex("https://[^\\s<>\\\"]+", RegexOption.IGNORE_CASE)
    private val supportedExtensions = setOf("apk", "apks", "xapk", "apkm", "zip")

    fun extractHttpsUrl(raw: String): String? {
        val value = raw.trim()
        val candidate = (httpsPattern.find(value)?.value ?: value)
            .trimEnd('.', ',', ';', ':', '!', '?', ')', ']', '}', '>', '\'', '"')
        return normalize(candidate)
    }

    fun normalize(value: String): String? = runCatching {
        val uri = URI(value.trim())
        if (!uri.scheme.equals("https", true) || uri.host.isNullOrBlank()) return@runCatching null
        if (uri.userInfo != null) return@runCatching null
        URI(
            "https",
            null,
            uri.host.lowercase(),
            if (uri.port == 443) -1 else uri.port,
            uri.rawPath.orEmpty().ifBlank { "/" },
            uri.rawQuery,
            null
        ).toASCIIString()
    }.getOrNull()

    fun isGooglePlayPage(value: String): Boolean = runCatching {
        val uri = URI(value)
        uri.host.equals("play.google.com", true) &&
            uri.path.orEmpty().startsWith("/store/apps/details")
    }.getOrDefault(false)

    fun isSupportedFileName(fileName: String): Boolean =
        extension(fileName) in supportedExtensions

    fun isLikelyPackageUrl(value: String): Boolean = fileNameHint(value) != null

    fun fileNameHint(value: String): String? {
        val normalized = normalize(value) ?: return null
        val uri = runCatching { URI(normalized) }.getOrNull() ?: return null
        val pathName = uri.path.orEmpty().substringAfterLast('/')
        if (isSupportedFileName(pathName)) return pathName
        return queryParameters(uri.rawQuery).values
            .map { it.substringAfterLast('/') }
            .firstOrNull(::isSupportedFileName)
    }

    fun extension(fileName: String): String = fileName
        .substringBefore('?')
        .substringBefore('#')
        .substringAfterLast('.', "")
        .lowercase()

    private fun queryParameters(rawQuery: String?): Map<String, String> {
        if (rawQuery.isNullOrBlank()) return emptyMap()
        return rawQuery.split('&').mapNotNull { pair ->
            val separator = pair.indexOf('=')
            if (separator <= 0) return@mapNotNull null
            decode(pair.substring(0, separator)) to decode(pair.substring(separator + 1))
        }.toMap()
    }

    private fun decode(value: String): String =
        URLDecoder.decode(value, StandardCharsets.UTF_8.name())
}
