package com.nova.downloader.core

import java.net.URI
import java.net.URLDecoder
import java.nio.charset.StandardCharsets

/**
 * Extracts real Facebook page URLs from short /share/v/ and /share/r/ pages.
 * This class only parses already-downloaded text; network access lives in FacebookPageResolver.
 */
object FacebookUrlExtractor {
    private val tagRegex = Regex(
        "<(?:meta|link)\\b[^>]*>",
        setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)
    )
    private val attributeRegex = Regex(
        "([a-zA-Z_:][-a-zA-Z0-9_:.]*)\\s*=\\s*([\"'])(.*?)\\2",
        setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)
    )
    private val absoluteFacebookUrlRegex = Regex(
        "https:(?:\\\\?/){2}(?:[a-z0-9-]+\\.)?facebook\\.com/[^\"'<>\\s]+",
        RegexOption.IGNORE_CASE
    )
    private val supportedPathRegex = Regex(
        """/(?:reel/\d+|[^/?#]+/videos/(?:[^/?#]+/)?\d+|watch/\?[^#]*\bv=\d+|video(?:/video)?\.php\?[^#]*\b(?:v|video_id)=\d+|groups/[^/]+/(?:posts|permalink)/[^/?#]+)""",
        RegexOption.IGNORE_CASE
    )
    private val videoIdPatterns = listOf(
        Regex("/reel/(\\d+)", RegexOption.IGNORE_CASE),
        Regex("/videos/(?:[^/?#]+/)?(\\d+)", RegexOption.IGNORE_CASE),
        Regex("[?&](?:v|video_id)=(\\d+)", RegexOption.IGNORE_CASE)
    )

    fun isFacebookUrl(url: String): Boolean {
        val host = runCatching { URI(url).host?.lowercase().orEmpty() }.getOrDefault("")
        return host == "facebook.com" || host.endsWith(".facebook.com") ||
            host == "fb.watch" || host.endsWith(".fb.watch")
    }

    fun isShareAlias(url: String): Boolean {
        if (!isFacebookUrl(url)) return false
        val path = runCatching { URI(url).path.orEmpty().lowercase() }.getOrDefault("")
        return path.startsWith("/share/v/") || path.startsWith("/share/r/") ||
            runCatching { URI(url).host.equals("fb.watch", ignoreCase = true) }.getOrDefault(false)
    }

    fun extractCandidates(html: String, baseUrl: String): List<String> {
        val candidates = linkedSetOf<String>()

        tagRegex.findAll(html).forEach { match ->
            val attributes = attributeRegex.findAll(match.value).associate { attribute ->
                attribute.groupValues[1].lowercase() to decodeRepeatedly(attribute.groupValues[3])
            }
            val property = attributes["property"]?.lowercase()
            val name = attributes["name"]?.lowercase()
            val rel = attributes["rel"]?.lowercase().orEmpty()
            val httpEquiv = attributes["http-equiv"]?.lowercase()

            if (property == "og:url" || name == "og:url" || "canonical" in rel.split(Regex("\\s+"))) {
                attributes["content"]?.let(candidates::add)
                attributes["href"]?.let(candidates::add)
            }

            if (httpEquiv == "refresh") {
                attributes["content"]
                    ?.substringAfter("url=", missingDelimiterValue = "")
                    ?.takeIf { it.isNotBlank() }
                    ?.let(candidates::add)
            }
        }

        val decodedHtml = decodeRepeatedly(html)
        listOf(html, decodedHtml).distinct().forEach { source ->
            absoluteFacebookUrlRegex.findAll(source).forEach { match ->
                val decoded = decodeRepeatedly(match.value)
                if (supportedPathRegex.containsMatchIn(decoded) || isShareAlias(decoded)) {
                    candidates += decoded
                }
            }
        }

        return expandCandidates(candidates, baseUrl)
    }

    fun expandCandidates(rawCandidates: Iterable<String>, baseUrl: String? = null): List<String> {
        val output = linkedSetOf<String>()

        rawCandidates.forEach { raw ->
            val decoded = decodeRepeatedly(raw).trim().trim('"', '\'', '\\', ',', ';')
            val resolved = resolveFacebookHttps(decoded, baseUrl) ?: return@forEach
            addIfUsable(output, resolved)
            decodeNestedTarget(resolved)?.let { addIfUsable(output, it) }
        }

        val ids = output.mapNotNull(::extractNumericVideoId).distinct()
        ids.forEach { id ->
            output += "https://www.facebook.com/video.php?v=$id"
            output += "https://www.facebook.com/watch/?v=$id"
            output += "https://m.facebook.com/watch/?v=$id&_rdr"
            output += "facebook:$id"
        }

        return output.toList()
    }

    fun extractNumericVideoId(url: String): String? {
        return videoIdPatterns.firstNotNullOfOrNull { pattern ->
            pattern.find(url)?.groupValues?.getOrNull(1)
        }
    }

    private fun addIfUsable(output: LinkedHashSet<String>, value: String) {
        if (value.startsWith("facebook:", ignoreCase = true)) {
            output += value
            return
        }
        if (!isFacebookUrl(value)) return
        val uri = runCatching { URI(value) }.getOrNull() ?: return
        val path = uri.path.orEmpty().lowercase()
        if (path.startsWith("/login") || path.startsWith("/checkpoint") || path.startsWith("/recover")) {
            decodeNestedTarget(value)?.let { nested ->
                if (isFacebookUrl(nested)) output += nested
            }
            return
        }
        output += uri.normalize().toASCIIString().substringBefore('#')
    }

    private fun decodeNestedTarget(url: String): String? {
        val uri = runCatching { URI(url) }.getOrNull() ?: return null
        val rawQuery = uri.rawQuery ?: return null
        val accepted = setOf("next", "u", "url", "href")
        for (part in rawQuery.split('&')) {
            val index = part.indexOf('=')
            if (index <= 0) continue
            val name = part.substring(0, index).lowercase()
            if (name !in accepted) continue
            val value = decodeRepeatedly(part.substring(index + 1))
            if (value.startsWith("https://", ignoreCase = true) && isFacebookUrl(value)) return value
        }
        return null
    }

    private fun resolveFacebookHttps(value: String, baseUrl: String?): String? {
        if (value.startsWith("facebook:", ignoreCase = true)) return value
        val uri = runCatching {
            when {
                value.startsWith("https://", ignoreCase = true) -> URI(value)
                !baseUrl.isNullOrBlank() -> URI(baseUrl).resolve(value)
                else -> null
            }
        }.getOrNull() ?: return null
        if (!uri.scheme.equals("https", ignoreCase = true)) return null
        if (!isFacebookUrl(uri.toString())) return null
        return uri.normalize().toASCIIString().substringBefore('#')
    }

    private fun decodeRepeatedly(value: String): String {
        var current = decodeHtmlEntities(value)
        repeat(5) {
            val jsonDecoded = decodeJsonSlashes(current)
            val percentDecoded = runCatching {
                URLDecoder.decode(jsonDecoded.replace("+", "%2B"), StandardCharsets.UTF_8.name())
            }.getOrDefault(jsonDecoded)
            val next = decodeHtmlEntities(percentDecoded)
            if (next == current) return next
            current = next
        }
        return current
    }

    private fun decodeJsonSlashes(value: String): String = value
        .replace("\\u0025", "%", ignoreCase = true)
        .replace("\\u0026", "&", ignoreCase = true)
        .replace("\\u003d", "=", ignoreCase = true)
        .replace("\\/", "/")

    private fun decodeHtmlEntities(value: String): String = value
        .replace("&amp;", "&", ignoreCase = true)
        .replace("&#38;", "&", ignoreCase = true)
        .replace("&#x26;", "&", ignoreCase = true)
        .replace("&quot;", "\"", ignoreCase = true)
        .replace("&#34;", "\"", ignoreCase = true)
        .replace("&#x22;", "\"", ignoreCase = true)
        .replace("&#39;", "'", ignoreCase = true)
        .replace("&#x27;", "'", ignoreCase = true)
}
