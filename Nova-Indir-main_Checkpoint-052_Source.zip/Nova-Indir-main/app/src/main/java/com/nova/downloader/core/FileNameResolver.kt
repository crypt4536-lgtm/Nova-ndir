package com.nova.downloader.core

import java.net.URI
import java.net.URLDecoder
import java.nio.charset.StandardCharsets

object FileNameResolver {
    private const val MAX_NAME_LENGTH = 120
    private val forbiddenChars = Regex("[\\x00-\\x1F\\x7F/\\\\:*?\"<>|]")
    private val repeatedWhitespace = Regex("\\s+")
    private val genericExtensions = setOf("bin", "download", "dat", "tmp", "part")


    // Checkpoint 046: clean only the user-facing default file name produced after
    // resolution. The resolved URL, extractor metadata and yt-dlp selection remain
    // untouched, so filename cleanup cannot change media resolution behaviour.
    private val socialMetricSegment = Regex(
        """(?i)^\s*[0-9]+(?:[.,][0-9]+)?\s*[KMB]?\s*(?:views?|reactions?|likes?|comments?|shares?|plays?|followers?|görüntüleme(?:ler)?|görüntülenme(?:ler)?|izlenme(?:ler)?|beğeni(?:ler)?|yorum(?:lar)?|paylaşım(?:lar)?|tepki(?:ler)?)\s*$"""
    )
    private val socialMetricPrefix = Regex(
        """(?i)^\s*(?:(?:[0-9]+(?:[.,][0-9]+)?\s*[KMB]?\s*(?:views?|reactions?|likes?|comments?|shares?|plays?|followers?|görüntüleme(?:ler)?|görüntülenme(?:ler)?|izlenme(?:ler)?|beğeni(?:ler)?|yorum(?:lar)?|paylaşım(?:lar)?|tepki(?:ler)?))\s*(?:[·•|_–—-]\s*)*)+"""
    )
    private val spacedDecorativeSeparator = Regex("""\s+(?:[·•|_–—]|-{1,2})\s+""")
    private val trailingPlatformBrand = Regex(
        """(?i)\s*(?:[-|·•–—]\s*)?(?:on\s+)?(?:facebook|instagram|tiktok|youtube|twitter)\s*$"""
    )
    private val embeddedUrl = Regex("""(?i)\b(?:https?://|www\.)\S+""")

    /**
     * Produces a conservative, clean default name for the download dialog.
     * It removes social-site engagement counters and obvious transport noise while
     * preserving the actual title and media extension. This method must never be
     * used to modify the resolver input/output URLs.
     */
    fun cleanResolvedDefaultName(name: String): String {
        val sanitizedOriginal = sanitize(name, "nova_download")
        val rawName = name.trim().ifBlank { sanitizedOriginal }
        val extension = extensionOfName(rawName)
            ?.takeIf { it in knownMediaExtensions }
        val stem = if (extension != null) {
            rawName.dropLast(extension.length + 1)
        } else {
            rawName
        }

        var cleaned = decodeCommonHtmlEntities(stem)
            .replace(embeddedUrl, " ")
            .replace(socialMetricPrefix, "")
            .trim()

        // Split only on visibly decorative separators (surrounded by spaces), so
        // legitimate names such as my_video_name are not altered.
        val segments = cleaned.split(spacedDecorativeSeparator)
            .map { it.trim().trim('·', '•', '|', '_', '-', '–', '—', ' ') }
            .filter { it.isNotBlank() && !socialMetricSegment.matches(it) }

        if (segments.isNotEmpty()) {
            cleaned = segments.joinToString(" - ")
        }

        cleaned = cleaned
            .replace(trailingPlatformBrand, "")
            .replace(Regex("""\s{2,}"""), " ")
            .trim()
            .trim('·', '•', '|', '_', '-', '–', '—', '.', ' ')

        if (cleaned.isBlank()) return sanitizedOriginal

        val candidate = if (extension != null) "$cleaned.$extension" else cleaned
        return sanitize(candidate, sanitizedOriginal)
    }

    private fun decodeCommonHtmlEntities(value: String): String = value
        .replace("&amp;", "&", ignoreCase = true)
        .replace("&quot;", "\"", ignoreCase = true)
        .replace("&#39;", "'", ignoreCase = true)
        .replace("&apos;", "'", ignoreCase = true)
        .replace("&nbsp;", " ", ignoreCase = true)

    fun fromUrl(url: String, fallbackTimestamp: Long = System.currentTimeMillis()): String {
        val rawSegment = runCatching {
            URI(url).rawPath
                ?.substringAfterLast('/')
                ?.takeIf { it.isNotBlank() }
                ?.let { URLDecoder.decode(it, StandardCharsets.UTF_8.name()) }
        }.getOrNull()

        val fallback = "nova_$fallbackTimestamp.bin"
        return sanitize(rawSegment ?: fallback, fallback)
    }

    fun fromContentDisposition(
        contentDisposition: String?,
        fallback: String
    ): String {
        if (contentDisposition.isNullOrBlank()) return sanitize(fallback, "nova_download.bin")

        val utf8Match = Regex("filename\\*=UTF-8''([^;]+)", RegexOption.IGNORE_CASE)
            .find(contentDisposition)
            ?.groupValues
            ?.getOrNull(1)
            ?.let { runCatching { URLDecoder.decode(it, StandardCharsets.UTF_8.name()) }.getOrNull() }

        val plainMatch = Regex("filename=\\\"?([^;\\\"]+)\\\"?", RegexOption.IGNORE_CASE)
            .find(contentDisposition)
            ?.groupValues
            ?.getOrNull(1)

        return sanitize(utf8Match ?: plainMatch ?: fallback, fallback)
    }

    fun ensureMediaExtension(
        requestedName: String,
        mimeType: String?,
        contentDisposition: String? = null,
        finalUrl: String? = null,
        detectedExtension: String? = null
    ): String {
        val dispositionName = contentDisposition?.let {
            fromContentDisposition(it, requestedName)
        }
        val extension = detectedExtension?.lowercase()
            ?: MediaTypePolicy.extensionForMimeType(mimeType)
            ?: MediaTypePolicy.extensionOf(dispositionName)
            ?: MediaTypePolicy.extensionOf(finalUrl)

        var safe = sanitize(requestedName, dispositionName ?: "nova_download")
        if (extension.isNullOrBlank()) return safe

        val current = extensionOfName(safe)
        val shouldReplace = current == null || current in genericExtensions ||
            (current in knownMediaExtensions && current != extension)

        if (shouldReplace) {
            val stem = if (current == null) safe else safe.dropLast(current.length + 1)
            safe = sanitize("$stem.$extension", "nova_download.$extension")
        }
        return safe
    }

    /** Keeps the real media extension while allowing the visible file name to change. */
    fun renamePreservingMediaExtension(
        requestedName: String,
        currentName: String,
        mimeType: String?
    ): String {
        val requiredExtension = MediaTypePolicy.extensionForMimeType(mimeType)
            ?: extensionOfName(currentName)
        val safeRequested = sanitize(requestedName, currentName)
        if (requiredExtension.isNullOrBlank()) return safeRequested

        val currentRequestedExtension = extensionOfName(safeRequested)
        if (currentRequestedExtension == requiredExtension) return safeRequested

        val looksLikeExplicitExtension = currentRequestedExtension
            ?.matches(Regex("[a-zA-Z][a-zA-Z0-9]{0,7}")) == true
        val stem = if (looksLikeExplicitExtension) {
            safeRequested.dropLast(currentRequestedExtension!!.length + 1)
        } else {
            safeRequested
        }
        return sanitize("$stem.$requiredExtension", "nova_download.$requiredExtension")
    }

    fun sanitize(name: String, fallback: String = "nova_download.bin"): String {
        var cleaned = name
            .replace(forbiddenChars, "_")
            .replace(repeatedWhitespace, " ")
            .trim()
            .trim('.', ' ')

        if (cleaned.isBlank() || cleaned == "." || cleaned == "..") {
            cleaned = fallback
        }

        if (cleaned.length <= MAX_NAME_LENGTH) return cleaned

        val extensionIndex = cleaned.lastIndexOf('.')
        val hasUsableExtension = extensionIndex in 1 until cleaned.lastIndex
        if (!hasUsableExtension) return cleaned.take(MAX_NAME_LENGTH)

        val extension = cleaned.substring(extensionIndex).take(16)
        val stemLength = (MAX_NAME_LENGTH - extension.length).coerceAtLeast(1)
        return cleaned.substring(0, extensionIndex).take(stemLength) + extension
    }

    private fun extensionOfName(name: String): String? {
        val dot = name.lastIndexOf('.')
        if (dot <= 0 || dot == name.lastIndex) return null
        return name.substring(dot + 1).lowercase().take(12)
    }

    private val knownMediaExtensions = setOf(
        "mp4", "m4v", "mov", "webm", "mkv", "avi", "3gp", "3g2", "ts",
        "mp3", "m4a", "aac", "ogg", "oga", "opus", "wav", "flac"
    )
}
