package com.nova.downloader.core

import java.net.URI
import java.net.URLDecoder
import java.nio.charset.StandardCharsets

object HtmlMediaExtractor {
    private val metaTagRegex = Regex(
        "<meta\\b[^>]*>",
        setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)
    )
    private val attributeRegex = Regex(
        "([a-zA-Z_:][-a-zA-Z0-9_:.]*)\\s*=\\s*([\"'])(.*?)\\2",
        setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)
    )
    private val jsonKeys = listOf(
        "playable_url_quality_hd",
        "browser_native_hd_url",
        "playable_url",
        "browser_native_sd_url",
        "playable_url_dash",
        "progressive_url",
        "hls_playlist_url",
        "manifest_url",
        "hd_src",
        "sd_src",
        "video_url",
        "contentUrl"
    )
    private val absoluteUrlRegex = Regex(
        "https:\\\\/\\\\/[^\"'<>\\s]+|https://[^\"'<>\\s]+",
        RegexOption.IGNORE_CASE
    )
    private val videoRedirectRegex = Regex(
        "(?:https?://[^\"'<>\\s]+)?/video_redirect/\\?[^\"'<>\\s]+",
        RegexOption.IGNORE_CASE
    )

    fun extract(html: String, baseUrl: String): List<String> {
        val candidates = mutableListOf<String>()

        metaTagRegex.findAll(html).forEach { match ->
            val attributes = attributeRegex.findAll(match.value).associate { attribute ->
                attribute.groupValues[1].lowercase() to attribute.groupValues[3]
            }
            val key = attributes["property"]?.lowercase() ?: attributes["name"]?.lowercase()
            if (key in setOf(
                    "og:video",
                    "og:video:url",
                    "og:video:secure_url",
                    "twitter:player:stream"
                )
            ) {
                attributes["content"]?.let(candidates::add)
            }
        }

        val decodedHtml = decodeRepeatedly(html)
        val jsonSources = listOf(html, decodedHtml).distinct()
        jsonKeys.forEach { key ->
            val quotedPattern = Regex(
                """[\"']${Regex.escape(key)}[\"']\s*:\s*[\"']((?:\\.|[^\"'])*)[\"']""",
                RegexOption.IGNORE_CASE
            )
            jsonSources.forEach { source ->
                quotedPattern.findAll(source).forEach { candidates += decodeRepeatedly(it.groupValues[1]) }
            }
        }

        jsonSources.forEach { source ->
            videoRedirectRegex.findAll(source).forEach { match ->
                extractRedirectTarget(baseUrl, decodeRepeatedly(match.value))?.let(candidates::add)
            }
            absoluteUrlRegex.findAll(source).forEach { match ->
                val url = decodeRepeatedly(match.value)
                if (looksLikeMediaCdnUrl(url)) candidates += url
            }
        }

        return candidates
            .asSequence()
            .map(::decodeRepeatedly)
            .map { it.trim().trimEnd('\\', ',', ';') }
            .filter { it.isNotBlank() }
            .mapNotNull { resolveHttps(baseUrl, it) }
            .distinct()
            .take(40)
            .toList()
    }

    private fun extractRedirectTarget(baseUrl: String, value: String): String? {
        val resolved = runCatching { URI(baseUrl).resolve(value) }.getOrNull() ?: return null
        val rawQuery = resolved.rawQuery ?: return null
        val src = rawQuery.split('&')
            .mapNotNull { part ->
                val index = part.indexOf('=')
                if (index <= 0) null else part.substring(0, index) to part.substring(index + 1)
            }
            .firstOrNull { it.first.equals("src", ignoreCase = true) }
            ?.second
            ?: return null
        return runCatching { URLDecoder.decode(src, StandardCharsets.UTF_8.name()) }.getOrNull()
    }

    private fun looksLikeMediaCdnUrl(url: String): Boolean {
        val lowered = url.lowercase()
        return lowered.contains(".mp4") ||
            lowered.contains(".m4v") ||
            lowered.contains(".webm") ||
            lowered.contains(".m3u8") ||
            lowered.contains(".mpd") ||
            lowered.contains("fbcdn.net") && lowered.contains("video") ||
            lowered.contains("fbsbx.com") && lowered.contains("video")
    }

    private fun resolveHttps(baseUrl: String, candidate: String): String? {
        val resolved = runCatching { URI(baseUrl).resolve(candidate).normalize() }.getOrNull()
            ?: return null
        if (!resolved.scheme.equals("https", ignoreCase = true)) return null
        return resolved.toASCIIString().substringBefore('#')
    }

    private fun decodeRepeatedly(value: String): String {
        var current = decodeHtmlEntities(value)
        repeat(4) {
            val decoded = decodeJsonStringOnce(decodeHtmlEntities(current))
            if (decoded == current) return decoded
            current = decoded
        }
        return current
    }

    private fun decodeJsonStringOnce(value: String): String {
        val output = StringBuilder(value.length)
        var index = 0
        while (index < value.length) {
            val char = value[index]
            if (char != '\\' || index + 1 >= value.length) {
                output.append(char)
                index++
                continue
            }

            when (val escaped = value[index + 1]) {
                '\\', '/', '"', '\'' -> {
                    output.append(escaped)
                    index += 2
                }
                'b' -> { output.append('\b'); index += 2 }
                'f' -> { output.append('\u000C'); index += 2 }
                'n' -> { output.append('\n'); index += 2 }
                'r' -> { output.append('\r'); index += 2 }
                't' -> { output.append('\t'); index += 2 }
                'u' -> {
                    val hexEnd = index + 6
                    if (hexEnd <= value.length) {
                        val decoded = value.substring(index + 2, hexEnd).toIntOrNull(16)
                        if (decoded != null) {
                            output.append(decoded.toChar())
                            index = hexEnd
                        } else {
                            output.append('\\').append(escaped)
                            index += 2
                        }
                    } else {
                        output.append('\\').append(escaped)
                        index += 2
                    }
                }
                else -> {
                    output.append(escaped)
                    index += 2
                }
            }
        }
        return output.toString()
    }

    private fun decodeHtmlEntities(value: String): String {
        var decoded = value
            .replace("&amp;", "&", ignoreCase = true)
            .replace("&quot;", "\"", ignoreCase = true)
            .replace("&#39;", "'", ignoreCase = true)
            .replace("&apos;", "'", ignoreCase = true)
            .replace("&lt;", "<", ignoreCase = true)
            .replace("&gt;", ">", ignoreCase = true)

        val numeric = Regex("&#(x?[0-9a-fA-F]+);")
        decoded = numeric.replace(decoded) { match ->
            val token = match.groupValues[1]
            val radix = if (token.startsWith("x", ignoreCase = true)) 16 else 10
            val digits = if (radix == 16) token.drop(1) else token
            digits.toIntOrNull(radix)?.let { codePoint ->
                runCatching { String(Character.toChars(codePoint)) }.getOrNull()
            } ?: match.value
        }
        return decoded
    }
}
