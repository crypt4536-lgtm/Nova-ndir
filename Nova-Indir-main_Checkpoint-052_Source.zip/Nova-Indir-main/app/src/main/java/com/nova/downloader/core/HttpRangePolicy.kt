package com.nova.downloader.core

object HttpRangePolicy {
    data class ContentRange(val start: Long?, val end: Long?, val total: Long?)

    fun parseContentRange(raw: String?): ContentRange? {
        if (raw.isNullOrBlank()) return null
        val value = raw.trim()
        Regex("bytes\\s+(\\d+)-(\\d+)/(\\d+|\\*)", RegexOption.IGNORE_CASE)
            .matchEntire(value)
            ?.let { match ->
                return ContentRange(
                    start = match.groupValues[1].toLongOrNull(),
                    end = match.groupValues[2].toLongOrNull(),
                    total = match.groupValues[3].takeUnless { it == "*" }?.toLongOrNull()
                )
            }
        Regex("bytes\\s+\\*/(\\d+|\\*)", RegexOption.IGNORE_CASE)
            .matchEntire(value)
            ?.let { match ->
                return ContentRange(
                    start = null,
                    end = null,
                    total = match.groupValues[1].takeUnless { it == "*" }?.toLongOrNull()
                )
            }
        return null
    }

    fun totalBytes(responseCode: Int, contentLength: Long, contentRange: String?, resumeOffset: Long): Long {
        val parsed = parseContentRange(contentRange)
        parsed?.total?.takeIf { it > 0L }?.let { return it }
        return when {
            responseCode == 206 && contentLength > 0L -> resumeOffset + contentLength
            contentLength > 0L -> contentLength
            else -> -1L
        }
    }

    fun canAppend(responseCode: Int, contentRange: String?, resumeOffset: Long): Boolean {
        if (resumeOffset <= 0L) return false
        if (responseCode != 206) return false
        return parseContentRange(contentRange)?.start == resumeOffset
    }
}
