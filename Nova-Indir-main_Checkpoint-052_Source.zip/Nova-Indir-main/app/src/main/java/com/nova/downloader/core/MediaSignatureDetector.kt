package com.nova.downloader.core

import java.io.File
import java.io.FileInputStream

object MediaSignatureDetector {
    data class Result(val extension: String, val mimeType: String)

    fun detect(file: File): Result? {
        if (!file.isFile || file.length() <= 0L) return null
        val bytes = ByteArray(4096)
        val count = runCatching {
            FileInputStream(file).use { it.read(bytes) }
        }.getOrDefault(-1)
        return if (count > 0) detect(bytes.copyOf(count)) else null
    }

    fun detect(bytes: ByteArray): Result? {
        if (bytes.size >= 12 && ascii(bytes, 4, 4) == "ftyp") {
            return Result("mp4", "video/mp4")
        }
        if (startsWith(bytes, 0x1A, 0x45, 0xDF, 0xA3)) {
            val headerText = bytes.toString(Charsets.ISO_8859_1).lowercase()
            return when {
                "webm" in headerText -> Result("webm", "video/webm")
                "matroska" in headerText -> Result("mkv", "video/x-matroska")
                else -> null
            }
        }
        if (bytes.size >= 3 && ascii(bytes, 0, 3) == "ID3") {
            return Result("mp3", "audio/mpeg")
        }
        if (bytes.size >= 2 && (bytes[0].toInt() and 0xFF) == 0xFF &&
            ((bytes[1].toInt() and 0xE0) == 0xE0)
        ) {
            return Result("mp3", "audio/mpeg")
        }
        if (bytes.size >= 4 && ascii(bytes, 0, 4) == "OggS") {
            return Result("ogg", "audio/ogg")
        }
        if (bytes.size >= 4 && ascii(bytes, 0, 4) == "fLaC") {
            return Result("flac", "audio/flac")
        }
        if (bytes.size >= 12 && ascii(bytes, 0, 4) == "RIFF" && ascii(bytes, 8, 4) == "WAVE") {
            return Result("wav", "audio/wav")
        }
        return null
    }

    private fun startsWith(bytes: ByteArray, vararg expected: Int): Boolean {
        if (bytes.size < expected.size) return false
        return expected.indices.all { (bytes[it].toInt() and 0xFF) == expected[it] }
    }

    private fun ascii(bytes: ByteArray, offset: Int, length: Int): String {
        if (offset < 0 || length < 0 || offset + length > bytes.size) return ""
        return bytes.copyOfRange(offset, offset + length).toString(Charsets.US_ASCII)
    }
}
