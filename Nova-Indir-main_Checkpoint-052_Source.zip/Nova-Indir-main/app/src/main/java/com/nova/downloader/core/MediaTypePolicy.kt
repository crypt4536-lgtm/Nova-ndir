package com.nova.downloader.core

import java.net.URI

object MediaTypePolicy {
    private val mediaExtensions = setOf(
        "mp4", "m4v", "mov", "webm", "mkv", "avi", "3gp", "3g2", "ts",
        "mp3", "m4a", "aac", "ogg", "oga", "opus", "wav", "flac"
    )

    fun normalizedMimeType(raw: String?): String? = raw
        ?.substringBefore(';')
        ?.trim()
        ?.lowercase()
        ?.takeIf { it.isNotBlank() }

    fun isHtml(rawMimeType: String?): Boolean = when (normalizedMimeType(rawMimeType)) {
        "text/html", "application/xhtml+xml" -> true
        else -> false
    }

    fun isPlaylist(rawMimeType: String?, urlOrName: String?): Boolean {
        val mime = normalizedMimeType(rawMimeType)
        if (mime in setOf(
                "application/vnd.apple.mpegurl",
                "application/x-mpegurl",
                "audio/mpegurl",
                "audio/x-mpegurl",
                "application/dash+xml"
            )
        ) return true
        return extensionOf(urlOrName) in setOf("m3u8", "mpd")
    }

    fun isDirectMedia(rawMimeType: String?, urlOrName: String?): Boolean {
        val mime = normalizedMimeType(rawMimeType)
        if (
            mime?.startsWith("video/") == true ||
            mime?.startsWith("audio/") == true ||
            mime in setOf("application/mp4", "application/x-matroska")
        ) {
            return !isPlaylist(mime, urlOrName)
        }
        if (mime in setOf("application/octet-stream", "application/force-download", "binary/octet-stream")) {
            return extensionOf(urlOrName) in mediaExtensions
        }
        return mime.isNullOrBlank() && extensionOf(urlOrName) in mediaExtensions
    }

    fun hasMediaExtension(urlOrName: String?): Boolean = extensionOf(urlOrName) in mediaExtensions

    fun extensionForMimeType(rawMimeType: String?): String? = when (normalizedMimeType(rawMimeType)) {
        "video/mp4", "application/mp4" -> "mp4"
        "video/webm" -> "webm"
        "video/quicktime" -> "mov"
        "video/x-matroska", "application/x-matroska" -> "mkv"
        "video/x-msvideo" -> "avi"
        "video/3gpp" -> "3gp"
        "audio/mpeg" -> "mp3"
        "audio/mp4" -> "m4a"
        "audio/aac" -> "aac"
        "audio/ogg" -> "ogg"
        "audio/opus" -> "opus"
        "audio/wav", "audio/x-wav" -> "wav"
        "audio/flac" -> "flac"
        else -> null
    }

    fun mimeTypeForExtension(extension: String?): String? = when (extension?.lowercase()) {
        "mp4", "m4v" -> "video/mp4"
        "webm" -> "video/webm"
        "mov" -> "video/quicktime"
        "mkv" -> "video/x-matroska"
        "avi" -> "video/x-msvideo"
        "3gp", "3g2" -> "video/3gpp"
        "mp3" -> "audio/mpeg"
        "m4a" -> "audio/mp4"
        "aac" -> "audio/aac"
        "ogg", "oga" -> "audio/ogg"
        "opus" -> "audio/opus"
        "wav" -> "audio/wav"
        "flac" -> "audio/flac"
        else -> null
    }

    fun extensionOf(urlOrName: String?): String? {
        if (urlOrName.isNullOrBlank()) return null
        val path = runCatching { URI(urlOrName).path }.getOrNull() ?: urlOrName
        val segment = path.substringAfterLast('/')
        val dot = segment.lastIndexOf('.')
        if (dot <= 0 || dot == segment.lastIndex) return null
        return segment.substring(dot + 1).lowercase().take(12)
    }
}
