package com.nova.downloader.core

import com.nova.downloader.R

data class PetDefinition(val id: String, val labelRes: Int, val glyph: String)

/** Extensible pet registry; UI labels live in Android string resources. */
object PetCatalog {
    const val NOVA_ID = "nova"
    const val ROBOT_ID = "robot"
    const val CAT_ID = "cat"
    const val BLOB_ID = "blob"

    val all: List<PetDefinition> = listOf(
        PetDefinition(NOVA_ID, R.string.pet_name_nova, "N↓"),
        PetDefinition(ROBOT_ID, R.string.pet_name_robot, "🤖"),
        PetDefinition(CAT_ID, R.string.pet_name_cat, "🐱"),
        PetDefinition(BLOB_ID, R.string.pet_name_blob, "●")
    )

    fun byId(id: String?): PetDefinition = all.firstOrNull { it.id == id } ?: all.first()
}
