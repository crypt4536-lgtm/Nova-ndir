package com.nova.downloader.core

import java.net.URI
import java.net.URLDecoder
import java.nio.charset.StandardCharsets

/** Safe parser for Google Play app links and Android package names. */
object PlayStoreLinkParser {
    private val packagePattern = Regex("^[A-Za-z][A-Za-z0-9_]*(?:\\.[A-Za-z0-9_]+)+$")
    private val urlPattern = Regex("(?:https://play\\.google\\.com/[^\\s]+|market://details\\?[^\\s]+)", RegexOption.IGNORE_CASE)

    fun extractPackageId(raw: String): String? {
        val value = raw.trim()
        if (packagePattern.matches(value)) return value

        val candidate = (urlPattern.find(value)?.value ?: value)
            .trimEnd('.', ',', ';', ':', '!', '?', ')', ']', '}', '>', '"', '\'')

        return runCatching {
            val uri = URI(candidate)
            val validTarget = when {
                uri.scheme.equals("https", true) && uri.host.equals("play.google.com", true) ->
                    uri.path.orEmpty().startsWith("/store/apps/details")
                uri.scheme.equals("market", true) && uri.host.equals("details", true) -> true
                else -> false
            }
            if (!validTarget) return@runCatching null
            queryParameters(uri.rawQuery)["id"]?.takeIf(packagePattern::matches)
        }.getOrNull()
    }

    fun canonicalUrl(packageId: String): String? =
        packageId.takeIf(packagePattern::matches)
            ?.let { "https://play.google.com/store/apps/details?id=$it" }

    private fun queryParameters(rawQuery: String?): Map<String, String> {
        if (rawQuery.isNullOrBlank()) return emptyMap()
        return rawQuery.split('&').mapNotNull { pair ->
            val separator = pair.indexOf('=')
            if (separator <= 0) return@mapNotNull null
            val key = decode(pair.substring(0, separator))
            val value = decode(pair.substring(separator + 1))
            key to value
        }.toMap()
    }

    private fun decode(value: String): String =
        URLDecoder.decode(value, StandardCharsets.UTF_8.name())
}
