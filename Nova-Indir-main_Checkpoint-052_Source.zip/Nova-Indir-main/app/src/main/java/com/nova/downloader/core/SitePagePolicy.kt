package com.nova.downloader.core

import java.net.URI

object SitePagePolicy {
    private val extractorHosts = setOf(
        "facebook.com",
        "fb.watch",
        "instagram.com",
        "threads.net",
        "bsky.app",
        "mastodon.social",
        "t.me",
        "telegram.org",
        "tiktok.com",
        "x.com",
        "twitter.com",
        "vimeo.com",
        "youtube.com",
        "youtu.be",
        "music.youtube.com"
    )

    fun shouldUseExtractor(url: String): Boolean {
        val host = runCatching { URI(url).host?.lowercase().orEmpty() }.getOrDefault("")
        return extractorHosts.any { host == it || host.endsWith(".$it") }
    }
}
