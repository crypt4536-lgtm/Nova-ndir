package com.nova.downloader.core

import com.nova.downloader.R
import com.nova.downloader.i18n.AppText
import java.net.IDN
import java.net.URI

object UrlPolicy {
    private const val MAX_URL_LENGTH = 4096
    private val httpsUrlRegex = Regex("https://[^\\s<>\\\"]+", RegexOption.IGNORE_CASE)

    enum class ErrorCode {
        EMPTY, TOO_LONG, INVALID, HTTPS_ONLY, CREDENTIALS_NOT_ALLOWED,
        HOST_MISSING, HOST_INVALID, LOCAL_NOT_SUPPORTED, NORMALIZE_FAILED
    }

    data class Check(val normalizedUrl: String? = null, val error: ErrorCode? = null) {
        val isValid: Boolean get() = normalizedUrl != null && error == null
    }

    sealed class Result {
        data class Valid(val normalizedUrl: String) : Result()
        data class Invalid(val message: String) : Result()
    }

    fun extractFirstHttpsUrl(text: String?): String? {
        if (text.isNullOrBlank()) return null
        val match = httpsUrlRegex.find(text)?.value ?: return null
        return match.trimEnd('.', ',', ';', ':', ')', ']', '}', '!', '?', '\'', '"')
    }

    /** Pure validation result, suitable for local unit tests and non-UI policy checks. */
    fun check(raw: String?): Check {
        val candidate = raw?.trim().orEmpty()
        if (candidate.isBlank()) return Check(error = ErrorCode.EMPTY)
        if (candidate.length > MAX_URL_LENGTH) return Check(error = ErrorCode.TOO_LONG)

        val extracted = extractFirstHttpsUrl(candidate) ?: candidate
        val uri = try {
            URI(extracted)
        } catch (_: Exception) {
            return Check(error = ErrorCode.INVALID)
        }

        if (!uri.scheme.equals("https", ignoreCase = true)) return Check(error = ErrorCode.HTTPS_ONLY)
        if (!uri.userInfo.isNullOrBlank()) return Check(error = ErrorCode.CREDENTIALS_NOT_ALLOWED)

        val host = uri.host?.trim().orEmpty()
        if (host.isBlank()) return Check(error = ErrorCode.HOST_MISSING)

        val asciiHost = try {
            IDN.toASCII(host, IDN.USE_STD3_ASCII_RULES).lowercase()
        } catch (_: Exception) {
            return Check(error = ErrorCode.HOST_INVALID)
        }
        if (asciiHost == "localhost" || asciiHost.endsWith(".localhost")) {
            return Check(error = ErrorCode.LOCAL_NOT_SUPPORTED)
        }

        val normalized = try {
            uri.normalize().toASCIIString().substringBefore('#')
        } catch (_: Exception) {
            return Check(error = ErrorCode.NORMALIZE_FAILED)
        }
        return Check(normalizedUrl = normalized)
    }

    fun validate(raw: String?): Result {
        val check = check(raw)
        return check.normalizedUrl?.let(Result::Valid)
            ?: Result.Invalid(errorMessage(check.error ?: ErrorCode.INVALID))
    }

    private fun errorMessage(code: ErrorCode): String = AppText.get(when (code) {
        ErrorCode.EMPTY -> R.string.url_empty
        ErrorCode.TOO_LONG -> R.string.url_too_long
        ErrorCode.INVALID -> R.string.url_invalid
        ErrorCode.HTTPS_ONLY -> R.string.url_https_only
        ErrorCode.CREDENTIALS_NOT_ALLOWED -> R.string.url_credentials_not_allowed
        ErrorCode.HOST_MISSING -> R.string.url_host_missing
        ErrorCode.HOST_INVALID -> R.string.url_host_invalid
        ErrorCode.LOCAL_NOT_SUPPORTED -> R.string.url_local_not_supported
        ErrorCode.NORMALIZE_FAILED -> R.string.url_normalize_failed
    })
}
