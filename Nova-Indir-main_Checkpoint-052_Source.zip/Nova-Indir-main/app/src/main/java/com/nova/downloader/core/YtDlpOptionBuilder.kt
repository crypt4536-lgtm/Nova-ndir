package com.nova.downloader.core

import com.nova.downloader.R
import com.nova.downloader.i18n.AppText

object YtDlpOptionBuilder {
    const val MODE_VIDEO = "video"
    const val MODE_AUDIO = "audio"

    data class QualityPreset(val id: String, val labelRes: Int, val maxHeight: Int?)
    data class AudioPreset(val id: String, val labelRes: Int, val extension: String, val mimeType: String)

    val qualityPresets = listOf(
        QualityPreset("best", R.string.quality_best, null),
        QualityPreset("2160", R.string.quality_2160, 2160),
        QualityPreset("1440", R.string.quality_1440, 1440),
        QualityPreset("1080", R.string.quality_1080, 1080),
        QualityPreset("720", R.string.quality_720, 720),
        QualityPreset("480", R.string.quality_480, 480),
        QualityPreset("360", R.string.quality_360, 360)
    )

    val audioPresets = listOf(
        AudioPreset("m4a", R.string.audio_m4a, "m4a", "audio/mp4"),
        AudioPreset("mp3", R.string.audio_mp3, "mp3", "audio/mpeg"),
        AudioPreset("opus", R.string.audio_opus, "opus", "audio/opus"),
        AudioPreset("flac", R.string.audio_flac, "flac", "audio/flac"),
        AudioPreset("wav", R.string.audio_wav, "wav", "audio/wav")
    )

    fun videoFormatSelector(qualityId: String?, container: String? = null): String {
        val height = qualityPresets.firstOrNull { it.id == qualityId }?.maxHeight
        val heightFilter = height?.let { "[height<=$it]" }.orEmpty()
        val generic = "bv*$heightFilter+ba/b$heightFilter/bv*+ba/b"
        return when (container?.lowercase()) {
            "mp4" -> "bv*[ext=mp4]$heightFilter+ba[ext=m4a]/b[ext=mp4]$heightFilter/$generic"
            "webm" -> "bv*[ext=webm]$heightFilter+ba[ext=webm]/b[ext=webm]$heightFilter/$generic"
            else -> generic
        }
    }

    fun suggestedVideoExtension(container: String?): String = when (container?.lowercase()) {
        "mkv" -> "mkv"
        "webm" -> "webm"
        else -> "mp4"
    }

    fun mimeForVideoContainer(container: String?): String = when (container?.lowercase()) {
        "mkv" -> "video/x-matroska"
        "webm" -> "video/webm"
        else -> "video/mp4"
    }

    fun audioPreset(id: String?): AudioPreset = audioPresets.firstOrNull { it.id == id } ?: audioPresets.first()
    fun qualityLabel(id: String?): String = AppText.get(qualityPresets.firstOrNull { it.id == id }?.labelRes ?: R.string.quality_best)
    fun audioLabel(id: String?): String = AppText.get(audioPreset(id).labelRes)
}
