package com.nova.downloader.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class AccountProfile(
    val id: String,
    val platform: String,
    val name: String,
    val enabled: Boolean = true,
    val createdAt: Long = System.currentTimeMillis(),
    val lastUsedAt: Long = 0L
)

/** Named, platform-scoped account profiles. Cookie contents remain encrypted in CookieVault. */
class AccountProfileStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun list(platform: String? = null): List<AccountProfile> = synchronized(LOCK) {
        readProfiles().filter { platform == null || it.platform == normalizePlatform(platform) }
            .sortedWith(compareBy<AccountProfile> { it.platform }.thenByDescending { it.lastUsedAt }.thenBy { it.name })
    }

    fun get(id: String): AccountProfile? = list().firstOrNull { it.id == id }

    fun create(platform: String, name: String): AccountProfile = synchronized(LOCK) {
        val normalized = normalizePlatform(platform)
        val profile = AccountProfile(
            id = UUID.randomUUID().toString().replace("-", ""),
            platform = normalized,
            name = name.trim().ifBlank { defaultName(normalized) }
        )
        val profiles = readProfiles().toMutableList().apply { add(profile) }
        writeProfiles(profiles)
        if (activeId(normalized) == null) setActive(normalized, profile.id)
        profile
    }

    fun ensureActive(platform: String): AccountProfile {
        val normalized = normalizePlatform(platform)
        return active(normalized) ?: create(normalized, defaultName(normalized))
    }

    fun active(platform: String): AccountProfile? {
        val normalized = normalizePlatform(platform)
        val id = activeId(normalized)
        return list(normalized).firstOrNull { it.id == id && it.enabled }
            ?: list(normalized).firstOrNull { it.enabled }
    }

    fun setActive(platform: String, profileId: String) {
        val normalized = normalizePlatform(platform)
        if (list(normalized).none { it.id == profileId }) return
        prefs.edit().putString(activeKey(normalized), profileId).apply()
        touch(profileId)
    }

    fun setEnabled(profileId: String, enabled: Boolean) = synchronized(LOCK) {
        val updated = readProfiles().map { if (it.id == profileId) it.copy(enabled = enabled) else it }
        writeProfiles(updated)
    }

    fun rename(profileId: String, name: String) = synchronized(LOCK) {
        val updated = readProfiles().map {
            if (it.id == profileId) it.copy(name = name.trim().ifBlank { it.name }) else it
        }
        writeProfiles(updated)
    }

    fun touch(profileId: String) = synchronized(LOCK) {
        val now = System.currentTimeMillis()
        writeProfiles(readProfiles().map { if (it.id == profileId) it.copy(lastUsedAt = now) else it })
    }

    fun remove(profileId: String) = synchronized(LOCK) {
        val target = readProfiles().firstOrNull { it.id == profileId } ?: return@synchronized
        writeProfiles(readProfiles().filterNot { it.id == profileId })
        if (activeId(target.platform) == profileId) prefs.edit().remove(activeKey(target.platform)).apply()
    }

    fun activeId(platform: String): String? = prefs.getString(activeKey(normalizePlatform(platform)), null)

    private fun readProfiles(): List<AccountProfile> = runCatching {
        val array = JSONArray(prefs.getString(KEY_PROFILES, "[]") ?: "[]")
        buildList {
            for (i in 0 until array.length()) {
                val item = array.optJSONObject(i) ?: continue
                val id = item.optString("id").takeIf(String::isNotBlank) ?: continue
                add(
                    AccountProfile(
                        id = id,
                        platform = normalizePlatform(item.optString("platform")),
                        name = item.optString("name").ifBlank { defaultName(item.optString("platform")) },
                        enabled = item.optBoolean("enabled", true),
                        createdAt = item.optLong("createdAt", System.currentTimeMillis()),
                        lastUsedAt = item.optLong("lastUsedAt", 0L)
                    )
                )
            }
        }
    }.getOrDefault(emptyList())

    private fun writeProfiles(profiles: List<AccountProfile>) {
        val array = JSONArray()
        profiles.distinctBy { it.id }.forEach { profile ->
            array.put(JSONObject().apply {
                put("id", profile.id); put("platform", profile.platform); put("name", profile.name)
                put("enabled", profile.enabled); put("createdAt", profile.createdAt); put("lastUsedAt", profile.lastUsedAt)
            })
        }
        prefs.edit().putString(KEY_PROFILES, array.toString()).apply()
    }

    private fun activeKey(platform: String) = "active_$platform"
    private fun defaultName(platform: String) = when (normalizePlatform(platform)) {
        PlatformPolicy.YOUTUBE -> "YouTube"
        PlatformPolicy.INSTAGRAM -> "Instagram"
        PlatformPolicy.FACEBOOK -> "Facebook"
        PlatformPolicy.TIKTOK -> "TikTok"
        PlatformPolicy.TWITTER -> "X / Twitter"
        else -> "Web"
    }

    private fun normalizePlatform(value: String) = when (value.lowercase()) {
        PlatformPolicy.YOUTUBE, PlatformPolicy.INSTAGRAM, PlatformPolicy.FACEBOOK,
        PlatformPolicy.TIKTOK, PlatformPolicy.TWITTER -> value.lowercase()
        else -> PlatformPolicy.GENERIC
    }

    companion object {
        private const val PREFS = "nova_account_profiles"
        private const val KEY_PROFILES = "profiles"
        private val LOCK = Any()
    }
}
