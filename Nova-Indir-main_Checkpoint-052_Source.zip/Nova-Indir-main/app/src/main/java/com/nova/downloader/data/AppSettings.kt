package com.nova.downloader.data

import android.content.Context
import android.app.ActivityManager
import android.graphics.Color
import com.nova.downloader.i18n.LocaleController
import com.nova.downloader.core.PetCatalog
import com.nova.downloader.core.YtDlpOptionBuilder

class AppSettings(context: Context) {
    private val appContext = context.applicationContext
    private val lowRamDefault = appContext.getSystemService(ActivityManager::class.java)?.isLowRamDevice == true
    private val prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    var onboardingComplete by bool(KEY_ONBOARDING_COMPLETE, false)
    var languageTag by string(KEY_LANGUAGE_TAG, LocaleController.SYSTEM)
    var automaticUpdateChecks by bool(KEY_AUTOMATIC_UPDATE_CHECKS, true)
    var memoryMode by string(KEY_MEMORY_MODE, if (lowRamDefault) MEMORY_SAVER else MEMORY_BALANCED)
    var defaultTreeUri: String?
        get() = prefs.getString(KEY_DEFAULT_TREE_URI, null)?.takeIf { it.isNotBlank() }
        set(value) = prefs.edit().putString(KEY_DEFAULT_TREE_URI, value.orEmpty()).apply()
    var confirmEachDownload by bool(KEY_CONFIRM_EACH_DOWNLOAD, true)
    var defaultOutputMode by string(KEY_DEFAULT_OUTPUT_MODE, YtDlpOptionBuilder.MODE_VIDEO)
    var defaultQualityId by string(KEY_DEFAULT_QUALITY, "best")
    var defaultAudioFormat by string(KEY_DEFAULT_AUDIO_FORMAT, "m4a")
    var defaultVideoContainer by string(KEY_DEFAULT_VIDEO_CONTAINER, "mp4")
    var defaultDuplicatePolicy by string(KEY_DUPLICATE_POLICY, DuplicatePolicy.RENAME)
    var remoteEjsEnabled by bool(KEY_REMOTE_EJS, true)
    var useCookies by bool(KEY_USE_COOKIES, true)
    var requestDelaySeconds: Int
        get() = prefs.getInt(KEY_REQUEST_DELAY_SECONDS, 2).coerceIn(0, 30)
        set(value) = prefs.edit().putInt(KEY_REQUEST_DELAY_SECONDS, value.coerceIn(0, 30)).apply()
    var concurrentFragments: Int
        get() = prefs.getInt(KEY_CONCURRENT_FRAGMENTS, 4).coerceIn(1, 8)
        set(value) = prefs.edit().putInt(KEY_CONCURRENT_FRAGMENTS, value.coerceIn(1, 8)).apply()
    var speedLimitKbps: Int
        get() = prefs.getInt(KEY_SPEED_LIMIT_KBPS, 0).coerceIn(0, 100_000)
        set(value) = prefs.edit().putInt(KEY_SPEED_LIMIT_KBPS, value.coerceIn(0, 100_000)).apply()
    var maxParallelDownloads: Int
        get() = prefs.getInt(KEY_MAX_PARALLEL_DOWNLOADS, 1).coerceIn(1, 3)
        set(value) = prefs.edit().putInt(KEY_MAX_PARALLEL_DOWNLOADS, value.coerceIn(1, 3)).apply()
    var youtubePlayerClient by string(KEY_YOUTUBE_PLAYER_CLIENT, "default")
    var youtubePoToken: String
        get() = SecretVault.decryptString(prefs.getString(KEY_YOUTUBE_PO_TOKEN, null))
        set(value) = prefs.edit().putString(KEY_YOUTUBE_PO_TOKEN, SecretVault.encryptString(value.trim())).apply()
    var youtubeVisitorData: String
        get() = SecretVault.decryptString(prefs.getString(KEY_YOUTUBE_VISITOR_DATA, null))
        set(value) = prefs.edit().putString(KEY_YOUTUBE_VISITOR_DATA, SecretVault.encryptString(value.trim())).apply()
    var poTokenProviderEnabled by bool(KEY_PO_PROVIDER_ENABLED, false)
    var poTokenProviderBaseUrl by string(KEY_PO_PROVIDER_URL, "http://127.0.0.1:4416")

    var browserHomeUrl by string(KEY_BROWSER_HOME_URL, "https://duckduckgo.com/")
    var browserAutoDetectEnabled by bool(KEY_BROWSER_AUTO_DETECT, true)
    var browserSyncCookies by bool(KEY_BROWSER_SYNC_COOKIES, true)
    var browserThirdPartyCookies by bool(KEY_BROWSER_THIRD_PARTY_COOKIES, true)
    var browserClearCacheOnExit by bool(KEY_BROWSER_CLEAR_CACHE_EXIT, false)

    var backgroundResolutionEnabled by bool(KEY_BACKGROUND_RESOLUTION, true)
    var autoStartAfterResolution by bool(KEY_AUTO_START_AFTER_RESOLUTION, false)
    var resolutionReadyNotifications by bool(KEY_RESOLUTION_READY_NOTIFICATIONS, true)
    var systemCompletionNotifications by bool(KEY_SYSTEM_COMPLETION_NOTIFICATIONS, true)
    var inAppCompletionDialog by bool(KEY_IN_APP_COMPLETION_DIALOG, true)
    var petCompletionAlerts by bool(KEY_PET_COMPLETION_ALERTS, true)

    var recoveryPolicy by string(KEY_RECOVERY_POLICY, RecoveryPolicy.MANUAL)
    var recoveryChargingOnly by bool(KEY_RECOVERY_CHARGING, false)
    var playlistDefaultAll by bool(KEY_PLAYLIST_ALL, false)
    var defaultEmbedMetadata by bool(KEY_EMBED_METADATA, true)
    var defaultEmbedChapters by bool(KEY_EMBED_CHAPTERS, true)

    var petEnabled by bool(KEY_PET_ENABLED, false)
    var petShowStatus by bool(KEY_PET_SHOW_STATUS, true)
    var petType by string(KEY_PET_TYPE, PET_NOVA)
    var petColor: Int
        get() = prefs.getInt(KEY_PET_COLOR, Color.rgb(15, 112, 255))
        set(value) = prefs.edit().putInt(KEY_PET_COLOR, value).apply()
    var petShell by string(KEY_PET_SHELL, SHELL_ROUNDED)
    var petX: Int
        get() = prefs.getInt(KEY_PET_X, 18)
        set(value) = prefs.edit().putInt(KEY_PET_X, value).apply()
    var petY: Int
        get() = prefs.getInt(KEY_PET_Y, 210)
        set(value) = prefs.edit().putInt(KEY_PET_Y, value).apply()
    var petSizePercent: Int
        get() = prefs.getInt(KEY_PET_SIZE, 100).coerceIn(50, 200)
        set(value) = prefs.edit().putInt(KEY_PET_SIZE, value.coerceIn(50, 200)).apply()
    var petOpacityPercent: Int
        get() = prefs.getInt(KEY_PET_OPACITY, 92).coerceIn(25, 100)
        set(value) = prefs.edit().putInt(KEY_PET_OPACITY, value.coerceIn(25, 100)).apply()
    var petSnapEdge by bool(KEY_PET_SNAP_EDGE, true)
    var petLowPower by bool(KEY_PET_LOW_POWER, true)
    var petStartOnBoot by bool(KEY_PET_START_BOOT, false)
    var petCustomPackagePath: String?
        get() = prefs.getString(KEY_PET_CUSTOM_PATH, null)?.takeIf { it.isNotBlank() }
        set(value) = prefs.edit().putString(KEY_PET_CUSTOM_PATH, value.orEmpty()).apply()

    private fun bool(key: String, default: Boolean) = object : kotlin.properties.ReadWriteProperty<Any?, Boolean> {
        override fun getValue(thisRef: Any?, property: kotlin.reflect.KProperty<*>) = prefs.getBoolean(key, default)
        override fun setValue(thisRef: Any?, property: kotlin.reflect.KProperty<*>, value: Boolean) { prefs.edit().putBoolean(key, value).apply() }
    }
    private fun string(key: String, default: String) = object : kotlin.properties.ReadWriteProperty<Any?, String> {
        override fun getValue(thisRef: Any?, property: kotlin.reflect.KProperty<*>) = prefs.getString(key, default) ?: default
        override fun setValue(thisRef: Any?, property: kotlin.reflect.KProperty<*>, value: String) { prefs.edit().putString(key, value).apply() }
    }

    companion object {
        const val PET_NOVA = PetCatalog.NOVA_ID; const val PET_ROBOT = PetCatalog.ROBOT_ID
        const val PET_CAT = PetCatalog.CAT_ID; const val PET_BLOB = PetCatalog.BLOB_ID
        const val PET_CUSTOM = "custom"
        const val SHELL_ROUNDED = "rounded"; const val SHELL_CIRCLE = "circle"
        const val SHELL_SQUARE = "square"; const val SHELL_OUTLINE = "outline"
        const val MEMORY_SAVER = "saver"; const val MEMORY_BALANCED = "balanced"; const val MEMORY_PERFORMANCE = "performance"
        private const val PREFS_NAME = "nova_downloader_settings"
        private const val KEY_ONBOARDING_COMPLETE = "onboarding_complete"; private const val KEY_DEFAULT_TREE_URI = "default_tree_uri"
        private const val KEY_LANGUAGE_TAG = "language_tag"; private const val KEY_AUTOMATIC_UPDATE_CHECKS = "automatic_update_checks"
        private const val KEY_MEMORY_MODE = "memory_mode"
        private const val KEY_CONFIRM_EACH_DOWNLOAD = "confirm_each_download"; private const val KEY_DEFAULT_OUTPUT_MODE = "default_output_mode"
        private const val KEY_DEFAULT_QUALITY = "default_quality"; private const val KEY_DEFAULT_AUDIO_FORMAT = "default_audio_format"
        private const val KEY_DEFAULT_VIDEO_CONTAINER = "default_video_container"; private const val KEY_DUPLICATE_POLICY = "duplicate_policy"
        private const val KEY_REMOTE_EJS = "remote_ejs"; private const val KEY_USE_COOKIES = "use_cookies"
        private const val KEY_REQUEST_DELAY_SECONDS = "request_delay_seconds"; private const val KEY_CONCURRENT_FRAGMENTS = "concurrent_fragments"
        private const val KEY_SPEED_LIMIT_KBPS = "speed_limit_kbps"; private const val KEY_MAX_PARALLEL_DOWNLOADS = "max_parallel_downloads"
        private const val KEY_YOUTUBE_PLAYER_CLIENT = "youtube_player_client"; private const val KEY_YOUTUBE_PO_TOKEN = "youtube_po_token"
        private const val KEY_YOUTUBE_VISITOR_DATA = "youtube_visitor_data"; private const val KEY_PO_PROVIDER_ENABLED = "po_provider_enabled"
        private const val KEY_PO_PROVIDER_URL = "po_provider_url"
        private const val KEY_BROWSER_HOME_URL = "browser_home_url"; private const val KEY_BROWSER_AUTO_DETECT = "browser_auto_detect"
        private const val KEY_BROWSER_SYNC_COOKIES = "browser_sync_cookies"; private const val KEY_BROWSER_THIRD_PARTY_COOKIES = "browser_third_party_cookies"
        private const val KEY_BROWSER_CLEAR_CACHE_EXIT = "browser_clear_cache_exit"
        private const val KEY_BACKGROUND_RESOLUTION = "background_resolution"
        private const val KEY_AUTO_START_AFTER_RESOLUTION = "auto_start_after_resolution"
        private const val KEY_RESOLUTION_READY_NOTIFICATIONS = "resolution_ready_notifications"
        private const val KEY_SYSTEM_COMPLETION_NOTIFICATIONS = "system_completion_notifications"
        private const val KEY_IN_APP_COMPLETION_DIALOG = "in_app_completion_dialog"
        private const val KEY_PET_COMPLETION_ALERTS = "pet_completion_alerts"
        private const val KEY_RECOVERY_POLICY = "recovery_policy"
        private const val KEY_RECOVERY_CHARGING = "recovery_charging"; private const val KEY_PLAYLIST_ALL = "playlist_all"
        private const val KEY_EMBED_METADATA = "embed_metadata"; private const val KEY_EMBED_CHAPTERS = "embed_chapters"
        private const val KEY_PET_ENABLED = "pet_enabled"; private const val KEY_PET_SHOW_STATUS = "pet_show_status"
        private const val KEY_PET_TYPE = "pet_type"; private const val KEY_PET_COLOR = "pet_color"; private const val KEY_PET_SHELL = "pet_shell"
        private const val KEY_PET_X = "pet_x"; private const val KEY_PET_Y = "pet_y"; private const val KEY_PET_SIZE = "pet_size"
        private const val KEY_PET_OPACITY = "pet_opacity"; private const val KEY_PET_SNAP_EDGE = "pet_snap_edge"
        private const val KEY_PET_LOW_POWER = "pet_low_power"; private const val KEY_PET_START_BOOT = "pet_start_boot"
        private const val KEY_PET_CUSTOM_PATH = "pet_custom_path"
    }
}
