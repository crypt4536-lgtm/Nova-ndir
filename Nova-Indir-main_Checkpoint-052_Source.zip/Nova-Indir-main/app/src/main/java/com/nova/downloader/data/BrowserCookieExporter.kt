package com.nova.downloader.data

import com.nova.downloader.i18n.AppText

import com.nova.downloader.R

import android.content.Context
import android.webkit.CookieManager
import java.net.URI

/** Copies only the browser session cookies needed by the selected platform into the encrypted CookieVault. */
object BrowserCookieExporter {
    data class Snapshot(val url: String, val cookieHeader: String)

    fun exportCurrentSession(context: Context, currentUrl: String): Result<String> = runCatching {
        val snapshots = snapshotsFor(currentUrl)
        require(snapshots.isNotEmpty()) { AppText.get(R.string.browser_no_exportable_cookies) }
        val platform = PlatformPolicy.platformFor(currentUrl)
        CookieVault.saveBrowserSession(context, snapshots, platform)
    }

    fun exportForProfile(context: Context, currentUrl: String, profileId: String, platform: String): Result<String> = runCatching {
        val snapshots = snapshotsFor(currentUrl, platform)
        require(snapshots.isNotEmpty()) { AppText.get(R.string.browser_no_exportable_cookies) }
        CookieVault.saveBrowserSession(context, snapshots, platform, profileId)
    }

    fun snapshotsFor(currentUrl: String, platformOverride: String? = null): List<Snapshot> {
        val manager = CookieManager.getInstance()
        manager.flush()
        return cookieProbeUrls(currentUrl, platformOverride).mapNotNull { url ->
            manager.getCookie(url)?.takeIf { it.isNotBlank() }?.let { Snapshot(url, it) }
        }
    }

    private fun cookieProbeUrls(currentUrl: String, platformOverride: String? = null): List<String> {
        val platform = platformOverride ?: PlatformPolicy.platformFor(currentUrl)
        return when (platform) {
            PlatformPolicy.YOUTUBE -> listOf(
                currentUrl,
                "https://www.youtube.com/",
                "https://m.youtube.com/",
                "https://music.youtube.com/",
                "https://accounts.google.com/"
            )
            PlatformPolicy.INSTAGRAM -> listOf(currentUrl, "https://www.instagram.com/", "https://i.instagram.com/")
            PlatformPolicy.FACEBOOK -> listOf(currentUrl, "https://www.facebook.com/", "https://m.facebook.com/", "https://mbasic.facebook.com/")
            PlatformPolicy.TIKTOK -> listOf(currentUrl, "https://www.tiktok.com/", "https://m.tiktok.com/")
            PlatformPolicy.TWITTER -> listOf(currentUrl, "https://x.com/", "https://twitter.com/", "https://mobile.twitter.com/")
            PlatformPolicy.THREADS -> listOf(currentUrl, "https://www.threads.net/")
            PlatformPolicy.BLUESKY -> listOf(currentUrl, "https://bsky.app/")
            PlatformPolicy.MASTODON -> listOf(currentUrl)
            PlatformPolicy.TELEGRAM -> listOf(currentUrl, "https://t.me/", "https://web.telegram.org/")
            else -> listOf(currentUrl)
        }.filter { runCatching { URI(it).scheme == "https" }.getOrDefault(false) }.distinct()
    }
}
