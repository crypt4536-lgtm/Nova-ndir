package com.nova.downloader.data

import android.content.Intent
import org.json.JSONObject

/** Internal transfer contract between the browser and the main download screen. */
object BrowserTransfer {
    const val ACTION_DOWNLOAD = "com.nova.downloader.action.BROWSER_DOWNLOAD"
    const val EXTRA_URL = "browser_url"
    const val EXTRA_PAGE_URL = "browser_page_url"
    const val EXTRA_TITLE = "browser_title"
    const val EXTRA_MIME_TYPE = "browser_mime_type"
    const val EXTRA_KIND = "browser_kind"
    const val EXTRA_HEADERS = "browser_headers"

    fun putHeaders(intent: Intent, headers: Map<String, String>) {
        intent.putExtra(EXTRA_HEADERS, JSONObject(headers).toString())
    }

    fun readHeaders(intent: Intent): Map<String, String> {
        val raw = intent.getStringExtra(EXTRA_HEADERS).orEmpty()
        if (raw.isBlank()) return emptyMap()
        return runCatching {
            val json = JSONObject(raw)
            buildMap {
                val keys = json.keys()
                while (keys.hasNext()) {
                    val key = keys.next()
                    val value = json.optString(key).trim()
                    if (key.isNotBlank() && value.isNotBlank()) put(key, value)
                }
            }
        }.getOrDefault(emptyMap())
    }
}
