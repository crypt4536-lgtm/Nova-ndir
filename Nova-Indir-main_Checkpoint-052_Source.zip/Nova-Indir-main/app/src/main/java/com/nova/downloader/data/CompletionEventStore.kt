package com.nova.downloader.data

import android.content.Context
import android.content.Intent
import org.json.JSONObject
import java.io.File

/** Cross-process completion queue used by the UI and the pet overlay. */
class CompletionEventStore(context: Context) {
    private val appContext = context.applicationContext
    private val root = File(appContext.filesDir, "completion_events").apply { mkdirs() }

    data class Event(val downloadId: Long, val fileName: String, val createdAt: Long)

    @Synchronized
    fun record(downloadId: Long, fileName: String) {
        val temporary = File(root, "$downloadId.tmp")
        val target = File(root, "$downloadId.json")
        temporary.writeText(JSONObject().apply {
            put("downloadId", downloadId)
            put("fileName", fileName)
            put("createdAt", System.currentTimeMillis())
        }.toString(), Charsets.UTF_8)
        if (!temporary.renameTo(target)) {
            target.writeBytes(temporary.readBytes())
            temporary.delete()
        }
        appContext.sendBroadcast(Intent(ACTION_CHANGED).setPackage(appContext.packageName).putExtra(EXTRA_DOWNLOAD_ID, downloadId))
    }

    @Synchronized
    fun pending(): List<Event> = root.listFiles().orEmpty()
        .asSequence()
        .filter { it.isFile && it.extension == "json" }
        .mapNotNull { candidate ->
            runCatching {
                val json = JSONObject(candidate.readText(Charsets.UTF_8))
                Event(json.getLong("downloadId"), json.getString("fileName"), json.getLong("createdAt"))
            }.getOrNull()
        }
        .filter { System.currentTimeMillis() - it.createdAt <= MAX_AGE_MS }
        .sortedBy { it.createdAt }
        .toList()

    @Synchronized
    fun remove(downloadId: Long) {
        File(root, "$downloadId.json").delete()
        File(root, "$downloadId.tmp").delete()
    }

    companion object {
        const val ACTION_CHANGED = "com.nova.downloader.action.DOWNLOAD_COMPLETION_CHANGED"
        const val EXTRA_DOWNLOAD_ID = "completed_download_id"
        private const val MAX_AGE_MS = 24L * 60L * 60L * 1000L
    }
}
