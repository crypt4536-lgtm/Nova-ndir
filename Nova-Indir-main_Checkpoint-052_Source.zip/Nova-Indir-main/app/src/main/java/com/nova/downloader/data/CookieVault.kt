package com.nova.downloader.data

import com.nova.downloader.i18n.AppText
import com.nova.downloader.R
import android.content.Context
import android.net.Uri
import java.io.File

/** Encrypted, platform- and profile-scoped Netscape cookies.txt storage. */
object CookieVault {
    private const val MAX_COOKIE_BYTES = 5 * 1024 * 1024

    fun importFromUri(
        context: Context,
        uri: Uri,
        platform: String = PlatformPolicy.GENERIC,
        profileId: String? = null
    ): Result<String> = runCatching {
        val text = context.contentResolver.openInputStream(uri)?.use { input ->
            input.readBytesLimited(MAX_COOKIE_BYTES).toString(Charsets.UTF_8)
        } ?: error(AppText.get(R.string.cookie_file_open_failed))
        validate(text)
        val normalized = normalizePlatform(platform)
        val profile = profileId ?: AccountProfileStore(context).ensureActive(normalized).id
        val target = encryptedFile(context, normalized, profile)
        target.parentFile?.mkdirs()
        target.writeText(SecretVault.encryptString(text), Charsets.UTF_8)
        securePermissions(target)
        AccountProfileStore(context).touch(profile)
        AppText.get(R.string.cookie_profile_imported, label(normalized))
    }

    fun saveBrowserSession(
        context: Context,
        snapshots: List<BrowserCookieExporter.Snapshot>,
        platform: String = PlatformPolicy.GENERIC,
        profileId: String? = null
    ): String {
        require(snapshots.isNotEmpty()) { AppText.get(R.string.browser_session_empty) }
        val lines = linkedSetOf<String>()
        lines += "# Netscape HTTP Cookie File"
        snapshots.forEach { snapshot ->
            val host = runCatching { java.net.URI(snapshot.url).host.orEmpty().lowercase() }.getOrDefault("")
            if (host.isBlank()) return@forEach
            snapshot.cookieHeader.split(';').map(String::trim).filter { '=' in it }.forEach { pair ->
                val name = pair.substringBefore('=').trim()
                val value = pair.substringAfter('=', "").trim().replace(Regex("[\\t\\r\\n]"), "")
                if (name.matches(Regex("[!#$%&'*+.^_`|~0-9A-Za-z-]+"))) {
                    lines += listOf(host, "FALSE", "/", "TRUE", "0", name, value).joinToString("\t")
                }
            }
        }
        require(lines.size > 1) { AppText.get(R.string.browser_session_no_usable_cookies) }
        val normalized = normalizePlatform(platform)
        val profile = profileId ?: AccountProfileStore(context).ensureActive(normalized).id
        val target = encryptedFile(context, normalized, profile)
        target.parentFile?.mkdirs()
        target.writeText(SecretVault.encryptString(lines.joinToString("\n") + "\n"), Charsets.UTF_8)
        securePermissions(target)
        AccountProfileStore(context).touch(profile)
        return AppText.get(R.string.browser_session_profile_imported, label(normalized))
    }

    fun hasCookies(context: Context, platform: String = PlatformPolicy.GENERIC, profileId: String? = null): Boolean {
        val normalized = normalizePlatform(platform)
        val selected = profileId ?: AccountProfileStore(context).active(normalized)?.id
        if (selected != null && encryptedFile(context, normalized, selected).let { it.isFile && it.length() > 0L }) return true
        return legacyFile(context, normalized).let { it.isFile && it.length() > 0L }
    }

    data class Selection(val platform: String, val profileId: String?)

    fun bestProfile(context: Context, url: String): Selection? {
        val platform = PlatformPolicy.platformFor(url)
        val store = AccountProfileStore(context)
        val active = store.active(platform)
        return when {
            active != null && active.enabled && hasCookies(context, platform, active.id) -> Selection(platform, active.id)
            hasCookies(context, platform, null) -> Selection(platform, null)
            store.active(PlatformPolicy.GENERIC)?.let { hasCookies(context, PlatformPolicy.GENERIC, it.id) } == true ->
                Selection(PlatformPolicy.GENERIC, store.active(PlatformPolicy.GENERIC)?.id)
            hasCookies(context, PlatformPolicy.GENERIC, null) -> Selection(PlatformPolicy.GENERIC, null)
            else -> null
        }
    }

    fun bestPlatform(context: Context, url: String): String? = bestProfile(context, url)?.platform

    fun materialize(
        context: Context,
        tag: String,
        platform: String = PlatformPolicy.GENERIC,
        profileId: String? = null
    ): File? {
        val normalized = normalizePlatform(platform)
        val selected = profileId ?: AccountProfileStore(context).active(normalized)?.id
        val source = selected?.let { encryptedFile(context, normalized, it) }
            ?.takeIf(File::isFile)
            ?: legacyFile(context, normalized).takeIf(File::isFile)
            ?: return null
        val plain = SecretVault.decryptString(source.readText(Charsets.UTF_8))
        if (plain.isBlank()) return null
        validate(plain)
        val folder = File(context.cacheDir, "auth/$tag").apply { mkdirs() }
        val target = File(folder, "cookies.txt")
        target.writeText(plain, Charsets.UTF_8)
        securePermissions(target)
        selected?.let { AccountProfileStore(context).touch(it) }
        return target
    }

    fun clearMaterialized(file: File?) {
        if (file == null) return
        runCatching { file.writeText("") }
        runCatching { file.delete() }
        runCatching { file.parentFile?.deleteRecursively() }
    }

    fun clear(context: Context, platform: String? = null, profileId: String? = null) {
        when {
            platform == null -> runCatching { File(context.noBackupFilesDir, "auth").deleteRecursively() }
            profileId != null -> runCatching { encryptedFile(context, normalizePlatform(platform), profileId).delete() }
            else -> {
                val normalized = normalizePlatform(platform)
                runCatching { legacyFile(context, normalized).delete() }
                File(context.noBackupFilesDir, "auth").listFiles()?.filter {
                    it.name.startsWith("cookies-$normalized-")
                }?.forEach { runCatching { it.delete() } }
            }
        }
        runCatching { File(context.cacheDir, "auth").deleteRecursively() }
    }

    fun profileSummary(context: Context): String {
        val profiles = AccountProfileStore(context).list().filter { hasCookies(context, it.platform, it.id) }
        val labels = profiles.map { "${label(it.platform)}: ${it.name}" }.toMutableList()
        PlatformPolicy.accountPlatforms
            .filter { legacyFile(context, it).isFile }
            .forEach { labels += label(it) }
        return labels.distinct().joinToString().ifBlank { AppText.get(R.string.none) }
    }

    private fun validate(text: String) {
        val first = text.removePrefix("\uFEFF").lineSequence().firstOrNull()?.trim().orEmpty()
        require(first == "# Netscape HTTP Cookie File" || first == "# HTTP Cookie File") {
            AppText.get(R.string.cookie_file_invalid_format)
        }
    }

    private fun encryptedFile(context: Context, platform: String, profileId: String): File =
        File(context.noBackupFilesDir, "auth/cookies-$platform-${sanitizeId(profileId)}.enc")

    private fun legacyFile(context: Context, platform: String): File =
        File(context.noBackupFilesDir, "auth/cookies-$platform.enc")

    private fun sanitizeId(value: String) = value.replace(Regex("[^A-Za-z0-9_-]"), "_").take(80)

    private fun normalizePlatform(value: String) = when (value.lowercase()) {
        PlatformPolicy.YOUTUBE, PlatformPolicy.INSTAGRAM, PlatformPolicy.FACEBOOK,
        PlatformPolicy.TIKTOK, PlatformPolicy.TWITTER, PlatformPolicy.THREADS,
        PlatformPolicy.BLUESKY, PlatformPolicy.MASTODON, PlatformPolicy.TELEGRAM -> value.lowercase()
        else -> PlatformPolicy.GENERIC
    }

    private fun label(platform: String) = when (platform) {
        PlatformPolicy.YOUTUBE -> "YouTube"
        PlatformPolicy.INSTAGRAM -> "Instagram"
        PlatformPolicy.FACEBOOK -> "Facebook"
        PlatformPolicy.TIKTOK -> "TikTok"
        PlatformPolicy.TWITTER -> "X"
        PlatformPolicy.THREADS -> "Threads"
        PlatformPolicy.BLUESKY -> "Bluesky"
        PlatformPolicy.MASTODON -> "Mastodon"
        PlatformPolicy.TELEGRAM -> "Telegram"
        else -> AppText.get(R.string.profile_generic)
    }

    private fun securePermissions(file: File) {
        file.setReadable(false, false); file.setWritable(false, false)
        file.setReadable(true, true); file.setWritable(true, true)
    }

    private fun java.io.InputStream.readBytesLimited(limit: Int): ByteArray {
        val output = java.io.ByteArrayOutputStream()
        val buffer = ByteArray(32 * 1024)
        var total = 0
        while (true) {
            val read = read(buffer)
            if (read < 0) break
            total += read
            require(total <= limit) { AppText.get(R.string.cookie_file_too_large) }
            output.write(buffer, 0, read)
        }
        return output.toByteArray()
    }
}
