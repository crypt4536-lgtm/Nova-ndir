package com.nova.downloader.data

import com.nova.downloader.i18n.AppText

import com.nova.downloader.R

import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import java.io.File
import java.util.zip.ZipInputStream

object CustomPetVault {
    private val allowedStates = setOf("idle", "downloading", "completed", "error")
    private val allowedExtensions = setOf("png", "webp", "gif")
    private const val MAX_BYTES = 12 * 1024 * 1024
    private const val MAX_DIMENSION = 2048

    fun import(context: Context, uri: Uri): Result<String> = runCatching {
        val name = queryName(context, uri).orEmpty()
        val root = directory(context)
        root.parentFile?.mkdirs()
        val staging = File(root.parentFile, "custom-pet-staging-${System.nanoTime()}").apply { mkdirs() }
        val backup = File(root.parentFile, "custom-pet-backup-${System.nanoTime()}")
        try {
            if (name.endsWith(".zip", true)) importZip(context, uri, staging) else importSingle(context, uri, name, staging)
            require(fileForStateIn(staging, "idle") != null) { AppText.get(R.string.pet_package_idle_missing) }
            staging.listFiles()?.filter(File::isFile)?.forEach(::validateDimensions)
            if (root.exists()) require(root.renameTo(backup)) { AppText.get(R.string.pet_package_backup_failed) }
            if (!staging.renameTo(root)) {
                if (backup.exists()) backup.renameTo(root)
                error(AppText.get(R.string.pet_package_activate_failed))
            }
            backup.deleteRecursively()
            AppSettings(context).apply {
                petType = AppSettings.PET_CUSTOM
                petCustomPackagePath = root.absolutePath
            }
            AppText.get(R.string.pet_package_installed)
        } catch (error: Exception) {
            if (!root.exists() && backup.exists()) backup.renameTo(root)
            throw error
        } finally {
            staging.deleteRecursively()
            if (backup.exists() && root.exists()) backup.deleteRecursively()
        }
    }

    fun fileForState(context: Context, state: String): File? {
        val safeState = state.takeIf { it in allowedStates } ?: "idle"
        val root = AppSettings(context).petCustomPackagePath?.let(::File) ?: directory(context)
        return fileForStateIn(root, safeState) ?: fileForStateIn(root, "idle")
    }

    fun clear(context: Context) {
        directory(context).deleteRecursively()
        AppSettings(context).petCustomPackagePath = null
    }

    private fun directory(context: Context) = File(context.noBackupFilesDir, "custom_pet")

    private fun importSingle(context: Context, uri: Uri, name: String, root: File) {
        val ext = name.substringAfterLast('.', "png").lowercase()
        require(ext in allowedExtensions) { AppText.get(R.string.pet_choose_supported_file) }
        val target = File(root, "idle.$ext")
        copyLimited(context, uri, target)
        listOf("downloading", "completed", "error").forEach { state -> target.copyTo(File(root, "$state.$ext"), overwrite = true) }
    }

    private fun importZip(context: Context, uri: Uri, root: File) {
        var total = 0L
        var entries = 0
        context.contentResolver.openInputStream(uri)?.use { input ->
            ZipInputStream(input.buffered()).use { zip ->
                while (true) {
                    val entry = zip.nextEntry ?: break
                    entries++
                    require(entries <= 40) { AppText.get(R.string.pet_package_too_many_files) }
                    if (!entry.isDirectory) {
                        val simple = File(entry.name).name.lowercase()
                        val state = simple.substringBeforeLast('.')
                        val ext = simple.substringAfterLast('.', "")
                        if (state in allowedStates && ext in allowedExtensions) {
                            val target = File(root, "$state.$ext")
                            target.outputStream().use { out ->
                                val buffer = ByteArray(32 * 1024)
                                while (true) {
                                    val n = zip.read(buffer)
                                    if (n < 0) break
                                    total += n
                                    require(total <= MAX_BYTES) { AppText.get(R.string.pet_package_too_large) }
                                    out.write(buffer, 0, n)
                                }
                            }
                        }
                    }
                    zip.closeEntry()
                }
            }
        } ?: error(AppText.get(R.string.pet_package_open_failed))
    }

    private fun copyLimited(context: Context, uri: Uri, target: File) {
        var total = 0L
        context.contentResolver.openInputStream(uri)?.use { input ->
            target.outputStream().use { out ->
                val buffer = ByteArray(32 * 1024)
                while (true) {
                    val n = input.read(buffer)
                    if (n < 0) break
                    total += n
                    require(total <= MAX_BYTES) { AppText.get(R.string.file_too_large_12mb) }
                    out.write(buffer, 0, n)
                }
            }
        } ?: error(AppText.get(R.string.file_open_failed))
    }

    private fun validateDimensions(file: File) {
        val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, options)
        require(options.outWidth in 1..MAX_DIMENSION && options.outHeight in 1..MAX_DIMENSION) {
            AppText.get(R.string.pet_image_invalid, file.name, MAX_DIMENSION)
        }
    }

    private fun fileForStateIn(root: File, state: String): File? = allowedExtensions.asSequence()
        .map { File(root, "$state.$it") }
        .firstOrNull(File::isFile)

    private fun queryName(context: Context, uri: Uri): String? = runCatching {
        context.contentResolver.query(
            uri,
            arrayOf(android.provider.OpenableColumns.DISPLAY_NAME),
            null,
            null,
            null
        )?.use { cursor -> if (cursor.moveToFirst()) cursor.getString(0) else null }
    }.getOrNull()
}
