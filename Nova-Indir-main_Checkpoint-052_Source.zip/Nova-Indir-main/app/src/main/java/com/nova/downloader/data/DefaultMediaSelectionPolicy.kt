package com.nova.downloader.data

import com.nova.downloader.core.YtDlpOptionBuilder

object DefaultMediaSelectionPolicy {
    fun apply(download: ResolvedDownload, settings: AppSettings): ResolvedDownload {
        val common = download.copy(
            duplicatePolicy = settings.defaultDuplicatePolicy,
            embedMetadata = settings.defaultEmbedMetadata,
            embedChapters = settings.defaultEmbedChapters,
            playlistMode = if (download.metadata.isPlaylist && settings.playlistDefaultAll) "all" else "single"
        )
        if (download.engine != DownloadEngine.YT_DLP) return common
        return if (settings.defaultOutputMode == YtDlpOptionBuilder.MODE_AUDIO) {
            val audio = YtDlpOptionBuilder.audioPreset(settings.defaultAudioFormat)
            common.copy(
                outputMode = YtDlpOptionBuilder.MODE_AUDIO,
                formatSelector = "bestaudio/best",
                mimeType = audio.mimeType,
                audioFormat = audio.id,
                videoContainer = null,
                title = replaceKnownMediaExtension(download.title, audio.extension)
            )
        } else {
            val container = settings.defaultVideoContainer
            val maxHeight = YtDlpOptionBuilder.qualityPresets
                .firstOrNull { it.id == settings.defaultQualityId }
                ?.maxHeight
            val actual = download.formats.filter { it.hasVideo }.let { formats ->
                if (maxHeight == null) formats.firstOrNull()
                else formats.filter { (it.height ?: Int.MAX_VALUE) <= maxHeight }
                    .maxByOrNull { it.height ?: 0 }
            }
            common.copy(
                outputMode = YtDlpOptionBuilder.MODE_VIDEO,
                formatSelector = actual?.selector
                    ?: YtDlpOptionBuilder.videoFormatSelector(settings.defaultQualityId, container),
                mimeType = YtDlpOptionBuilder.mimeForVideoContainer(container),
                audioFormat = null,
                videoContainer = container,
                qualityId = actual?.formatId ?: settings.defaultQualityId,
                title = replaceKnownMediaExtension(
                    download.title,
                    YtDlpOptionBuilder.suggestedVideoExtension(container)
                )
            )
        }
    }

    private fun replaceKnownMediaExtension(name: String, extension: String): String {
        val trimmed = name.trim()
        if (trimmed.isBlank()) return trimmed
        val known = Regex(
            "\\.(mp4|mkv|webm|m4v|mov|avi|3gp|mp3|m4a|aac|ogg|oga|opus|flac|wav|bin|download)$",
            RegexOption.IGNORE_CASE
        )
        return "${trimmed.replace(known, "")}.$extension"
    }
}
