package com.nova.downloader.data

object DownloadEngine {
    const val DIRECT = "direct"
    const val YT_DLP = "yt_dlp"
}
