package com.nova.downloader.data

import android.content.Context
import com.nova.downloader.diagnostics.LocalLog
import java.util.concurrent.atomic.AtomicBoolean

/** Starts pending downloads in the user-defined order while respecting the parallel limit. */
object DownloadQueueCoordinator {
    private val running = AtomicBoolean(false)

    fun kick(context: Context) {
        val app = context.applicationContext
        if (!running.compareAndSet(false, true)) return
        Thread {
            try {
                val history = HistoryStore(app)
                val settings = AppSettings(app)
                val schedule = ScheduleStore(app)
                val order = QueueOrderStore(app)
                val all = history.list()
                val active = all.count { it.status == DownloadState.RUNNING }
                var slots = (settings.maxParallelDownloads - active).coerceAtLeast(0)
                if (slots > 0) {
                    val pendingById = all
                        .filter { it.status == DownloadState.PENDING && schedule.isDue(it.downloadId) }
                        .associateBy { it.downloadId }
                    val ordered = order.ordered(pendingById.keys)
                    val repository = DownloadRepository(app)
                    for (id in ordered) {
                        if (slots <= 0) break
                        val item = pendingById[id] ?: continue
                        history.update(id) { it.copy(status = DownloadState.RUNNING, errorMessage = null) }
                        when (val result = repository.startStored(item.copy(status = DownloadState.RUNNING))) {
                            is DownloadRepository.EnqueueResult.Success -> {
                                LocalLog.info("DownloadQueue", "Service start accepted id=$id engine=${item.engine}")
                                slots--
                            }
                            is DownloadRepository.EnqueueResult.Error -> {
                                // startStored already persists FAILED + the real error. Never hide it by
                                // reverting to PENDING; doing so made the Download button appear inert.
                                LocalLog.error("DownloadQueue", "Service start rejected id=$id: ${result.message}")
                            }
                        }
                    }
                }
            } finally {
                running.set(false)
            }
        }.start()
    }
}
