package com.nova.downloader.data

import com.nova.downloader.i18n.AppText

import com.nova.downloader.R
import com.nova.downloader.diagnostics.LocalLog

import android.content.Context
import android.net.Uri
import android.os.Build
import com.nova.downloader.core.FileNameResolver
import com.nova.downloader.service.DownloadService
import com.nova.downloader.service.YtDlpDownloadService
import com.nova.downloader.worker.DownloadScheduleManager
import org.json.JSONObject
import java.util.concurrent.atomic.AtomicLong

class DownloadRepository(context: Context) {
    private val appContext = context.applicationContext
    private val historyStore = HistoryStore(appContext)
    fun resolve(rawUrl: String): LinkResolver.Result = MediaResolverClient.resolve(appContext, rawUrl)

    fun enqueue(
        download: ResolvedDownload,
        fileName: String,
        destinationTreeUri: String?,
        scheduledAt: Long? = null
    ): EnqueueResult {
        runCatching { StorageHelper.requireFreeSpace(appContext, download.contentLength, destinationTreeUri) }
            .exceptionOrNull()?.let { return EnqueueResult.Error(it.message ?: AppText.get(R.string.not_enough_space_generic)) }
        val now = System.currentTimeMillis()
        val downloadId = nextId.updateAndGet { current -> maxOf(current + 1L, now) }
        val finalName = FileNameResolver.ensureMediaExtension(
            requestedName = fileName,
            mimeType = download.mimeType,
            finalUrl = download.downloadUrl
        )
        val partialPath = if (download.engine == DownloadEngine.YT_DLP) {
            YtDlpDownloadService.jobDirectory(appContext, downloadId).absolutePath
        } else {
            StorageHelper.partialFile(appContext, downloadId).absolutePath
        }
        val headersJson = JSONObject(persistableHeaders(download.headers)).toString()
        val item = StoredDownload(
            downloadId = downloadId,
            url = download.sourceUrl,
            title = finalName,
            createdAt = now,
            status = DownloadState.PENDING,
            totalBytes = download.contentLength,
            destinationTreeUri = destinationTreeUri,
            mediaType = download.mimeType,
            downloadUrl = download.downloadUrl,
            referer = download.referer,
            headersJson = headersJson,
            partialFilePath = partialPath,
            engine = download.engine,
            formatSelector = download.formatSelector,
            outputMode = download.outputMode,
            audioFormat = download.audioFormat,
            videoContainer = download.videoContainer,
            qualityId = download.qualityId,
            audioLanguage = download.selectedAudioLanguage,
            subtitleLanguages = download.subtitleLanguages.joinToString(",").takeIf { it.isNotBlank() },
            writeSubtitles = download.writeSubtitles,
            writeAutoSubtitles = download.writeAutoSubtitles,
            writeThumbnail = download.writeThumbnail,
            writeDescription = download.writeDescription,
            embedMetadata = download.embedMetadata,
            embedChapters = download.embedChapters,
            playlistMode = download.playlistMode,
            liveFromStart = download.liveFromStart,
            duplicatePolicy = DuplicatePolicy.normalize(download.duplicatePolicy),
            resumeSupported = download.engine == DownloadEngine.YT_DLP
        )
        historyStore.add(item)
        QueueOrderStore(appContext).add(downloadId)
        if (scheduledAt != null && scheduledAt > System.currentTimeMillis()) {
            ScheduleStore(appContext).put(downloadId, scheduledAt)
            DownloadScheduleManager.schedule(appContext, downloadId, scheduledAt)
        } else {
            DownloadQueueCoordinator.kick(appContext)
        }
        return EnqueueResult.Success(item)
    }

    fun resume(downloadId: Long, refreshed: ResolvedDownload? = null): EnqueueResult {
        val old = historyStore.get(downloadId) ?: return EnqueueResult.Error(AppText.get(R.string.download_record_not_found))
        val effective = if (old.engine == DownloadEngine.YT_DLP) null else refreshed
        val downloadUrl = effective?.downloadUrl ?: old.downloadUrl
            ?: return EnqueueResult.Error(AppText.get(R.string.media_url_must_be_resolved))
        val headers = effective?.headers ?: parseHeaders(old.headersJson)
        val updated = old.copy(
            status = DownloadState.PENDING,
            errorMessage = null,
            reason = 0,
            downloadUrl = downloadUrl,
            referer = effective?.referer ?: old.referer,
            headersJson = JSONObject(persistableHeaders(headers)).toString(),
            mediaType = effective?.mimeType ?: old.mediaType,
            totalBytes = effective?.contentLength?.takeIf { it > 0L } ?: old.totalBytes,
            partialFilePath = old.partialFilePath ?: if (old.engine == DownloadEngine.YT_DLP) {
                YtDlpDownloadService.jobDirectory(appContext, old.downloadId).absolutePath
            } else {
                StorageHelper.partialFile(appContext, old.downloadId).absolutePath
            },
            retryCount = 0,
            resumeSupported = true
        )
        historyStore.add(updated)
        QueueOrderStore(appContext).add(downloadId)
        ScheduleStore(appContext).remove(downloadId)
        DownloadScheduleManager.cancel(appContext, downloadId)
        DownloadQueueCoordinator.kick(appContext)
        return EnqueueResult.Success(updated)
    }

    internal fun startStored(item: StoredDownload, runtimeHeaders: Map<String, String>? = null): EnqueueResult {
        return runCatching {
            val intent = if (item.engine == DownloadEngine.YT_DLP) {
                YtDlpDownloadService.startIntent(appContext, item)
            } else {
                val downloadUrl = item.downloadUrl ?: error(AppText.get(R.string.download_url_missing))
                DownloadService.startIntent(
                    context = appContext,
                    downloadId = item.downloadId,
                    sourceUrl = item.url,
                    downloadUrl = downloadUrl,
                    fileName = item.title,
                    mimeType = item.mediaType,
                    contentLength = item.totalBytes,
                    destinationTreeUri = item.destinationTreeUri,
                    referer = item.referer,
                    headers = runtimeHeaders ?: parseHeaders(item.headersJson),
                    partialFilePath = item.partialFilePath,
                    etag = item.etag,
                    lastModified = item.lastModified
                )
            }
            LocalLog.info("DownloadRepository", "Starting service id=${item.downloadId} engine=${item.engine}")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                appContext.startForegroundService(intent)
            } else {
                appContext.startService(intent)
            }
            EnqueueResult.Success(item)
        }.getOrElse { error ->
            LocalLog.error("DownloadRepository", "Could not start service id=${item.downloadId} engine=${item.engine}", error)
            historyStore.update(item.downloadId) {
                it.copy(status = DownloadState.FAILED, errorMessage = error.message)
            }
            EnqueueResult.Error(error.message ?: AppText.get(R.string.download_could_not_start))
        }
    }

    fun startNow(downloadId: Long): EnqueueResult {
        val item = historyStore.get(downloadId) ?: return EnqueueResult.Error(AppText.get(R.string.download_record_not_found))
        ScheduleStore(appContext).remove(downloadId)
        DownloadScheduleManager.cancel(appContext, downloadId)
        historyStore.update(downloadId) { it.copy(status = DownloadState.PENDING, errorMessage = null) }
        QueueOrderStore(appContext).add(downloadId)
        DownloadQueueCoordinator.kick(appContext)
        return EnqueueResult.Success(item.copy(status = DownloadState.PENDING))
    }

    fun schedule(downloadId: Long, timeMillis: Long): EnqueueResult {
        val item = historyStore.get(downloadId) ?: return EnqueueResult.Error(AppText.get(R.string.download_record_not_found))
        if (item.status == DownloadState.RUNNING) pause(downloadId)
        historyStore.update(downloadId) { it.copy(status = DownloadState.PENDING, errorMessage = null) }
        ScheduleStore(appContext).put(downloadId, timeMillis)
        QueueOrderStore(appContext).add(downloadId)
        DownloadScheduleManager.schedule(appContext, downloadId, timeMillis)
        return EnqueueResult.Success(item.copy(status = DownloadState.PENDING))
    }

    fun scheduledAt(downloadId: Long): Long? = ScheduleStore(appContext).get(downloadId)

    fun snapshots(): List<DownloadSnapshot> = historyStore.list().map(::DownloadSnapshot)

    fun pause(downloadId: Long) {
        val item = historyStore.get(downloadId) ?: return
        val intent = if (item.engine == DownloadEngine.YT_DLP) {
            YtDlpDownloadService.pauseIntent(appContext, downloadId)
        } else {
            DownloadService.pauseIntent(appContext, downloadId)
        }
        appContext.startService(intent)
        historyStore.update(downloadId) { it.copy(status = DownloadState.PAUSED, errorMessage = null) }
        DownloadQueueCoordinator.kick(appContext)
    }

    fun cancel(downloadId: Long) {
        val item = historyStore.get(downloadId) ?: return
        val active = if (item.engine == DownloadEngine.YT_DLP) {
            YtDlpDownloadService.isActive(downloadId)
        } else {
            DownloadService.isActive(downloadId)
        }
        val intent = if (item.engine == DownloadEngine.YT_DLP) {
            YtDlpDownloadService.cancelIntent(appContext, downloadId)
        } else {
            DownloadService.cancelIntent(appContext, downloadId)
        }
        appContext.startService(intent)
        if (!active) StorageHelper.deletePartial(appContext, item)
        historyStore.update(downloadId) {
            it.copy(
                status = DownloadState.CANCELLED,
                bytesDownloaded = if (active) it.bytesDownloaded else 0L,
                partialFilePath = if (active) it.partialFilePath else null,
                resumeSupported = false,
                errorMessage = if (active) AppText.get(R.string.cancel_waiting_for_process)
                    else AppText.get(R.string.cancelled_partial_removed)
            )
        }
        ScheduleStore(appContext).remove(downloadId)
        DownloadScheduleManager.cancel(appContext, downloadId)
        QueueOrderStore(appContext).remove(downloadId)
        DownloadQueueCoordinator.kick(appContext)
    }

    fun discard(downloadId: Long) {
        historyStore.get(downloadId)?.let { StorageHelper.deletePartial(appContext, it) }
        ScheduleStore(appContext).remove(downloadId)
        DownloadScheduleManager.cancel(appContext, downloadId)
        QueueOrderStore(appContext).remove(downloadId)
        historyStore.remove(downloadId)
    }

    fun removeHistory(downloadId: Long) = discard(downloadId)

    fun clearHistory() {
        historyStore.list().forEach { item ->
            if (item.status != DownloadState.SUCCESSFUL) StorageHelper.deletePartial(appContext, item)
        }
        historyStore.list().forEach {
            ScheduleStore(appContext).remove(it.downloadId)
            DownloadScheduleManager.cancel(appContext, it.downloadId)
        }
        QueueOrderStore(appContext).replace(emptyList())
        historyStore.clear()
    }


    fun clearCompletedRecords(): Int {
        val completed = historyStore.list().filter { it.status == DownloadState.SUCCESSFUL }
        completed.forEach { historyStore.remove(it.downloadId) }
        return completed.size
    }

    fun clearIncompleteRecords(): Int {
        val targets = historyStore.list().filter { it.status != DownloadState.SUCCESSFUL }
        targets.forEach { item ->
            if (item.status == DownloadState.RUNNING || item.status == DownloadState.PENDING) cancel(item.downloadId)
            StorageHelper.deletePartial(appContext, item)
            historyStore.remove(item.downloadId)
        }
        return targets.size
    }

    data class BulkRelocateResult(val moved: Int, val failed: Int, val errors: List<String>)

    fun relocateCompleted(destinationTreeUri: String): BulkRelocateResult {
        var moved = 0
        val errors = mutableListOf<String>()
        historyStore.list().filter { it.status == DownloadState.SUCCESSFUL && !it.outputUri.isNullOrBlank() }.forEach { item ->
            runCatching {
                val result = StorageHelper.relocateOutput(appContext, item, destinationTreeUri, item.duplicatePolicy)
                historyStore.update(item.downloadId) { current ->
                    current.copy(
                        title = result.displayName,
                        outputUri = result.uri.toString(),
                        destinationTreeUri = destinationTreeUri,
                        checksumSha256 = result.checksumSha256,
                        integrityVerified = true
                    )
                }
            }.onSuccess { moved++ }.onFailure { errors += it.message?.let { message -> "${item.title}: $message" } ?: AppText.get(R.string.item_move_failed, item.title) }
        }
        return BulkRelocateResult(moved, errors.size, errors.take(8))
    }


    sealed interface RenameResult {
        data class Success(val item: StoredDownload) : RenameResult
        data class Error(val message: String) : RenameResult
    }

    fun renameCompleted(downloadId: Long, requestedName: String): RenameResult {
        val item = historyStore.get(downloadId)
            ?: return RenameResult.Error(AppText.get(R.string.download_record_not_found))
        if (item.status != DownloadState.SUCCESSFUL || item.outputUri.isNullOrBlank()) {
            return RenameResult.Error(AppText.get(R.string.only_completed_renameable))
        }
        return runCatching {
            val result = StorageHelper.renameOutput(appContext, item, requestedName)
            historyStore.update(downloadId) { current ->
                current.copy(title = result.displayName, outputUri = result.uri.toString())
            }
            RenameResult.Success(historyStore.get(downloadId) ?: item.copy(
                title = result.displayName, outputUri = result.uri.toString()
            ))
        }.getOrElse { error ->
            RenameResult.Error(error.message ?: AppText.get(R.string.file_rename_failed))
        }
    }

    /** Synchronizes names changed by the system file manager when the content URI remains valid. */
    fun synchronizeCompletedOutputMetadata(): Int {
        var updated = 0
        historyStore.list()
            .filter { it.status == DownloadState.SUCCESSFUL && !it.outputUri.isNullOrBlank() }
            .forEach { item ->
                val info = StorageHelper.inspectOutput(appContext, item) ?: return@forEach
                if (info.displayName != item.title || info.mimeType != item.mediaType) {
                    historyStore.update(item.downloadId) { current ->
                        current.copy(
                            title = info.displayName,
                            outputUri = info.uri.toString(),
                            mediaType = info.mimeType ?: current.mediaType
                        )
                    }
                    updated++
                }
            }
        return updated
    }

    fun markInterruptedAsPaused() {
        historyStore.list()
            .filter { item ->
                (item.status == DownloadState.RUNNING || item.status == DownloadState.PENDING) &&
                    if (item.engine == DownloadEngine.YT_DLP) {
                        !YtDlpDownloadService.isActive(item.downloadId)
                    } else {
                        !DownloadService.isActive(item.downloadId)
                    }
            }
            .forEach { item ->
                val partialBytes = if (item.engine == DownloadEngine.YT_DLP) {
                    YtDlpDownloadService.jobBytes(appContext, item.downloadId, item.partialFilePath)
                } else {
                    StorageHelper.partialFile(appContext, item.downloadId, item.partialFilePath).length()
                }
                historyStore.update(item.downloadId) {
                    it.copy(
                        status = DownloadState.PAUSED,
                        bytesDownloaded = maxOf(it.bytesDownloaded, partialBytes),
                        errorMessage = AppText.get(R.string.download_interrupted_can_resume),
                        resumeSupported = true
                    )
                }
            }
    }

    fun item(downloadId: Long): StoredDownload? = historyStore.get(downloadId)
    fun latestCompleted(): StoredDownload? = historyStore.latestCompleted()
    fun completedUri(downloadId: Long): Uri? = item(downloadId)?.outputUri?.let { Uri.parse(it) }
    fun mimeType(downloadId: Long): String? = item(downloadId)?.mediaType

    private fun persistableHeaders(headers: Map<String, String>): Map<String, String> =
        headers.filterKeys { name ->
            name.lowercase() !in setOf("cookie", "set-cookie", "authorization", "proxy-authorization")
        }

    private fun parseHeaders(raw: String?): Map<String, String> {
        if (raw.isNullOrBlank()) return emptyMap()
        return runCatching {
            val json = JSONObject(raw)
            buildMap {
                val keys = json.keys()
                while (keys.hasNext()) {
                    val key = keys.next()
                    json.optString(key).takeIf { it.isNotBlank() }?.let { put(key, it) }
                }
            }
        }.getOrDefault(emptyMap())
    }

    sealed class EnqueueResult {
        data class Success(val item: StoredDownload) : EnqueueResult()
        data class Error(val message: String) : EnqueueResult()
    }

    companion object {
        private val nextId = AtomicLong(System.currentTimeMillis())
    }
}
