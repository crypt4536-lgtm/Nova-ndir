package com.nova.downloader.data

data class DownloadSnapshot(
    val stored: StoredDownload,
    val status: Int = stored.status,
    val reason: Int = stored.reason,
    val bytesDownloaded: Long = stored.bytesDownloaded,
    val totalBytes: Long = stored.totalBytes,
    val localUri: String? = stored.outputUri,
    val mediaType: String? = stored.mediaType
) {
    val progressPercent: Int?
        get() = when {
            stored.engine == DownloadEngine.YT_DLP && reason in 0..100 &&
                status in setOf(DownloadState.PENDING, DownloadState.RUNNING, DownloadState.PAUSED) -> reason
            totalBytes > 0L -> ((bytesDownloaded * 100L) / totalBytes)
                .coerceIn(0L, 100L)
                .toInt()
            else -> null
        }
}
