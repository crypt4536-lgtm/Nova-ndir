package com.nova.downloader.data

object DownloadState {
    const val PENDING = 1
    const val RUNNING = 2
    const val PAUSED = 4
    const val SUCCESSFUL = 8
    const val FAILED = 16
    const val CANCELLED = 1000
    const val INVALID_CONTENT = 1001
}
