package com.nova.downloader.data

object DuplicatePolicy {
    const val RENAME = "rename"
    const val REPLACE = "replace"
    const val SKIP = "skip"

    fun normalize(value: String?): String = when (value?.lowercase()) {
        REPLACE -> REPLACE
        SKIP -> SKIP
        else -> RENAME
    }
}
