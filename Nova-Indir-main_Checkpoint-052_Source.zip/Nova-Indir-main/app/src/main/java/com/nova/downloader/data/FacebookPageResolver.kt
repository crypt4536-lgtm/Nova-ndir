package com.nova.downloader.data

import com.nova.downloader.i18n.AppText

import com.nova.downloader.R

import com.nova.downloader.core.FacebookUrlExtractor
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URI

/** Resolves Facebook short share aliases without sending data to a third-party service. */
class FacebookPageResolver {
    data class Resolution(val candidates: List<String>, val note: String)

    fun resolve(sourceUrl: String): Resolution {
        if (!FacebookUrlExtractor.isShareAlias(sourceUrl)) {
            return Resolution(listOf(sourceUrl), "")
        }

        val candidates = linkedSetOf<String>()
        candidates += sourceUrl

        USER_AGENTS.forEach { userAgent ->
            resolveWithUserAgent(sourceUrl, userAgent).forEach(candidates::add)
        }

        val expanded = FacebookUrlExtractor.expandCandidates(candidates, sourceUrl)
        val realCandidates = expanded.filterNot { it == sourceUrl }
        val note = if (realCandidates.isEmpty()) {
            AppText.get(R.string.facebook_short_not_resolved)
        } else {
            AppText.get(R.string.facebook_candidates_extracted, realCandidates.size)
        }
        return Resolution((listOf(sourceUrl) + realCandidates).distinct(), note)
    }

    private fun resolveWithUserAgent(sourceUrl: String, userAgent: String): List<String> {
        val found = linkedSetOf<String>()
        val cookies = linkedMapOf<String, String>()
        var current = sourceUrl

        repeat(MAX_REDIRECTS + 1) { hop ->
            val connection = runCatching {
                (URI(current).toURL().openConnection() as HttpURLConnection).apply {
                    instanceFollowRedirects = false
                    requestMethod = "GET"
                    connectTimeout = CONNECT_TIMEOUT_MS
                    readTimeout = READ_TIMEOUT_MS
                    setRequestProperty("User-Agent", userAgent)
                    setRequestProperty("Accept-Language", "tr-TR,tr;q=0.9,en-US;q=0.7,en;q=0.6")
                    setRequestProperty("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
                    setRequestProperty("Accept-Encoding", "identity")
                    if (cookies.isNotEmpty()) {
                        setRequestProperty("Cookie", cookies.entries.joinToString("; ") { "${it.key}=${it.value}" })
                    }
                }
            }.getOrNull() ?: return found.toList()

            try {
                rememberCookies(connection, cookies)
                val code = connection.responseCode
                if (code in 300..399) {
                    if (hop >= MAX_REDIRECTS) return found.toList()
                    val location = connection.getHeaderField("Location") ?: return found.toList()
                    val redirected = runCatching {
                        URI(current).resolve(location).normalize().toASCIIString()
                    }.getOrNull() ?: return found.toList()
                    FacebookUrlExtractor.expandCandidates(listOf(redirected), current).forEach(found::add)
                    if (!redirected.startsWith("https://", ignoreCase = true) ||
                        !FacebookUrlExtractor.isFacebookUrl(redirected)
                    ) return found.toList()
                    current = redirected
                    return@repeat
                }

                if (code !in 200..299) return found.toList()
                found += current
                val body = connection.inputStream.use { input ->
                    val output = ByteArrayOutputStream()
                    val buffer = ByteArray(16 * 1024)
                    var total = 0
                    while (total < MAX_HTML_BYTES) {
                        val count = input.read(buffer)
                        if (count <= 0) break
                        val accepted = count.coerceAtMost(MAX_HTML_BYTES - total)
                        output.write(buffer, 0, accepted)
                        total += accepted
                    }
                    output.toString(Charsets.UTF_8.name())
                }
                FacebookUrlExtractor.extractCandidates(body, current).forEach(found::add)
                return found.toList()
            } catch (_: Exception) {
                return found.toList()
            } finally {
                connection.disconnect()
            }
        }
        return found.toList()
    }

    private fun rememberCookies(
        connection: HttpURLConnection,
        cookies: MutableMap<String, String>
    ) {
        connection.headerFields
            .filterKeys { it?.equals("Set-Cookie", ignoreCase = true) == true }
            .values
            .flatten()
            .forEach { header ->
                val first = header.substringBefore(';')
                val separator = first.indexOf('=')
                if (separator > 0) cookies[first.substring(0, separator)] = first.substring(separator + 1)
            }
    }

    companion object {
        private const val MAX_REDIRECTS = 8
        private const val CONNECT_TIMEOUT_MS = 8_000
        private const val READ_TIMEOUT_MS = 10_000
        private const val MAX_HTML_BYTES = 2 * 1024 * 1024

        private val USER_AGENTS = listOf(
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 " +
                "(KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36",
            "Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) " +
                "AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1",
            "facebookexternalhit/1.1"
        )
    }
}
