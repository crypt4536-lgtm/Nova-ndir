package com.nova.downloader.data

import android.content.Context
import com.nova.downloader.data.db.DownloadEntity
import com.nova.downloader.data.db.NovaDatabase
import org.json.JSONArray
import org.json.JSONObject

/** Room-backed persistent queue/history with one-time migration from the legacy JSON store. */
class HistoryStore(context: Context) {
    private val appContext = context.applicationContext
    private val dao = NovaDatabase.get(appContext).downloads()
    private val legacyPrefs = appContext.getSharedPreferences(LEGACY_PREFS_NAME, Context.MODE_PRIVATE)

    init { migrateLegacyOnce() }

    fun list(): List<StoredDownload> = synchronized(LOCK) { dao.list(MAX_ITEMS).map { it.toStored() } }
    fun get(downloadId: Long): StoredDownload? = synchronized(LOCK) { dao.get(downloadId)?.toStored() }

    fun latestCompleted(): StoredDownload? = list()
        .filter { it.status == DownloadState.SUCCESSFUL && !it.outputUri.isNullOrBlank() }
        .maxByOrNull { it.updatedAt }

    fun latestActive(): StoredDownload? = list()
        .filter { it.status == DownloadState.PENDING || it.status == DownloadState.RUNNING }
        .maxByOrNull { it.updatedAt }

    fun add(item: StoredDownload) = synchronized(LOCK) {
        dao.upsert(DownloadEntity.from(item))
        dao.trim(MAX_ITEMS)
    }

    fun update(downloadId: Long, transform: (StoredDownload) -> StoredDownload) = synchronized(LOCK) {
        dao.get(downloadId)?.toStored()?.let { old ->
            dao.upsert(DownloadEntity.from(transform(old).copy(updatedAt = System.currentTimeMillis())))
        }
    }

    fun remove(downloadId: Long) = synchronized(LOCK) { dao.delete(downloadId) }
    fun clear() = synchronized(LOCK) { dao.clear() }

    private fun migrateLegacyOnce() {
        synchronized(LOCK) {
        if (legacyPrefs.getBoolean(KEY_MIGRATED, false)) return@synchronized
        val raw = legacyPrefs.getString(KEY_ITEMS, null)
        val migrated = raw?.let(::parseLegacy).orEmpty()
        if (migrated.isNotEmpty()) dao.upsertAll(migrated.map(DownloadEntity::from))
        legacyPrefs.edit().remove(KEY_ITEMS).putBoolean(KEY_MIGRATED, true).commit()
        }
    }

    private fun parseLegacy(raw: String): List<StoredDownload> = runCatching {
        val array = JSONArray(raw)
        buildList {
            for (index in 0 until array.length()) {
                val item = array.optJSONObject(index) ?: continue
                val createdAt = item.optLong("createdAt", System.currentTimeMillis())
                add(
                    StoredDownload(
                        downloadId = item.getLong("downloadId"),
                        url = item.optString("url"),
                        title = item.optString("title", "nova_download"),
                        createdAt = createdAt,
                        status = item.optInt("status", migrateLegacyStatus(item)),
                        reason = item.optInt("reason", 0),
                        bytesDownloaded = item.optLong("bytesDownloaded", 0L),
                        totalBytes = item.optLong("totalBytes", -1L),
                        outputUri = item.optString("outputUri").takeIf(String::isNotBlank),
                        destinationTreeUri = item.optString("destinationTreeUri").takeIf(String::isNotBlank),
                        mediaType = item.optString("mediaType").takeIf(String::isNotBlank),
                        errorMessage = item.optString("errorMessage").takeIf(String::isNotBlank),
                        updatedAt = item.optLong("updatedAt", createdAt),
                        downloadUrl = item.optString("downloadUrl").takeIf(String::isNotBlank),
                        referer = item.optString("referer").takeIf(String::isNotBlank),
                        headersJson = item.optString("headersJson").takeIf(String::isNotBlank),
                        partialFilePath = item.optString("partialFilePath").takeIf(String::isNotBlank),
                        etag = item.optString("etag").takeIf(String::isNotBlank),
                        lastModified = item.optString("lastModified").takeIf(String::isNotBlank),
                        resumeSupported = item.optBoolean("resumeSupported", false),
                        retryCount = item.optInt("retryCount", 0),
                        engine = item.optString("engine", DownloadEngine.DIRECT),
                        formatSelector = item.optString("formatSelector").takeIf(String::isNotBlank),
                        outputMode = item.optString("outputMode", "video"),
                        audioFormat = item.optString("audioFormat").takeIf(String::isNotBlank),
                        videoContainer = item.optString("videoContainer", "mp4").takeIf(String::isNotBlank),
                        qualityId = item.optString("qualityId", "best").takeIf(String::isNotBlank),
                        duplicatePolicy = DuplicatePolicy.normalize(item.optString("duplicatePolicy"))
                    )
                )
            }
        }
    }.getOrDefault(emptyList())

    private fun migrateLegacyStatus(item: JSONObject): Int = when (item.optString("stateOverride")) {
        "cancelled" -> DownloadState.CANCELLED
        else -> DownloadState.FAILED
    }

    companion object {
        private val LOCK = Any()
        private const val LEGACY_PREFS_NAME = "nova_downloader_history"
        private const val KEY_ITEMS = "items"
        private const val KEY_MIGRATED = "room_migrated_v1"
        private const val MAX_ITEMS = 500
    }
}
