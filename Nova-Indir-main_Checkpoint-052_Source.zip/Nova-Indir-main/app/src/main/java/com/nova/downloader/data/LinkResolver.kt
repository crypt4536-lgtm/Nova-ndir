package com.nova.downloader.data

import com.nova.downloader.i18n.AppText

import com.nova.downloader.R

import android.content.Context
import com.nova.downloader.core.FileNameResolver
import com.nova.downloader.core.HtmlMediaExtractor
import com.nova.downloader.core.MediaTypePolicy
import com.nova.downloader.core.SitePagePolicy
import com.nova.downloader.core.UrlPolicy
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URI

class LinkResolver(context: Context) {
    private val extractorResolver = YtDlpMediaResolver(context)

    fun resolve(rawUrl: String): Result {
        val validated = UrlPolicy.validate(rawUrl)
        if (validated is UrlPolicy.Result.Invalid) return Result.Error(validated.message)
        val sourceUrl = (validated as UrlPolicy.Result.Valid).normalizedUrl

        var extractorMessage: String? = null
        val preferredExtractor = SitePagePolicy.shouldUseExtractor(sourceUrl)
        if (preferredExtractor) {
            when (val extracted = extractorResolver.resolve(sourceUrl)) {
                is YtDlpMediaResolver.Result.Ready -> return Result.Ready(extracted.download)
                is YtDlpMediaResolver.Result.Unsupported -> extractorMessage = extracted.message
                is YtDlpMediaResolver.Result.Error -> extractorMessage = extracted.message
            }
        }

        val first = fetch(sourceUrl, referer = null, readHtml = true)
        if (first is FetchResult.Error) {
            return if (extractorMessage != null) Result.Unsupported(extractorMessage)
            else Result.Error(first.message)
        }
        first as FetchResult.Success

        directResult(sourceUrl, first, referer = null)?.let { return it }

        if (MediaTypePolicy.isPlaylist(first.mimeType, first.finalUrl)) {
            val baseName = FileNameResolver.fromUrl(first.finalUrl)
            val title = FileNameResolver.ensureMediaExtension(baseName, "video/mp4")
            return Result.Ready(
                ResolvedDownload(
                    sourceUrl = sourceUrl,
                    downloadUrl = first.finalUrl,
                    title = title,
                    mimeType = "video/mp4",
                    contentLength = -1L,
                    referer = sourceUrl,
                    engine = DownloadEngine.YT_DLP,
                    formatSelector = com.nova.downloader.core.YtDlpOptionBuilder.videoFormatSelector("best", "mp4"),
                    outputMode = com.nova.downloader.core.YtDlpOptionBuilder.MODE_VIDEO,
                    videoContainer = "mp4",
                    qualityId = "best"
                )
            )
        }

        val bodyLooksHtml = first.body?.let(::looksLikeHtml) == true
        if (!MediaTypePolicy.isHtml(first.mimeType) && !bodyLooksHtml) {
            return Result.Unsupported(
                AppText.get(R.string.server_unsupported_mime, first.mimeType ?: AppText.get(R.string.undefined_file_type))
            )
        }

        val html = first.body
        if (html != null) {
            val candidates = HtmlMediaExtractor.extract(html, first.finalUrl)
            for (candidate in candidates) {
                val fetched = fetch(candidate, referer = first.finalUrl, readHtml = false)
                if (fetched is FetchResult.Success) {
                    directResult(sourceUrl, fetched, referer = first.finalUrl)?.let { return it }
                }
            }
        }

        if (!preferredExtractor) {
            when (val extracted = extractorResolver.resolve(sourceUrl)) {
                is YtDlpMediaResolver.Result.Ready -> return Result.Ready(extracted.download)
                is YtDlpMediaResolver.Result.Unsupported -> extractorMessage = extracted.message
                is YtDlpMediaResolver.Result.Error -> extractorMessage = extracted.message
            }
        }

        return Result.Unsupported(
            extractorMessage
                ?: AppText.get(R.string.page_media_unresolved)
        )
    }

    private fun directResult(
        sourceUrl: String,
        fetched: FetchResult.Success,
        referer: String?
    ): Result.Ready? {
        val fallback = FileNameResolver.fromUrl(fetched.finalUrl)
        if (fetched.body?.let(::looksLikeHtml) == true) return null
        var title = FileNameResolver.fromContentDisposition(fetched.contentDisposition, fallback)
        if (
            !MediaTypePolicy.isDirectMedia(fetched.mimeType, title) &&
            !MediaTypePolicy.isDirectMedia(fetched.mimeType, fallback)
        ) return null

        if (!MediaTypePolicy.hasMediaExtension(title)) {
            MediaTypePolicy.extensionForMimeType(fetched.mimeType)?.let { extension ->
                val stem = if (title.endsWith(".bin", ignoreCase = true)) title.dropLast(4) else title
                title = "$stem.$extension"
            }
        }

        return Result.Ready(
            ResolvedDownload(
                sourceUrl = sourceUrl,
                downloadUrl = fetched.finalUrl,
                title = title,
                mimeType = MediaTypePolicy.normalizedMimeType(fetched.mimeType),
                contentLength = fetched.contentLength,
                referer = referer
            )
        )
    }

    private fun fetch(url: String, referer: String?, readHtml: Boolean): FetchResult {
        var current = url
        repeat(MAX_REDIRECTS + 1) { hop ->
            val connection = runCatching {
                (URI(current).toURL().openConnection() as HttpURLConnection).apply {
                    instanceFollowRedirects = false
                    connectTimeout = CONNECT_TIMEOUT_MS
                    readTimeout = READ_TIMEOUT_MS
                    requestMethod = "GET"
                    setRequestProperty("User-Agent", USER_AGENT)
                    setRequestProperty("Accept-Language", "tr-TR,tr;q=0.9,en-US;q=0.7,en;q=0.6")
                    setRequestProperty("Accept", "video/*,audio/*,application/octet-stream,text/html;q=0.9,*/*;q=0.5")
                    setRequestProperty("Accept-Encoding", "identity")
                    if (!referer.isNullOrBlank()) setRequestProperty("Referer", referer)
                }
            }.getOrElse { return FetchResult.Error(it.message ?: AppText.get(R.string.link_open_failed)) }

            try {
                val code = connection.responseCode
                if (code in 300..399) {
                    if (hop >= MAX_REDIRECTS) return FetchResult.Error(AppText.get(R.string.link_too_many_redirects))
                    val location = connection.getHeaderField("Location")
                        ?: return FetchResult.Error(AppText.get(R.string.link_invalid_redirect))
                    val redirected = runCatching { URI(current).resolve(location).toASCIIString() }.getOrNull()
                        ?: return FetchResult.Error(AppText.get(R.string.link_redirect_unresolved))
                    val validation = UrlPolicy.validate(redirected)
                    if (validation is UrlPolicy.Result.Invalid) return FetchResult.Error(validation.message)
                    current = (validation as UrlPolicy.Result.Valid).normalizedUrl
                    return@repeat
                }

                if (code !in 200..299 && code != HttpURLConnection.HTTP_PARTIAL) {
                    return FetchResult.Error(AppText.get(R.string.link_server_http_error, code))
                }

                val mime = connection.contentType
                val body = if (
                    readHtml && (MediaTypePolicy.isHtml(mime) || mime.isNullOrBlank())
                ) {
                    connection.inputStream.use { input ->
                        val output = ByteArrayOutputStream()
                        val buffer = ByteArray(32 * 1024)
                        var total = 0
                        while (true) {
                            val count = input.read(buffer)
                            if (count <= 0) break
                            val remaining = MAX_HTML_BYTES - total
                            if (remaining <= 0) break
                            val accepted = count.coerceAtMost(remaining)
                            output.write(buffer, 0, accepted)
                            total += accepted
                            if (total >= MAX_HTML_BYTES) break
                        }
                        output.toString(Charsets.UTF_8.name())
                    }
                } else null

                return FetchResult.Success(
                    finalUrl = current,
                    mimeType = mime,
                    contentDisposition = connection.getHeaderField("Content-Disposition"),
                    contentLength = connection.getHeaderFieldLong("Content-Length", -1L),
                    body = body
                )
            } catch (error: Exception) {
                return FetchResult.Error(error.message ?: AppText.get(R.string.link_check_failed))
            } finally {
                connection.disconnect()
            }
        }
        return FetchResult.Error(AppText.get(R.string.link_unresolved))
    }

    private fun looksLikeHtml(body: String): Boolean {
        val prefix = body.trimStart().take(512).lowercase()
        return prefix.startsWith("<!doctype html") ||
            prefix.startsWith("<html") ||
            "<head" in prefix ||
            "<body" in prefix
    }

    sealed class Result {
        data class Ready(val download: ResolvedDownload) : Result()
        data class Unsupported(val message: String) : Result()
        data class Error(val message: String) : Result()
    }

    private sealed class FetchResult {
        data class Success(
            val finalUrl: String,
            val mimeType: String?,
            val contentDisposition: String?,
            val contentLength: Long,
            val body: String?
        ) : FetchResult()

        data class Error(val message: String) : FetchResult()
    }

    companion object {
        private const val MAX_REDIRECTS = 8
        private const val CONNECT_TIMEOUT_MS = 15_000
        private const val READ_TIMEOUT_MS = 25_000
        private const val MAX_HTML_BYTES = 8 * 1024 * 1024
        private const val USER_AGENT =
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 " +
                "(KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36"
    }
}
