package com.nova.downloader.data

data class MediaFormatOption(
    val formatId: String,
    val selector: String,
    val label: String,
    val extension: String?,
    val mimeType: String?,
    val width: Int?,
    val height: Int?,
    val fps: Double?,
    val videoCodec: String?,
    val audioCodec: String?,
    val audioLanguage: String?,
    val fileSize: Long?,
    val dynamicRange: String?,
    val protocol: String?,
    val hasVideo: Boolean,
    val hasAudio: Boolean
)
