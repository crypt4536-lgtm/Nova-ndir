package com.nova.downloader.data

data class MediaMetadata(
    val extractor: String? = null,
    val description: String? = null,
    val thumbnailUrl: String? = null,
    val durationSeconds: Long? = null,
    val isLive: Boolean = false,
    val liveStatus: String? = null,
    val isPlaylist: Boolean = false,
    val playlistCount: Int = 0,
    val audioLanguages: List<String> = emptyList(),
    val subtitleLanguages: List<String> = emptyList(),
    val automaticSubtitleLanguages: List<String> = emptyList(),
    val chapterCount: Int = 0
)
