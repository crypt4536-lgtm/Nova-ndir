package com.nova.downloader.data

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.Message
import android.os.Messenger
import com.nova.downloader.R
import com.nova.downloader.diagnostics.LocalLog
import com.nova.downloader.i18n.AppText
import com.nova.downloader.service.MediaResolverService
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicReference

object MediaResolverClient {
    fun resolve(context: Context, url: String): LinkResolver.Result {
        val app = context.applicationContext
        val latch = CountDownLatch(1)
        val result = AtomicReference<LinkResolver.Result>()
        val reply = Messenger(object : Handler(Looper.getMainLooper()) {
            override fun handleMessage(message: Message) {
                if (message.what != MediaResolverService.MSG_RESULT) return
                result.set(decode(message.data))
                latch.countDown()
            }
        })
        lateinit var connection: ServiceConnection
        connection = object : ServiceConnection {
            override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
                runCatching {
                    val remoteBinder = binder ?: error(AppText.get(R.string.media_resolver_connection_failed))
                    Messenger(remoteBinder).send(Message.obtain(null, MediaResolverService.MSG_RESOLVE).apply {
                        replyTo = reply
                        data = Bundle().apply { putString(MediaResolverService.KEY_URL, url) }
                    })
                }.onFailure {
                    result.set(LinkResolver.Result.Error(it.message ?: AppText.get(R.string.media_resolver_connection_failed)))
                    latch.countDown()
                }
            }
            override fun onServiceDisconnected(name: ComponentName?) {
                if (result.get() == null) {
                    result.set(LinkResolver.Result.Error(AppText.get(R.string.media_resolver_disconnected)))
                    latch.countDown()
                }
            }
        }
        if (!app.bindService(Intent(app, MediaResolverService::class.java), connection, Context.BIND_AUTO_CREATE)) {
            return LinkResolver.Result.Error(AppText.get(R.string.media_resolver_connection_failed))
        }
        return try {
            if (!latch.await(RESOLVE_TIMEOUT_SECONDS, TimeUnit.SECONDS)) {
                LinkResolver.Result.Error(AppText.get(R.string.media_resolver_timeout))
            } else result.get() ?: LinkResolver.Result.Error(AppText.get(R.string.media_resolver_no_result))
        } catch (_: InterruptedException) {
            Thread.currentThread().interrupt()
            LinkResolver.Result.Error(AppText.get(R.string.media_resolver_interrupted))
        } finally {
            runCatching { app.unbindService(connection) }.onFailure { LocalLog.debug("ResolverClient", "Service already unbound") }
        }
    }

    private fun decode(data: Bundle): LinkResolver.Result = when (data.getString(MediaResolverService.KEY_TYPE)) {
        MediaResolverService.TYPE_READY -> runCatching {
            LinkResolver.Result.Ready(ResolvedDownloadCodec.decode(data.getString(MediaResolverService.KEY_PAYLOAD).orEmpty()))
        }.getOrElse { LinkResolver.Result.Error(it.message ?: AppText.get(R.string.media_resolver_decode_failed)) }
        MediaResolverService.TYPE_UNSUPPORTED -> LinkResolver.Result.Unsupported(data.getString(MediaResolverService.KEY_MESSAGE).orEmpty())
        else -> LinkResolver.Result.Error(data.getString(MediaResolverService.KEY_MESSAGE).orEmpty().ifBlank { AppText.get(R.string.media_resolver_no_result) })
    }

    private const val RESOLVE_TIMEOUT_SECONDS = 120L
}
