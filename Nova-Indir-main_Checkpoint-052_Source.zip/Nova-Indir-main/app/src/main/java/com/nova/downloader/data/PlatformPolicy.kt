package com.nova.downloader.data

import java.net.URI

object PlatformPolicy {
    const val YOUTUBE = "youtube"
    const val INSTAGRAM = "instagram"
    const val FACEBOOK = "facebook"
    const val TIKTOK = "tiktok"
    const val TWITTER = "twitter"
    const val THREADS = "threads"
    const val BLUESKY = "bluesky"
    const val MASTODON = "mastodon"
    const val TELEGRAM = "telegram"
    const val GENERIC = "generic"

    val accountPlatforms = listOf(YOUTUBE, INSTAGRAM, FACEBOOK, TIKTOK, TWITTER, THREADS, BLUESKY, MASTODON, TELEGRAM, GENERIC)

    fun platformFor(url: String): String {
        val host = runCatching { URI(url).host.orEmpty().lowercase() }.getOrDefault("")
        return when {
            host == "youtu.be" || host.endsWith("youtube.com") || host.endsWith("youtube-nocookie.com") -> YOUTUBE
            host.endsWith("instagram.com") -> INSTAGRAM
            host.endsWith("facebook.com") || host == "fb.watch" || host.endsWith("fbcdn.net") -> FACEBOOK
            host.endsWith("tiktok.com") || host.endsWith("tiktokcdn.com") -> TIKTOK
            host == "x.com" || host.endsWith(".x.com") || host == "twitter.com" || host.endsWith(".twitter.com") || host.endsWith(".twimg.com") -> TWITTER
            host == "threads.net" || host.endsWith(".threads.net") -> THREADS
            host == "bsky.app" || host.endsWith(".bsky.app") -> BLUESKY
            host == "mastodon.social" || host.endsWith(".mastodon.social") || host.contains(".mastodon.") -> MASTODON
            host == "t.me" || host == "telegram.me" || host == "telegram.org" || host.endsWith(".telegram.org") -> TELEGRAM
            else -> GENERIC
        }
    }
}
