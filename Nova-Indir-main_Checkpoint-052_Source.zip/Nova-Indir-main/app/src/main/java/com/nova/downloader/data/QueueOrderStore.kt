package com.nova.downloader.data

import android.content.Context

/** Persists user-defined queue order independently of download history. */
class QueueOrderStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun ordered(ids: Collection<Long>): List<Long> = synchronized(LOCK) {
        val available = ids.toSet()
        val saved = read().filter { it in available }
        saved + ids.filterNot { it in saved }
    }

    fun add(id: Long) = synchronized(LOCK) {
        val items = read().toMutableList()
        if (id !in items) items += id
        write(items)
    }

    fun remove(id: Long) = synchronized(LOCK) { write(read().filterNot { it == id }) }

    fun replace(ids: List<Long>) = synchronized(LOCK) { write(ids.distinct()) }

    private fun read(): List<Long> = prefs.getString(KEY, null)
        ?.split(',')
        ?.mapNotNull(String::toLongOrNull)
        .orEmpty()

    private fun write(ids: List<Long>) {
        prefs.edit().putString(KEY, ids.joinToString(",")).apply()
    }

    companion object {
        private const val PREFS = "nova_queue_order"
        private const val KEY = "ids"
        private val LOCK = Any()
    }
}
