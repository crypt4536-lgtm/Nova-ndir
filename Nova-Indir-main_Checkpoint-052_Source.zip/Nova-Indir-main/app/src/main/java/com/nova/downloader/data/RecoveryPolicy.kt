package com.nova.downloader.data

object RecoveryPolicy {
    const val MANUAL = "manual"
    const val WIFI = "wifi"
    const val ANY_NETWORK = "any_network"
}
