package com.nova.downloader.data

import android.content.Context
import org.json.JSONObject
import java.io.File
import java.util.concurrent.atomic.AtomicLong

/**
 * Small cross-process task store for media resolution jobs.
 * Each task is written atomically into internal storage so the foreground
 * resolver process may finish even when the UI process is backgrounded or killed.
 */
class ResolutionTaskStore(context: Context) {
    private val root = File(context.applicationContext.filesDir, "resolution_tasks").apply { mkdirs() }

    data class Task(
        val id: Long,
        val sourceUrl: String,
        val state: String,
        val resultPayload: String? = null,
        val message: String? = null,
        val createdAt: Long,
        val updatedAt: Long,
        val downloadId: Long? = null
    )

    @Synchronized
    fun create(sourceUrl: String): Task {
        prune()
        val now = System.currentTimeMillis()
        val id = IDS.updateAndGet { previous -> maxOf(previous + 1L, now) }
        return Task(id, sourceUrl, STATE_PENDING, createdAt = now, updatedAt = now).also(::write)
    }

    @Synchronized
    fun get(id: Long): Task? = read(file(id))

    @Synchronized
    fun list(): List<Task> = root.listFiles()
        .orEmpty()
        .asSequence()
        .filter { it.isFile && it.extension == "json" }
        .mapNotNull(::read)
        .sortedBy { it.createdAt }
        .toList()

    @Synchronized
    fun latestActive(): Task? = list().lastOrNull { it.state == STATE_PENDING || it.state == STATE_RUNNING }

    @Synchronized
    fun latestReady(): Task? = list().lastOrNull { it.state == STATE_READY }

    @Synchronized
    fun update(
        id: Long,
        state: String,
        payload: String? = null,
        message: String? = null,
        downloadId: Long? = null
    ): Task? {
        val current = get(id) ?: return null
        return current.copy(
            state = state,
            resultPayload = payload,
            message = message,
            downloadId = downloadId,
            updatedAt = System.currentTimeMillis()
        ).also(::write)
    }

    @Synchronized
    fun remove(id: Long) {
        file(id).delete()
        File(root, "$id.tmp").delete()
    }

    @Synchronized
    fun prune(maxAgeMs: Long = MAX_AGE_MS) {
        val cutoff = System.currentTimeMillis() - maxAgeMs
        root.listFiles().orEmpty().forEach { candidate ->
            val task = read(candidate)
            if (task == null || task.updatedAt < cutoff) candidate.delete()
        }
    }

    private fun file(id: Long) = File(root, "$id.json")

    private fun write(task: Task) {
        val target = file(task.id)
        val temporary = File(root, "${task.id}.tmp")
        temporary.writeText(JSONObject().apply {
            put("id", task.id)
            put("sourceUrl", task.sourceUrl)
            put("state", task.state)
            put("resultPayload", task.resultPayload)
            put("message", task.message)
            put("createdAt", task.createdAt)
            put("updatedAt", task.updatedAt)
            put("downloadId", task.downloadId)
        }.toString(), Charsets.UTF_8)
        if (!temporary.renameTo(target)) {
            target.writeBytes(temporary.readBytes())
            temporary.delete()
        }
    }

    private fun read(candidate: File): Task? = runCatching {
        if (!candidate.isFile || candidate.extension != "json") return@runCatching null
        val json = JSONObject(candidate.readText(Charsets.UTF_8))
        Task(
            id = json.getLong("id"),
            sourceUrl = json.getString("sourceUrl"),
            state = json.getString("state"),
            resultPayload = json.optString("resultPayload").takeIf { it.isNotBlank() && it != "null" },
            message = json.optString("message").takeIf { it.isNotBlank() && it != "null" },
            createdAt = json.getLong("createdAt"),
            updatedAt = json.getLong("updatedAt"),
            downloadId = json.optLong("downloadId", -1L).takeIf { it > 0L }
        )
    }.getOrNull()

    companion object {
        const val STATE_PENDING = "pending"
        const val STATE_RUNNING = "running"
        const val STATE_READY = "ready"
        const val STATE_AUTO_ENQUEUED = "auto_enqueued"
        const val STATE_UNSUPPORTED = "unsupported"
        const val STATE_ERROR = "error"
        const val STATE_CANCELLED = "cancelled"
        const val ACTION_CHANGED = "com.nova.downloader.action.RESOLUTION_CHANGED"
        const val EXTRA_TASK_ID = "resolution_task_id"
        private const val MAX_AGE_MS = 7L * 24L * 60L * 60L * 1000L
        private val IDS = AtomicLong(System.currentTimeMillis())
    }
}
