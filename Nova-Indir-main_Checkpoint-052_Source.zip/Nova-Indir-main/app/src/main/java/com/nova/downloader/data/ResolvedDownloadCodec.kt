package com.nova.downloader.data

import org.json.JSONArray
import org.json.JSONObject

object ResolvedDownloadCodec {
    fun encode(value: ResolvedDownload): String = JSONObject().apply {
        put("sourceUrl", value.sourceUrl)
        put("downloadUrl", value.downloadUrl)
        put("title", value.title)
        put("mimeType", value.mimeType)
        put("contentLength", value.contentLength)
        put("referer", value.referer)
        put("headers", JSONObject(value.headers))
        put("engine", value.engine)
        put("formatSelector", value.formatSelector)
        put("outputMode", value.outputMode)
        put("audioFormat", value.audioFormat)
        put("videoContainer", value.videoContainer)
        put("qualityId", value.qualityId)
        put("formats", JSONArray(value.formats.map(::formatToJson)))
        put("metadata", metadataToJson(value.metadata))
        put("selectedAudioLanguage", value.selectedAudioLanguage)
        put("subtitleLanguages", JSONArray(value.subtitleLanguages))
        put("writeSubtitles", value.writeSubtitles)
        put("writeAutoSubtitles", value.writeAutoSubtitles)
        put("writeThumbnail", value.writeThumbnail)
        put("writeDescription", value.writeDescription)
        put("embedMetadata", value.embedMetadata)
        put("embedChapters", value.embedChapters)
        put("playlistMode", value.playlistMode)
        put("liveFromStart", value.liveFromStart)
        put("duplicatePolicy", value.duplicatePolicy)
    }.toString()

    fun decode(raw: String): ResolvedDownload {
        val item = JSONObject(raw)
        return ResolvedDownload(
            sourceUrl = item.getString("sourceUrl"),
            downloadUrl = item.getString("downloadUrl"),
            title = item.getString("title"),
            mimeType = item.optString("mimeType").takeIf(String::isNotBlank),
            contentLength = item.optLong("contentLength", -1L),
            referer = item.optString("referer").takeIf(String::isNotBlank),
            headers = jsonStringMap(item.optJSONObject("headers")),
            engine = item.optString("engine", DownloadEngine.DIRECT),
            formatSelector = item.optString("formatSelector").takeIf(String::isNotBlank),
            outputMode = item.optString("outputMode", "video"),
            audioFormat = item.optString("audioFormat").takeIf(String::isNotBlank),
            videoContainer = item.optString("videoContainer", "mp4").takeIf(String::isNotBlank),
            qualityId = item.optString("qualityId", "best").takeIf(String::isNotBlank),
            formats = jsonArray(item.optJSONArray("formats"), ::formatFromJson),
            metadata = item.optJSONObject("metadata")?.let(::metadataFromJson) ?: MediaMetadata(),
            selectedAudioLanguage = item.optString("selectedAudioLanguage").takeIf(String::isNotBlank),
            subtitleLanguages = stringList(item.optJSONArray("subtitleLanguages")),
            writeSubtitles = item.optBoolean("writeSubtitles", false),
            writeAutoSubtitles = item.optBoolean("writeAutoSubtitles", false),
            writeThumbnail = item.optBoolean("writeThumbnail", false),
            writeDescription = item.optBoolean("writeDescription", false),
            embedMetadata = item.optBoolean("embedMetadata", true),
            embedChapters = item.optBoolean("embedChapters", true),
            playlistMode = item.optString("playlistMode", "single"),
            liveFromStart = item.optBoolean("liveFromStart", false),
            duplicatePolicy = DuplicatePolicy.normalize(item.optString("duplicatePolicy"))
        )
    }

    private fun formatToJson(value: MediaFormatOption) = JSONObject().apply {
        put("formatId", value.formatId); put("selector", value.selector); put("label", value.label)
        put("extension", value.extension); put("mimeType", value.mimeType); put("width", value.width)
        put("height", value.height); put("fps", value.fps); put("videoCodec", value.videoCodec)
        put("audioCodec", value.audioCodec); put("audioLanguage", value.audioLanguage); put("fileSize", value.fileSize)
        put("dynamicRange", value.dynamicRange); put("protocol", value.protocol); put("hasVideo", value.hasVideo); put("hasAudio", value.hasAudio)
    }

    private fun formatFromJson(item: JSONObject) = MediaFormatOption(
        formatId = item.optString("formatId"), selector = item.optString("selector"), label = item.optString("label"),
        extension = item.optString("extension").takeIf(String::isNotBlank), mimeType = item.optString("mimeType").takeIf(String::isNotBlank),
        width = item.optInt("width").takeIf { item.has("width") && !item.isNull("width") },
        height = item.optInt("height").takeIf { item.has("height") && !item.isNull("height") },
        fps = item.optDouble("fps").takeIf { item.has("fps") && !item.isNull("fps") && !it.isNaN() },
        videoCodec = item.optString("videoCodec").takeIf(String::isNotBlank), audioCodec = item.optString("audioCodec").takeIf(String::isNotBlank),
        audioLanguage = item.optString("audioLanguage").takeIf(String::isNotBlank),
        fileSize = item.optLong("fileSize").takeIf { item.has("fileSize") && !item.isNull("fileSize") },
        dynamicRange = item.optString("dynamicRange").takeIf(String::isNotBlank), protocol = item.optString("protocol").takeIf(String::isNotBlank),
        hasVideo = item.optBoolean("hasVideo"), hasAudio = item.optBoolean("hasAudio")
    )

    private fun metadataToJson(value: MediaMetadata) = JSONObject().apply {
        put("extractor", value.extractor); put("description", value.description); put("thumbnailUrl", value.thumbnailUrl)
        put("durationSeconds", value.durationSeconds); put("isLive", value.isLive); put("liveStatus", value.liveStatus)
        put("isPlaylist", value.isPlaylist); put("playlistCount", value.playlistCount); put("audioLanguages", JSONArray(value.audioLanguages))
        put("subtitleLanguages", JSONArray(value.subtitleLanguages)); put("automaticSubtitleLanguages", JSONArray(value.automaticSubtitleLanguages))
        put("chapterCount", value.chapterCount)
    }

    private fun metadataFromJson(item: JSONObject) = MediaMetadata(
        extractor = item.optString("extractor").takeIf(String::isNotBlank),
        description = item.optString("description").takeIf(String::isNotBlank),
        thumbnailUrl = item.optString("thumbnailUrl").takeIf(String::isNotBlank),
        durationSeconds = item.optLong("durationSeconds").takeIf { item.has("durationSeconds") && !item.isNull("durationSeconds") },
        isLive = item.optBoolean("isLive"), liveStatus = item.optString("liveStatus").takeIf(String::isNotBlank),
        isPlaylist = item.optBoolean("isPlaylist"), playlistCount = item.optInt("playlistCount"),
        audioLanguages = stringList(item.optJSONArray("audioLanguages")), subtitleLanguages = stringList(item.optJSONArray("subtitleLanguages")),
        automaticSubtitleLanguages = stringList(item.optJSONArray("automaticSubtitleLanguages")), chapterCount = item.optInt("chapterCount")
    )

    private fun jsonStringMap(item: JSONObject?): Map<String, String> = if (item == null) emptyMap() else buildMap {
        item.keys().forEach { key -> put(key, item.optString(key)) }
    }
    private fun stringList(array: JSONArray?): List<String> = if (array == null) emptyList() else buildList {
        for (index in 0 until array.length()) array.optString(index).takeIf(String::isNotBlank)?.let(::add)
    }
    private fun <T> jsonArray(array: JSONArray?, mapper: (JSONObject) -> T): List<T> = if (array == null) emptyList() else buildList {
        for (index in 0 until array.length()) array.optJSONObject(index)?.let { add(mapper(it)) }
    }
}
