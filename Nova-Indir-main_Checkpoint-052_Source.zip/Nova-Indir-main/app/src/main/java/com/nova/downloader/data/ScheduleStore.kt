package com.nova.downloader.data

import android.content.Context
import org.json.JSONObject

/** Stores scheduled start timestamps for downloads. */
class ScheduleStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun get(downloadId: Long): Long? = synchronized(LOCK) {
        read().optLong(downloadId.toString(), 0L).takeIf { it > 0L }
    }

    fun put(downloadId: Long, timeMillis: Long) = synchronized(LOCK) {
        val json = read().put(downloadId.toString(), timeMillis)
        prefs.edit().putString(KEY, json.toString()).apply()
    }

    fun remove(downloadId: Long) = synchronized(LOCK) {
        val json = read().apply { remove(downloadId.toString()) }
        prefs.edit().putString(KEY, json.toString()).apply()
    }

    fun all(): Map<Long, Long> = synchronized(LOCK) {
        val json = read()
        buildMap {
            val keys = json.keys()
            while (keys.hasNext()) {
                val key = keys.next()
                key.toLongOrNull()?.let { id -> json.optLong(key, 0L).takeIf { it > 0L }?.let { put(id, it) } }
            }
        }
    }

    fun isDue(downloadId: Long, now: Long = System.currentTimeMillis()): Boolean =
        get(downloadId)?.let { it <= now } ?: true

    private fun read(): JSONObject = runCatching {
        JSONObject(prefs.getString(KEY, "{}") ?: "{}")
    }.getOrDefault(JSONObject())

    companion object {
        private const val PREFS = "nova_download_schedules"
        private const val KEY = "items"
        private val LOCK = Any()
    }
}
