package com.nova.downloader.data

import com.nova.downloader.i18n.AppText
import com.nova.downloader.core.FileNameResolver

import com.nova.downloader.R

import android.app.Activity
import android.app.DownloadManager
import android.content.ActivityNotFoundException
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.provider.DocumentsContract
import android.provider.MediaStore
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.OutputStream
import java.security.MessageDigest

object StorageHelper {
    private const val EXTERNAL_STORAGE_DOCUMENTS_AUTHORITY = "com.android.externalstorage.documents"
    val DEFAULT_RELATIVE_PATH = "${Environment.DIRECTORY_DOWNLOADS}/NovaDownloader/"

    data class OutputTarget(val uri: Uri, val stream: OutputStream, val file: File? = null, val mediaStorePending: Boolean = false)
    data class CommitResult(val uri: Uri, val displayName: String, val checksumSha256: String)
    data class RelocateResult(val uri: Uri, val displayName: String, val checksumSha256: String)
    data class RenameResult(val uri: Uri, val displayName: String)
    data class OutputInfo(val uri: Uri, val displayName: String, val mimeType: String?)

    fun partialFile(context: Context, downloadId: Long, storedPath: String? = null): File {
        storedPath?.takeIf { it.isNotBlank() }?.let { return File(it) }
        val root = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: context.filesDir
        return File(File(root, "partials").apply { mkdirs() }, "$downloadId.nova.part")
    }

    fun deletePartial(context: Context, item: StoredDownload) = runCatching {
        val target = partialFile(context, item.downloadId, item.partialFilePath)
        if (target.isDirectory) target.deleteRecursively() else target.delete()
    }.getOrDefault(false)

    fun availableBytes(context: Context, destinationTreeUri: String?): Long? {
        if (!destinationTreeUri.isNullOrBlank()) return null
        val root = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: context.filesDir
        return runCatching { StatFs(root.absolutePath).availableBytes }.getOrNull()
    }

    fun requireFreeSpace(context: Context, requiredBytes: Long, destinationTreeUri: String?) {
        if (requiredBytes <= 0L) return
        val available = availableBytes(context, destinationTreeUri) ?: return
        val reserve = 64L * 1024L * 1024L
        require(available - reserve >= requiredBytes) {
            AppText.get(R.string.not_enough_space, formatBytes(requiredBytes), formatBytes(available))
        }
    }

    fun commitPartial(
        context: Context,
        partialFile: File,
        fileName: String,
        mimeType: String,
        destinationTreeUri: String?,
        duplicatePolicy: String = DuplicatePolicy.RENAME
    ): CommitResult {
        require(partialFile.isFile && partialFile.length() > 0L) { AppText.get(R.string.partial_file_missing) }
        requireFreeSpace(context, partialFile.length(), destinationTreeUri)
        val checksum = sha256(partialFile)
        val target = createOutput(context, fileName, mimeType, destinationTreeUri, DuplicatePolicy.normalize(duplicatePolicy))
        try {
            FileInputStream(partialFile).use { input -> target.stream.use { output -> input.copyTo(output, 128 * 1024); output.flush() } }
            finishOutput(context, target)
            require(verifyReadableMedia(context, target.uri, checksum)) {
                AppText.get(R.string.saved_file_hash_failed)
            }
            val actualName = queryDisplayName(context, target.uri) ?: target.file?.name ?: fileName
            return CommitResult(target.uri, actualName, checksum)
        } catch (error: Exception) {
            deleteOutput(context, target); throw error
        }
    }

    fun relocateOutput(
        context: Context,
        item: StoredDownload,
        destinationTreeUri: String,
        duplicatePolicy: String = DuplicatePolicy.RENAME
    ): RelocateResult {
        require(item.status == DownloadState.SUCCESSFUL) { AppText.get(R.string.only_completed_movable) }
        val sourceUri = item.outputUri?.takeIf(String::isNotBlank)?.let(Uri::parse)
            ?: error(AppText.get(R.string.move_source_location_missing))
        val mime = item.mediaType?.takeIf(String::isNotBlank) ?: "application/octet-stream"
        val target = createOutput(context, item.title, mime, destinationTreeUri, DuplicatePolicy.normalize(duplicatePolicy))
        val digest = MessageDigest.getInstance("SHA-256")
        try {
            val input = context.contentResolver.openInputStream(sourceUri)
                ?: error(AppText.get(R.string.source_file_open_failed))
            input.use { source ->
                target.stream.use { output ->
                    val buffer = ByteArray(128 * 1024)
                    while (true) {
                        val count = source.read(buffer)
                        if (count < 0) break
                        output.write(buffer, 0, count)
                        digest.update(buffer, 0, count)
                    }
                    output.flush()
                }
            }
            finishOutput(context, target)
            val actualName = queryDisplayName(context, target.uri) ?: target.file?.name ?: item.title
            val checksum = digest.digest().joinToString("") { "%02x".format(it) }
            require(item.checksumSha256.isNullOrBlank() || item.checksumSha256.equals(checksum, true)) {
                AppText.get(R.string.move_hash_failed_source_kept)
            }
            require(verifyReadableMedia(context, target.uri, checksum)) {
                AppText.get(R.string.moved_file_unverified_source_kept)
            }
            if (sourceUri != target.uri) runCatching { context.contentResolver.delete(sourceUri, null, null) }
            return RelocateResult(target.uri, actualName, checksum)
        } catch (error: Exception) {
            deleteOutput(context, target)
            throw error
        }
    }


    /** Renames a completed output and returns the URI/name that must be persisted in Room.
     * The media extension is preserved/corrected so a renamed MP4 does not become extensionless.
     */
    fun renameOutput(context: Context, item: StoredDownload, requestedName: String): RenameResult {
        require(item.status == DownloadState.SUCCESSFUL) { AppText.get(R.string.only_completed_renameable) }
        val sourceUri = item.outputUri?.takeIf(String::isNotBlank)?.let(Uri::parse)
            ?: error(AppText.get(R.string.rename_source_location_missing))
        require(requestedName.isNotBlank()) { AppText.get(R.string.file_name_required) }

        val currentName = queryDisplayName(context, sourceUri) ?: item.title
        val finalName = FileNameResolver.renamePreservingMediaExtension(
            requestedName = requestedName.trim(),
            currentName = currentName,
            mimeType = item.mediaType
        )
        if (finalName == currentName) return RenameResult(sourceUri, currentName)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && sourceUri.authority == MediaStore.AUTHORITY) {
            val candidate = if (findMediaStore(context, finalName) == null) finalName else uniqueMediaStoreName(context, finalName)
            val changed = context.contentResolver.update(
                sourceUri,
                ContentValues().apply { put(MediaStore.MediaColumns.DISPLAY_NAME, candidate) },
                null,
                null
            )
            require(changed > 0) { AppText.get(R.string.file_rename_provider_failed) }
            return RenameResult(sourceUri, queryDisplayName(context, sourceUri) ?: candidate)
        }

        if (DocumentsContract.isDocumentUri(context, sourceUri)) {
            val candidate = item.destinationTreeUri?.takeIf(String::isNotBlank)?.let(Uri::parse)?.let { tree ->
                runCatching {
                    val parentId = DocumentsContract.getTreeDocumentId(tree)
                    if (findSafChild(context, tree, parentId, finalName) == null) finalName
                    else uniqueSafName(context, tree, parentId, finalName)
                }.getOrDefault(finalName)
            } ?: finalName
            val renamedUri = DocumentsContract.renameDocument(context.contentResolver, sourceUri, candidate)
                ?: error(AppText.get(R.string.file_rename_provider_failed))
            return RenameResult(renamedUri, queryDisplayName(context, renamedUri) ?: candidate)
        }

        if (sourceUri.authority == "${context.packageName}.files") {
            @Suppress("DEPRECATION")
            val folder = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "NovaDownloader")
            val source = File(folder, currentName)
            require(source.isFile) { AppText.get(R.string.rename_source_location_missing) }
            val requestedTarget = File(folder, finalName)
            val target = if (requestedTarget.exists()) uniqueFile(folder, finalName) else requestedTarget
            require(source.renameTo(target)) { AppText.get(R.string.file_rename_provider_failed) }
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.files", target)
            return RenameResult(uri, target.name)
        }

        val changed = context.contentResolver.update(
            sourceUri,
            ContentValues().apply { put(MediaStore.MediaColumns.DISPLAY_NAME, finalName) },
            null,
            null
        )
        require(changed > 0) { AppText.get(R.string.file_rename_provider_failed) }
        return RenameResult(sourceUri, queryDisplayName(context, sourceUri) ?: finalName)
    }

    /** Reads the current provider metadata so externally renamed files are reflected in Nova. */
    fun inspectOutput(context: Context, item: StoredDownload): OutputInfo? {
        val uri = item.outputUri?.takeIf(String::isNotBlank)?.let(Uri::parse) ?: return null
        return runCatching {
            context.contentResolver.openAssetFileDescriptor(uri, "r")?.use { } ?: return null
            OutputInfo(
                uri = uri,
                displayName = queryDisplayName(context, uri) ?: item.title,
                mimeType = context.contentResolver.getType(uri) ?: item.mediaType
            )
        }.getOrNull()
    }

    private fun createOutput(context: Context, requestedName: String, mimeType: String, tree: String?, policy: String): OutputTarget {
        if (!tree.isNullOrBlank()) return createSafOutput(context, Uri.parse(tree), requestedName, mimeType, policy)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) return createMediaStoreOutput(context, requestedName, mimeType, policy)
        @Suppress("DEPRECATION") val base = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        val folder = File(base, "NovaDownloader").apply { mkdirs() }
        val existing = File(folder, requestedName)
        val file = when {
            !existing.exists() -> existing
            policy == DuplicatePolicy.REPLACE -> existing.apply { delete() }
            policy == DuplicatePolicy.SKIP -> error(AppText.get(R.string.duplicate_file_exists, requestedName))
            else -> uniqueFile(folder, requestedName)
        }
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.files", file)
        return OutputTarget(uri, FileOutputStream(file, false), file)
    }

    private fun createSafOutput(context: Context, treeUri: Uri, requestedName: String, mimeType: String, policy: String): OutputTarget {
        val parentId = DocumentsContract.getTreeDocumentId(treeUri)
        val parentUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, parentId)
        val existing = findSafChild(context, treeUri, parentId, requestedName)
        val name = when {
            existing == null -> requestedName
            policy == DuplicatePolicy.REPLACE -> { context.contentResolver.delete(existing, null, null); requestedName }
            policy == DuplicatePolicy.SKIP -> error(AppText.get(R.string.duplicate_file_exists, requestedName))
            else -> uniqueSafName(context, treeUri, parentId, requestedName)
        }
        val documentUri = DocumentsContract.createDocument(context.contentResolver, parentUri, mimeType, name)
            ?: error(AppText.get(R.string.destination_file_create_failed))
        val stream = context.contentResolver.openOutputStream(documentUri, "rwt") ?: error(AppText.get(R.string.destination_file_write_failed))
        return OutputTarget(documentUri, stream)
    }

    private fun createMediaStoreOutput(context: Context, requestedName: String, mimeType: String, policy: String): OutputTarget {
        val existing = findMediaStore(context, requestedName)
        val name = when {
            existing == null -> requestedName
            policy == DuplicatePolicy.REPLACE -> { context.contentResolver.delete(existing, null, null); requestedName }
            policy == DuplicatePolicy.SKIP -> error(AppText.get(R.string.duplicate_file_exists, requestedName))
            else -> uniqueMediaStoreName(context, requestedName)
        }
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name); put(MediaStore.MediaColumns.MIME_TYPE, mimeType)
            put(MediaStore.MediaColumns.RELATIVE_PATH, DEFAULT_RELATIVE_PATH); put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val uri = context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: error(AppText.get(R.string.downloads_file_create_failed))
        val stream = context.contentResolver.openOutputStream(uri, "rwt") ?: run {
            context.contentResolver.delete(uri, null, null); error(AppText.get(R.string.downloaded_file_open_failed))
        }
        return OutputTarget(uri, stream, mediaStorePending = true)
    }

    private fun findMediaStore(context: Context, name: String): Uri? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return null
        val projection = arrayOf(MediaStore.MediaColumns._ID)
        val selection = "${MediaStore.MediaColumns.DISPLAY_NAME}=? AND ${MediaStore.MediaColumns.RELATIVE_PATH}=?"
        context.contentResolver.query(MediaStore.Downloads.EXTERNAL_CONTENT_URI, projection, selection, arrayOf(name, DEFAULT_RELATIVE_PATH), null)?.use { c ->
            if (c.moveToFirst()) return ContentUris.withAppendedId(MediaStore.Downloads.EXTERNAL_CONTENT_URI, c.getLong(0))
        }
        return null
    }

    private fun uniqueMediaStoreName(context: Context, requested: String): String {
        var candidate = requested; var i = 1
        while (findMediaStore(context, candidate) != null) { candidate = suffixedName(requested, i++) }
        return candidate
    }

    private fun findSafChild(context: Context, treeUri: Uri, parentId: String, name: String): Uri? {
        val children = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, parentId)
        context.contentResolver.query(children, arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME), null, null, null)?.use { c ->
            while (c.moveToNext()) if (c.getString(1) == name) return DocumentsContract.buildDocumentUriUsingTree(treeUri, c.getString(0))
        }
        return null
    }

    private fun uniqueSafName(context: Context, tree: Uri, parentId: String, requested: String): String {
        var candidate = requested; var i = 1
        while (findSafChild(context, tree, parentId, candidate) != null) candidate = suffixedName(requested, i++)
        return candidate
    }

    private fun finishOutput(context: Context, target: OutputTarget) {
        runCatching { target.stream.close() }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && target.mediaStorePending) {
            context.contentResolver.update(target.uri, ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }, null, null)
        }
    }
    private fun deleteOutput(context: Context, target: OutputTarget?) {
        if (target == null) return; runCatching { target.stream.close() }
        target.file?.let { runCatching { it.delete() } } ?: runCatching { context.contentResolver.delete(target.uri, null, null) }
    }

    fun verifyReadableMedia(context: Context, uri: Uri, expectedSha256: String?): Boolean = runCatching {
        val digest = MessageDigest.getInstance("SHA-256")
        context.contentResolver.openInputStream(uri)?.use { input ->
            val buffer = ByteArray(128 * 1024); while (true) { val n = input.read(buffer); if (n < 0) break; digest.update(buffer, 0, n) }
        } ?: return false
        expectedSha256.isNullOrBlank() || digest.digest().joinToString("") { "%02x".format(it) }.equals(expectedSha256, true)
    }.getOrDefault(false)

    fun destinationLabel(context: Context, treeUriString: String?): String {
        if (treeUriString.isNullOrBlank()) return AppText.get(R.string.automatic_download_directory)
        return queryDisplayName(context, Uri.parse(treeUriString))?.let { AppText.get(R.string.custom_directory_label, it) } ?: AppText.get(R.string.selected_custom_directory)
    }
    private fun queryDisplayName(context: Context, uri: Uri): String? {
        val documentUri = runCatching { DocumentsContract.buildDocumentUriUsingTree(uri, DocumentsContract.getTreeDocumentId(uri)) }.getOrNull() ?: uri
        var cursor: Cursor? = null
        return try {
            cursor = context.contentResolver.query(documentUri, arrayOf(DocumentsContract.Document.COLUMN_DISPLAY_NAME, MediaStore.MediaColumns.DISPLAY_NAME), null, null, null)
            if (cursor?.moveToFirst() == true) (0 until cursor!!.columnCount).asSequence().mapNotNull { cursor!!.getString(it)?.takeIf(String::isNotBlank) }.firstOrNull() else null
        } catch (_: Exception) { null } finally { cursor?.close() }
    }

    fun takeTreePermission(context: Context, data: Intent?): String? {
        val uri = data?.data ?: return null
        val flags = data.flags and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        runCatching { context.contentResolver.takePersistableUriPermission(uri, flags) }; return uri.toString()
    }
    fun openFile(context: Context, item: StoredDownload): Boolean {
        val uri = item.outputUri?.let(Uri::parse) ?: return false
        return try { context.startActivity(Intent(Intent.ACTION_VIEW).apply { setDataAndType(uri, item.mediaType ?: "*/*"); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }); true }
        catch (_: ActivityNotFoundException) { false }
    }
    fun openLocation(activity: Activity, item: StoredDownload?): Boolean {
        val directoryUri = resolveOutputDirectoryUri(activity, item)
        if (directoryUri != null) {
            val directView = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(directoryUri, DocumentsContract.Document.MIME_TYPE_DIR)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            }
            if (runCatching { activity.startActivity(directView); true }.getOrDefault(false)) return true

            val treePicker = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
                addFlags(
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or
                        Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                        Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
                )
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    putExtra(DocumentsContract.EXTRA_INITIAL_URI, directoryUri)
                }
            }
            if (runCatching { activity.startActivity(treePicker); true }.getOrDefault(false)) return true
        }

        return try {
            activity.startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS))
            true
        } catch (_: ActivityNotFoundException) {
            activity.startActivity(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE))
            true
        }
    }

    /**
     * Resolves the exact parent directory of a completed download.
     *
     * Custom SAF destinations already carry their tree URI. Automatic downloads are written to
     * MediaStore.Downloads with RELATIVE_PATH=Downloads/NovaDownloader/, so use that provider
     * metadata to open the real folder instead of falling back to the top-level Downloads screen.
     */
    private fun resolveOutputDirectoryUri(context: Context, item: StoredDownload?): Uri? {
        val tree = item?.destinationTreeUri?.takeIf(String::isNotBlank)?.let(Uri::parse)
        if (tree != null) {
            return runCatching {
                DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))
            }.getOrDefault(tree)
        }

        val output = item?.outputUri?.takeIf(String::isNotBlank)?.let(Uri::parse)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && output != null) {
            val relativePath = runCatching {
                context.contentResolver.query(
                    output,
                    arrayOf(MediaStore.MediaColumns.RELATIVE_PATH),
                    null,
                    null,
                    null
                )?.use { cursor ->
                    if (cursor.moveToFirst()) cursor.getString(0) else null
                }
            }.getOrNull()

            relativePath?.takeIf(String::isNotBlank)?.let { path ->
                externalStorageDirectoryUri(path)?.let { return it }
            }
        }

        // Nova's automatic destination on all supported Android versions.
        return externalStorageDirectoryUri(DEFAULT_RELATIVE_PATH)
    }

    private fun externalStorageDirectoryUri(relativePath: String): Uri? {
        val cleanPath = relativePath
            .replace('\\', '/')
            .trim()
            .trim('/')
            .takeIf(String::isNotBlank)
            ?: return null
        return runCatching {
            DocumentsContract.buildDocumentUri(
                EXTERNAL_STORAGE_DOCUMENTS_AUTHORITY,
                "primary:$cleanPath"
            )
        }.getOrNull()
    }

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input -> val b = ByteArray(128 * 1024); while (true) { val n = input.read(b); if (n < 0) break; digest.update(b, 0, n) } }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }
    private fun uniqueFile(folder: File, requested: String): File { var f = File(folder, requested); var i = 1; while (f.exists()) f = File(folder, suffixedName(requested, i++)); return f }
    private fun suffixedName(name: String, suffix: Int): String { val dot = name.lastIndexOf('.'); val base = if (dot > 0) name.substring(0, dot) else name; val ext = if (dot > 0) name.substring(dot) else ""; return "$base ($suffix)$ext" }
    private fun formatBytes(v: Long) = when {
        v >= 1073741824L -> AppText.get(R.string.gigabytes_format, v / 1073741824.0)
        v >= 1048576L -> AppText.get(R.string.megabytes_format, v / 1048576.0)
        else -> AppText.get(R.string.kilobytes_format, v / 1024.0)
    }
}
