package com.nova.downloader.data

data class StoredDownload(
    val downloadId: Long,
    val url: String,
    val title: String,
    val createdAt: Long,
    val status: Int = DownloadState.PENDING,
    val reason: Int = 0,
    val bytesDownloaded: Long = 0L,
    val totalBytes: Long = -1L,
    val outputUri: String? = null,
    val destinationTreeUri: String? = null,
    val mediaType: String? = null,
    val errorMessage: String? = null,
    val updatedAt: Long = createdAt,
    val downloadUrl: String? = null,
    val referer: String? = null,
    val headersJson: String? = null,
    val partialFilePath: String? = null,
    val etag: String? = null,
    val lastModified: String? = null,
    val resumeSupported: Boolean = false,
    val retryCount: Int = 0,
    val engine: String = DownloadEngine.DIRECT,
    val formatSelector: String? = null,
    val outputMode: String = "video",
    val audioFormat: String? = null,
    val videoContainer: String? = "mp4",
    val qualityId: String? = "best",
    val audioLanguage: String? = null,
    val subtitleLanguages: String? = null,
    val writeSubtitles: Boolean = false,
    val writeAutoSubtitles: Boolean = false,
    val writeThumbnail: Boolean = false,
    val writeDescription: Boolean = false,
    val embedMetadata: Boolean = true,
    val embedChapters: Boolean = true,
    val playlistMode: String = "single",
    val liveFromStart: Boolean = false,
    val duplicatePolicy: String = DuplicatePolicy.RENAME,
    val checksumSha256: String? = null,
    val integrityVerified: Boolean = false
) {
    val hasPartialData: Boolean
        get() = !partialFilePath.isNullOrBlank() &&
            (bytesDownloaded > 0L || engine == DownloadEngine.YT_DLP)
}
