package com.nova.downloader.data

/**
 * Decides when Nova may retry a public-media extraction with another anonymous yt-dlp profile.
 * Hard access gates are never treated as anonymous fallback opportunities.
 */
object YtDlpFallbackPolicy {
    fun isHardAccessGate(raw: String?): Boolean {
        val message = raw.orEmpty()
        return HARD_GATE_MARKERS.any { message.contains(it, ignoreCase = true) }
    }

    fun isRetryableExtractionFailure(raw: String?): Boolean {
        val message = raw.orEmpty()
        if (message.isBlank() || isHardAccessGate(message)) return false
        return RETRYABLE_MARKERS.any { message.contains(it, ignoreCase = true) }
    }

    private val HARD_GATE_MARKERS = listOf(
        "private video",
        "private account",
        "this account is private",
        "members-only",
        "members only",
        "join this channel",
        "subscribers-only",
        "subscriber-only",
        "followers-only",
        "friends-only",
        "only followers can see",
        "age-restricted",
        "age restricted",
        "confirm your age",
        "age verification",
        "premium-only",
        "purchase required",
        "subscription required"
    )

    private val RETRYABLE_MARKERS = listOf(
        "sign in to confirm",
        "not a bot",
        "login required",
        "log in",
        "cookies",
        "cookie",
        "po token",
        "pot",
        "http error 403",
        "403 forbidden",
        "no video formats",
        "requested format",
        "unable to extract",
        "cannot parse",
        "challenge",
        "player response",
        "unsupported client"
    )
}
