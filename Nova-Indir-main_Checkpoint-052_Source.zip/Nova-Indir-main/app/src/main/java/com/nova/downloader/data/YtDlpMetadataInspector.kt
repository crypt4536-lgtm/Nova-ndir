package com.nova.downloader.data

import com.nova.downloader.i18n.AppText

import com.nova.downloader.R

import android.content.Context
import com.nova.downloader.core.MediaTypePolicy
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import org.json.JSONArray
import org.json.JSONObject

class YtDlpMetadataInspector(context: Context) {
    private val configurator = YtDlpRequestConfigurator(context.applicationContext)

    data class Inspection(
        val title: String,
        val extension: String,
        val contentLength: Long,
        val formats: List<MediaFormatOption>,
        val metadata: MediaMetadata
    )

    fun inspect(url: String, profile: YtDlpRequestConfigurator.RequestProfile): Inspection {
        val request = YoutubeDLRequest(url)
        val auth = configurator.applyCommon(request, "inspect_${System.nanoTime()}", url, profile)
        try {
            request.addOption("--skip-download")
            request.addOption("--dump-single-json")
            request.addOption("--no-clean-info-json")
            val response = YoutubeDL.getInstance().execute(request)
            val root = parseJson(response.out)
            return parseInspection(root)
        } finally {
            auth.clear()
        }
    }

    private fun parseJson(raw: String): JSONObject {
        val text = raw.trim()
        runCatching { JSONObject(text) }.getOrNull()?.let { return it }
        val candidate = text.lineSequence().map(String::trim)
            .lastOrNull { it.startsWith("{") && it.endsWith("}") }
            ?: error(AppText.get(R.string.metadata_json_missing))
        return JSONObject(candidate)
    }

    private fun parseInspection(root: JSONObject): Inspection {
        val entries = root.optJSONArray("entries")
        val isPlaylist = root.optString("_type") == "playlist" || entries != null
        val first = firstPlayableEntry(entries) ?: root
        val title = if (isPlaylist) root.optString("title").ifBlank { first.optString("title") }
            else first.optString("title")
        val formats = parseFormats(first.optJSONArray("formats"))
        val extension = first.optString("ext").ifBlank {
            formats.firstOrNull { it.hasVideo }?.extension ?: "mp4"
        }
        val contentLength = formats.mapNotNull { it.fileSize }.maxOrNull()
            ?: first.optLong("filesize", -1L).takeIf { it > 0L }
            ?: first.optLong("filesize_approx", -1L)
        val subtitles = keys(first.optJSONObject("subtitles"))
        val autoSubs = keys(first.optJSONObject("automatic_captions"))
        val audioLanguages = formats.mapNotNull { it.audioLanguage }.filter { it.isNotBlank() }.distinct().sorted()
        val chapters = first.optJSONArray("chapters")?.length() ?: 0
        val liveStatus = first.optString("live_status").takeIf { it.isNotBlank() }
        val metadata = MediaMetadata(
            extractor = first.optString("extractor_key").ifBlank { first.optString("extractor") }.takeIf { it.isNotBlank() },
            description = first.optString("description").takeIf { it.isNotBlank() },
            thumbnailUrl = first.optString("thumbnail").takeIf { it.isNotBlank() },
            durationSeconds = first.optLong("duration", -1L).takeIf { it >= 0L },
            isLive = first.optBoolean("is_live", false) || liveStatus in setOf("is_live", "is_upcoming", "post_live"),
            liveStatus = liveStatus,
            isPlaylist = isPlaylist,
            playlistCount = entries?.length() ?: 0,
            audioLanguages = audioLanguages,
            subtitleLanguages = subtitles,
            automaticSubtitleLanguages = autoSubs,
            chapterCount = chapters
        )
        return Inspection(title.ifBlank { "nova_${System.currentTimeMillis()}" }, extension, contentLength, formats, metadata)
    }

    private fun firstPlayableEntry(entries: JSONArray?): JSONObject? {
        if (entries == null) return null
        for (i in 0 until entries.length()) {
            val item = entries.optJSONObject(i) ?: continue
            if (item.optString("_type") == "url" && item.optJSONArray("formats") == null) continue
            return item
        }
        return entries.optJSONObject(0)
    }

    private fun parseFormats(array: JSONArray?): List<MediaFormatOption> {
        if (array == null) return listOf(bestFallback())
        val parsed = buildList {
            add(bestFallback())
            for (i in 0 until array.length()) {
                val item = array.optJSONObject(i) ?: continue
                val id = item.optString("format_id").takeIf { it.isNotBlank() } ?: continue
                val vcodec = item.optString("vcodec").takeIf { it.isNotBlank() && it != "none" }
                val acodec = item.optString("acodec").takeIf { it.isNotBlank() && it != "none" }
                if (vcodec == null && acodec == null) continue
                val ext = item.optString("ext").takeIf { it.isNotBlank() }
                val height = item.optInt("height", 0).takeIf { it > 0 }
                val width = item.optInt("width", 0).takeIf { it > 0 }
                val fps = item.optDouble("fps", 0.0).takeIf { it > 0.0 }
                val size = item.optLong("filesize", -1L).takeIf { it > 0L }
                    ?: item.optLong("filesize_approx", -1L).takeIf { it > 0L }
                val language = item.optString("language").takeIf { it.isNotBlank() }
                val dynamicRange = item.optString("dynamic_range").takeIf { it.isNotBlank() && it != "SDR" }
                val note = item.optString("format_note").takeIf { it.isNotBlank() }
                val protocol = item.optString("protocol").takeIf { it.isNotBlank() }
                val selector = if (vcodec != null && acodec == null) "$id+bestaudio/$id/best" else id
                val label = buildString {
                    append(if (vcodec != null) height?.let { "${it}p" } ?: note ?: AppText.get(R.string.format_video) else AppText.get(R.string.format_audio))
                    fps?.takeIf { it >= 50 }?.let { append(" ${it.toInt()}fps") }
                    dynamicRange?.let { append(" $it") }
                    ext?.let { append(" • ${it.uppercase()}") }
                    if (vcodec != null) append(" • ${shortCodec(vcodec)}")
                    if (acodec != null) append(" + ${shortCodec(acodec)}")
                    language?.let { append(" • $it") }
                    size?.let { append(" • ${formatBytes(it)}") }
                    protocol?.takeIf { it.contains("m3u8", true) || it.contains("dash", true) }?.let { append(" • ").append(AppText.get(R.string.format_stream)) }
                    append(" [$id]")
                }
                add(MediaFormatOption(id, selector, label, ext, MediaTypePolicy.mimeTypeForExtension(ext), width, height, fps, vcodec, acodec, language, size, dynamicRange, protocol, vcodec != null, acodec != null))
            }
        }
        return parsed.distinctBy { it.selector }.sortedWith(
            compareByDescending<MediaFormatOption> { it.formatId == "best" }
                .thenByDescending { it.hasVideo }
                .thenByDescending { it.height ?: 0 }
                .thenByDescending { it.fps ?: 0.0 }
                .thenByDescending { it.fileSize ?: 0L }
        )
    }

    private fun bestFallback() = MediaFormatOption(
        "best", "bestvideo*+bestaudio/best", AppText.get(R.string.best_available_quality), "mp4", "video/mp4",
        null, null, null, null, null, null, null, null, null, true, true
    )

    private fun keys(obj: JSONObject?): List<String> = if (obj == null) emptyList() else buildList {
        val iterator = obj.keys(); while (iterator.hasNext()) add(iterator.next())
    }.sorted()

    private fun shortCodec(codec: String) = codec.substringBefore('.').uppercase()
    private fun formatBytes(bytes: Long): String = when {
        bytes >= 1024L * 1024L * 1024L -> String.format("%.2f GB", bytes / 1073741824.0)
        bytes >= 1024L * 1024L -> String.format("%.1f MB", bytes / 1048576.0)
        else -> String.format("%.0f KB", bytes / 1024.0)
    }
}
