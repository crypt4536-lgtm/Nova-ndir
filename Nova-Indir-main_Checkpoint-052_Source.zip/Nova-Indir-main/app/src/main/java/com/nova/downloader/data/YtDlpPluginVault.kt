package com.nova.downloader.data

import com.nova.downloader.i18n.AppText

import com.nova.downloader.R

import android.content.Context
import android.net.Uri
import java.io.File
import java.security.MessageDigest
import java.util.zip.ZipInputStream

/** Imports trusted yt-dlp plugin ZIPs into the private plugin directory after strict traversal/type checks. */
object YtDlpPluginVault {
    private const val MAX_ZIP_BYTES = 20 * 1024 * 1024
    private const val MAX_ENTRY_BYTES = 8 * 1024 * 1024
    private const val MAX_ENTRIES = 250

    fun importZip(context: Context, uri: Uri): Result<String> = runCatching {
        val archiveSha256 = sha256Uri(context, uri)
        val root = pluginDirectory(context)
        root.parentFile?.mkdirs()
        val staging = File(root.parentFile, "plugins-staging-${System.nanoTime()}").apply { mkdirs() }
        val backup = File(root.parentFile, "plugins-backup-${System.nanoTime()}")
        var total = 0L
        var count = 0
        try {
            context.contentResolver.openInputStream(uri)?.buffered()?.use { raw ->
                ZipInputStream(raw).use { zip ->
                    while (true) {
                            val entry = zip.nextEntry ?: break
                            count++
                            require(count <= MAX_ENTRIES) { AppText.get(R.string.plugin_too_many_files) }
                            require(!entry.name.startsWith("/") && !entry.name.startsWith("\\")) { AppText.get(R.string.plugin_absolute_path_rejected) }
                            val target = File(staging, entry.name).canonicalFile
                            require(target.path.startsWith(staging.canonicalPath + File.separator)) { AppText.get(R.string.plugin_invalid_zip_path) }
                            if (entry.isDirectory) {
                                target.mkdirs()
                            } else {
                                require(entry.name.endsWith(".py", true) || entry.name.endsWith(".json", true) || entry.name.endsWith(".txt", true)) {
                                    AppText.get(R.string.plugin_forbidden_file_type, entry.name)
                                }
                                target.parentFile?.mkdirs()
                                target.outputStream().use { out ->
                                    val buffer = ByteArray(32 * 1024)
                                    var entryBytes = 0L
                                    while (true) {
                                        val read = zip.read(buffer)
                                        if (read < 0) break
                                        entryBytes += read
                                        total += read
                                        require(entryBytes <= MAX_ENTRY_BYTES && total <= MAX_ZIP_BYTES) {
                                            AppText.get(R.string.plugin_size_limit)
                                        }
                                        out.write(buffer, 0, read)
                                    }
                                }
                            }
                        zip.closeEntry()
                    }
                }
            } ?: error(AppText.get(R.string.plugin_zip_open_failed))
            require(staging.walkTopDown().any { it.isFile && it.extension.equals("py", true) }) {
                AppText.get(R.string.plugin_python_missing)
            }
            if (root.exists()) require(root.renameTo(backup)) { AppText.get(R.string.plugin_backup_failed) }
            if (!staging.renameTo(root)) {
                if (backup.exists()) backup.renameTo(root)
                error(AppText.get(R.string.plugin_activate_failed))
            }
            backup.deleteRecursively()
            AppText.get(R.string.plugin_imported, count, archiveSha256)
        } catch (error: Exception) {
            if (!root.exists() && backup.exists()) backup.renameTo(root)
            throw error
        } finally {
            staging.deleteRecursively()
            if (backup.exists() && root.exists()) backup.deleteRecursively()
        }
    }


    private fun sha256Uri(context: Context, uri: Uri): String {
        val digest = MessageDigest.getInstance("SHA-256")
        var total = 0L
        context.contentResolver.openInputStream(uri)?.use { input ->
            val buffer = ByteArray(32 * 1024)
            while (true) {
                val read = input.read(buffer)
                if (read < 0) break
                total += read
                require(total <= MAX_ZIP_BYTES) { AppText.get(R.string.plugin_zip_too_large) }
                digest.update(buffer, 0, read)
            }
        } ?: error(AppText.get(R.string.plugin_zip_open_failed))
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    fun pluginDirectory(context: Context): File = File(context.noBackupFilesDir, "yt_dlp_plugins")
    fun hasPlugins(context: Context): Boolean = pluginDirectory(context).walkTopDown().any {
        it.isFile && it.extension.equals("py", true)
    }
    fun clear(context: Context) = runCatching { pluginDirectory(context).deleteRecursively() }
}
