package com.nova.downloader.data

import android.content.Context
import com.yausername.youtubedl_android.YoutubeDLRequest
import java.io.File

class YtDlpRequestConfigurator(private val context: Context) {
    private val settings = AppSettings(context)

    data class RequestProfile(
        val id: String,
        val youtubePlayerClient: String? = null,
        val allowStoredCookies: Boolean = false,
        val userAgent: String? = null,
        val inheritConfiguredYoutubeClient: Boolean = false
    )

    data class AuthMaterial(val cookieFile: File?) {
        fun clear() = CookieVault.clearMaterialized(cookieFile)
    }

    /**
     * Ordered profiles used automatically for public content. Anonymous profiles are tried first.
     * A previously saved user session is appended only when one already exists and cookies are enabled.
     */
    fun automaticProfiles(sourceUrl: String, preferredProfileId: String? = null): List<RequestProfile> {
        val platform = PlatformPolicy.platformFor(sourceUrl)
        val profiles = mutableListOf<RequestProfile>()
        when (platform) {
            PlatformPolicy.YOUTUBE -> {
                profiles += ANONYMOUS_DEFAULT
                profiles += YOUTUBE_WEB_SAFARI
                profiles += YOUTUBE_WEB_EMBEDDED
                profiles += YOUTUBE_ANDROID_VR
                if (settings.poTokenProviderEnabled && settings.poTokenProviderBaseUrl.isNotBlank()) {
                    profiles += YOUTUBE_MWEB_PROVIDER
                }
            }
            PlatformPolicy.FACEBOOK -> {
                profiles += ANONYMOUS_DEFAULT
                profiles += MOBILE_BROWSER
                profiles += DESKTOP_BROWSER
            }
            PlatformPolicy.INSTAGRAM, PlatformPolicy.TIKTOK, PlatformPolicy.TWITTER,
            PlatformPolicy.THREADS, PlatformPolicy.BLUESKY, PlatformPolicy.MASTODON, PlatformPolicy.TELEGRAM -> {
                profiles += ANONYMOUS_DEFAULT
                profiles += MOBILE_BROWSER
                profiles += DESKTOP_BROWSER
            }
            else -> {
                profiles += ANONYMOUS_DEFAULT
                profiles += DESKTOP_BROWSER
                profiles += MOBILE_BROWSER
            }
        }

        if (settings.useCookies && CookieVault.bestProfile(context, sourceUrl) != null) {
            profiles += STORED_SESSION
        }

        val unique = profiles.distinctBy { it.id }.toMutableList()
        val preferred = preferredProfileId?.let(::profileById)
        if (preferred != null) {
            unique.removeAll { it.id == preferred.id }
            unique.add(0, preferred)
        }
        return unique
    }

    fun applyCommon(
        request: YoutubeDLRequest,
        tag: String,
        sourceUrl: String = "",
        profile: RequestProfile = STORED_SESSION
    ): AuthMaterial {
        request.addOption("--no-warnings")
        request.addOption("--socket-timeout", 30)
        val retryCount = if (settings.memoryMode == AppSettings.MEMORY_SAVER) 5 else 10
        request.addOption("--retries", retryCount)
        request.addOption("--fragment-retries", retryCount)
        request.addOption("--extractor-retries", if (settings.memoryMode == AppSettings.MEMORY_PERFORMANCE) 5 else 3)
        request.addOption("--retry-sleep", "http:exp=1:30")
        request.addOption("--retry-sleep", "fragment:exp=1:20")
        val effectiveFragments = when (settings.memoryMode) {
            AppSettings.MEMORY_SAVER -> 1
            AppSettings.MEMORY_BALANCED -> settings.concurrentFragments.coerceAtMost(2)
            else -> settings.concurrentFragments
        }
        request.addOption("--concurrent-fragments", effectiveFragments)
        request.addOption("--sleep-requests", settings.requestDelaySeconds)
        request.addOption("--sleep-interval", settings.requestDelaySeconds)
        request.addOption("--max-sleep-interval", (settings.requestDelaySeconds + 3).coerceAtMost(35))
        if (settings.speedLimitKbps > 0) request.addOption("--limit-rate", "${settings.speedLimitKbps}K")
        if (settings.remoteEjsEnabled) request.addOption("--remote-components", "ejs:github")
        profile.userAgent?.takeIf { it.isNotBlank() }?.let { request.addOption("--user-agent", it) }

        if (YtDlpPluginVault.hasPlugins(context)) {
            request.addOption("--plugin-dirs", YtDlpPluginVault.pluginDirectory(context).absolutePath)
        }
        if (settings.poTokenProviderEnabled && settings.poTokenProviderBaseUrl.isNotBlank()) {
            request.addOption(
                "--extractor-args",
                "youtubepot-bgutilhttp:base_url=${settings.poTokenProviderBaseUrl.trim()}"
            )
        }

        val youtubeArgs = buildYoutubeExtractorArgs(profile)
        if (youtubeArgs.isNotBlank()) request.addOption("--extractor-args", "youtube:$youtubeArgs")

        val cookieSelection = if (profile.allowStoredCookies && settings.useCookies) {
            CookieVault.bestProfile(context, sourceUrl)
        } else null
        val cookieFile = cookieSelection?.let { selection ->
            CookieVault.materialize(context, tag, selection.platform, selection.profileId)
                ?.also { request.addOption("--cookies", it.absolutePath) }
        }
        return AuthMaterial(cookieFile)
    }

    private fun buildYoutubeExtractorArgs(profile: RequestProfile): String {
        val args = mutableListOf<String>()
        val configuredClient = settings.youtubePlayerClient
            .trim()
            .takeUnless { it.isBlank() || it.equals("default", ignoreCase = true) }
        val client = profile.youtubePlayerClient
            ?: configuredClient.takeIf { profile.inheritConfiguredYoutubeClient }
        client?.takeIf { it.isNotBlank() }?.let { args += "player_client=$it" }
        args += "formats=incomplete"
        settings.youtubePoToken.takeIf { it.isNotBlank() }?.let { args += "po_token=$it" }
        settings.youtubeVisitorData.takeIf { it.isNotBlank() }?.let { args += "visitor_data=$it" }
        return args.joinToString(";")
    }

    companion object {
        const val PROFILE_HEADER = "X-Nova-Internal-Ytdlp-Profile"
        const val PROFILE_ANONYMOUS_DEFAULT = "anonymous-default"
        const val PROFILE_YOUTUBE_WEB_SAFARI = "youtube-web-safari"
        const val PROFILE_YOUTUBE_WEB_EMBEDDED = "youtube-web-embedded"
        const val PROFILE_YOUTUBE_ANDROID_VR = "youtube-android-vr"
        const val PROFILE_YOUTUBE_MWEB_PROVIDER = "youtube-mweb-provider"
        const val PROFILE_MOBILE_BROWSER = "mobile-browser"
        const val PROFILE_DESKTOP_BROWSER = "desktop-browser"
        const val PROFILE_STORED_SESSION = "stored-session"

        private const val MOBILE_USER_AGENT = "Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1"
        private const val DESKTOP_USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36"

        val ANONYMOUS_DEFAULT = RequestProfile(PROFILE_ANONYMOUS_DEFAULT)
        val YOUTUBE_WEB_SAFARI = RequestProfile(PROFILE_YOUTUBE_WEB_SAFARI, youtubePlayerClient = "web_safari")
        val YOUTUBE_WEB_EMBEDDED = RequestProfile(PROFILE_YOUTUBE_WEB_EMBEDDED, youtubePlayerClient = "web_embedded")
        val YOUTUBE_ANDROID_VR = RequestProfile(PROFILE_YOUTUBE_ANDROID_VR, youtubePlayerClient = "android_vr")
        val YOUTUBE_MWEB_PROVIDER = RequestProfile(PROFILE_YOUTUBE_MWEB_PROVIDER, youtubePlayerClient = "mweb")
        val MOBILE_BROWSER = RequestProfile(PROFILE_MOBILE_BROWSER, userAgent = MOBILE_USER_AGENT)
        val DESKTOP_BROWSER = RequestProfile(PROFILE_DESKTOP_BROWSER, userAgent = DESKTOP_USER_AGENT)
        val STORED_SESSION = RequestProfile(
            PROFILE_STORED_SESSION,
            allowStoredCookies = true,
            inheritConfiguredYoutubeClient = true
        )

        fun profileById(id: String?): RequestProfile? = when (id) {
            PROFILE_ANONYMOUS_DEFAULT -> ANONYMOUS_DEFAULT
            PROFILE_YOUTUBE_WEB_SAFARI -> YOUTUBE_WEB_SAFARI
            PROFILE_YOUTUBE_WEB_EMBEDDED -> YOUTUBE_WEB_EMBEDDED
            PROFILE_YOUTUBE_ANDROID_VR -> YOUTUBE_ANDROID_VR
            PROFILE_YOUTUBE_MWEB_PROVIDER -> YOUTUBE_MWEB_PROVIDER
            PROFILE_MOBILE_BROWSER -> MOBILE_BROWSER
            PROFILE_DESKTOP_BROWSER -> DESKTOP_BROWSER
            PROFILE_STORED_SESSION -> STORED_SESSION
            else -> null
        }
    }
}
