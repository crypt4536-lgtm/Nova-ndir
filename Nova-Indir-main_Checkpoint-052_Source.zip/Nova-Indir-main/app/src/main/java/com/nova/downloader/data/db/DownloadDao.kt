package com.nova.downloader.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface DownloadDao {
    @Query("SELECT * FROM downloads ORDER BY createdAt DESC LIMIT :limit")
    fun list(limit: Int = 500): List<DownloadEntity>

    @Query("SELECT * FROM downloads WHERE downloadId = :id LIMIT 1")
    fun get(id: Long): DownloadEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun upsert(item: DownloadEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun upsertAll(items: List<DownloadEntity>)

    @Query("DELETE FROM downloads WHERE downloadId = :id")
    fun delete(id: Long)

    @Query("DELETE FROM downloads")
    fun clear()

    @Query("DELETE FROM downloads WHERE downloadId NOT IN (SELECT downloadId FROM downloads ORDER BY createdAt DESC LIMIT :keep)")
    fun trim(keep: Int)
}
