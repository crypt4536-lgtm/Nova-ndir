package com.nova.downloader.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.nova.downloader.data.StoredDownload

@Entity(tableName = "downloads")
data class DownloadEntity(
    @PrimaryKey val downloadId: Long,
    val url: String,
    val title: String,
    val createdAt: Long,
    val status: Int,
    val reason: Int,
    val bytesDownloaded: Long,
    val totalBytes: Long,
    val outputUri: String?,
    val destinationTreeUri: String?,
    val mediaType: String?,
    val errorMessage: String?,
    val updatedAt: Long,
    val downloadUrl: String?,
    val referer: String?,
    val headersJson: String?,
    val partialFilePath: String?,
    val etag: String?,
    val lastModified: String?,
    val resumeSupported: Boolean,
    val retryCount: Int,
    val engine: String,
    val formatSelector: String?,
    val outputMode: String,
    val audioFormat: String?,
    val videoContainer: String?,
    val qualityId: String?,
    val audioLanguage: String?,
    val subtitleLanguages: String?,
    val writeSubtitles: Boolean,
    val writeAutoSubtitles: Boolean,
    val writeThumbnail: Boolean,
    val writeDescription: Boolean,
    val embedMetadata: Boolean,
    val embedChapters: Boolean,
    val playlistMode: String,
    val liveFromStart: Boolean,
    val duplicatePolicy: String,
    val checksumSha256: String?,
    val integrityVerified: Boolean
) {
    fun toStored() = StoredDownload(
        downloadId, url, title, createdAt, status, reason, bytesDownloaded, totalBytes,
        outputUri, destinationTreeUri, mediaType, errorMessage, updatedAt, downloadUrl,
        referer, headersJson, partialFilePath, etag, lastModified, resumeSupported,
        retryCount, engine, formatSelector, outputMode, audioFormat, videoContainer,
        qualityId, audioLanguage, subtitleLanguages, writeSubtitles, writeAutoSubtitles,
        writeThumbnail, writeDescription, embedMetadata, embedChapters, playlistMode,
        liveFromStart, duplicatePolicy, checksumSha256, integrityVerified
    )

    companion object {
        fun from(item: StoredDownload) = DownloadEntity(
            item.downloadId, item.url, item.title, item.createdAt, item.status, item.reason,
            item.bytesDownloaded, item.totalBytes, item.outputUri, item.destinationTreeUri,
            item.mediaType, item.errorMessage, item.updatedAt, item.downloadUrl, item.referer,
            item.headersJson, item.partialFilePath, item.etag, item.lastModified,
            item.resumeSupported, item.retryCount, item.engine, item.formatSelector,
            item.outputMode, item.audioFormat, item.videoContainer, item.qualityId,
            item.audioLanguage, item.subtitleLanguages, item.writeSubtitles,
            item.writeAutoSubtitles, item.writeThumbnail, item.writeDescription,
            item.embedMetadata, item.embedChapters, item.playlistMode, item.liveFromStart,
            item.duplicatePolicy, item.checksumSha256, item.integrityVerified
        )
    }
}
