package com.nova.downloader.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [DownloadEntity::class], version = 1, exportSchema = true)
abstract class NovaDatabase : RoomDatabase() {
    abstract fun downloads(): DownloadDao

    companion object {
        @Volatile private var instance: NovaDatabase? = null

        fun get(context: Context): NovaDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(
                context.applicationContext,
                NovaDatabase::class.java,
                "nova_downloads.db"
            )
                // The repository exposes a small synchronous API; all heavy transfer work runs off-main.
                // UI history is capped at 500 rows, so synchronous reads remain bounded.
                .allowMainThreadQueries()
                .build()
                .also { instance = it }
        }
    }
}
