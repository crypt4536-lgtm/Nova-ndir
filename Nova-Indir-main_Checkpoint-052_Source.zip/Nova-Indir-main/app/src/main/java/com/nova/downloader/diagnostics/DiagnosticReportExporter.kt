package com.nova.downloader.diagnostics

import android.app.ActivityManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import com.nova.downloader.BuildConfig
import com.nova.downloader.R
import com.nova.downloader.data.AppSettings
import com.nova.downloader.data.DownloadState
import com.nova.downloader.data.HistoryStore
import com.nova.downloader.engine.EngineRecoveryManager
import com.nova.downloader.i18n.AppText
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

object DiagnosticReportExporter {
    private const val PUBLIC_RELATIVE_PATH = "Download/NovaDownloader/Diagnostics/"

    fun create(context: Context): Result<File> = runCatching {
        val app = context.applicationContext
        val outputDir = File(app.cacheDir, "diagnostics")
        require(outputDir.isDirectory || outputDir.mkdirs()) { "Tanılama klasörü oluşturulamadı." }
        val file = File(outputDir, "nova-diagnostic-${System.currentTimeMillis()}.zip")
        val warnings = mutableListOf<String>()

        ZipOutputStream(FileOutputStream(file)).use { zip ->
            val report = runCatching { buildReport(app) }.getOrElse { error ->
                warnings += "report.json: ${error.javaClass.simpleName}: ${error.message.orEmpty()}"
                minimalReport(app, error)
            }
            addText(zip, "report.json", report.toString(2))
            addText(zip, "logger-status.json", JSONObject(LocalLog.diagnosticsStatus()).toString(2))

            val logs = LocalLog.listLogFiles()
            if (logs.isEmpty()) {
                addText(
                    zip,
                    "logs/README.txt",
                    "Nova yerel günlük dosyası bulunamadı. logger-status.json dosyasını kontrol edin."
                )
            } else {
                logs.forEach { log ->
                    runCatching { addFile(zip, "logs/${log.name}", log) }
                        .onFailure { warnings += "${log.name}: ${it.javaClass.simpleName}: ${it.message.orEmpty()}" }
                }
            }

            if (warnings.isNotEmpty()) addText(zip, "export-warnings.txt", warnings.joinToString("\n"))
            addText(zip, "privacy.txt", AppText.get(R.string.diagnostic_privacy_note))
        }
        require(file.isFile && file.length() > 0L) { "Tanılama ZIP dosyası boş oluşturuldu." }
        LocalLog.info("Diagnostics", "Diagnostic report created bytes=${file.length()}")
        file
    }

    /** Saves a durable copy that can be found without relying on the Android share sheet. */
    fun publishToDownloads(context: Context, file: File): Result<String> = runCatching {
        val name = file.name
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val resolver = context.contentResolver
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, name)
                put(MediaStore.Downloads.MIME_TYPE, "application/zip")
                put(MediaStore.Downloads.RELATIVE_PATH, PUBLIC_RELATIVE_PATH)
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: error("Tanılama ZIP'i İndirilenler'e kaydedilemedi.")
            try {
                resolver.openOutputStream(uri, "w")?.use { output ->
                    FileInputStream(file).use { input -> input.copyTo(output, 64 * 1024) }
                } ?: error("Tanılama ZIP'i için çıktı akışı açılamadı.")
                resolver.update(uri, ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }, null, null)
            } catch (error: Throwable) {
                runCatching { resolver.delete(uri, null, null) }
                throw error
            }
            "İndirilenler/NovaDownloader/Diagnostics/$name"
        } else {
            @Suppress("DEPRECATION")
            val root = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            val dir = File(root, "NovaDownloader/Diagnostics").apply {
                require(isDirectory || mkdirs()) { "Tanılama çıktı klasörü oluşturulamadı." }
            }
            val target = File(dir, name)
            FileInputStream(file).use { input -> FileOutputStream(target).use { output -> input.copyTo(output, 64 * 1024) } }
            target.absolutePath
        }
    }

    fun share(context: Context, file: File): Result<Unit> = runCatching {
        val uri: Uri = FileProvider.getUriForFile(context, "${context.packageName}.files", file)
        context.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
            type = "application/zip"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, AppText.get(R.string.diagnostic_report_subject))
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }, AppText.get(R.string.share_diagnostic_report)))
    }

    private fun buildReport(context: Context): JSONObject {
        val activityManager = context.getSystemService(ActivityManager::class.java)
        val memory = ActivityManager.MemoryInfo().also(activityManager::getMemoryInfo)
        val settings = AppSettings(context)
        val downloads = runCatching { HistoryStore(context).list() }.getOrElse { emptyList() }
        return JSONObject().apply {
            put("schema", 2)
            put("createdAt", System.currentTimeMillis())
            put("app", JSONObject().apply {
                put("package", context.packageName)
                put("versionName", BuildConfig.VERSION_NAME)
                put("versionCode", BuildConfig.VERSION_CODE)
                put("checkpoint", BuildConfig.NOVA_CHECKPOINT)
                put("flavor", BuildConfig.FLAVOR)
                put("hasFfmpeg", BuildConfig.HAS_FFMPEG)
            })
            put("device", JSONObject().apply {
                put("manufacturer", Build.MANUFACTURER)
                put("model", Build.MODEL)
                put("sdk", Build.VERSION.SDK_INT)
                put("release", Build.VERSION.RELEASE)
                put("supportedAbis", JSONArray(Build.SUPPORTED_ABIS.toList()))
                put("lowRamDevice", activityManager.isLowRamDevice)
                put("availableMemory", memory.availMem)
                put("totalMemory", memory.totalMem)
                put("lowMemory", memory.lowMemory)
            })
            put("settings", JSONObject().apply {
                put("language", settings.languageTag)
                put("outputMode", settings.defaultOutputMode)
                put("quality", settings.defaultQualityId)
                put("audioFormat", settings.defaultAudioFormat)
                put("videoContainer", settings.defaultVideoContainer)
                put("recoveryPolicy", settings.recoveryPolicy)
                put("cookiesEnabled", settings.useCookies)
                put("browserAutoDetect", settings.browserAutoDetectEnabled)
                put("petEnabled", settings.petEnabled)
                put("automaticUpdateChecks", settings.automaticUpdateChecks)
                put("memoryMode", settings.memoryMode)
            })
            put("engine", runCatching { EngineRecoveryManager(context).statusJson() }
                .getOrElse { JSONObject().put("error", LocalLog.redact(it.message.orEmpty())) })
            put("downloads", JSONObject().apply {
                put("total", downloads.size)
                put("active", downloads.count { it.status == DownloadState.RUNNING || it.status == DownloadState.PENDING })
                put("paused", downloads.count { it.status == DownloadState.PAUSED })
                put("failed", downloads.count { it.status == DownloadState.FAILED })
                put("completed", downloads.count { it.status == DownloadState.SUCCESSFUL })
                put("recent", JSONArray(downloads.take(20).map { item -> JSONObject().apply {
                    put("id", item.downloadId)
                    put("engine", item.engine)
                    put("status", item.status)
                    put("bytes", item.bytesDownloaded)
                    put("totalBytes", item.totalBytes)
                    put("updatedAt", item.updatedAt)
                    put("mediaType", item.mediaType)
                    put("container", item.videoContainer)
                    put("integrityVerified", item.integrityVerified)
                    put("error", item.errorMessage?.let(LocalLog::redact))
                } }))
            })
        }
    }

    private fun minimalReport(context: Context, error: Throwable): JSONObject = JSONObject().apply {
        put("schema", 2)
        put("createdAt", System.currentTimeMillis())
        put("app", JSONObject().apply {
            put("package", context.packageName)
            put("versionName", BuildConfig.VERSION_NAME)
            put("versionCode", BuildConfig.VERSION_CODE)
            put("checkpoint", BuildConfig.NOVA_CHECKPOINT)
        })
        put("reportBuildError", LocalLog.redact("${error.javaClass.name}: ${error.message.orEmpty()}"))
    }

    private fun addText(zip: ZipOutputStream, name: String, text: String) {
        zip.putNextEntry(ZipEntry(name))
        zip.write(text.toByteArray(Charsets.UTF_8))
        zip.closeEntry()
    }

    private fun addFile(zip: ZipOutputStream, name: String, file: File) {
        zip.putNextEntry(ZipEntry(name))
        FileInputStream(file).use { it.copyTo(zip) }
        zip.closeEntry()
    }
}
