package com.nova.downloader.diagnostics

import android.content.Context
import android.os.Process
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.nio.charset.StandardCharsets
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/** Local-only rotating log. Secrets, cookies and full URLs are redacted before writing. */
object LocalLog {
    private const val MAX_FILE_BYTES = 512L * 1024L
    private const val MAX_FILES = 3
    private const val MAX_MESSAGE_CHARS = 8_000
    @Volatile private var appContext: Context? = null
    @Volatile private var installedHandler = false
    @Volatile private var lastWriteFailure: String? = null
    private val writeMonitor = Any()

    fun initialize(context: Context) {
        appContext = context.applicationContext
        if (!installedHandler) synchronized(this) {
            if (!installedHandler) {
                val previous = Thread.getDefaultUncaughtExceptionHandler()
                Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
                    error("Crash", "Uncaught exception on ${thread.name}", throwable)
                    previous?.uncaughtException(thread, throwable)
                }
                installedHandler = true
            }
        }
        info("App", "Nova process started pid=${Process.myPid()}")
    }

    fun debug(tag: String, message: String) = write("D", tag, message, null)
    fun info(tag: String, message: String) = write("I", tag, message, null)
    fun warn(tag: String, message: String, error: Throwable? = null) = write("W", tag, message, error)
    fun error(tag: String, message: String, error: Throwable? = null) = write("E", tag, message, error)

    fun listLogFiles(): List<File> = logDirectory()?.listFiles()
        ?.filter { it.isFile && it.name.startsWith("nova-") && it.extension == "log" }
        ?.sortedByDescending(File::lastModified)
        .orEmpty()

    fun diagnosticsStatus(): Map<String, Any?> {
        val dir = logDirectory()
        return linkedMapOf(
            "initialized" to (appContext != null),
            "directory" to dir?.absolutePath,
            "directoryExists" to (dir?.isDirectory == true),
            "directoryWritable" to (dir?.canWrite() == true),
            "logCount" to listLogFiles().size,
            "lastWriteFailure" to lastWriteFailure
        )
    }

    fun clear() {
        listLogFiles().forEach { runCatching { it.delete() } }
        lastWriteFailure = null
    }

    private fun write(level: String, tag: String, message: String, error: Throwable?) {
        val dir = logDirectory() ?: return
        val payload = buildPayload(level, tag, message, error)
        synchronized(writeMonitor) {
            val result = runCatching {
                if (!dir.exists() && !dir.mkdirs()) error("Cannot create diagnostics directory: ${dir.absolutePath}")
                rotateIfNeeded(dir)
                val target = File(dir, "nova-0.log")
                RandomAccessFile(target, "rw").use { raf ->
                    raf.channel.use { channel ->
                        channel.lock().use {
                            raf.seek(raf.length())
                            raf.write(payload)
                        }
                    }
                }
            }
            if (result.isSuccess) {
                lastWriteFailure = null
            } else {
                // FileChannel locking can fail on some vendor builds or during overlapping writes.
                // Keep diagnostics alive with a process-specific append-only fallback instead of
                // silently dropping the very error that we are trying to diagnose.
                val cause = result.exceptionOrNull()
                lastWriteFailure = "${cause?.javaClass?.simpleName}: ${cause?.message.orEmpty()}".take(500)
                runCatching {
                    if (!dir.exists()) dir.mkdirs()
                    val fallback = File(dir, "nova-fallback-${Process.myPid()}.log")
                    FileOutputStream(fallback, true).use { it.write(payload) }
                }
            }
        }
    }

    private fun buildPayload(level: String, tag: String, message: String, error: Throwable?): ByteArray = buildString {
        append(timestamp()).append(' ')
        append(level).append('/').append(safeTag(tag)).append(' ')
        append("pid=").append(Process.myPid()).append(' ')
        append(redact(message))
        if (error != null) {
            append('\n').append(redact(error.stackTraceToString()))
        }
        append('\n')
    }.take(MAX_MESSAGE_CHARS).toByteArray(StandardCharsets.UTF_8)

    private fun rotateIfNeeded(dir: File) {
        val active = File(dir, "nova-0.log")
        if (!active.exists() || active.length() < MAX_FILE_BYTES) return
        for (index in MAX_FILES - 1 downTo 1) {
            val previous = File(dir, "nova-${index - 1}.log")
            val next = File(dir, "nova-$index.log")
            if (next.exists()) next.delete()
            if (previous.exists()) previous.renameTo(next)
        }
    }

    private fun logDirectory(): File? = appContext?.let { File(it.filesDir, "diagnostics") }

    private fun timestamp(): String = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US).apply {
        timeZone = TimeZone.getTimeZone("UTC")
    }.format(Date())

    private fun safeTag(tag: String): String = tag.replace(Regex("[^A-Za-z0-9_.-]"), "_").take(48)

    fun redact(raw: String): String {
        var value = raw
        value = value.replace(Regex("(?i)(authorization|proxy-authorization|cookie|set-cookie|po[_ -]?token|visitor[_ -]?data)\\s*[:=]\\s*[^\\s,;]+"), "$1=<redacted>")
        value = value.replace(Regex("(?i)([?&](?:token|key|sig|signature|auth|session|cookie|code)=)[^&\\s]+"), "$1<redacted>")
        value = value.replace(Regex("https?://[^\\s)\\]}]+")) { match ->
            runCatching {
                val uri = java.net.URI(match.value)
                val path = uri.path.orEmpty().take(120)
                "${uri.scheme}://${uri.host ?: "host"}$path"
            }.getOrDefault("<url>")
        }
        return value.take(MAX_MESSAGE_CHARS)
    }
}
