package com.nova.downloader.engine

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.Message
import android.os.Messenger
import com.nova.downloader.R
import com.nova.downloader.i18n.AppText
import com.nova.downloader.service.EngineMaintenanceService
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicReference

object EngineMaintenanceClient {
    data class Result(val success: Boolean, val message: String)

    fun run(context: Context, command: String): Result {
        val app = context.applicationContext
        val latch = CountDownLatch(1)
        val output = AtomicReference<Result>()
        val reply = Messenger(object : Handler(Looper.getMainLooper()) {
            override fun handleMessage(message: Message) {
                if (message.what != EngineMaintenanceService.MSG_RESULT) return
                output.set(Result(message.data.getBoolean(EngineMaintenanceService.KEY_SUCCESS), message.data.getString(EngineMaintenanceService.KEY_MESSAGE).orEmpty()))
                latch.countDown()
            }
        })
        lateinit var connection: ServiceConnection
        connection = object : ServiceConnection {
            override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
                runCatching {
                    val remote = binder ?: error(AppText.get(R.string.engine_service_connection_failed))
                    Messenger(remote).send(Message.obtain(null, EngineMaintenanceService.MSG_RUN).apply {
                        replyTo = reply
                        data = Bundle().apply { putString(EngineMaintenanceService.KEY_COMMAND, command) }
                    })
                }.onFailure {
                    output.set(Result(false, it.message ?: AppText.get(R.string.engine_service_connection_failed)))
                    latch.countDown()
                }
            }
            override fun onServiceDisconnected(name: ComponentName?) {
                if (output.get() == null) {
                    output.set(Result(false, AppText.get(R.string.engine_service_disconnected)))
                    latch.countDown()
                }
            }
        }
        if (!app.bindService(Intent(app, EngineMaintenanceService::class.java), connection, Context.BIND_AUTO_CREATE)) {
            return Result(false, AppText.get(R.string.engine_service_connection_failed))
        }
        return try {
            if (!latch.await(90, TimeUnit.SECONDS)) Result(false, AppText.get(R.string.engine_service_timeout))
            else output.get() ?: Result(false, AppText.get(R.string.engine_service_no_result))
        } finally {
            runCatching { app.unbindService(connection) }
        }
    }
}
