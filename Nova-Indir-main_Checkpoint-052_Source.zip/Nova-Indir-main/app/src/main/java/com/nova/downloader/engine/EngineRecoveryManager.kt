package com.nova.downloader.engine

import android.content.Context
import com.nova.downloader.R
import com.nova.downloader.diagnostics.LocalLog
import com.nova.downloader.i18n.AppText
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.security.MessageDigest

/**
 * Stages yt-dlp updates, retains known-good snapshots and automatically rolls back
 * after repeated engine-level failures. Downloads and user media are never touched.
 */
class EngineRecoveryManager(context: Context) {
    private val appContext = context.applicationContext
    private val prefs = appContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private val baseDir = File(appContext.noBackupFilesDir, "youtubedl-android")
    private val ytdlpDir = File(baseDir, YoutubeDL.ytdlpDirName)
    private val activeBinary = File(ytdlpDir, YoutubeDL.ytdlpBin)
    private val snapshotDir = File(appContext.noBackupFilesDir, "nova-engine/snapshots")

    data class OperationResult(val success: Boolean, val message: String, val version: String = "")

    fun ensureUpdated(channel: YoutubeDL.UpdateChannel, maxAgeMs: Long = UPDATE_CHECK_INTERVAL_MS): OperationResult {
        val key = KEY_LAST_UPDATE_PREFIX + channelName(channel)
        val last = prefs.getLong(key, 0L)
        if (last > 0L && System.currentTimeMillis() - last < maxAgeMs) {
            val version = runCatching { YoutubeDL.getInstance().init(appContext); currentVersion() }.getOrDefault("")
            return OperationResult(true, AppText.get(R.string.engine_update_recent, version.ifBlank { AppText.get(R.string.unknown) }), version)
        }
        val result = update(channel)
        if (result.success) prefs.edit().putLong(key, System.currentTimeMillis()).apply()
        return result
    }

    @Synchronized
    fun update(channel: YoutubeDL.UpdateChannel): OperationResult {
        return runCatching {
            YoutubeDL.getInstance().init(appContext)
            val beforeVersion = currentVersion()
            val beforeSnapshot = snapshotCurrent("before-${channelName(channel)}-$beforeVersion")
            prefs.edit().putString(KEY_PREVIOUS_SNAPSHOT, beforeSnapshot?.absolutePath.orEmpty()).apply()
            val status = YoutubeDL.getInstance().updateYoutubeDL(appContext, channel)
            val health = healthCheck()
            if (!health.first) {
                if (beforeSnapshot != null) restoreSnapshot(beforeSnapshot)
                error(AppText.get(R.string.engine_update_health_failed, health.second))
            }
            val version = health.second.ifBlank { currentVersion() }
            snapshotCurrent("good-$version")
            markHealthy(version, channelName(channel))
            pruneSnapshots()
            LocalLog.info("Engine", "Engine update channel=${channelName(channel)} status=$status version=$version")
            OperationResult(true, AppText.get(R.string.engine_update_success, version), version)
        }.getOrElse { error ->
            LocalLog.error("Engine", "Engine update failed", error)
            OperationResult(false, error.message ?: AppText.get(R.string.engine_update_failed))
        }
    }

    @Synchronized
    fun rollback(): OperationResult {
        val previous = prefs.getString(KEY_PREVIOUS_SNAPSHOT, null)?.takeIf(String::isNotBlank)?.let(::File)
            ?: snapshotDir.listFiles()?.filter(File::isFile)?.sortedByDescending(File::lastModified)?.getOrNull(1)
            ?: return OperationResult(false, AppText.get(R.string.engine_no_rollback_snapshot))
        return runCatching {
            snapshotCurrent("failed-${currentVersion()}")
            restoreSnapshot(previous)
            val health = healthCheck()
            require(health.first) { AppText.get(R.string.engine_rollback_health_failed) }
            markHealthy(health.second, "rollback")
            LocalLog.warn("Engine", "Rolled back engine to ${health.second}")
            OperationResult(true, AppText.get(R.string.engine_rollback_success, health.second), health.second)
        }.getOrElse { error ->
            LocalLog.error("Engine", "Engine rollback failed", error)
            OperationResult(false, error.message ?: AppText.get(R.string.engine_rollback_failed))
        }
    }

    @Synchronized
    fun restoreBundled(): OperationResult = runCatching {
        YoutubeDL.getInstance().init(appContext)
        snapshotCurrent("before-bundled-${currentVersion()}")?.also {
            prefs.edit().putString(KEY_PREVIOUS_SNAPSHOT, it.absolutePath).apply()
        }
        if (activeBinary.exists()) activeBinary.delete()
        YoutubeDL.getInstance().init_ytdlp(appContext, ytdlpDir)
        val health = healthCheck()
        require(health.first) { AppText.get(R.string.engine_bundled_health_failed) }
        markHealthy(health.second, "bundled")
        LocalLog.warn("Engine", "Restored bundled engine ${health.second}")
        OperationResult(true, AppText.get(R.string.engine_bundled_restored, health.second), health.second)
    }.getOrElse { error ->
        LocalLog.error("Engine", "Bundled engine restore failed", error)
        OperationResult(false, error.message ?: AppText.get(R.string.engine_bundled_restore_failed))
    }

    fun recordSuccess() {
        val version = runCatching { currentVersion() }.getOrDefault("")
        prefs.edit()
            .putInt(KEY_FAILURE_COUNT, 0)
            .putLong(KEY_FAILURE_WINDOW_START, 0L)
            .putString(KEY_ACTIVE_VERSION, version)
            .putString(KEY_LAST_GOOD_VERSION, version)
            .apply()
    }

    /** Returns a localized rollback note when automatic rollback was performed. */
    fun recordFailure(rawMessage: String, sourceHost: String? = null): String? {
        if (!isEngineFailure(rawMessage)) return null
        val now = System.currentTimeMillis()
        val windowStart = prefs.getLong(KEY_FAILURE_WINDOW_START, 0L)
        val withinWindow = windowStart > 0L && now - windowStart <= FAILURE_WINDOW_MS
        val count = if (withinWindow) prefs.getInt(KEY_FAILURE_COUNT, 0) + 1 else 1
        prefs.edit()
            .putInt(KEY_FAILURE_COUNT, count)
            .putLong(KEY_FAILURE_WINDOW_START, if (withinWindow) windowStart else now)
            .putString(KEY_LAST_FAILURE_HOST, sourceHost.orEmpty())
            .apply()
        LocalLog.warn("Engine", "Engine-level failure count=$count host=${sourceHost.orEmpty()} message=${LocalLog.redact(rawMessage)}")
        if (count < FAILURE_THRESHOLD) return null
        val result = rollback()
        prefs.edit().putInt(KEY_FAILURE_COUNT, 0).putLong(KEY_FAILURE_WINDOW_START, 0L).apply()
        return if (result.success) AppText.get(R.string.engine_auto_rollback_done, result.version)
        else AppText.get(R.string.engine_auto_rollback_failed, result.message)
    }

    fun statusText(): String {
        val version = runCatching { currentVersion() }.getOrDefault(prefs.getString(KEY_ACTIVE_VERSION, "").orEmpty())
        val channel = prefs.getString(KEY_ACTIVE_CHANNEL, "bundled").orEmpty()
        val failures = prefs.getInt(KEY_FAILURE_COUNT, 0)
        val snapshots = snapshotDir.listFiles()?.count(File::isFile) ?: 0
        return AppText.get(R.string.engine_status_format, version.ifBlank { AppText.get(R.string.unknown) }, channel, failures, snapshots)
    }

    fun statusJson(): JSONObject = JSONObject().apply {
        put("version", prefs.getString(KEY_ACTIVE_VERSION, ""))
        put("lastGoodVersion", prefs.getString(KEY_LAST_GOOD_VERSION, ""))
        put("channel", prefs.getString(KEY_ACTIVE_CHANNEL, "bundled"))
        put("failureCount", prefs.getInt(KEY_FAILURE_COUNT, 0))
        put("snapshots", snapshotDir.listFiles()?.count(File::isFile) ?: 0)
        put("binarySha256", runCatching { sha256(activeBinary) }.getOrDefault(""))
    }

    private fun healthCheck(): Pair<Boolean, String> = runCatching {
        val response = YoutubeDL.getInstance().execute(
            YoutubeDLRequest(emptyList()).addOption("--version"),
            "nova_engine_health_${System.nanoTime()}"
        )
        val version = response.out.trim().lineSequence().firstOrNull().orEmpty()
        require(version.matches(Regex("[0-9]{4}\\.[0-9]{2}\\.[0-9]{2}.*"))) { AppText.get(R.string.engine_invalid_version_output) }
        true to version
    }.getOrElse { false to (it.message ?: AppText.get(R.string.engine_health_check_error)) }

    private fun markHealthy(version: String, channel: String) {
        prefs.edit()
            .putString(KEY_ACTIVE_VERSION, version)
            .putString(KEY_LAST_GOOD_VERSION, version)
            .putString(KEY_ACTIVE_CHANNEL, channel)
            .putInt(KEY_FAILURE_COUNT, 0)
            .putLong(KEY_FAILURE_WINDOW_START, 0L)
            .apply()
    }

    private fun currentVersion(): String = YoutubeDL.getInstance().versionName(appContext).orEmpty()
        .ifBlank { prefs.getString(KEY_ACTIVE_VERSION, "bundled").orEmpty() }

    private fun snapshotCurrent(label: String): File? {
        if (!activeBinary.isFile || activeBinary.length() <= 0L) return null
        snapshotDir.mkdirs()
        val safe = label.replace(Regex("[^A-Za-z0-9_.-]"), "_").take(80)
        val hash = sha256(activeBinary).take(12)
        val target = File(snapshotDir, "${System.currentTimeMillis()}-$safe-$hash.bin")
        copyAtomic(activeBinary, target)
        return target
    }

    private fun restoreSnapshot(snapshot: File) {
        require(snapshot.isFile && snapshot.length() > 0L) { AppText.get(R.string.engine_snapshot_invalid) }
        ytdlpDir.mkdirs()
        copyAtomic(snapshot, activeBinary)
        require(sha256(snapshot) == sha256(activeBinary)) { AppText.get(R.string.engine_snapshot_hash_mismatch) }
    }

    private fun copyAtomic(source: File, target: File) {
        target.parentFile?.mkdirs()
        val temporary = File(target.parentFile, ".${target.name}.${System.nanoTime()}.tmp")
        FileInputStream(source).use { input -> FileOutputStream(temporary).use { output -> input.copyTo(output); output.fd.sync() } }
        if (target.exists() && !target.delete()) error(AppText.get(R.string.engine_replace_failed))
        if (!temporary.renameTo(target)) {
            FileInputStream(temporary).use { input -> FileOutputStream(target).use { output -> input.copyTo(output); output.fd.sync() } }
            temporary.delete()
        }
        target.setExecutable(true, true)
    }

    private fun pruneSnapshots() {
        snapshotDir.listFiles()?.filter(File::isFile)?.sortedByDescending(File::lastModified)
            ?.drop(MAX_SNAPSHOTS)?.forEach { it.delete() }
    }

    private fun isEngineFailure(message: String): Boolean {
        val value = message.lowercase()
        return ENGINE_FAILURE_MARKERS.any(value::contains)
    }

    private fun channelName(channel: YoutubeDL.UpdateChannel): String = when (channel) {
        YoutubeDL.UpdateChannel.NIGHTLY -> "nightly"
        YoutubeDL.UpdateChannel.MASTER -> "master"
        else -> "stable"
    }

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        FileInputStream(file).use { input ->
            val buffer = ByteArray(64 * 1024)
            while (true) {
                val read = input.read(buffer)
                if (read <= 0) break
                digest.update(buffer, 0, read)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    companion object {
        private const val PREFS = "nova_engine_recovery"
        private const val KEY_ACTIVE_VERSION = "active_version"
        private const val KEY_LAST_GOOD_VERSION = "last_good_version"
        private const val KEY_ACTIVE_CHANNEL = "active_channel"
        private const val KEY_PREVIOUS_SNAPSHOT = "previous_snapshot"
        private const val KEY_FAILURE_COUNT = "failure_count"
        private const val KEY_FAILURE_WINDOW_START = "failure_window_start"
        private const val KEY_LAST_FAILURE_HOST = "last_failure_host"
        private const val KEY_LAST_UPDATE_PREFIX = "last_update_"
        private const val FAILURE_THRESHOLD = 3
        private const val FAILURE_WINDOW_MS = 24L * 60L * 60L * 1000L
        private const val MAX_SNAPSHOTS = 3
        private const val UPDATE_CHECK_INTERVAL_MS = 24L * 60L * 60L * 1000L
        private val ENGINE_FAILURE_MARKERS = listOf(
            "unable to extract", "cannot parse", "no video formats", "unsupported url",
            "failed to fetch video information", "python", "traceback", "requested format"
        )
    }
}
