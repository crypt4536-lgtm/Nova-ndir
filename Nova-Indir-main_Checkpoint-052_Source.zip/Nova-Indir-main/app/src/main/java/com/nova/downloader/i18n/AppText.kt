package com.nova.downloader.i18n

import android.app.Application
import androidx.annotation.StringRes

/** Central access to localized resources for non-UI components. */
object AppText {
    @Volatile private var app: Application? = null

    fun init(application: Application) {
        app = application
    }

    fun get(@StringRes id: Int, vararg args: Any): String {
        val application = checkNotNull(app) { "AppText is not initialized" }
        val context = LocaleController.localizedContext(application)
        return context.resources.getString(id, *args)
    }
}
