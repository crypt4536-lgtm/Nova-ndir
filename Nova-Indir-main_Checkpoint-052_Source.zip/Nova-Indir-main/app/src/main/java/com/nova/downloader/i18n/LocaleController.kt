package com.nova.downloader.i18n

import android.app.LocaleManager
import android.content.Context
import android.content.res.Configuration
import android.os.Build
import android.os.LocaleList
import java.util.Locale

object LocaleController {
    const val SYSTEM = "system"
    const val TURKISH = "tr"
    const val ENGLISH = "en"
    const val SWEDISH = "sv"
    const val FRENCH = "fr"
    const val SPANISH = "es"
    const val JAPANESE = "ja"
    const val CHINESE_SIMPLIFIED = "zh-CN"
    const val GERMAN = "de"
    val supported = listOf(
        SYSTEM,
        TURKISH,
        ENGLISH,
        SWEDISH,
        FRENCH,
        SPANISH,
        JAPANESE,
        CHINESE_SIMPLIFIED,
        GERMAN
    )

    private const val PREFS = "nova_downloader_settings"
    private const val KEY = "language_tag"

    fun selectedLanguage(context: Context): String =
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY, SYSTEM).orEmpty().takeIf { it in supported } ?: SYSTEM

    fun setLanguage(context: Context, tag: String) {
        val normalized = tag.takeIf { it in supported } ?: SYSTEM
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY, normalized).apply()
        if (Build.VERSION.SDK_INT >= 33) {
            val manager = context.getSystemService(LocaleManager::class.java)
            manager.applicationLocales = if (normalized == SYSTEM) LocaleList.getEmptyLocaleList()
            else LocaleList.forLanguageTags(normalized)
        }
    }

    fun localizedContext(context: Context): Context {
        if (Build.VERSION.SDK_INT >= 33) return context
        val tag = selectedLanguage(context)
        if (tag == SYSTEM) return context
        val locale = Locale.forLanguageTag(tag)
        val configuration = Configuration(context.resources.configuration)
        configuration.setLocale(locale)
        configuration.setLocales(LocaleList(locale))
        return context.createConfigurationContext(configuration)
    }
}
