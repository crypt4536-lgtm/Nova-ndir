package com.nova.downloader.i18n

import android.app.Activity
import android.content.Context

abstract class LocalizedActivity : Activity() {
    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(LocaleController.localizedContext(newBase))
    }
}
