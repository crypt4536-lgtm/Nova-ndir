package com.nova.downloader.runtime

import android.content.Context
import com.nova.downloader.BuildConfig
import com.nova.downloader.R
import com.nova.downloader.i18n.AppText

object FfmpegRuntime {
    fun initialize(context: Context) {
        if (!BuildConfig.HAS_FFMPEG) return
        val clazz = Class.forName("com.yausername.ffmpeg.FFmpeg")
        val instance = clazz.getMethod("getInstance").invoke(null)
        clazz.getMethod("init", Context::class.java).invoke(instance, context.applicationContext)
    }

    fun requireAvailable() {
        require(BuildConfig.HAS_FFMPEG) { AppText.get(R.string.ffmpeg_not_available_lite) }
    }
}
