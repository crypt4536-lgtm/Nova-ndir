package com.nova.downloader.runtime

import android.os.Handler
import android.os.Looper
import android.os.Process
import java.util.concurrent.atomic.AtomicInteger

/** Releases the dedicated media process after Python/FFmpeg become idle. */
object MediaProcessState {
    private val activeResolvers = AtomicInteger(0)
    private val activeDownloads = AtomicInteger(0)
    private val handler = Handler(Looper.getMainLooper())
    private val exitRunnable = Runnable {
        if (activeResolvers.get() == 0 && activeDownloads.get() == 0) {
            Process.killProcess(Process.myPid())
        }
    }

    fun resolverStarted() { activeResolvers.incrementAndGet(); handler.removeCallbacks(exitRunnable) }
    fun resolverFinished() { activeResolvers.updateAndGet { value -> (value - 1).coerceAtLeast(0) }; scheduleExit() }
    fun downloadStarted() { activeDownloads.incrementAndGet(); handler.removeCallbacks(exitRunnable) }
    fun downloadFinished() { activeDownloads.updateAndGet { value -> (value - 1).coerceAtLeast(0) }; scheduleExit() }
    fun hasActiveDownloads(): Boolean = activeDownloads.get() > 0

    private fun scheduleExit() {
        handler.removeCallbacks(exitRunnable)
        handler.postDelayed(exitRunnable, IDLE_EXIT_DELAY_MS)
    }

    private const val IDLE_EXIT_DELAY_MS = 15_000L
}
