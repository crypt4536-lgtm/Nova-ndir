package com.nova.downloader.service

import com.nova.downloader.distribution.PetIntegration

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import com.nova.downloader.R
import com.nova.downloader.data.AppSettings
import com.nova.downloader.data.DefaultMediaSelectionPolicy
import com.nova.downloader.data.DownloadRepository
import com.nova.downloader.data.LinkResolver
import com.nova.downloader.data.ResolutionTaskStore
import com.nova.downloader.data.ResolvedDownloadCodec
import com.nova.downloader.diagnostics.LocalLog
import com.nova.downloader.i18n.AppText
import com.nova.downloader.runtime.MediaProcessState
import com.nova.downloader.ui.MainActivity
import java.util.concurrent.Executors
import java.util.concurrent.Future

/**
 * Foreground resolver that remains alive when Nova's activity is backgrounded.
 * Results are persisted before any UI notification is sent.
 */
class BackgroundResolutionService : Service() {
    private val executor = Executors.newSingleThreadExecutor()
    private lateinit var tasks: ResolutionTaskStore
    private lateinit var notifications: NotificationManager
    private var activeFuture: Future<*>? = null
    private var activeTaskId: Long = -1L

    override fun onCreate() {
        super.onCreate()
        tasks = ResolutionTaskStore(this)
        notifications = getSystemService(NotificationManager::class.java)
        createChannels()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_CANCEL -> {
                val id = intent.getLongExtra(ResolutionTaskStore.EXTRA_TASK_ID, -1L)
                if (id > 0L) cancelTask(id)
                return START_NOT_STICKY
            }
            ACTION_START -> {
                val id = intent.getLongExtra(ResolutionTaskStore.EXTRA_TASK_ID, -1L)
                val task = tasks.get(id) ?: return START_NOT_STICKY
                activeTaskId = id
                startForeground(FOREGROUND_NOTIFICATION_ID, resolvingNotification(task.sourceUrl))
                activeFuture?.cancel(true)
                activeFuture = executor.submit { resolve(task.id) }
                return START_REDELIVER_INTENT
            }
            else -> return START_NOT_STICKY
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onTimeout(startId: Int, fgsType: Int) {
        if (activeTaskId > 0L) {
            tasks.update(activeTaskId, ResolutionTaskStore.STATE_ERROR, message = AppText.get(R.string.background_resolution_timeout))
            broadcastChanged(activeTaskId)
        }
        activeFuture?.cancel(true)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf(startId)
    }

    override fun onDestroy() {
        activeFuture?.cancel(true)
        executor.shutdownNow()
        super.onDestroy()
    }

    private fun resolve(taskId: Long) {
        val task = tasks.get(taskId) ?: return
        val wakeLock = acquireWakeLock(taskId)
        MediaProcessState.resolverStarted()
        tasks.update(taskId, ResolutionTaskStore.STATE_RUNNING)
        broadcastChanged(taskId)
        PetIntegration.refreshMaybe(this)
        try {
            val result = LinkResolver(this).resolve(task.sourceUrl)
            if (tasks.get(taskId)?.state == ResolutionTaskStore.STATE_CANCELLED) return
            when (result) {
                is LinkResolver.Result.Ready -> onReady(taskId, result)
                is LinkResolver.Result.Unsupported -> {
                    tasks.update(taskId, ResolutionTaskStore.STATE_UNSUPPORTED, message = result.message)
                    notifyResult(taskId, AppText.get(R.string.video_stream_unresolved), result.message, success = false)
                }
                is LinkResolver.Result.Error -> {
                    tasks.update(taskId, ResolutionTaskStore.STATE_ERROR, message = result.message)
                    notifyResult(taskId, AppText.get(R.string.resolution_failed_title), result.message, success = false)
                }
            }
        } catch (error: InterruptedException) {
            Thread.currentThread().interrupt()
            tasks.update(taskId, ResolutionTaskStore.STATE_CANCELLED, message = AppText.get(R.string.resolution_cancelled))
        } catch (error: Exception) {
            LocalLog.error("BackgroundResolver", "Resolution failed task=$taskId", error)
            tasks.update(
                taskId,
                ResolutionTaskStore.STATE_ERROR,
                message = error.message ?: AppText.get(R.string.media_resolver_start_failed)
            )
            notifyResult(
                taskId,
                AppText.get(R.string.resolution_failed_title),
                error.message ?: AppText.get(R.string.media_resolver_start_failed),
                success = false
            )
        } finally {
            runCatching { if (wakeLock?.isHeld == true) wakeLock.release() }
            MediaProcessState.resolverFinished()
            broadcastChanged(taskId)
            PetIntegration.refreshMaybe(this)
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    private fun onReady(taskId: Long, result: LinkResolver.Result.Ready) {
        val settings = AppSettings(this)
        val autoStart = !settings.confirmEachDownload || settings.autoStartAfterResolution
        if (autoStart) {
            val selected = DefaultMediaSelectionPolicy.apply(result.download, settings)
            when (val enqueued = DownloadRepository(this).enqueue(
                selected,
                selected.title,
                settings.defaultTreeUri
            )) {
                is DownloadRepository.EnqueueResult.Success -> {
                    tasks.update(
                        taskId,
                        ResolutionTaskStore.STATE_AUTO_ENQUEUED,
                        message = enqueued.item.title,
                        downloadId = enqueued.item.downloadId
                    )
                    if (settings.resolutionReadyNotifications) {
                        notifyResult(
                            taskId,
                            AppText.get(R.string.background_download_started_title),
                            enqueued.item.title,
                            success = true
                        )
                    }
                }
                is DownloadRepository.EnqueueResult.Error -> {
                    tasks.update(taskId, ResolutionTaskStore.STATE_ERROR, message = enqueued.message)
                    notifyResult(taskId, AppText.get(R.string.resolution_failed_title), enqueued.message, success = false)
                }
            }
        } else {
            tasks.update(
                taskId,
                ResolutionTaskStore.STATE_READY,
                payload = ResolvedDownloadCodec.encode(result.download),
                message = result.download.title
            )
            if (settings.resolutionReadyNotifications) {
                notifyResult(
                    taskId,
                    AppText.get(R.string.video_ready_title),
                    AppText.get(R.string.video_ready_tap_to_choose, result.download.title),
                    success = true
                )
            }
        }
    }

    private fun cancelTask(taskId: Long) {
        tasks.update(taskId, ResolutionTaskStore.STATE_CANCELLED, message = AppText.get(R.string.resolution_cancelled))
        activeFuture?.cancel(true)
        notifications.cancel(FOREGROUND_NOTIFICATION_ID)
        broadcastChanged(taskId)
        PetIntegration.refreshMaybe(this)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun resolvingNotification(sourceUrl: String): Notification {
        val cancel = PendingIntent.getService(
            this,
            FOREGROUND_NOTIFICATION_ID + 1,
            Intent(this, BackgroundResolutionService::class.java)
                .setAction(ACTION_CANCEL)
                .putExtra(ResolutionTaskStore.EXTRA_TASK_ID, activeTaskId),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val open = PendingIntent.getActivity(
            this,
            FOREGROUND_NOTIFICATION_ID,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL_RESOLUTION)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle(AppText.get(R.string.resolving_video))
            .setContentText(AppText.get(R.string.background_resolution_continues))
            .setSubText(runCatching { java.net.URI(sourceUrl).host }.getOrNull())
            .setOngoing(true)
            .setProgress(0, 0, true)
            .setContentIntent(open)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, AppText.get(R.string.cancel_resolution), cancel)
            .build()
    }

    private fun notifyResult(taskId: Long, title: String, text: String, success: Boolean) {
        val open = PendingIntent.getActivity(
            this,
            resultNotificationId(taskId),
            Intent(this, MainActivity::class.java)
                .putExtra(MainActivity.EXTRA_RESOLUTION_ID, taskId)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        notifications.notify(
            resultNotificationId(taskId),
            Notification.Builder(this, CHANNEL_RESULTS)
                .setSmallIcon(if (success) android.R.drawable.stat_sys_download_done else android.R.drawable.stat_notify_error)
                .setContentTitle(title)
                .setContentText(text.take(140))
                .setStyle(Notification.BigTextStyle().bigText(text.take(800)))
                .setAutoCancel(true)
                .setContentIntent(open)
                .build()
        )
    }

    private fun broadcastChanged(taskId: Long) {
        sendBroadcast(
            Intent(ResolutionTaskStore.ACTION_CHANGED)
                .setPackage(packageName)
                .putExtra(ResolutionTaskStore.EXTRA_TASK_ID, taskId)
        )
    }

    private fun createChannels() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        notifications.createNotificationChannel(
            NotificationChannel(
                CHANNEL_RESOLUTION,
                AppText.get(R.string.resolution_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply { description = AppText.get(R.string.resolution_channel_description) }
        )
        notifications.createNotificationChannel(
            NotificationChannel(
                CHANNEL_RESULTS,
                AppText.get(R.string.result_alert_channel_name),
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply { description = AppText.get(R.string.result_alert_channel_description) }
        )
    }

    private fun acquireWakeLock(taskId: Long): PowerManager.WakeLock? = runCatching {
        val manager = getSystemService(Context.POWER_SERVICE) as PowerManager
        manager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "NovaDownloader:resolve:$taskId").apply {
            setReferenceCounted(false)
            acquire(MAX_WAKE_LOCK_MS)
        }
    }.getOrNull()

    companion object {
        private const val ACTION_START = "com.nova.downloader.action.BACKGROUND_RESOLVE"
        private const val ACTION_CANCEL = "com.nova.downloader.action.CANCEL_BACKGROUND_RESOLVE"
        private const val CHANNEL_RESOLUTION = "nova_resolution"
        private const val CHANNEL_RESULTS = "nova_result_alerts"
        private const val FOREGROUND_NOTIFICATION_ID = 6900
        private const val MAX_WAKE_LOCK_MS = 30L * 60L * 1000L

        fun clearResultNotification(context: Context, taskId: Long) {
            context.getSystemService(NotificationManager::class.java)
                ?.cancel(resultNotificationId(taskId))
        }

        fun start(context: Context, sourceUrl: String): Long {
            val app = context.applicationContext
            val task = ResolutionTaskStore(app).create(sourceUrl)
            val intent = Intent(app, BackgroundResolutionService::class.java)
                .setAction(ACTION_START)
                .putExtra(ResolutionTaskStore.EXTRA_TASK_ID, task.id)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) app.startForegroundService(intent)
            else app.startService(intent)
            return task.id
        }

        private fun resultNotificationId(taskId: Long): Int = 7000 + (taskId % 100000).toInt()
    }
}
