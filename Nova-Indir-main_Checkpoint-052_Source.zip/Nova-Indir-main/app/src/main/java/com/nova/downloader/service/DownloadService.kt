package com.nova.downloader.service

import com.nova.downloader.distribution.PetIntegration

import com.nova.downloader.i18n.AppText

import com.nova.downloader.R

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import com.nova.downloader.core.FileNameResolver
import com.nova.downloader.core.BandwidthLimiter
import com.nova.downloader.core.HttpRangePolicy
import com.nova.downloader.core.MediaSignatureDetector
import com.nova.downloader.core.MediaTypePolicy
import com.nova.downloader.data.AppSettings
import com.nova.downloader.data.CompletionEventStore
import com.nova.downloader.data.DownloadEngine
import com.nova.downloader.data.DownloadQueueCoordinator
import com.nova.downloader.data.DownloadState
import com.nova.downloader.data.HistoryStore
import com.nova.downloader.data.StorageHelper
import com.nova.downloader.ui.MainActivity
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URI
import java.util.Collections
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger

class DownloadService : Service() {
    private val executor = Executors.newFixedThreadPool(MAX_PARALLEL_DOWNLOADS)
    private val paused = Collections.synchronizedSet(mutableSetOf<Long>())
    private val cancelled = Collections.synchronizedSet(mutableSetOf<Long>())
    private val queuedCount = AtomicInteger(0)
    private lateinit var history: HistoryStore
    private lateinit var notifications: NotificationManager

    override fun onCreate() {
        super.onCreate()
        history = HistoryStore(this)
        notifications = getSystemService(NotificationManager::class.java)
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_CANCEL -> {
                val id = intent.getLongExtra(EXTRA_ID, -1L)
                if (id > 0L) {
                    cancelled.add(id)
                    paused.add(id)
                    if (id !in ACTIVE_IDS) history.get(id)?.let { StorageHelper.deletePartial(this, it) }
                    history.update(id) { item ->
                        item.copy(
                            status = DownloadState.CANCELLED,
                            bytesDownloaded = if (id in ACTIVE_IDS) item.bytesDownloaded else 0L,
                            partialFilePath = if (id in ACTIVE_IDS) item.partialFilePath else null,
                            resumeSupported = false,
                            errorMessage = AppText.get(R.string.download_cancelled_message)
                        )
                    }
                    PetIntegration.refreshMaybe(this)
                    if (queuedCount.get() <= 0) stopSelf(startId)
                }
            }
            ACTION_PAUSE -> {
                val id = intent.getLongExtra(EXTRA_ID, -1L)
                if (id > 0L) {
                    paused.add(id)
                    history.update(id) {
                        it.copy(
                            status = DownloadState.PAUSED,
                            bytesDownloaded = partialLength(it),
                            errorMessage = null
                        )
                    }
                    PetIntegration.refreshMaybe(this)
                    if (queuedCount.get() <= 0) stopSelf(startId)
                }
            }
            ACTION_START -> {
                val task = Task.from(intent) ?: return START_NOT_STICKY
                paused.remove(task.downloadId)
                cancelled.remove(task.downloadId)
                if (!ACTIVE_IDS.add(task.downloadId)) return START_REDELIVER_INTENT
                val activeCount = queuedCount.incrementAndGet()
                startForeground(SUMMARY_NOTIFICATION_ID, buildSummaryNotification(activeCount))
                notifications.notify(
                    foregroundNotificationId(task.downloadId),
                    buildProgressNotification(task, AppText.get(R.string.download_queued), 0, true)
                )
                executor.execute { runTask(task) }
            }
        }
        return START_REDELIVER_INTENT
    }

    override fun onDestroy() {
        executor.shutdownNow()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onTimeout(startId: Int, fgsType: Int) {
        history.list()
            .filter { it.engine == DownloadEngine.DIRECT && (it.status == DownloadState.RUNNING || it.status == DownloadState.PENDING) }
            .forEach { item ->
                paused.add(item.downloadId)
                history.update(item.downloadId) {
                    it.copy(
                        status = DownloadState.PAUSED,
                        bytesDownloaded = partialLength(it),
                        errorMessage = AppText.get(R.string.background_limit_paused)
                    )
                }
            }
        executor.shutdownNow()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf(startId)
    }

    private fun runTask(task: Task) {
        val partialFile = StorageHelper.partialFile(this, task.downloadId, task.partialFilePath)
        partialFile.parentFile?.mkdirs()
        val wakeLock = acquireWakeLock(task.downloadId)
        try {
            checkPaused(task.downloadId)
            history.update(task.downloadId) {
                it.copy(
                    status = DownloadState.RUNNING,
                    errorMessage = null,
                    partialFilePath = partialFile.absolutePath,
                    bytesDownloaded = partialFile.length()
                )
            }
            PetIntegration.refreshMaybe(this)

            var attempt = 0
            var result: CompletedTransfer? = null
            while (result == null) {
                checkPaused(task.downloadId)
                try {
                    result = downloadOnce(task, partialFile)
                } catch (error: Exception) {
                    if (error is PausedException) throw error
                    if (!isRetryable(error) || attempt >= MAX_AUTOMATIC_RETRIES) throw error
                    attempt++
                    history.update(task.downloadId) {
                        it.copy(
                            status = DownloadState.RUNNING,
                            bytesDownloaded = partialFile.length(),
                            retryCount = attempt,
                            errorMessage = AppText.get(R.string.retrying_attempt, attempt, MAX_AUTOMATIC_RETRIES)
                        )
                    }
                    notifications.notify(
                        foregroundNotificationId(task.downloadId),
                        buildProgressNotification(
                            task,
                            AppText.get(R.string.connection_retrying),
                            progressFor(partialFile.length(), history.get(task.downloadId)?.totalBytes ?: -1L),
                            false
                        )
                    )
                    waitBeforeRetry(task.downloadId, attempt)
                }
            }

            val completed = result ?: error(AppText.get(R.string.download_result_missing))
            checkCancelled(task.downloadId)
            val signature = MediaSignatureDetector.detect(partialFile)
            require(signature != null || MediaTypePolicy.isDirectMedia(completed.mimeType, completed.finalUrl)) {
                AppText.get(R.string.downloaded_media_integrity_failed)
            }
            val finalMime = signature?.mimeType
                ?: MediaTypePolicy.normalizedMimeType(completed.mimeType)
                ?: MediaTypePolicy.normalizedMimeType(task.mimeType)
                ?: "application/octet-stream"
            val finalName = FileNameResolver.ensureMediaExtension(
                requestedName = task.fileName,
                mimeType = finalMime,
                contentDisposition = completed.contentDisposition,
                finalUrl = completed.finalUrl,
                detectedExtension = signature?.extension
            )

            history.update(task.downloadId) {
                it.copy(title = finalName, mediaType = finalMime, bytesDownloaded = partialFile.length())
            }

            val committed = StorageHelper.commitPartial(
                context = this,
                partialFile = partialFile,
                fileName = finalName,
                mimeType = finalMime,
                destinationTreeUri = task.destinationTreeUri,
                duplicatePolicy = history.get(task.downloadId)?.duplicatePolicy ?: com.nova.downloader.data.DuplicatePolicy.RENAME
            )
            val finalSize = partialFile.length()
            partialFile.delete()
            history.update(task.downloadId) {
                it.copy(
                    title = committed.displayName,
                    status = DownloadState.SUCCESSFUL,
                    bytesDownloaded = finalSize,
                    totalBytes = if (completed.totalBytes > 0L) completed.totalBytes else finalSize,
                    outputUri = committed.uri.toString(),
                    destinationTreeUri = task.destinationTreeUri,
                    mediaType = finalMime,
                    partialFilePath = null,
                    errorMessage = null,
                    retryCount = 0,
                    checksumSha256 = committed.checksumSha256,
                    integrityVerified = true
                )
            }
            val completionSettings = AppSettings(this)
            if (completionSettings.inAppCompletionDialog) {
                CompletionEventStore(this).record(task.downloadId, committed.displayName)
            }
            if (completionSettings.systemCompletionNotifications) {
                notifications.notify(
                    completeNotificationId(task.downloadId),
                    buildCompleteNotification(task, committed.displayName)
                )
            }
        } catch (_: CancelledException) {
            partialFile.delete()
            history.update(task.downloadId) { it.copy(status = DownloadState.CANCELLED, bytesDownloaded = 0L, partialFilePath = null, resumeSupported = false, errorMessage = AppText.get(R.string.download_cancelled_message)) }
        } catch (_: PausedException) {
            val size = partialFile.length()
            history.update(task.downloadId) {
                it.copy(
                    status = DownloadState.PAUSED,
                    bytesDownloaded = size,
                    partialFilePath = partialFile.absolutePath,
                    errorMessage = null
                )
            }
            notifications.notify(
                completeNotificationId(task.downloadId),
                buildPausedNotification(task, size)
            )
        } catch (error: Exception) {
            val size = partialFile.length()
            history.update(task.downloadId) {
                it.copy(
                    status = DownloadState.FAILED,
                    bytesDownloaded = size,
                    partialFilePath = partialFile.absolutePath,
                    errorMessage = error.message ?: AppText.get(R.string.download_failed_message)
                )
            }
            notifications.notify(
                completeNotificationId(task.downloadId),
                buildFailedNotification(
                    task,
                    if (size > 0L) AppText.get(R.string.download_interrupted_resumable)
                    else error.message ?: AppText.get(R.string.download_failed_message)
                )
            )
        } finally {
            wakeLock?.let { if (it.isHeld) it.release() }
            notifications.cancel(foregroundNotificationId(task.downloadId))
            paused.remove(task.downloadId)
            cancelled.remove(task.downloadId)
            ACTIVE_IDS.remove(task.downloadId)
            PetIntegration.refreshMaybe(this)
            DownloadQueueCoordinator.kick(this)
            val remaining = queuedCount.decrementAndGet()
            if (remaining <= 0) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    stopForeground(STOP_FOREGROUND_REMOVE)
                } else {
                    @Suppress("DEPRECATION") stopForeground(true)
                }
                stopSelf()
            } else {
                notifications.notify(SUMMARY_NOTIFICATION_ID, buildSummaryNotification(remaining))
            }
        }
    }

    private fun downloadOnce(task: Task, partialFile: File): CompletedTransfer {
        var resumeOffset = partialFile.length()
        val storedBeforeRequest = history.get(task.downloadId)
        var validatorEtag = storedBeforeRequest?.etag ?: task.etag
        var validatorLastModified = storedBeforeRequest?.lastModified ?: task.lastModified
        var connection = openSecureConnection(task, resumeOffset, validatorEtag, validatorLastModified)
        try {
            var responseCode = connection.responseCode
            if (responseCode == HTTP_RANGE_NOT_SATISFIABLE) {
                val remoteTotal = HttpRangePolicy.parseContentRange(
                    connection.getHeaderField("Content-Range")
                )?.total
                if (resumeOffset > 0L && remoteTotal == resumeOffset) {
                    return CompletedTransfer(
                        mimeType = preferredMime(task.mimeType, connection.contentType),
                        contentDisposition = connection.getHeaderField("Content-Disposition"),
                        finalUrl = connection.url.toString(),
                        totalBytes = resumeOffset
                    )
                }
                connection.disconnect()
                truncate(partialFile)
                resumeOffset = 0L
                validatorEtag = null
                validatorLastModified = null
                connection = openSecureConnection(task, 0L, null, null)
                responseCode = connection.responseCode
            }

            if (responseCode !in 200..299) {
                if (responseCode == 408 || responseCode == 429 || responseCode in 500..599) {
                    throw RetryableDownloadException(AppText.get(R.string.server_temporary_http_error, responseCode))
                }
                error(AppText.get(R.string.server_http_error, responseCode))
            }

            var contentRange = connection.getHeaderField("Content-Range")
            var responseEtag = connection.getHeaderField("ETag")
            var responseLastModified = connection.getHeaderField("Last-Modified")
            val validatorChanged = resumeOffset > 0L && (
                (!validatorEtag.isNullOrBlank() && !responseEtag.isNullOrBlank() && validatorEtag != responseEtag) ||
                    (validatorEtag.isNullOrBlank() && !validatorLastModified.isNullOrBlank() &&
                        !responseLastModified.isNullOrBlank() && validatorLastModified != responseLastModified)
                )
            var canAppend = !validatorChanged &&
                HttpRangePolicy.canAppend(responseCode, contentRange, resumeOffset)
            if (resumeOffset > 0L && !canAppend) {
                truncate(partialFile)
                resumeOffset = 0L
                validatorEtag = null
                validatorLastModified = null
                if (responseCode == HttpURLConnection.HTTP_PARTIAL) {
                    connection.disconnect()
                    connection = openSecureConnection(task, 0L, null, null)
                    responseCode = connection.responseCode
                    if (responseCode !in 200..299) {
                        error(AppText.get(R.string.server_http_error, responseCode))
                    }
                    contentRange = connection.getHeaderField("Content-Range")
                    responseEtag = connection.getHeaderField("ETag")
                    responseLastModified = connection.getHeaderField("Last-Modified")
                }
                canAppend = false
            }

            val resolvedMime = preferredMime(task.mimeType, connection.contentType)
            if (MediaTypePolicy.isHtml(resolvedMime)) {
                error(AppText.get(R.string.server_returned_html))
            }
            val contentLength = connection.contentLengthLong
            val total = HttpRangePolicy.totalBytes(
                responseCode = responseCode,
                contentLength = contentLength,
                contentRange = contentRange,
                resumeOffset = resumeOffset
            ).takeIf { it > 0L } ?: task.contentLength
            val etag = responseEtag ?: validatorEtag
            val lastModified = responseLastModified ?: validatorLastModified
            val resumeSupported = canAppend || connection.getHeaderField("Accept-Ranges")
                ?.contains("bytes", ignoreCase = true) == true

            history.update(task.downloadId) {
                it.copy(
                    status = DownloadState.RUNNING,
                    bytesDownloaded = resumeOffset,
                    totalBytes = total,
                    mediaType = resolvedMime,
                    etag = etag,
                    lastModified = lastModified,
                    resumeSupported = resumeSupported,
                    retryCount = 0
                )
            }

            BufferedInputStream(connection.inputStream, BUFFER_SIZE).use { input ->
                FileOutputStream(partialFile, canAppend).use { output ->
                    val buffer = ByteArray(BUFFER_SIZE)
                    val limitKbps = AppSettings(this@DownloadService).speedLimitKbps
                    val limiter = BandwidthLimiter(limitKbps.toLong() * 1024L)
                    var downloaded = resumeOffset
                    var lastUpdate = 0L
                    while (true) {
                        checkCancelled(task.downloadId)
                        checkPaused(task.downloadId)
                        val read = try {
                            input.read(buffer)
                        } catch (error: IOException) {
                            throw RetryableDownloadException(error.message ?: AppText.get(R.string.network_disconnected), error)
                        }
                        if (read < 0) break
                        output.write(buffer, 0, read)
                        limiter.onBytesTransferred(read)
                        downloaded += read
                        val now = System.currentTimeMillis()
                        if (now - lastUpdate >= UPDATE_INTERVAL_MS) {
                            updateProgress(task, downloaded, total)
                            lastUpdate = now
                        }
                    }
                    output.fd.sync()
                    updateProgress(task, downloaded, if (total > 0L) total else downloaded)
                    if (total > 0L && downloaded < total) {
                        throw RetryableDownloadException(
                            AppText.get(R.string.connection_ended_early, downloaded, total)
                        )
                    }
                }
            }

            return CompletedTransfer(
                mimeType = resolvedMime,
                contentDisposition = connection.getHeaderField("Content-Disposition"),
                finalUrl = connection.url.toString(),
                totalBytes = if (total > 0L) total else partialFile.length()
            )
        } finally {
            connection.disconnect()
        }
    }

    private fun openSecureConnection(
        task: Task,
        resumeOffset: Long,
        etag: String?,
        lastModified: String?
    ): HttpURLConnection {
        var current = URI(task.downloadUrl)
        repeat(MAX_REDIRECTS + 1) { redirectCount ->
            if (!current.scheme.equals("https", ignoreCase = true)) {
                error(AppText.get(R.string.insecure_redirect_rejected))
            }
            val connection = (current.toURL().openConnection() as HttpURLConnection).apply {
                instanceFollowRedirects = false
                connectTimeout = 30_000
                readTimeout = 45_000
                requestMethod = "GET"
                setRequestProperty("Accept-Encoding", "identity")
                if (task.headers.keys.none { it.equals("User-Agent", true) }) {
                    setRequestProperty("User-Agent", USER_AGENT)
                }
                task.referer?.takeIf { it.isNotBlank() }?.let { setRequestProperty("Referer", it) }
                task.headers.forEach { (name, value) ->
                    if (name.isNotBlank() && value.isNotBlank()) setRequestProperty(name, value)
                }
                if (resumeOffset > 0L) {
                    setRequestProperty("Range", "bytes=$resumeOffset-")
                    (etag ?: lastModified)?.takeIf { it.isNotBlank() }
                        ?.let { setRequestProperty("If-Range", it) }
                }
            }
            connection.connect()
            if (connection.responseCode !in 300..399) return connection
            val location = connection.getHeaderField("Location")
                ?.takeIf { it.isNotBlank() }
                ?: run {
                    connection.disconnect()
                    error(AppText.get(R.string.redirect_address_missing))
                }
            connection.disconnect()
            if (redirectCount >= MAX_REDIRECTS) error(AppText.get(R.string.too_many_https_redirects))
            current = current.resolve(location)
        }
        error(AppText.get(R.string.secure_redirect_failed))
    }

    private fun preferredMime(taskMime: String?, responseMime: String?): String {
        val response = MediaTypePolicy.normalizedMimeType(responseMime)
        val task = MediaTypePolicy.normalizedMimeType(taskMime)
        val generic = setOf(null, "application/octet-stream", "application/force-download", "binary/octet-stream")
        return when {
            response !in generic -> response!!
            task != null -> task
            response != null -> response
            else -> "application/octet-stream"
        }
    }

    private fun updateProgress(task: Task, downloaded: Long, total: Long) {
        history.update(task.downloadId) {
            it.copy(
                status = DownloadState.RUNNING,
                bytesDownloaded = downloaded,
                totalBytes = total
            )
        }
        val percent = progressFor(downloaded, total)
        notifications.notify(
            foregroundNotificationId(task.downloadId),
            buildProgressNotification(
                task,
                if (total > 0L) AppText.get(R.string.progress_downloading_percent, percent) else AppText.get(R.string.downloading_plain),
                percent,
                total <= 0L
            )
        )
        PetIntegration.refreshMaybe(this)
    }

    private fun progressFor(downloaded: Long, total: Long): Int =
        if (total > 0L) ((downloaded * 100L) / total).toInt().coerceIn(0, 100) else 0

    private fun waitBeforeRetry(downloadId: Long, attempt: Int) {
        val until = System.currentTimeMillis() + (RETRY_BASE_DELAY_MS * attempt)
        while (System.currentTimeMillis() < until) {
            checkPaused(downloadId)
            try {
                Thread.sleep(250L)
            } catch (_: InterruptedException) {
                throw PausedException()
            }
        }
    }

    private fun checkCancelled(downloadId: Long) {
        if (downloadId in cancelled) throw CancelledException()
    }

    private fun checkPaused(downloadId: Long) {
        checkCancelled(downloadId)
        if (downloadId in paused || Thread.currentThread().isInterrupted) throw PausedException()
    }

    private fun isRetryable(error: Exception): Boolean =
        error is RetryableDownloadException || error is IOException

    private fun truncate(file: File) {
        FileOutputStream(file, false).use { it.channel.truncate(0L) }
    }

    private fun partialLength(item: com.nova.downloader.data.StoredDownload): Long =
        StorageHelper.partialFile(this, item.downloadId, item.partialFilePath).length()

    private fun acquireWakeLock(downloadId: Long): PowerManager.WakeLock? = runCatching {
        val manager = getSystemService(Context.POWER_SERVICE) as PowerManager
        manager.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "NovaDownloader:download:$downloadId"
        ).apply {
            setReferenceCounted(false)
            acquire(MAX_WAKE_LOCK_MS)
        }
    }.getOrNull()

    private fun buildSummaryNotification(activeCount: Int): Notification {
        val openApp = PendingIntent.getActivity(
            this,
            SUMMARY_NOTIFICATION_ID,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL_DOWNLOADS)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle(AppText.get(R.string.app_name))
            .setContentText(AppText.get(R.string.active_download_count, activeCount))
            .setOngoing(true)
            .setContentIntent(openApp)
            .build()
    }

    private fun buildProgressNotification(
        task: Task,
        text: String,
        progress: Int,
        indeterminate: Boolean
    ): Notification {
        val pauseIntent = PendingIntent.getService(
            this,
            foregroundNotificationId(task.downloadId),
            pauseIntent(this, task.downloadId),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val cancelIntent = PendingIntent.getService(
            this,
            foregroundNotificationId(task.downloadId) + 1,
            cancelIntent(this, task.downloadId),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL_DOWNLOADS)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle(task.fileName)
            .setContentText(text)
            .setProgress(100, progress, indeterminate)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_media_pause, AppText.get(R.string.pause_download), pauseIntent)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, AppText.get(R.string.action_cancel), cancelIntent)
            .build()
    }

    private fun buildCompleteNotification(task: Task, fileName: String): Notification {
        val openApp = PendingIntent.getActivity(
            this,
            completeNotificationId(task.downloadId),
            Intent(this, MainActivity::class.java).apply {
                putExtra(MainActivity.EXTRA_OPEN_DOWNLOAD_ID, task.downloadId)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL_COMPLETIONS)
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setContentTitle(AppText.get(R.string.notification_download_complete))
            .setContentText(fileName)
            .setAutoCancel(true)
            .setContentIntent(openApp)
            .build()
    }

    private fun buildPausedNotification(task: Task, bytes: Long): Notification {
        val openApp = PendingIntent.getActivity(
            this,
            completeNotificationId(task.downloadId),
            Intent(this, MainActivity::class.java).apply {
                putExtra(MainActivity.EXTRA_OPEN_DOWNLOAD_ID, task.downloadId)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL_DOWNLOADS)
            .setSmallIcon(android.R.drawable.ic_media_pause)
            .setContentTitle(AppText.get(R.string.notification_download_paused))
            .setContentText(if (bytes > 0L) AppText.get(R.string.resumable_hint) else task.fileName)
            .setAutoCancel(true)
            .setContentIntent(openApp)
            .build()
    }

    private fun buildFailedNotification(task: Task, message: String): Notification {
        val openApp = PendingIntent.getActivity(
            this,
            completeNotificationId(task.downloadId),
            Intent(this, MainActivity::class.java).apply {
                putExtra(MainActivity.EXTRA_OPEN_DOWNLOAD_ID, task.downloadId)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL_DOWNLOADS)
            .setSmallIcon(android.R.drawable.stat_notify_error)
            .setContentTitle(AppText.get(R.string.notification_download_interrupted))
            .setContentText(message.take(100))
            .setAutoCancel(true)
            .setContentIntent(openApp)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        notifications.createNotificationChannel(
            NotificationChannel(
                CHANNEL_DOWNLOADS,
                AppText.get(R.string.direct_download_channel),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = AppText.get(R.string.direct_download_channel_description)
            }
        )
        notifications.createNotificationChannel(
            NotificationChannel(
                CHANNEL_COMPLETIONS,
                AppText.get(R.string.result_alert_channel_name),
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = AppText.get(R.string.result_alert_channel_description)
            }
        )
    }

    private data class CompletedTransfer(
        val mimeType: String,
        val contentDisposition: String?,
        val finalUrl: String,
        val totalBytes: Long
    )

    private data class Task(
        val downloadId: Long,
        val sourceUrl: String,
        val downloadUrl: String,
        val fileName: String,
        val mimeType: String?,
        val contentLength: Long,
        val destinationTreeUri: String?,
        val referer: String?,
        val headers: Map<String, String>,
        val partialFilePath: String?,
        val etag: String?,
        val lastModified: String?
    ) {
        companion object {
            fun from(intent: Intent): Task? {
                val id = intent.getLongExtra(EXTRA_ID, -1L)
                val sourceUrl = intent.getStringExtra(EXTRA_SOURCE_URL).orEmpty()
                val downloadUrl = intent.getStringExtra(EXTRA_DOWNLOAD_URL).orEmpty()
                val fileName = intent.getStringExtra(EXTRA_FILE_NAME).orEmpty()
                if (id <= 0L || sourceUrl.isBlank() || downloadUrl.isBlank() || fileName.isBlank()) {
                    return null
                }
                val headersJson = intent.getStringExtra(EXTRA_HEADERS).orEmpty()
                val headers = linkedMapOf<String, String>()
                runCatching {
                    val json = JSONObject(headersJson)
                    val keys = json.keys()
                    while (keys.hasNext()) {
                        val key = keys.next()
                        headers[key] = json.optString(key)
                    }
                }
                return Task(
                    downloadId = id,
                    sourceUrl = sourceUrl,
                    downloadUrl = downloadUrl,
                    fileName = fileName,
                    mimeType = intent.getStringExtra(EXTRA_MIME),
                    contentLength = intent.getLongExtra(EXTRA_CONTENT_LENGTH, -1L),
                    destinationTreeUri = intent.getStringExtra(EXTRA_TREE_URI),
                    referer = intent.getStringExtra(EXTRA_REFERER),
                    headers = headers,
                    partialFilePath = intent.getStringExtra(EXTRA_PARTIAL_PATH),
                    etag = intent.getStringExtra(EXTRA_ETAG),
                    lastModified = intent.getStringExtra(EXTRA_LAST_MODIFIED)
                )
            }
        }
    }

    private class PausedException : Exception()
    private class CancelledException : Exception()
    private class RetryableDownloadException(message: String, cause: Throwable? = null) : IOException(message, cause)

    companion object {
        private const val ACTION_START = "com.nova.downloader.action.START_DOWNLOAD"
        private const val ACTION_PAUSE = "com.nova.downloader.action.PAUSE_DOWNLOAD"
        private const val ACTION_CANCEL = "com.nova.downloader.action.CANCEL_DOWNLOAD"
        private const val EXTRA_ID = "download_id"
        private const val EXTRA_SOURCE_URL = "source_url"
        private const val EXTRA_DOWNLOAD_URL = "download_url"
        private const val EXTRA_FILE_NAME = "file_name"
        private const val EXTRA_MIME = "mime"
        private const val EXTRA_CONTENT_LENGTH = "content_length"
        private const val EXTRA_TREE_URI = "tree_uri"
        private const val EXTRA_REFERER = "referer"
        private const val EXTRA_HEADERS = "headers"
        private const val EXTRA_PARTIAL_PATH = "partial_path"
        private const val EXTRA_ETAG = "etag"
        private const val EXTRA_LAST_MODIFIED = "last_modified"
        private const val CHANNEL_DOWNLOADS = "nova_downloads"
        private const val CHANNEL_COMPLETIONS = "nova_download_completions"
        private const val BUFFER_SIZE = 128 * 1024
        private const val UPDATE_INTERVAL_MS = 1_000L
        private const val MAX_REDIRECTS = 8
        private const val HTTP_RANGE_NOT_SATISFIABLE = 416
        private const val MAX_AUTOMATIC_RETRIES = 3
        private const val MAX_PARALLEL_DOWNLOADS = 2
        private const val SUMMARY_NOTIFICATION_ID = 9_001
        private const val RETRY_BASE_DELAY_MS = 2_000L
        private const val MAX_WAKE_LOCK_MS = 6L * 60L * 60L * 1_000L
        private const val USER_AGENT = "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/124 Mobile Safari/537.36 NovaDownloader/0.6.0"
        private val ACTIVE_IDS = Collections.synchronizedSet(mutableSetOf<Long>())

        fun isActive(downloadId: Long): Boolean = downloadId in ACTIVE_IDS

        fun startIntent(
            context: Context,
            downloadId: Long,
            sourceUrl: String,
            downloadUrl: String,
            fileName: String,
            mimeType: String?,
            contentLength: Long,
            destinationTreeUri: String?,
            referer: String?,
            headers: Map<String, String>,
            partialFilePath: String?,
            etag: String?,
            lastModified: String?
        ): Intent = Intent(context, DownloadService::class.java).apply {
            action = ACTION_START
            putExtra(EXTRA_ID, downloadId)
            putExtra(EXTRA_SOURCE_URL, sourceUrl)
            putExtra(EXTRA_DOWNLOAD_URL, downloadUrl)
            putExtra(EXTRA_FILE_NAME, fileName)
            putExtra(EXTRA_MIME, mimeType)
            putExtra(EXTRA_CONTENT_LENGTH, contentLength)
            putExtra(EXTRA_TREE_URI, destinationTreeUri)
            putExtra(EXTRA_REFERER, referer)
            putExtra(EXTRA_HEADERS, JSONObject(headers).toString())
            putExtra(EXTRA_PARTIAL_PATH, partialFilePath)
            putExtra(EXTRA_ETAG, etag)
            putExtra(EXTRA_LAST_MODIFIED, lastModified)
        }

        fun pauseIntent(context: Context, downloadId: Long): Intent =
            Intent(context, DownloadService::class.java).apply {
                action = ACTION_PAUSE
                putExtra(EXTRA_ID, downloadId)
            }

        fun cancelIntent(context: Context, downloadId: Long): Intent =
            Intent(context, DownloadService::class.java).apply {
                action = ACTION_CANCEL
                putExtra(EXTRA_ID, downloadId)
            }

        private fun foregroundNotificationId(id: Long): Int = 10_000 + (id % 20_000L).toInt()
        private fun completeNotificationId(id: Long): Int = 40_000 + (id % 20_000L).toInt()
    }
}
