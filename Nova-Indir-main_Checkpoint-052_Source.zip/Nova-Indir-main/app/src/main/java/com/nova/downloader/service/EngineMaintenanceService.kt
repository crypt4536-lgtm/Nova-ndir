package com.nova.downloader.service

import android.app.Service
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.Message
import android.os.Messenger
import com.nova.downloader.R
import com.nova.downloader.engine.EngineRecoveryManager
import com.nova.downloader.i18n.AppText
import com.nova.downloader.runtime.MediaProcessState
import java.util.concurrent.Executors

class EngineMaintenanceService : Service() {
    private val executor = Executors.newSingleThreadExecutor()
    private val messenger = Messenger(object : Handler(Looper.getMainLooper()) {
        override fun handleMessage(message: Message) {
            val reply = message.replyTo ?: return
            val command = message.data.getString(KEY_COMMAND).orEmpty()
            MediaProcessState.resolverStarted()
            executor.execute {
                val result = runCatching {
                    val manager = EngineRecoveryManager(applicationContext)
                    when (command) {
                        COMMAND_STATUS -> manager.statusText()
                        COMMAND_UPDATE_STABLE -> manager.update(com.yausername.youtubedl_android.YoutubeDL.UpdateChannel.STABLE).message
                        COMMAND_UPDATE_NIGHTLY -> manager.update(com.yausername.youtubedl_android.YoutubeDL.UpdateChannel.NIGHTLY).message
                        COMMAND_ROLLBACK -> manager.rollback().message
                        COMMAND_RESTORE_BUNDLED -> manager.restoreBundled().message
                        else -> error(AppText.get(R.string.engine_unknown_command))
                    }
                }
                runCatching {
                    reply.send(Message.obtain(null, MSG_RESULT).apply {
                        data = Bundle().apply {
                            putBoolean(KEY_SUCCESS, result.isSuccess)
                            putString(KEY_MESSAGE, result.getOrElse { it.message ?: AppText.get(R.string.unknown) })
                        }
                    })
                }
                MediaProcessState.resolverFinished()
                stopSelf()
            }
        }
    })

    override fun onBind(intent: Intent?): IBinder = messenger.binder
    override fun onDestroy() { executor.shutdownNow(); super.onDestroy() }

    companion object {
        const val MSG_RUN = 1
        const val MSG_RESULT = 2
        const val KEY_COMMAND = "command"
        const val KEY_SUCCESS = "success"
        const val KEY_MESSAGE = "message"
        const val COMMAND_STATUS = "status"
        const val COMMAND_UPDATE_STABLE = "update_stable"
        const val COMMAND_UPDATE_NIGHTLY = "update_nightly"
        const val COMMAND_ROLLBACK = "rollback"
        const val COMMAND_RESTORE_BUNDLED = "restore_bundled"
    }
}
