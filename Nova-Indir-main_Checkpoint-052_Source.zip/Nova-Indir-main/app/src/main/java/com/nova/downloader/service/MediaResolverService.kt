package com.nova.downloader.service

import android.app.Service
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.Message
import android.os.Messenger
import com.nova.downloader.R
import com.nova.downloader.data.LinkResolver
import com.nova.downloader.data.ResolvedDownloadCodec
import com.nova.downloader.diagnostics.LocalLog
import com.nova.downloader.i18n.AppText
import com.nova.downloader.runtime.MediaProcessState
import java.util.concurrent.Executors

class MediaResolverService : Service() {
    private val executor = Executors.newSingleThreadExecutor()
    private val messenger = Messenger(IncomingHandler(Looper.getMainLooper()))

    override fun onBind(intent: Intent?): IBinder = messenger.binder

    override fun onDestroy() {
        executor.shutdownNow()
        super.onDestroy()
    }

    private inner class IncomingHandler(looper: Looper) : Handler(looper) {
        override fun handleMessage(message: Message) {
            if (message.what != MSG_RESOLVE) return super.handleMessage(message)
            val reply = message.replyTo ?: return
            val url = message.data.getString(KEY_URL).orEmpty()
            MediaProcessState.resolverStarted()
            executor.execute {
                val result = runCatching { LinkResolver(this@MediaResolverService).resolve(url) }
                    .getOrElse { LinkResolver.Result.Error(it.message ?: AppText.get(R.string.media_resolver_start_failed)) }
                val response = Message.obtain(null, MSG_RESULT).apply {
                    data = Bundle().apply {
                        when (result) {
                            is LinkResolver.Result.Ready -> {
                                putString(KEY_TYPE, TYPE_READY)
                                putString(KEY_PAYLOAD, ResolvedDownloadCodec.encode(result.download))
                            }
                            is LinkResolver.Result.Unsupported -> { putString(KEY_TYPE, TYPE_UNSUPPORTED); putString(KEY_MESSAGE, result.message) }
                            is LinkResolver.Result.Error -> { putString(KEY_TYPE, TYPE_ERROR); putString(KEY_MESSAGE, result.message) }
                        }
                    }
                }
                runCatching { reply.send(response) }.onFailure { LocalLog.warn("ResolverService", "Reply failed", it) }
                MediaProcessState.resolverFinished()
                stopSelf()
            }
        }
    }

    companion object {
        const val MSG_RESOLVE = 1
        const val MSG_RESULT = 2
        const val KEY_URL = "url"
        const val KEY_TYPE = "type"
        const val KEY_PAYLOAD = "payload"
        const val KEY_MESSAGE = "message"
        const val TYPE_READY = "ready"
        const val TYPE_UNSUPPORTED = "unsupported"
        const val TYPE_ERROR = "error"
    }
}
