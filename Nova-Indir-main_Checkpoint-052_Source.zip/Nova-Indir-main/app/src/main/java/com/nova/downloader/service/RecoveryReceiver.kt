package com.nova.downloader.service

import com.nova.downloader.distribution.PetIntegration

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.nova.downloader.BuildConfig
import com.nova.downloader.data.AppSettings
import com.nova.downloader.worker.RecoveryScheduler

class RecoveryReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action !in setOf(Intent.ACTION_BOOT_COMPLETED, Intent.ACTION_MY_PACKAGE_REPLACED)) return
        RecoveryScheduler.schedule(context)
        val settings = AppSettings(context)
        if (BuildConfig.HAS_PET_OVERLAY && settings.petEnabled && settings.petStartOnBoot && PetIntegration.canDrawOverlays(context)) {
            PetIntegration.startOrRefresh(context)
        }
    }
}
