package com.nova.downloader.service

import com.nova.downloader.distribution.PetIntegration

import com.nova.downloader.i18n.AppText

import com.nova.downloader.R

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import com.nova.downloader.BuildConfig
import com.nova.downloader.core.FileNameResolver
import com.nova.downloader.core.MediaSignatureDetector
import com.nova.downloader.core.MediaTypePolicy
import com.nova.downloader.core.YtDlpOptionBuilder
import com.nova.downloader.data.AppSettings
import com.nova.downloader.data.CompletionEventStore
import com.nova.downloader.data.DownloadState
import com.nova.downloader.data.HistoryStore
import com.nova.downloader.data.StorageHelper
import com.nova.downloader.data.YtDlpFallbackPolicy
import com.nova.downloader.data.YtDlpRequestConfigurator
import com.nova.downloader.diagnostics.LocalLog
import com.nova.downloader.engine.EngineRecoveryManager
import com.nova.downloader.runtime.FfmpegRuntime
import com.nova.downloader.runtime.MediaProcessState
import com.nova.downloader.ui.MainActivity
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import java.io.File
import java.util.Collections
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger
import org.json.JSONObject

class YtDlpDownloadService : Service() {
    private val executor = Executors.newFixedThreadPool(MAX_PARALLEL)
    private val paused = Collections.synchronizedSet(mutableSetOf<Long>())
    private val cancelled = Collections.synchronizedSet(mutableSetOf<Long>())
    private val activeCount = AtomicInteger(0)
    private lateinit var history: HistoryStore
    private lateinit var notifications: NotificationManager

    override fun onCreate() {
        super.onCreate()
        history = HistoryStore(this)
        notifications = getSystemService(NotificationManager::class.java)
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_CANCEL -> {
                val id = intent.getLongExtra(EXTRA_ID, -1L)
                if (id > 0L) {
                    cancelInternal(id)
                    if (activeCount.get() <= 0) stopSelf(startId)
                }
            }
            ACTION_PAUSE -> {
                val id = intent.getLongExtra(EXTRA_ID, -1L)
                if (id > 0L) {
                    pauseInternal(id)
                    if (activeCount.get() <= 0) stopSelf(startId)
                }
            }
            ACTION_START -> {
                val task = Task.from(intent) ?: return START_NOT_STICKY
                paused.remove(task.id)
                cancelled.remove(task.id)
                if (!ACTIVE_IDS.add(task.id)) return START_REDELIVER_INTENT
                val count = activeCount.incrementAndGet()
                startForeground(SUMMARY_NOTIFICATION_ID, summaryNotification(count))
                executor.execute { runTask(task) }
            }
        }
        return START_REDELIVER_INTENT
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onTimeout(startId: Int, fgsType: Int) {
        ACTIVE_IDS.toList().forEach(::pauseInternal)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf(startId)
    }

    override fun onDestroy() {
        executor.shutdownNow()
        super.onDestroy()
    }

    private fun runTask(task: Task) {
        MediaProcessState.downloadStarted()
        val engineRecovery = EngineRecoveryManager(this)
        val jobDir = jobDirectory(this, task.id, task.partialPath)
        jobDir.mkdirs()
        val processId = processId(task.id)
        val wakeLock = acquireWakeLock(task.id)
        var auth: YtDlpRequestConfigurator.AuthMaterial? = null
        try {
            YoutubeDL.getInstance().init(applicationContext)
            if (requiresFfmpeg(task)) FfmpegRuntime.initialize(applicationContext)
            LocalLog.info("Download", "yt-dlp task started id=${task.id}")
            history.update(task.id) {
                it.copy(
                    status = DownloadState.RUNNING,
                    reason = 0,
                    errorMessage = null,
                    partialFilePath = jobDir.absolutePath,
                    bytesDownloaded = directoryBytes(jobDir),
                    resumeSupported = true
                )
            }
            PetIntegration.refreshMaybe(this)

            val configurator = YtDlpRequestConfigurator(this)
            val profiles = configurator.automaticProfiles(task.sourceUrl, task.requestProfileId)
            var completed = false
            var lastFailure: Exception? = null
            var hardGateSeen = false

            for ((attemptIndex, profile) in profiles.withIndex()) {
                if (hardGateSeen && !profile.allowStoredCookies) continue
                if (task.id in cancelled) throw CancelledException()
                if (task.id in paused) throw PausedException()

                val request = buildRequest(task, jobDir, relaxFormat = attemptIndex > 0)
                var attemptAuth: YtDlpRequestConfigurator.AuthMaterial? = null
                try {
                    LocalLog.info("Download", "yt-dlp profile attempt id=${task.id} profile=${profile.id}")
                    attemptAuth = configurator.applyCommon(
                        request,
                        "download_${task.id}_${profile.id}",
                        task.sourceUrl,
                        profile
                    )
                    auth = attemptAuth
                    YoutubeDL.getInstance().execute(request, processId) { progress, etaSeconds, line ->
                        if (task.id in paused || task.id in cancelled) {
                            runCatching { YoutubeDL.getInstance().destroyProcessById(processId) }
                        }
                        val percent = progress.toInt().coerceIn(0, 100)
                        val size = directoryBytes(jobDir)
                        history.update(task.id) {
                            it.copy(
                                status = DownloadState.RUNNING,
                                reason = percent,
                                bytesDownloaded = size,
                                partialFilePath = jobDir.absolutePath,
                                errorMessage = null
                            )
                        }
                        notifications.notify(
                            notificationId(task.id),
                            progressNotification(task, percent, etaSeconds, line)
                        )
                        PetIntegration.refreshMaybe(this)
                    }
                    completed = true
                    LocalLog.info("Download", "yt-dlp profile accepted id=${task.id} profile=${profile.id}")
                    break
                } catch (error: Exception) {
                    if (task.id in cancelled) throw CancelledException()
                    if (task.id in paused) throw PausedException()
                    lastFailure = error
                    val raw = error.message.orEmpty()
                    hardGateSeen = hardGateSeen || YtDlpFallbackPolicy.isHardAccessGate(raw)
                    val canRetry = YtDlpFallbackPolicy.isRetryableExtractionFailure(raw) || hardGateSeen
                    LocalLog.warn("Download", "yt-dlp profile failed id=${task.id} profile=${profile.id} retry=$canRetry", error)
                    if (!canRetry) break
                } finally {
                    attemptAuth?.clear()
                    if (auth === attemptAuth) auth = null
                }
            }

            if (!completed) throw lastFailure ?: error(AppText.get(R.string.media_download_failed_message))
            if (task.id in cancelled) throw CancelledException()
            if (task.id in paused) throw PausedException()
            val artifacts = findOutputArtifacts(jobDir)
            val primary = findPrimaryMedia(artifacts)
                ?: error(AppText.get(R.string.ytdlp_output_missing))
            val signature = MediaSignatureDetector.detect(primary)
            require(signature != null || primary.extension.isNotBlank()) { AppText.get(R.string.media_integrity_unverified) }
            val extension = signature?.extension ?: primary.extension.lowercase().takeIf { it.isNotBlank() }
            val mime = signature?.mimeType
                ?: MediaTypePolicy.mimeTypeForExtension(extension)
                ?: task.mimeType
                ?: "application/octet-stream"
            val primaryName = if (task.playlistMode == "all") {
                FileNameResolver.sanitize(primary.name, task.fileName)
            } else {
                FileNameResolver.ensureMediaExtension(
                    requestedName = task.fileName,
                    mimeType = mime,
                    finalUrl = primary.name,
                    detectedExtension = extension
                )
            }
            val committed = StorageHelper.commitPartial(
                context = this, partialFile = primary, fileName = primaryName, mimeType = mime,
                destinationTreeUri = task.destinationTreeUri, duplicatePolicy = task.duplicatePolicy
            )
            var totalCommittedBytes = primary.length()
            var committedCount = 1
            artifacts.filterNot { it == primary }.forEach { artifact ->
                val artifactName = if (task.playlistMode == "all") {
                    FileNameResolver.sanitize(artifact.name, "nova_artifact_${committedCount}")
                } else {
                    sidecarName(committed.displayName, artifact.name)
                }
                val artifactMime = mimeForArtifact(artifact)
                StorageHelper.commitPartial(
                    context = this, partialFile = artifact, fileName = artifactName, mimeType = artifactMime,
                    destinationTreeUri = task.destinationTreeUri, duplicatePolicy = task.duplicatePolicy
                )
                totalCommittedBytes += artifact.length()
                committedCount++
            }
            history.update(task.id) {
                it.copy(
                    title = if (committedCount > 1) AppText.get(R.string.additional_files_title, committed.displayName, committedCount - 1) else committed.displayName,
                    status = DownloadState.SUCCESSFUL, reason = 100,
                    bytesDownloaded = totalCommittedBytes, totalBytes = totalCommittedBytes,
                    outputUri = committed.uri.toString(), mediaType = mime, errorMessage = null,
                    resumeSupported = false, checksumSha256 = committed.checksumSha256, integrityVerified = true
                )
            }
            runCatching { jobDir.deleteRecursively() }
            engineRecovery.recordSuccess()
            LocalLog.info("Download", "yt-dlp task completed id=${task.id} bytes=$totalCommittedBytes")
            val completionName = if (committedCount > 1) {
                AppText.get(R.string.additional_files_summary, committed.displayName, committedCount - 1)
            } else committed.displayName
            val completionSettings = AppSettings(this)
            if (completionSettings.inAppCompletionDialog) {
                CompletionEventStore(this).record(task.id, completionName)
            }
            if (completionSettings.systemCompletionNotifications) {
                notifications.notify(notificationId(task.id), completedNotification(task, completionName))
            }
        } catch (_: CancelledException) {
            runCatching { jobDir.deleteRecursively() }
            history.update(task.id) { it.copy(status = DownloadState.CANCELLED, bytesDownloaded = 0L, partialFilePath = null, resumeSupported = false, errorMessage = AppText.get(R.string.download_cancelled_message)) }
        } catch (_: PausedException) {
            val size = directoryBytes(jobDir)
            history.update(task.id) {
                it.copy(
                    status = DownloadState.PAUSED,
                    bytesDownloaded = size,
                    partialFilePath = jobDir.absolutePath,
                    errorMessage = AppText.get(R.string.download_paused_ytdlp_resumable)
                )
            }
            notifications.notify(notificationId(task.id), pausedNotification(task))
        } catch (error: Exception) {
            val size = directoryBytes(jobDir)
            val wasPaused = task.id in paused
            val wasCancelled = task.id in cancelled
            if (wasCancelled) runCatching { jobDir.deleteRecursively() }
            history.update(task.id) {
                it.copy(
                    status = when { wasCancelled -> DownloadState.CANCELLED; wasPaused -> DownloadState.PAUSED; else -> DownloadState.FAILED },
                    bytesDownloaded = if (wasCancelled) 0L else size,
                    partialFilePath = if (wasCancelled) null else jobDir.absolutePath,
                    resumeSupported = !wasCancelled,
                    errorMessage = if (wasCancelled) AppText.get(R.string.download_cancelled_message) else friendlyError(error.message)
                )
            }
            if (!wasCancelled && !wasPaused) {
                engineRecovery.recordFailure(error.message.orEmpty(), runCatching { java.net.URI(task.sourceUrl).host }.getOrNull())
                LocalLog.error("Download", "yt-dlp task failed id=${task.id}", error)
            }
            notifications.notify(
                notificationId(task.id),
                when {
                    wasCancelled -> cancelledNotification(task)
                    wasPaused -> pausedNotification(task)
                    else -> failedNotification(task, friendlyError(error.message))
                }
            )
        } finally {
            auth?.clear()
            runCatching { wakeLock?.release() }
            ACTIVE_IDS.remove(task.id)
            paused.remove(task.id)
            cancelled.remove(task.id)
            val remaining = activeCount.decrementAndGet().coerceAtLeast(0)
            PetIntegration.refreshMaybe(this)
            MediaProcessState.downloadFinished()
            if (remaining == 0) {
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            } else {
                notifications.notify(SUMMARY_NOTIFICATION_ID, summaryNotification(remaining))
            }
        }
    }

    private fun buildRequest(task: Task, jobDir: File, relaxFormat: Boolean = false): YoutubeDLRequest {
        val request = YoutubeDLRequest(task.sourceUrl)
        request.addOption("--no-mtime")
        request.addOption("--continue")
        request.addOption("--part")
        request.addOption("--newline")
        request.addOption("--progress")
        request.addOption("--progress-delta", 1)
        request.addOption("--paths", "home:${jobDir.absolutePath}")
        request.addOption("--paths", "temp:${File(jobDir, "temp").absolutePath}")
        request.addOption("--windows-filenames")
        val outputTemplate = if (task.playlistMode == "all") {
            File(jobDir, "%(playlist_index)03d - %(title).180B [%(id)s].%(ext)s").absolutePath
        } else {
            File(jobDir, "result.%(ext)s").absolutePath
        }
        request.addOption("-o", outputTemplate)
        if (task.playlistMode == "all") request.addOption("--yes-playlist") else request.addOption("--no-playlist")
        if (task.liveFromStart) request.addOption("--live-from-start")
        task.audioLanguage?.takeIf { it.isNotBlank() }?.let { request.addOption("--audio-multistreams"); request.addOption("--format-sort", "lang:$it") }
        if (task.writeSubtitles) request.addOption("--write-subs")
        if (task.writeAutoSubtitles) request.addOption("--write-auto-subs")
        task.subtitleLanguages?.takeIf { it.isNotBlank() }?.let { request.addOption("--sub-langs", it) }
        if (task.writeThumbnail) request.addOption("--write-thumbnail")
        if (task.writeDescription) request.addOption("--write-description")
        if (task.embedMetadata) request.addOption("--embed-metadata")
        if (task.embedChapters) request.addOption("--embed-chapters")

        if (task.outputMode == YtDlpOptionBuilder.MODE_AUDIO) {
            FfmpegRuntime.requireAvailable()
            val audio = YtDlpOptionBuilder.audioPreset(task.audioFormat)
            request.addOption("-f", if (relaxFormat) "ba/b" else task.formatSelector ?: "ba/b")
            request.addOption("--extract-audio")
            request.addOption("--audio-format", audio.id)
            request.addOption("--audio-quality", "0")
        } else {
            val container = task.videoContainer?.takeIf { it in setOf("mp4", "mkv", "webm") } ?: "mp4"
            if (BuildConfig.HAS_FFMPEG) {
                request.addOption("-f", if (relaxFormat) YtDlpOptionBuilder.videoFormatSelector(task.qualityId, container) else task.formatSelector ?: YtDlpOptionBuilder.videoFormatSelector(task.qualityId, container))
                if (requiresFfmpeg(task)) {
                    request.addOption("--merge-output-format", container)
                    request.addOption("--remux-video", container)
                }
            } else {
                request.addOption("-f", "b[ext=$container]/b")
            }
        }
        return request
    }

    private fun requiresFfmpeg(task: Task): Boolean {
        if (!BuildConfig.HAS_FFMPEG) return task.outputMode == YtDlpOptionBuilder.MODE_AUDIO
        if (task.outputMode == YtDlpOptionBuilder.MODE_AUDIO) return true
        val selector = task.formatSelector.orEmpty()
        if (selector.isBlank() || '+' in selector) return true
        if (task.embedMetadata || task.embedChapters) return true
        val requestedContainer = task.videoContainer?.lowercase().orEmpty()
        val sourceExtension = MediaTypePolicy.extensionOf(task.fileName).orEmpty()
        return requestedContainer.isNotBlank() && sourceExtension.isNotBlank() && requestedContainer != sourceExtension
    }

    private fun cancelInternal(id: Long) {
        cancelled.add(id)
        paused.add(id)
        runCatching { YoutubeDL.getInstance().destroyProcessById(processId(id)) }
        if (id !in ACTIVE_IDS) history.get(id)?.let { StorageHelper.deletePartial(this, it) }
        history.update(id) { item ->
            item.copy(
                status = DownloadState.CANCELLED,
                bytesDownloaded = if (id in ACTIVE_IDS) item.bytesDownloaded else 0L,
                partialFilePath = if (id in ACTIVE_IDS) item.partialFilePath else null,
                resumeSupported = false,
                errorMessage = AppText.get(R.string.download_cancelled_message)
            )
        }
        PetIntegration.refreshMaybe(this)
    }

    private fun pauseInternal(id: Long) {
        paused.add(id)
        runCatching { YoutubeDL.getInstance().destroyProcessById(processId(id)) }
        val item = history.get(id)
        history.update(id) {
            it.copy(
                status = DownloadState.PAUSED,
                bytesDownloaded = jobBytes(this, id, item?.partialFilePath),
                errorMessage = null
            )
        }
        PetIntegration.refreshMaybe(this)
    }

    private fun findOutputArtifacts(jobDir: File): List<File> = jobDir.walkTopDown()
        .filter { it.isFile && !it.toPath().startsWith(File(jobDir, "temp").toPath()) }
        .filterNot { it.name.endsWith(".part", true) || it.name.endsWith(".ytdl", true) }
        .sortedBy { it.name.lowercase() }
        .toList()

    private fun findPrimaryMedia(files: List<File>): File? = files
        .filter { file ->
            MediaSignatureDetector.detect(file) != null || file.extension.lowercase() in MEDIA_EXTENSIONS
        }
        .maxByOrNull { it.length() }

    private fun sidecarName(primaryName: String, artifactName: String): String {
        val primaryStem = primaryName.substringBeforeLast('.', primaryName)
        val suffix = artifactName.removePrefix("result").ifBlank { ".${artifactName.substringAfterLast('.', "bin")}" }
        return FileNameResolver.sanitize("$primaryStem$suffix", AppText.get(R.string.sidecar_fallback_name, primaryStem))
    }

    private fun mimeForArtifact(file: File): String = when (file.extension.lowercase()) {
        "vtt" -> "text/vtt"
        "srt" -> "application/x-subrip"
        "ass", "ssa" -> "text/x-ssa"
        "json" -> "application/json"
        "description", "txt" -> "text/plain"
        "jpg", "jpeg" -> "image/jpeg"
        "png" -> "image/png"
        "webp" -> "image/webp"
        else -> MediaSignatureDetector.detect(file)?.mimeType
            ?: MediaTypePolicy.mimeTypeForExtension(file.extension)
            ?: "application/octet-stream"
    }

    private fun friendlyError(raw: String?): String {
        val message = raw.orEmpty().replace(Regex("https?://\\S+"), AppText.get(R.string.redacted_address)).take(900)
        return when {
            message.contains("Sign in", true) || message.contains("login", true) || message.contains("cookies", true) ->
                AppText.get(R.string.auth_or_cookies_required_details, message)
            message.contains("HTTP Error 429", true) || message.contains("rate", true) ->
                AppText.get(R.string.rate_limit_details, message)
            message.contains("PO Token", true) || message.contains("pot", true) ->
                AppText.get(R.string.youtube_po_token_required_details, message)
            message.contains("JavaScript runtime", true) || message.contains("challenge", true) ->
                AppText.get(R.string.youtube_js_challenge_details, message)
            message.isBlank() -> AppText.get(R.string.media_download_failed_message)
            else -> message
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            notifications.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, AppText.get(R.string.media_download_channel), NotificationManager.IMPORTANCE_LOW)
            )
            notifications.createNotificationChannel(
                NotificationChannel(
                    CHANNEL_COMPLETIONS,
                    AppText.get(R.string.result_alert_channel_name),
                    NotificationManager.IMPORTANCE_DEFAULT
                ).apply { description = AppText.get(R.string.result_alert_channel_description) }
            )
        }
    }

    private fun summaryNotification(count: Int): Notification = Notification.Builder(this, CHANNEL_ID)
        .setSmallIcon(android.R.drawable.stat_sys_download)
        .setContentTitle(AppText.get(R.string.app_name))
        .setContentText(AppText.get(R.string.active_media_downloads, count))
        .setOngoing(true)
        .setContentIntent(openAppIntent(SUMMARY_NOTIFICATION_ID))
        .build()

    private fun progressNotification(task: Task, progress: Int, eta: Long, line: String): Notification {
        val pause = PendingIntent.getService(
            this,
            notificationId(task.id) + 1,
            pauseIntent(this, task.id),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val cancel = PendingIntent.getService(
            this,
            notificationId(task.id) + 2,
            cancelIntent(this, task.id),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val etaText = if (eta > 0) AppText.get(R.string.eta_seconds_remaining, eta) else ""
        val detail = line.trim().takeIf { it.isNotBlank() }?.take(100) ?: AppText.get(R.string.downloading_plain)
        return Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle(task.fileName)
            .setContentText(AppText.get(R.string.media_progress_detail, progress, etaText, detail))
            .setProgress(100, progress, false)
            .setOngoing(true)
            .setContentIntent(openAppIntent(notificationId(task.id)))
            .addAction(android.R.drawable.ic_media_pause, AppText.get(R.string.pause_download), pause)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, AppText.get(R.string.action_cancel), cancel)
            .build()
    }

    private fun completedNotification(task: Task, name: String): Notification = Notification.Builder(this, CHANNEL_COMPLETIONS)
        .setSmallIcon(android.R.drawable.stat_sys_download_done)
        .setContentTitle(AppText.get(R.string.notification_download_complete))
        .setContentText(name)
        .setAutoCancel(true)
        .setContentIntent(openDownloadIntent(task.id))
        .build()

    private fun pausedNotification(task: Task): Notification = Notification.Builder(this, CHANNEL_ID)
        .setSmallIcon(android.R.drawable.ic_media_pause)
        .setContentTitle(AppText.get(R.string.notification_download_paused))
        .setContentText(task.fileName)
        .setAutoCancel(true)
        .setContentIntent(openDownloadIntent(task.id))
        .build()

    private fun cancelledNotification(task: Task): Notification = Notification.Builder(this, CHANNEL_ID)
        .setSmallIcon(android.R.drawable.ic_menu_close_clear_cancel)
        .setContentTitle(AppText.get(R.string.notification_download_cancelled))
        .setContentText(task.fileName)
        .setAutoCancel(true)
        .setContentIntent(openDownloadIntent(task.id))
        .build()

    private fun failedNotification(task: Task, message: String): Notification = Notification.Builder(this, CHANNEL_ID)
        .setSmallIcon(android.R.drawable.stat_notify_error)
        .setContentTitle(AppText.get(R.string.notification_download_failed))
        .setContentText(message.lineSequence().firstOrNull()?.take(120))
        .setAutoCancel(true)
        .setContentIntent(openDownloadIntent(task.id))
        .build()

    private fun openAppIntent(requestCode: Int): PendingIntent = PendingIntent.getActivity(
        this,
        requestCode,
        Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    private fun openDownloadIntent(id: Long): PendingIntent = PendingIntent.getActivity(
        this,
        notificationId(id),
        Intent(this, MainActivity::class.java)
            .putExtra(MainActivity.EXTRA_OPEN_DOWNLOAD_ID, id)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    private fun acquireWakeLock(id: Long): PowerManager.WakeLock? = runCatching {
        val manager = getSystemService(Context.POWER_SERVICE) as PowerManager
        manager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "NovaDownloader:ytdlp:$id").apply {
            setReferenceCounted(false)
            acquire(MAX_WAKE_LOCK_MS)
        }
    }.getOrNull()

    private data class Task(
        val id: Long,
        val sourceUrl: String,
        val fileName: String,
        val mimeType: String?,
        val destinationTreeUri: String?,
        val partialPath: String?,
        val formatSelector: String?,
        val outputMode: String,
        val audioFormat: String?,
        val videoContainer: String?,
        val qualityId: String?,
        val audioLanguage: String?,
        val subtitleLanguages: String?,
        val writeSubtitles: Boolean,
        val writeAutoSubtitles: Boolean,
        val writeThumbnail: Boolean,
        val writeDescription: Boolean,
        val embedMetadata: Boolean,
        val embedChapters: Boolean,
        val playlistMode: String,
        val liveFromStart: Boolean,
        val duplicatePolicy: String,
        val requestProfileId: String?
    ) {
        companion object {
            fun from(intent: Intent): Task? {
                val id = intent.getLongExtra(EXTRA_ID, -1L)
                val source = intent.getStringExtra(EXTRA_SOURCE_URL).orEmpty()
                val name = intent.getStringExtra(EXTRA_FILE_NAME).orEmpty()
                if (id <= 0 || source.isBlank() || name.isBlank()) return null
                return Task(
                    id = id,
                    sourceUrl = source,
                    fileName = name,
                    mimeType = intent.getStringExtra(EXTRA_MIME),
                    destinationTreeUri = intent.getStringExtra(EXTRA_TREE_URI),
                    partialPath = intent.getStringExtra(EXTRA_PARTIAL_PATH),
                    formatSelector = intent.getStringExtra(EXTRA_FORMAT),
                    outputMode = intent.getStringExtra(EXTRA_OUTPUT_MODE) ?: YtDlpOptionBuilder.MODE_VIDEO,
                    audioFormat = intent.getStringExtra(EXTRA_AUDIO_FORMAT),
                    videoContainer = intent.getStringExtra(EXTRA_VIDEO_CONTAINER),
                    qualityId = intent.getStringExtra(EXTRA_QUALITY),
                    audioLanguage = intent.getStringExtra(EXTRA_AUDIO_LANGUAGE),
                    subtitleLanguages = intent.getStringExtra(EXTRA_SUBTITLE_LANGUAGES),
                    writeSubtitles = intent.getBooleanExtra(EXTRA_WRITE_SUBTITLES, false),
                    writeAutoSubtitles = intent.getBooleanExtra(EXTRA_WRITE_AUTO_SUBTITLES, false),
                    writeThumbnail = intent.getBooleanExtra(EXTRA_WRITE_THUMBNAIL, false),
                    writeDescription = intent.getBooleanExtra(EXTRA_WRITE_DESCRIPTION, false),
                    embedMetadata = intent.getBooleanExtra(EXTRA_EMBED_METADATA, true),
                    embedChapters = intent.getBooleanExtra(EXTRA_EMBED_CHAPTERS, true),
                    playlistMode = intent.getStringExtra(EXTRA_PLAYLIST_MODE) ?: "single",
                    liveFromStart = intent.getBooleanExtra(EXTRA_LIVE_FROM_START, false),
                    duplicatePolicy = intent.getStringExtra(EXTRA_DUPLICATE_POLICY) ?: com.nova.downloader.data.DuplicatePolicy.RENAME,
                    requestProfileId = intent.getStringExtra(EXTRA_REQUEST_PROFILE)
                )
            }
        }
    }

    private class PausedException : RuntimeException()
    private class CancelledException : RuntimeException()

    companion object {
        private const val ACTION_START = "com.nova.downloader.action.YTDLP_START"
        private const val ACTION_PAUSE = "com.nova.downloader.action.YTDLP_PAUSE"
        private const val ACTION_CANCEL = "com.nova.downloader.action.YTDLP_CANCEL"
        private const val EXTRA_ID = "id"
        private const val EXTRA_SOURCE_URL = "source_url"
        private const val EXTRA_FILE_NAME = "file_name"
        private const val EXTRA_MIME = "mime"
        private const val EXTRA_TREE_URI = "tree_uri"
        private const val EXTRA_PARTIAL_PATH = "partial_path"
        private const val EXTRA_FORMAT = "format"
        private const val EXTRA_OUTPUT_MODE = "output_mode"
        private const val EXTRA_AUDIO_FORMAT = "audio_format"
        private const val EXTRA_VIDEO_CONTAINER = "video_container"
        private const val EXTRA_QUALITY = "quality"
        private const val EXTRA_AUDIO_LANGUAGE = "audio_language"
        private const val EXTRA_SUBTITLE_LANGUAGES = "subtitle_languages"
        private const val EXTRA_WRITE_SUBTITLES = "write_subtitles"
        private const val EXTRA_WRITE_AUTO_SUBTITLES = "write_auto_subtitles"
        private const val EXTRA_WRITE_THUMBNAIL = "write_thumbnail"
        private const val EXTRA_WRITE_DESCRIPTION = "write_description"
        private const val EXTRA_EMBED_METADATA = "embed_metadata"
        private const val EXTRA_EMBED_CHAPTERS = "embed_chapters"
        private const val EXTRA_PLAYLIST_MODE = "playlist_mode"
        private const val EXTRA_LIVE_FROM_START = "live_from_start"
        private const val EXTRA_DUPLICATE_POLICY = "duplicate_policy"
        private const val EXTRA_REQUEST_PROFILE = "request_profile"
        private const val CHANNEL_ID = "nova_media_engine"
        private const val CHANNEL_COMPLETIONS = "nova_download_completions"
        private const val SUMMARY_NOTIFICATION_ID = 3700
        private const val MAX_PARALLEL = 1
        private const val MAX_WAKE_LOCK_MS = 6 * 60 * 60 * 1000L
        private val MEDIA_EXTENSIONS = setOf(
            "mp4", "mkv", "webm", "mov", "m4v", "avi", "3gp",
            "mp3", "m4a", "aac", "opus", "ogg", "oga", "flac", "wav"
        )
        private val ACTIVE_IDS = Collections.synchronizedSet(mutableSetOf<Long>())

        fun startIntent(context: Context, item: com.nova.downloader.data.StoredDownload): Intent =
            Intent(context, YtDlpDownloadService::class.java)
                .setAction(ACTION_START)
                .putExtra(EXTRA_ID, item.downloadId)
                .putExtra(EXTRA_SOURCE_URL, item.url)
                .putExtra(EXTRA_FILE_NAME, item.title)
                .putExtra(EXTRA_MIME, item.mediaType)
                .putExtra(EXTRA_TREE_URI, item.destinationTreeUri)
                .putExtra(EXTRA_PARTIAL_PATH, item.partialFilePath)
                .putExtra(EXTRA_FORMAT, item.formatSelector)
                .putExtra(EXTRA_OUTPUT_MODE, item.outputMode)
                .putExtra(EXTRA_AUDIO_FORMAT, item.audioFormat)
                .putExtra(EXTRA_VIDEO_CONTAINER, item.videoContainer)
                .putExtra(EXTRA_QUALITY, item.qualityId)
                .putExtra(EXTRA_AUDIO_LANGUAGE, item.audioLanguage)
                .putExtra(EXTRA_SUBTITLE_LANGUAGES, item.subtitleLanguages)
                .putExtra(EXTRA_WRITE_SUBTITLES, item.writeSubtitles)
                .putExtra(EXTRA_WRITE_AUTO_SUBTITLES, item.writeAutoSubtitles)
                .putExtra(EXTRA_WRITE_THUMBNAIL, item.writeThumbnail)
                .putExtra(EXTRA_WRITE_DESCRIPTION, item.writeDescription)
                .putExtra(EXTRA_EMBED_METADATA, item.embedMetadata)
                .putExtra(EXTRA_EMBED_CHAPTERS, item.embedChapters)
                .putExtra(EXTRA_PLAYLIST_MODE, item.playlistMode)
                .putExtra(EXTRA_LIVE_FROM_START, item.liveFromStart)
                .putExtra(EXTRA_DUPLICATE_POLICY, item.duplicatePolicy)
                .putExtra(EXTRA_REQUEST_PROFILE, requestProfileId(item.headersJson))

        private fun requestProfileId(headersJson: String?): String? = runCatching {
            val raw = headersJson?.takeIf { it.isNotBlank() } ?: return@runCatching null
            JSONObject(raw).optString(YtDlpRequestConfigurator.PROFILE_HEADER).takeIf { it.isNotBlank() }
        }.getOrNull()

        fun pauseIntent(context: Context, id: Long): Intent =
            Intent(context, YtDlpDownloadService::class.java)
                .setAction(ACTION_PAUSE)
                .putExtra(EXTRA_ID, id)

        fun cancelIntent(context: Context, id: Long): Intent =
            Intent(context, YtDlpDownloadService::class.java)
                .setAction(ACTION_CANCEL)
                .putExtra(EXTRA_ID, id)

        fun isActive(id: Long): Boolean = id in ACTIVE_IDS

        fun jobDirectory(context: Context, id: Long, storedPath: String? = null): File {
            storedPath?.takeIf { it.isNotBlank() }?.let { return File(it) }
            val root = context.getExternalFilesDir(android.os.Environment.DIRECTORY_DOWNLOADS) ?: context.filesDir
            return File(root, "ytdlp/$id")
        }

        fun jobBytes(context: Context, id: Long, storedPath: String? = null): Long =
            directoryBytes(jobDirectory(context, id, storedPath))

        private fun directoryBytes(file: File): Long = when {
            !file.exists() -> 0L
            file.isFile -> file.length()
            else -> file.walkTopDown().filter { it.isFile }.sumOf { it.length() }
        }

        private fun processId(id: Long) = "nova-ytdlp-$id"
        private fun notificationId(id: Long): Int = 4000 + (id % 100000).toInt()
    }
}
