package com.nova.downloader.ui

import android.app.AlertDialog
import android.graphics.Bitmap
import android.os.Bundle
import android.view.Gravity
import android.webkit.CookieManager
import android.webkit.SslErrorHandler
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.net.http.SslError
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import com.nova.downloader.R
import com.nova.downloader.data.AccountProfileStore
import com.nova.downloader.data.AppSettings
import com.nova.downloader.data.BrowserCookieExporter
import com.nova.downloader.data.PlatformPolicy
import com.nova.downloader.i18n.LocalizedActivity

class AccountLoginActivity : LocalizedActivity() {
    private lateinit var webView: WebView
    private lateinit var progress: ProgressBar
    private lateinit var profileId: String
    private lateinit var platform: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        profileId = intent.getStringExtra(EXTRA_PROFILE_ID).orEmpty()
        val profile = AccountProfileStore(this).get(profileId)
        if (profile == null) { finish(); return }
        platform = profile.platform
        title = profile.name
        setContentView(buildView(profile.name))
        configureWebView()
        webView.loadUrl(loginUrl(platform))
    }

    private fun buildView(profileName: String): android.view.View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(UiPalette.screenBackground(this@AccountLoginActivity))
        }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        bar.addView(Button(this).apply { text = getString(R.string.back); isAllCaps = false; setOnClickListener { finish() } })
        bar.addView(TextView(this).apply { text = getString(R.string.account_login_title, profileName); textSize = 18f; setPadding(dp(10),0,0,0) }, LinearLayout.LayoutParams(0, -2, 1f))
        bar.addView(Button(this).apply { text = getString(R.string.save_session); isAllCaps = false; setOnClickListener { saveSession() } })
        root.addView(bar)
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 }
        root.addView(progress, LinearLayout.LayoutParams(-1, dp(3)))
        webView = WebView(this)
        root.addView(webView, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(TextView(this).apply {
            text = getString(R.string.account_login_privacy); textSize = 11f; alpha = 0.72f; setPadding(dp(10), dp(6), dp(10), dp(10))
        })
        return root
    }

    private fun configureWebView() {
        val settings = AppSettings(this)
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(false)
            safeBrowsingEnabled = true
        }
        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(webView, settings.browserThirdPartyCookies)
        }
        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) { progress.progress = newProgress }
        }
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val uri = request?.url ?: return true
                return !uri.scheme.equals("https", true)
            }
            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) { super.onPageStarted(view, url, favicon) }
            override fun onReceivedSslError(view: WebView?, handler: SslErrorHandler?, error: SslError?) {
                handler?.cancel()
                AlertDialog.Builder(this@AccountLoginActivity).setTitle(R.string.ssl_error_title)
                    .setMessage(R.string.ssl_error_message).setPositiveButton(R.string.ok, null).show()
            }
        }
    }

    private fun saveSession() {
        val current = webView.url ?: loginUrl(platform)
        BrowserCookieExporter.exportForProfile(this, current, profileId, platform)
            .onSuccess {
                AccountProfileStore(this).setActive(platform, profileId)
                Toast.makeText(this, getString(R.string.account_session_saved), Toast.LENGTH_LONG).show()
                setResult(RESULT_OK); finish()
            }
            .onFailure {
                AlertDialog.Builder(this).setTitle(R.string.account_session_save_failed)
                    .setMessage(it.message ?: getString(R.string.unknown_error)).setPositiveButton(R.string.ok, null).show()
            }
    }

    override fun onDestroy() {
        webView.stopLoading(); webView.clearHistory(); webView.removeAllViews(); webView.destroy()
        super.onDestroy()
    }

    private fun loginUrl(platform: String) = when (platform) {
        PlatformPolicy.YOUTUBE -> "https://accounts.google.com/ServiceLogin?continue=https%3A%2F%2Fwww.youtube.com%2F"
        PlatformPolicy.INSTAGRAM -> "https://www.instagram.com/accounts/login/"
        PlatformPolicy.FACEBOOK -> "https://m.facebook.com/login/"
        PlatformPolicy.TIKTOK -> "https://www.tiktok.com/login"
        PlatformPolicy.TWITTER -> "https://x.com/i/flow/login"
        PlatformPolicy.THREADS -> "https://www.threads.net/login/"
        PlatformPolicy.BLUESKY -> "https://bsky.app/"
        PlatformPolicy.MASTODON -> "https://mastodon.social/auth/sign_in"
        PlatformPolicy.TELEGRAM -> "https://web.telegram.org/"
        else -> "https://duckduckgo.com/"
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    companion object {
        const val EXTRA_PROFILE_ID = "profile_id"
        fun intent(context: android.content.Context, profileId: String) =
            android.content.Intent(context, AccountLoginActivity::class.java).putExtra(EXTRA_PROFILE_ID, profileId)
    }
}
