package com.nova.downloader.ui

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import com.nova.downloader.R
import com.nova.downloader.data.AccountProfile
import com.nova.downloader.data.AccountProfileStore
import com.nova.downloader.data.CookieVault
import com.nova.downloader.data.PlatformPolicy
import com.nova.downloader.i18n.LocalizedActivity

class AccountManagerActivity : LocalizedActivity() {
    private lateinit var store: AccountProfileStore
    private lateinit var listView: ListView
    private lateinit var empty: TextView
    private var profiles = emptyList<AccountProfile>()
    private var pendingImportProfile: AccountProfile? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = AccountProfileStore(this)
        setContentView(buildView())
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun buildView(): android.view.View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(12), dp(12), dp(10)); setBackgroundColor(UiPalette.screenBackground(this@AccountManagerActivity))
        }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(Button(this).apply { text = getString(R.string.back); isAllCaps = false; setOnClickListener { finish() } })
        top.addView(TextView(this).apply { text = getString(R.string.account_manager_title); textSize = 22f; setPadding(dp(10),0,0,0) }, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(Button(this).apply { text = getString(R.string.add_account); isAllCaps = false; setOnClickListener { addAccount() } })
        root.addView(top)
        root.addView(TextView(this).apply { text = getString(R.string.account_manager_info); textSize = 12f; alpha = 0.75f; setPadding(0, dp(8), 0, dp(8)) })
        listView = ListView(this).apply { setOnItemClickListener { _, _, pos, _ -> showActions(profiles[pos]) } }
        empty = TextView(this).apply { text = getString(R.string.no_accounts); gravity = Gravity.CENTER; textSize = 15f }
        listView.emptyView = empty
        val frame = android.widget.FrameLayout(this).apply {
            addView(listView, android.widget.FrameLayout.LayoutParams(-1,-1)); addView(empty, android.widget.FrameLayout.LayoutParams(-1,-1))
        }
        root.addView(frame, LinearLayout.LayoutParams(-1,0,1f))
        return root
    }

    private fun refresh() {
        profiles = store.list()
        val labels = profiles.map { profile ->
            val active = store.active(profile.platform)?.id == profile.id
            val cookie = CookieVault.hasCookies(this, profile.platform, profile.id)
            getString(
                R.string.account_row,
                platformLabel(profile.platform), profile.name,
                if (active) getString(R.string.account_active) else getString(R.string.account_inactive),
                if (cookie) getString(R.string.session_ready) else getString(R.string.session_missing)
            )
        }
        listView.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, labels)
    }

    private fun addAccount() {
        val platforms = PlatformPolicy.accountPlatforms.toTypedArray()
        val labels = platforms.map(::platformLabel).toTypedArray()
        AlertDialog.Builder(this).setTitle(R.string.choose_platform).setItems(labels) { _, index ->
            val input = EditText(this).apply { hint = getString(R.string.account_name_hint); setText(labels[index]); selectAll() }
            AlertDialog.Builder(this).setTitle(R.string.account_name).setView(input)
                .setPositiveButton(R.string.continue_label) { _, _ ->
                    val profile = store.create(platforms[index], input.text.toString())
                    refresh()
                    if (profile.platform != PlatformPolicy.GENERIC) startActivity(AccountLoginActivity.intent(this, profile.id))
                }.setNegativeButton(R.string.cancel, null).show()
        }.show()
    }

    private fun showActions(profile: AccountProfile) {
        val labels = mutableListOf<String>()
        val actions = mutableListOf<() -> Unit>()
        if (profile.platform != PlatformPolicy.GENERIC) {
            labels += getString(R.string.sign_in_refresh); actions += { startActivity(AccountLoginActivity.intent(this, profile.id)) }
        }
        labels += getString(R.string.import_cookies_for_account); actions += { chooseCookieFile(profile) }
        labels += getString(R.string.set_active_account); actions += { store.setActive(profile.platform, profile.id); refresh() }
        labels += getString(R.string.rename_account); actions += { rename(profile) }
        labels += if (profile.enabled) getString(R.string.disable_account) else getString(R.string.enable_account)
        actions += { store.setEnabled(profile.id, !profile.enabled); refresh() }
        labels += getString(R.string.sign_out_clear_session); actions += {
            CookieVault.clear(this, profile.platform, profile.id); refresh(); toast(getString(R.string.account_signed_out))
        }
        labels += getString(R.string.delete_account); actions += { confirmDelete(profile) }
        AlertDialog.Builder(this).setTitle(profile.name).setItems(labels.toTypedArray()) { _, i -> actions[i]() }.show()
    }

    private fun rename(profile: AccountProfile) {
        val input = EditText(this).apply { setText(profile.name); setSelection(text.length) }
        AlertDialog.Builder(this).setTitle(R.string.rename_account).setView(input)
            .setPositiveButton(R.string.save) { _, _ -> store.rename(profile.id, input.text.toString()); refresh() }
            .setNegativeButton(R.string.cancel, null).show()
    }

    private fun confirmDelete(profile: AccountProfile) {
        AlertDialog.Builder(this).setTitle(R.string.delete_account).setMessage(R.string.delete_account_confirm)
            .setPositiveButton(R.string.delete) { _, _ ->
                CookieVault.clear(this, profile.platform, profile.id); store.remove(profile.id); refresh()
            }.setNegativeButton(R.string.cancel, null).show()
    }

    private fun chooseCookieFile(profile: AccountProfile) {
        pendingImportProfile = profile
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"; putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("text/plain", "application/octet-stream"))
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }, REQ_COOKIE)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_COOKIE || resultCode != RESULT_OK) return
        val profile = pendingImportProfile ?: return
        val uri = data?.data ?: return
        CookieVault.importFromUri(this, uri, profile.platform, profile.id)
            .onSuccess { store.setActive(profile.platform, profile.id); toast(it); refresh() }
            .onFailure { toast(it.message ?: getString(R.string.cookie_import_failed)) }
    }

    private fun platformLabel(platform: String) = when (platform) {
        PlatformPolicy.YOUTUBE -> "YouTube"
        PlatformPolicy.INSTAGRAM -> "Instagram"
        PlatformPolicy.FACEBOOK -> "Facebook"
        PlatformPolicy.TIKTOK -> "TikTok"
        PlatformPolicy.TWITTER -> "X"
        PlatformPolicy.THREADS -> "Threads"
        PlatformPolicy.BLUESKY -> "Bluesky"
        PlatformPolicy.MASTODON -> "Mastodon"
        PlatformPolicy.TELEGRAM -> "Telegram"
        else -> getString(R.string.profile_generic)
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    companion object { private const val REQ_COOKIE = 901 }
}
