package com.nova.downloader.ui

import android.app.AlertDialog
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.net.http.SslError
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.webkit.CookieManager
import android.webkit.DownloadListener
import android.webkit.PermissionRequest
import android.webkit.SslErrorHandler
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import com.nova.downloader.i18n.LocalizedActivity
import com.nova.downloader.R
import com.nova.downloader.core.BrowserMediaDetector
import com.nova.downloader.core.FileNameResolver
import com.nova.downloader.data.AppSettings
import com.nova.downloader.data.BrowserCookieExporter
import com.nova.downloader.data.BrowserTransfer
import org.json.JSONArray
import org.json.JSONTokener
import java.net.URI
import java.util.LinkedHashMap

/**
 * Privacy-oriented in-app browser with automatic media discovery.
 * It never bypasses TLS errors, does not expose a JavaScript native bridge, and only accepts HTTPS pages.
 */
class BrowserActivity : LocalizedActivity() {
    private lateinit var settingsStore: AppSettings
    private lateinit var webView: WebView
    private lateinit var addressInput: EditText
    private lateinit var progress: ProgressBar
    private lateinit var statusText: TextView
    private lateinit var candidateButton: Button
    private lateinit var backButton: Button
    private lateinit var forwardButton: Button

    private val candidates = LinkedHashMap<String, Candidate>()
    private val pollHandler = Handler(Looper.getMainLooper())
    private var pageTitle: String = ""
    private var browserUserAgent: String = ""
    private var pageUrl: String = ""
    private var destroyed = false

    private val pollRunnable = object : Runnable {
        override fun run() {
            if (destroyed || !::webView.isInitialized) return
            if (settingsStore.browserAutoDetectEnabled && webView.progress >= 70) scanDocumentMedia()
            pollHandler.postDelayed(this, DOM_SCAN_INTERVAL_MS)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        settingsStore = AppSettings(this)
        pageTitle = getString(R.string.browser_title)
        setContentView(buildContent())
        configureWebView()

        if (savedInstanceState == null || webView.restoreState(savedInstanceState) == null) {
            val requested = intent.getStringExtra(EXTRA_START_URL).orEmpty()
            openInput(requested.ifBlank { settingsStore.browserHomeUrl })
        }
    }

    override fun onResume() {
        super.onResume()
        webView.onResume()
        pollHandler.removeCallbacks(pollRunnable)
        pollHandler.postDelayed(pollRunnable, DOM_SCAN_INTERVAL_MS)
    }

    override fun onPause() {
        pollHandler.removeCallbacks(pollRunnable)
        webView.onPause()
        CookieManager.getInstance().flush()
        super.onPause()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        webView.saveState(outState)
        super.onSaveInstanceState(outState)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        destroyed = true
        pollHandler.removeCallbacksAndMessages(null)
        if (settingsStore.browserClearCacheOnExit) {
            webView.clearCache(true)
            webView.clearHistory()
        }
        webView.stopLoading()
        webView.removeAllViews()
        webView.destroy()
        super.onDestroy()
    }

    private fun buildContent(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(UiPalette.screenBackground(this@BrowserActivity))
        }

        val titleRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(7), dp(8), dp(4))
        }
        titleRow.addView(TextView(this).apply {
            setText(R.string.browser_title)
            textSize = 19f
            setTypeface(typeface, Typeface.BOLD)
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        titleRow.addView(Button(this).apply {
            setText(R.string.browser_save_session)
            textSize = 11f
            isAllCaps = false
            setOnClickListener { saveBrowserSession(showResult = true) }
        })
        titleRow.addView(Button(this).apply {
            setText(R.string.close)
            textSize = 11f
            isAllCaps = false
            setOnClickListener { finish() }
        })
        root.addView(titleRow)

        val navRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(7), 0, dp(7), dp(3))
        }
        backButton = navButton("‹") { if (webView.canGoBack()) webView.goBack() }
        forwardButton = navButton("›") { if (webView.canGoForward()) webView.goForward() }
        navRow.addView(backButton, LinearLayout.LayoutParams(dp(48), dp(48)))
        navRow.addView(forwardButton, LinearLayout.LayoutParams(dp(48), dp(48)))
        navRow.addView(navButton("↻") { webView.reload() }, LinearLayout.LayoutParams(dp(48), dp(48)))
        navRow.addView(navButton("⌂") { openInput(settingsStore.browserHomeUrl) }, LinearLayout.LayoutParams(dp(48), dp(48)))
        root.addView(navRow)

        val addressRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(9), 0, dp(9), dp(5))
        }
        addressInput = EditText(this).apply {
            setHint(R.string.browser_address_hint)
            isSingleLine = true
            inputType = android.text.InputType.TYPE_CLASS_TEXT or
                android.text.InputType.TYPE_TEXT_VARIATION_URI or
                android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            setOnEditorActionListener { _, _, event ->
                if (event == null || event.keyCode == KeyEvent.KEYCODE_ENTER) {
                    openInput(text?.toString().orEmpty()); true
                } else false
            }
        }
        addressRow.addView(addressInput, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        addressRow.addView(Button(this).apply {
            setText(R.string.browser_go)
            isAllCaps = false
            setOnClickListener { openInput(addressInput.text?.toString().orEmpty()) }
        }, LinearLayout.LayoutParams(dp(62), LinearLayout.LayoutParams.WRAP_CONTENT).apply { marginStart = dp(5) })
        root.addView(addressRow)

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = 0
        }
        root.addView(progress, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(3)))

        webView = WebView(this)
        root.addView(webView, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(9), dp(5), dp(9), dp(8))
            setBackgroundColor(UiPalette.surface(this@BrowserActivity))
        }
        statusText = TextView(this).apply {
            setText(R.string.browser_status_initial)
            textSize = 11.5f
            alpha = 0.78f
            maxLines = 2
        }
        bottom.addView(statusText)
        val actionRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        candidateButton = Button(this).apply {
            text = getString(R.string.browser_detected_count, 0)
            isAllCaps = false
            isEnabled = false
            setOnClickListener { showCandidates() }
        }
        actionRow.addView(candidateButton, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        actionRow.addView(Button(this).apply {
            setText(R.string.browser_download_page)
            isAllCaps = false
            setOnClickListener { currentPageCandidate()?.let(::downloadCandidate) ?: toast(getString(R.string.browser_open_page_first)) }
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(7) })
        bottom.addView(actionRow)
        root.addView(bottom)
        return root
    }

    private fun configureWebView() {
        WebView.setWebContentsDebuggingEnabled(false)
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            allowFileAccessFromFileURLs = false
            allowUniversalAccessFromFileURLs = false
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(false)
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            mediaPlaybackRequiresUserGesture = true
            builtInZoomControls = true
            displayZoomControls = false
            loadWithOverviewMode = true
            useWideViewPort = true
            setGeolocationEnabled(false)
            safeBrowsingEnabled = true
        }
        browserUserAgent = webView.settings.userAgentString.orEmpty()
        webView.isLongClickable = true

        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(webView, settingsStore.browserThirdPartyCookies)
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                progress.progress = newProgress
                progress.visibility = if (newProgress >= 100) View.GONE else View.VISIBLE
            }

            override fun onReceivedTitle(view: WebView?, title: String?) {
                pageTitle = title?.trim().orEmpty().ifBlank { getString(R.string.browser_title) }
            }

            override fun onPermissionRequest(request: PermissionRequest?) {
                request?.deny()
                runOnUiThread { toast(getString(R.string.browser_permission_rejected)) }
            }

            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                filePathCallback?.onReceiveValue(null)
                return true
            }
        }

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val target = request?.url?.toString().orEmpty()
                if (target.startsWith("about:blank")) return false
                val safe = BrowserMediaDetector.normalizeHttpsUrl(target)
                if (safe == null) {
                    runOnUiThread { toast(getString(R.string.browser_https_only)) }
                    return true
                }
                return false
            }

            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                if (settingsStore.browserAutoDetectEnabled && request != null) {
                    captureCandidate(
                        rawUrl = request.url.toString(),
                        mimeType = request.requestHeaders["Content-Type"],
                        source = getString(R.string.browser_source_network),
                        requestHeaders = request.requestHeaders
                    )
                }
                return null
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                pageUrl = BrowserMediaDetector.normalizeHttpsUrl(url).orEmpty()
                synchronized(candidates) { candidates.clear() }
                updateCandidateUi()
                addressInput.setText(url.orEmpty())
                statusText.setText(R.string.browser_loading)
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                pageUrl = BrowserMediaDetector.normalizeHttpsUrl(url).orEmpty()
                addressInput.setText(url.orEmpty())
                addressInput.setSelection(addressInput.text.length)
                addPageCandidate()
                updateNavigation()
                statusText.text = if (settingsStore.browserAutoDetectEnabled) {
                    getString(R.string.browser_monitoring)
                } else getString(R.string.browser_detection_disabled)
                scanDocumentMedia()
            }

            override fun onLoadResource(view: WebView?, url: String?) {
                if (settingsStore.browserAutoDetectEnabled) captureCandidate(url.orEmpty(), null, getString(R.string.browser_source_page), emptyMap())
            }

            override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                if (request?.isForMainFrame == true) statusText.text = getString(R.string.browser_page_error, error?.description?.toString().orEmpty())
            }

            override fun onReceivedSslError(view: WebView?, handler: SslErrorHandler?, error: SslError?) {
                handler?.cancel()
                runOnUiThread {
                    AlertDialog.Builder(this@BrowserActivity)
                        .setTitle(getString(R.string.browser_tls_error_title))
                        .setMessage(getString(R.string.browser_tls_error_message))
                        .setPositiveButton(R.string.ok, null)
                        .show()
                }
            }

        }

        webView.setDownloadListener(DownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
            val headers = linkedMapOf<String, String>()
            if (!userAgent.isNullOrBlank()) headers["User-Agent"] = userAgent
            if (pageUrl.isNotBlank()) headers["Referer"] = pageUrl
            captureCandidate(url.orEmpty(), mimeType, getString(R.string.browser_source_download), headers, contentDisposition)
            runOnUiThread { showCandidates() }
        })
    }

    private fun openInput(raw: String) {
        val value = raw.trim()
        val target = when {
            value.startsWith("https://", true) -> BrowserMediaDetector.normalizeHttpsUrl(value)
            value.startsWith("http://", true) -> null
            value.contains('.') && !value.contains(' ') -> BrowserMediaDetector.normalizeHttpsUrl("https://$value")
            value.isNotBlank() -> "https://duckduckgo.com/?q=${Uri.encode(value)}"
            else -> BrowserMediaDetector.normalizeHttpsUrl(settingsStore.browserHomeUrl)
        }
        if (target == null) {
            toast(getString(R.string.browser_enter_https))
            return
        }
        webView.loadUrl(target)
    }

    private fun scanDocumentMedia() {
        if (pageUrl.isBlank()) return
        val script = """
            (() => {
              const out = new Set();
              const add = value => {
                if (typeof value === 'string' && value.startsWith('https://')) out.add(value);
              };
              document.querySelectorAll('video,audio,source').forEach(node => {
                add(node.currentSrc); add(node.src);
                if (node.getAttribute) add(node.getAttribute('src'));
              });
              try {
                performance.getEntriesByType('resource').forEach(entry => {
                  const value = entry && entry.name;
                  if (typeof value === 'string' && /\\.(mp4|m4v|mov|webm|mkv|mp3|m4a|aac|ogg|opus|flac|wav|m3u8|mpd)(?:[?#]|$)/i.test(value)) add(value);
                });
              } catch (_) {}
              return JSON.stringify(Array.from(out).slice(0, 80));
            })();
        """.trimIndent()
        webView.evaluateJavascript(script) { raw ->
            if (raw.isNullOrBlank() || raw == "null") return@evaluateJavascript
            runCatching {
                val decoded = JSONTokener(raw).nextValue() as? String ?: raw
                val array = JSONArray(decoded)
                for (index in 0 until array.length()) {
                    captureCandidate(array.optString(index), null, getString(R.string.browser_source_dom), emptyMap())
                }
            }
        }
    }

    private fun addPageCandidate() {
        val normalized = BrowserMediaDetector.normalizeHttpsUrl(pageUrl) ?: return
        val candidate = Candidate(
            url = normalized,
            pageUrl = normalized,
            title = pageTitle,
            mimeType = "text/html",
            kind = BrowserMediaDetector.Kind.PAGE,
            source = getString(R.string.browser_source_open_page),
            headers = browserHeaders(normalized)
        )
        synchronized(candidates) { candidates[candidate.key] = candidate }
        updateCandidateUi()
    }

    private fun captureCandidate(
        rawUrl: String,
        mimeType: String?,
        source: String,
        requestHeaders: Map<String, String>,
        contentDisposition: String? = null
    ) {
        val normalized = BrowserMediaDetector.normalizeHttpsUrl(rawUrl) ?: return
        val match = BrowserMediaDetector.classify(normalized, mimeType, allowPage = false) ?: return
        val headers = linkedMapOf<String, String>()
        requestHeaders.forEach { (name, value) ->
            if (name.equals("User-Agent", true) || name.equals("Referer", true) || name.equals("Origin", true)) {
                headers[name] = value
            }
        }
        browserHeaders(pageUrl).forEach { (name, value) -> headers.putIfAbsent(name, value) }
        val fallbackTitle = if (!contentDisposition.isNullOrBlank()) {
            FileNameResolver.fromContentDisposition(contentDisposition, FileNameResolver.fromUrl(normalized))
        } else FileNameResolver.fromUrl(normalized)
        val candidate = Candidate(
            url = normalized,
            pageUrl = pageUrl.ifBlank { normalized },
            title = fallbackTitle.ifBlank { pageTitle },
            mimeType = match.mimeType,
            kind = match.kind,
            source = source,
            headers = headers
        )
        synchronized(candidates) {
            if (candidates.size >= MAX_CANDIDATES && !candidates.containsKey(candidate.key)) {
                val removable = candidates.entries.firstOrNull { it.value.kind != BrowserMediaDetector.Kind.PAGE }?.key
                if (removable != null) candidates.remove(removable)
            }
            candidates[candidate.key] = candidate
        }
        runOnUiThread { updateCandidateUi() }
    }

    private fun browserHeaders(referer: String): Map<String, String> = buildMap {
        browserUserAgent.takeIf { it.isNotBlank() }?.let { put("User-Agent", it) }
        referer.takeIf { it.isNotBlank() }?.let { safeReferer ->
            put("Referer", safeReferer)
            CookieManager.getInstance().getCookie(safeReferer)?.takeIf { it.isNotBlank() }?.let { put("Cookie", it) }
        }
    }

    private fun showCandidates() {
        val snapshot = synchronized(candidates) { candidates.values.toList() }
        if (snapshot.isEmpty()) {
            toast(getString(R.string.browser_no_media))
            return
        }
        val labels = snapshot.map { candidate ->
            val host = runCatching { URI(candidate.url).host.orEmpty() }.getOrDefault("")
            getString(
                R.string.browser_candidate_label,
                getString(BrowserMediaDetector.labelRes(candidate.kind)),
                candidate.source,
                candidate.title.take(70),
                if (host.isBlank()) "" else getString(R.string.browser_host_suffix, host)
            )
        }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle(R.string.browser_choose_item)
            .setItems(labels) { _, which -> downloadCandidate(snapshot[which]) }
            .setNegativeButton(R.string.close, null)
            .show()
    }

    private fun downloadCandidate(candidate: Candidate) {
        statusText.setText(R.string.browser_preparing_session)
        Thread {
            if (settingsStore.browserSyncCookies && candidate.pageUrl.isNotBlank()) {
                BrowserCookieExporter.exportCurrentSession(this, candidate.pageUrl)
                    .onSuccess { settingsStore.useCookies = true }
            }
            val headers = candidate.headers.toMutableMap()
            CookieManager.getInstance().getCookie(candidate.pageUrl)?.takeIf { it.isNotBlank() }?.let { headers["Cookie"] = it }
            runOnUiThread {
                val intent = Intent(this, MainActivity::class.java).apply {
                    action = BrowserTransfer.ACTION_DOWNLOAD
                    addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                    putExtra(BrowserTransfer.EXTRA_URL, candidate.url)
                    putExtra(BrowserTransfer.EXTRA_PAGE_URL, candidate.pageUrl)
                    putExtra(BrowserTransfer.EXTRA_TITLE, candidate.title)
                    putExtra(BrowserTransfer.EXTRA_MIME_TYPE, candidate.mimeType)
                    putExtra(BrowserTransfer.EXTRA_KIND, candidate.kind.name)
                    BrowserTransfer.putHeaders(this, headers)
                }
                startActivity(intent)
                statusText.setText(R.string.browser_sent_to_nova)
            }
        }.start()
    }

    private fun saveBrowserSession(showResult: Boolean) {
        val current = pageUrl
        if (current.isBlank()) {
            toast(getString(R.string.browser_open_logged_page))
            return
        }
        Thread {
            BrowserCookieExporter.exportCurrentSession(this, current)
                .onSuccess {
                    settingsStore.useCookies = true
                    if (showResult) runOnUiThread { toast(it) }
                }
                .onFailure { if (showResult) runOnUiThread { toast(it.message ?: getString(R.string.browser_session_export_failed)) } }
        }.start()
    }

    private fun currentPageCandidate(): Candidate? = synchronized(candidates) {
        candidates.values.firstOrNull { it.kind == BrowserMediaDetector.Kind.PAGE }
    }

    private fun updateCandidateUi() {
        if (!::candidateButton.isInitialized) return
        val directCount = synchronized(candidates) { candidates.values.count { it.kind != BrowserMediaDetector.Kind.PAGE } }
        candidateButton.text = if (directCount > 0) getString(R.string.browser_detected_count, directCount) else getString(R.string.browser_video_options)
        candidateButton.isEnabled = synchronized(candidates) { candidates.isNotEmpty() }
        updateNavigation()
    }

    private fun updateNavigation() {
        if (::backButton.isInitialized) backButton.isEnabled = webView.canGoBack()
        if (::forwardButton.isInitialized) forwardButton.isEnabled = webView.canGoForward()
    }

    private fun navButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        textSize = 20f
        isAllCaps = false
        setTextColor(Color.DKGRAY)
        setOnClickListener { action() }
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    private data class Candidate(
        val url: String,
        val pageUrl: String,
        val title: String,
        val mimeType: String?,
        val kind: BrowserMediaDetector.Kind,
        val source: String,
        val headers: Map<String, String>
    ) {
        val key: String get() = "${kind.name}|$url"
    }

    companion object {
        const val EXTRA_START_URL = "start_url"
        private const val DOM_SCAN_INTERVAL_MS = 2_000L
        private const val MAX_CANDIDATES = 80
    }
}
