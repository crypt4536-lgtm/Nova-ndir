package com.nova.downloader.ui

import android.content.Context
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import com.nova.downloader.R
import com.nova.downloader.data.DownloadState
import com.nova.downloader.data.DownloadSnapshot
import java.text.DateFormat
import java.util.Date

class DownloadAdapter(private val context: Context) : BaseAdapter() {
    private val items = mutableListOf<DownloadSnapshot>()

    fun submitList(newItems: List<DownloadSnapshot>) {
        items.clear()
        items.addAll(newItems)
        notifyDataSetChanged()
    }

    override fun getCount(): Int = items.size
    override fun getItem(position: Int): DownloadSnapshot = items[position]
    override fun getItemId(position: Int): Long = items[position].stored.downloadId

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val holder: Holder
        val row: LinearLayout

        if (convertView is LinearLayout && convertView.tag is Holder) {
            row = convertView
            holder = convertView.tag as Holder
        } else {
            row = LinearLayout(context).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(16), dp(13), dp(16), dp(13))
                minimumHeight = dp(92)
            }
            val title = TextView(context).apply {
                textSize = 16f
                setTypeface(typeface, Typeface.BOLD)
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.MIDDLE
            }
            val status = TextView(context).apply {
                textSize = 13f
                setPadding(0, dp(5), 0, dp(4))
            }
            val progress = ProgressBar(
                context,
                null,
                android.R.attr.progressBarStyleHorizontal
            ).apply {
                max = 100
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    dp(5)
                )
            }
            val meta = TextView(context).apply {
                textSize = 11f
                gravity = Gravity.START
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
                alpha = 0.7f
                setPadding(0, dp(5), 0, 0)
            }

            row.addView(title)
            row.addView(status)
            row.addView(progress)
            row.addView(meta)
            holder = Holder(title, status, progress, meta)
            row.tag = holder
        }

        bind(holder, items[position])
        return row
    }

    private fun bind(holder: Holder, item: DownloadSnapshot) {
        holder.title.text = item.stored.title
        holder.status.text = statusText(item)
        holder.meta.text = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT)
            .format(Date(item.stored.createdAt)) + "  •  " + item.stored.url

        val progress = item.progressPercent
        when {
            item.status == DownloadState.SUCCESSFUL -> {
                holder.progress.visibility = View.VISIBLE
                holder.progress.isIndeterminate = false
                holder.progress.progress = 100
            }
            item.status == DownloadState.RUNNING && progress != null -> {
                holder.progress.visibility = View.VISIBLE
                holder.progress.isIndeterminate = false
                holder.progress.progress = progress
            }
            item.status == DownloadState.PENDING ||
                item.status == DownloadState.PAUSED ||
                item.status == DownloadState.RUNNING -> {
                holder.progress.visibility = View.VISIBLE
                holder.progress.isIndeterminate = true
            }
            else -> holder.progress.visibility = View.GONE
        }
    }

    private fun statusText(item: DownloadSnapshot): String {
        val sizeText = if (item.totalBytes > 0) context.getString(
            R.string.size_progress,
            formatBytes(item.bytesDownloaded),
            formatBytes(item.totalBytes)
        ) else ""
        return when (item.status) {
            DownloadState.PENDING -> context.getString(R.string.status_queued)
            DownloadState.RUNNING -> context.getString(
                R.string.status_downloading,
                item.progressPercent?.let { context.getString(R.string.progress_percent, it) }.orEmpty(),
                sizeText
            )
            DownloadState.PAUSED -> context.getString(R.string.status_paused_resumable, sizeText)
            DownloadState.SUCCESSFUL -> context.getString(R.string.status_completed, formatBytes(item.totalBytes.coerceAtLeast(item.bytesDownloaded)))
            DownloadState.FAILED -> if (item.stored.hasPartialData) context.getString(R.string.status_interrupted_resumable, sizeText) else context.getString(R.string.status_failed)
            DownloadState.CANCELLED -> if (item.stored.hasPartialData) context.getString(R.string.status_paused, sizeText) else context.getString(R.string.status_cancelled)
            DownloadState.INVALID_CONTENT -> context.getString(R.string.status_invalid_content)
            else -> context.getString(R.string.status_unknown)
        }
    }

    private fun formatBytes(value: Long): String {
        if (value < 0L) return "?"
        if (value < 1024L) return context.getString(R.string.bytes_format, value)
        val kb = value / 1024.0
        if (kb < 1024.0) return context.getString(R.string.kilobytes_format, kb)
        val mb = kb / 1024.0
        if (mb < 1024.0) return context.getString(R.string.megabytes_format, mb)
        return context.getString(R.string.gigabytes_format, mb / 1024.0)
    }

    private fun dp(value: Int): Int = (value * context.resources.displayMetrics.density).toInt()

    private data class Holder(
        val title: TextView,
        val status: TextView,
        val progress: ProgressBar,
        val meta: TextView
    )
}
