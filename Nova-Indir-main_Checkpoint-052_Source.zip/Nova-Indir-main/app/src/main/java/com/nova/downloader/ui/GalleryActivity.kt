package com.nova.downloader.ui

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.nova.downloader.R
import com.nova.downloader.data.DownloadRepository
import com.nova.downloader.data.DownloadState
import com.nova.downloader.data.HistoryStore
import com.nova.downloader.data.StorageHelper
import com.nova.downloader.data.StoredDownload
import com.nova.downloader.i18n.LocalizedActivity

class GalleryActivity : LocalizedActivity() {
    private lateinit var repository: DownloadRepository
    private lateinit var adapter: GalleryAdapter
    private lateinit var search: EditText
    private lateinit var filter: Spinner
    private lateinit var sort: Spinner
    private val all = mutableListOf<StoredDownload>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        repository = DownloadRepository(this)
        setContentView(buildView())
    }

    override fun onResume() {
        super.onResume()
        reloadGallery()
    }

    private fun reloadGallery() {
        repository.synchronizeCompletedOutputMetadata()
        all.clear()
        all += HistoryStore(this).list().filter {
            it.status == DownloadState.SUCCESSFUL && !it.outputUri.isNullOrBlank()
        }
        applyFilters()
    }

    private fun buildView(): android.view.View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(8))
            setBackgroundColor(UiPalette.screenBackground(this@GalleryActivity))
        }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(Button(this).apply { text = getString(R.string.back); isAllCaps = false; setOnClickListener { finish() } })
        top.addView(TextView(this).apply { text = getString(R.string.gallery_title); textSize = 22f; setPadding(dp(10),0,0,0) }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(top)

        search = EditText(this).apply { hint = getString(R.string.gallery_search); isSingleLine = true }
        root.addView(search)
        val selectors = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        filter = Spinner(this).apply {
            adapter = ArrayAdapter(this@GalleryActivity, android.R.layout.simple_spinner_dropdown_item, arrayOf(
                getString(R.string.filter_all), getString(R.string.video), getString(R.string.audio), getString(R.string.file)
            ))
        }
        sort = Spinner(this).apply {
            adapter = ArrayAdapter(this@GalleryActivity, android.R.layout.simple_spinner_dropdown_item, arrayOf(
                getString(R.string.sort_newest), getString(R.string.sort_oldest), getString(R.string.sort_name), getString(R.string.sort_size)
            ))
        }
        selectors.addView(filter, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        selectors.addView(sort, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(selectors)

        adapter = GalleryAdapter(
            this,
            onClick = { item -> startActivity(PlayerActivity.intent(this, item)) },
            onLongClick = ::showActions
        )
        val list = RecyclerView(this).apply {
            layoutManager = GridLayoutManager(this@GalleryActivity, if (resources.configuration.screenWidthDp >= 600) 4 else 2)
            adapter = this@GalleryActivity.adapter
        }
        root.addView(list, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = applyFilters()
            override fun afterTextChanged(s: Editable?) = Unit
        })
        val listener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: android.view.View?, position: Int, id: Long) = applyFilters()
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) = Unit
        }
        filter.onItemSelectedListener = listener; sort.onItemSelectedListener = listener
        return root
    }

    private fun applyFilters() {
        if (!::adapter.isInitialized) return
        val query = if (::search.isInitialized) search.text.toString().trim().lowercase() else ""
        var result = all.filter { item ->
            val typeOk = when (if (::filter.isInitialized) filter.selectedItemPosition else 0) {
                1 -> item.mediaType?.startsWith("video/") == true
                2 -> item.mediaType?.startsWith("audio/") == true
                3 -> item.mediaType?.startsWith("video/") != true && item.mediaType?.startsWith("audio/") != true
                else -> true
            }
            typeOk && (query.isBlank() || item.title.lowercase().contains(query))
        }
        result = when (if (::sort.isInitialized) sort.selectedItemPosition else 0) {
            1 -> result.sortedBy { it.updatedAt }
            2 -> result.sortedBy { it.title.lowercase() }
            3 -> result.sortedByDescending { it.totalBytes.coerceAtLeast(it.bytesDownloaded) }
            else -> result.sortedByDescending { it.updatedAt }
        }
        adapter.submit(result)
    }

    private fun showActions(item: StoredDownload) {
        val labels = arrayOf(
            getString(R.string.play_in_nova), getString(R.string.open_external),
            getString(R.string.open_file_location), getString(R.string.rename_downloaded_file),
            getString(R.string.share)
        )
        AlertDialog.Builder(this).setTitle(item.title).setItems(labels) { _, which ->
            when (which) {
                0 -> startActivity(PlayerActivity.intent(this, item))
                1 -> StorageHelper.openFile(this, item)
                2 -> StorageHelper.openLocation(this, item)
                3 -> showRenameDialog(item)
                4 -> item.outputUri?.let { uri -> startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                    type = item.mediaType ?: "*/*"; putExtra(Intent.EXTRA_STREAM, android.net.Uri.parse(uri)); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }, getString(R.string.share))) }
            }
        }.show()
    }


    private fun showRenameDialog(item: StoredDownload) {
        val input = EditText(this).apply {
            setText(item.title)
            setSelection(text.length)
            isSingleLine = true
            hint = getString(R.string.new_file_name)
            imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_DONE
        }
        val cancelButton = Button(this).apply {
            text = getString(R.string.cancel)
            isAllCaps = false
        }
        val applyButton = Button(this).apply {
            text = getString(R.string.apply_changes)
            isAllCaps = false
        }
        val actionRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END
            setPadding(0, dp(14), 0, 0)
            addView(cancelButton, LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f
            ))
            addView(applyButton, LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f
            ).apply { marginStart = dp(10) })
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(8), dp(22), dp(16))
            addView(input)
            addView(TextView(this@GalleryActivity).apply {
                text = getString(R.string.rename_preserves_extension)
                textSize = 12f
                alpha = 0.7f
                setPadding(0, dp(8), 0, 0)
            })
            addView(actionRow)
        }
        val dialog = AlertDialog.Builder(this)
            .setTitle(getString(R.string.rename_downloaded_file))
            .setView(content)
            .create()

        fun applyRename() {
            val requested = input.text?.toString().orEmpty().trim()
            if (requested.isBlank()) {
                input.error = getString(R.string.file_name_required)
                return
            }
            when (val result = repository.renameCompleted(item.downloadId, requested)) {
                is DownloadRepository.RenameResult.Success -> {
                    android.widget.Toast.makeText(
                        this,
                        getString(R.string.file_renamed_message, result.item.title),
                        android.widget.Toast.LENGTH_SHORT
                    ).show()
                    dialog.dismiss()
                    reloadGallery()
                }
                is DownloadRepository.RenameResult.Error -> input.error = result.message
            }
        }

        cancelButton.setOnClickListener { dialog.dismiss() }
        applyButton.setOnClickListener { applyRename() }
        input.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == android.view.inputmethod.EditorInfo.IME_ACTION_DONE) {
                applyRename()
                true
            } else {
                false
            }
        }

        dialog.setOnShowListener {
            dialog.window?.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
            input.requestFocus()
        }
        dialog.show()
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}
