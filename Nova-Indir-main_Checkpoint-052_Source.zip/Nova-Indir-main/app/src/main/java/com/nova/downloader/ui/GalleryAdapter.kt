package com.nova.downloader.ui

import android.content.Context
import android.graphics.Typeface
import android.view.Gravity
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.nova.downloader.R
import com.nova.downloader.data.StoredDownload
import java.text.DateFormat
import java.util.Date

class GalleryAdapter(
    private val context: Context,
    private val onClick: (StoredDownload) -> Unit,
    private val onLongClick: (StoredDownload) -> Unit
) : RecyclerView.Adapter<GalleryAdapter.Holder>() {
    private val items = mutableListOf<StoredDownload>()

    fun submit(newItems: List<StoredDownload>) {
        items.clear(); items.addAll(newItems); notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
        val root = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(6), dp(6), dp(6), dp(10))
        }
        val image = ImageView(context).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            adjustViewBounds = true
        }
        root.addView(image, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(116)))
        val title = TextView(context).apply {
            textSize = 14f; maxLines = 2; setTypeface(typeface, Typeface.BOLD); setPadding(0, dp(6), 0, 0)
        }
        root.addView(title)
        val meta = TextView(context).apply { textSize = 11f; alpha = 0.68f; maxLines = 1 }
        root.addView(meta)
        return Holder(root, image, title, meta)
    }

    override fun onBindViewHolder(holder: Holder, position: Int) {
        val item = items[position]
        holder.title.text = item.title
        holder.meta.text = context.getString(
            R.string.gallery_item_meta,
            typeLabel(item),
            DateFormat.getDateInstance(DateFormat.SHORT).format(Date(item.updatedAt))
        )
        ThumbnailLoader.load(context, item, holder.image)
        holder.itemView.setOnClickListener { onClick(item) }
        holder.itemView.setOnLongClickListener { onLongClick(item); true }
    }

    override fun getItemCount() = items.size

    private fun typeLabel(item: StoredDownload): String = when {
        item.mediaType?.startsWith("audio/") == true -> context.getString(R.string.audio)
        item.mediaType?.startsWith("video/") == true -> context.getString(R.string.video)
        else -> context.getString(R.string.file)
    }

    private fun dp(value: Int) = (value * context.resources.displayMetrics.density).toInt()

    class Holder(root: LinearLayout, val image: ImageView, val title: TextView, val meta: TextView) : RecyclerView.ViewHolder(root)
}
