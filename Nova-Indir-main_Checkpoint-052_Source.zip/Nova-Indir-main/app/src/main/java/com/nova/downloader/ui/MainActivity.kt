package com.nova.downloader.ui

import android.Manifest
import android.app.AlertDialog
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.ConnectivityManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ArrayAdapter
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.Spinner
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import com.nova.downloader.i18n.LocalizedActivity
import com.nova.downloader.BuildConfig
import com.nova.downloader.R
import com.nova.downloader.core.BrowserMediaDetector
import com.nova.downloader.core.FileNameResolver
import com.nova.downloader.core.MediaTypePolicy
import com.nova.downloader.core.UrlPolicy
import com.nova.downloader.core.YtDlpOptionBuilder
import com.nova.downloader.data.AppSettings
import com.nova.downloader.data.BrowserTransfer
import com.nova.downloader.data.CompletionEventStore
import com.nova.downloader.data.DefaultMediaSelectionPolicy
import com.nova.downloader.data.DownloadRepository
import com.nova.downloader.data.DownloadEngine
import com.nova.downloader.data.DuplicatePolicy
import com.nova.downloader.data.MediaFormatOption
import com.nova.downloader.data.DownloadSnapshot
import com.nova.downloader.data.DownloadState
import com.nova.downloader.data.LinkResolver
import com.nova.downloader.data.ResolvedDownload
import com.nova.downloader.data.RecoveryPolicy
import com.nova.downloader.data.ResolutionTaskStore
import com.nova.downloader.data.ResolvedDownloadCodec
import com.nova.downloader.data.StorageHelper
import com.nova.downloader.service.BackgroundResolutionService
import com.nova.downloader.distribution.PetIntegration
import java.text.DateFormat
import java.util.Calendar

class MainActivity : LocalizedActivity() {
    private lateinit var repository: DownloadRepository
    private lateinit var appSettings: AppSettings
    private lateinit var urlInput: EditText
    private lateinit var adapter: DownloadAdapter
    private lateinit var emptyView: TextView
    private lateinit var pasteButton: Button
    private lateinit var downloadButton: Button
    private lateinit var resolutionTasks: ResolutionTaskStore
    private lateinit var completionEvents: CompletionEventStore
    private var isResolving = false
    private var activeResolutionId: Long? = null
    private var completionDialogShowing = false
    private var receiverRegistered = false

    private val refreshHandler = Handler(Looper.getMainLooper())
    private var pendingUrlAfterPermission: String? = null
    private var pendingResolvedDownload: ResolvedDownload? = null
    private var pendingFileName: String? = null
    private var pendingDestinationTreeUri: String? = null

    private val backgroundEventsReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                ResolutionTaskStore.ACTION_CHANGED -> processResolutionResults(
                    intent.getLongExtra(ResolutionTaskStore.EXTRA_TASK_ID, -1L).takeIf { it > 0L }
                )
                CompletionEventStore.ACTION_CHANGED -> showNextCompletionDialog()
            }
        }
    }

    private val refreshRunnable = object : Runnable {
        override fun run() {
            refreshHistory()
            refreshHandler.postDelayed(this, REFRESH_INTERVAL_MS)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        appSettings = AppSettings(this)
        if (!appSettings.onboardingComplete) {
            startActivity(Intent(this, SetupActivity::class.java))
            finish()
            return
        }
        repository = DownloadRepository(this)
        resolutionTasks = ResolutionTaskStore(this)
        completionEvents = CompletionEventStore(this)
        repository.markInterruptedAsPaused()
        adapter = DownloadAdapter(this)
        setContentView(buildContentView())
        handleIncomingIntent(intent)
        handleBrowserDownloadIntent(intent)
        handleOpenDownloadIntent(intent)
        handleResolutionIntent(intent)
        maybeRequestNotificationPermission()
        resumeEligibleInterruptedDownloads()
        PetIntegration.refreshMaybe(this)
    }


    private fun resumeEligibleInterruptedDownloads() {
        val policy = appSettings.recoveryPolicy
        if (policy == RecoveryPolicy.MANUAL) return
        if (appSettings.recoveryChargingOnly) {
            val battery = getSystemService(BatteryManager::class.java)
            if (!battery.isCharging) return
        }
        if (policy == RecoveryPolicy.WIFI) {
            val connectivity = getSystemService(ConnectivityManager::class.java)
            if (connectivity.activeNetwork == null || connectivity.isActiveNetworkMetered) return
        }
        repository.snapshots()
            .map { it.stored }
            .filter { it.status == DownloadState.PAUSED && it.hasPartialData }
            .forEach { repository.resume(it.downloadId) }
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (intent != null) {
            setIntent(intent)
            handleIncomingIntent(intent)
            handleBrowserDownloadIntent(intent)
            handleOpenDownloadIntent(intent)
            handleResolutionIntent(intent)
        }
    }

    override fun onStart() {
        super.onStart()
        if (!receiverRegistered) {
            ContextCompat.registerReceiver(
                this,
                backgroundEventsReceiver,
                IntentFilter().apply {
                    addAction(ResolutionTaskStore.ACTION_CHANGED)
                    addAction(CompletionEventStore.ACTION_CHANGED)
                },
                ContextCompat.RECEIVER_NOT_EXPORTED
            )
            receiverRegistered = true
        }
    }

    override fun onStop() {
        if (receiverRegistered) {
            runCatching { unregisterReceiver(backgroundEventsReceiver) }
            receiverRegistered = false
        }
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        if (!::repository.isInitialized) return
        repository.synchronizeCompletedOutputMetadata()
        refreshHandler.removeCallbacks(refreshRunnable)
        refreshHandler.post(refreshRunnable)
        PetIntegration.refreshMaybe(this)
        processResolutionResults(activeResolutionId)
        showNextCompletionDialog()
    }

    override fun onPause() {
        refreshHandler.removeCallbacks(refreshRunnable)
        super.onPause()
    }

    private fun buildContentView(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(12))
            setBackgroundColor(UiPalette.screenBackground(this@MainActivity))
        }

        root.addView(buildHeader())
        root.addView(buildNavigationRow())
        root.addView(buildDownloadCard())
        root.addView(buildHistoryHeader())

        val historyFrame = FrameLayout(this)
        val listView = ListView(this).apply {
            adapter = this@MainActivity.adapter
            dividerHeight = dp(1)
            setPadding(0, dp(4), 0, 0)
            clipToPadding = false
            setOnItemClickListener { _, _, position, _ ->
                val item = this@MainActivity.adapter.getItem(position)
                if (item.status == DownloadState.SUCCESSFUL && !item.stored.outputUri.isNullOrBlank()) {
                    startActivity(PlayerActivity.intent(this@MainActivity, item.stored))
                } else {
                    showDownloadActions(item)
                }
            }
            setOnItemLongClickListener { _, _, position, _ ->
                showDownloadActions(this@MainActivity.adapter.getItem(position))
                true
            }
        }

        emptyView = TextView(this).apply {
            text = getString(R.string.empty_downloads)
            textSize = 15f
            gravity = Gravity.CENTER
            alpha = 0.72f
            setPadding(dp(28), dp(36), dp(28), dp(36))
        }
        listView.emptyView = emptyView

        historyFrame.addView(
            listView,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        )
        historyFrame.addView(
            emptyView,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        )

        root.addView(
            historyFrame,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                0,
                1f
            )
        )

        return root
    }

    private fun buildHeader(): View {
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(13), dp(10), dp(10), dp(10))
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(17, 145, 255), Color.rgb(0, 70, 220))
            ).apply { cornerRadius = dp(24).toFloat() }
        }

        header.addView(ImageView(this).apply {
            setImageResource(R.mipmap.ic_launcher)
            scaleType = ImageView.ScaleType.FIT_CENTER
            contentDescription = getString(R.string.logo_description)
        }, LinearLayout.LayoutParams(dp(70), dp(70)))

        val titleBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), 0, 0, 0)
        }
        titleBox.addView(TextView(this).apply {
            text = getString(R.string.app_name_header)
            textSize = 22f
            setTextColor(Color.WHITE)
            setTypeface(typeface, Typeface.BOLD)
        })
        titleBox.addView(TextView(this).apply {
            text = getString(R.string.app_tagline)
            textSize = 12f
            setTextColor(Color.argb(225, 255, 255, 255))
            setPadding(0, dp(4), 0, 0)
        })
        titleBox.addView(TextView(this).apply {
            text = getString(
                R.string.main_full_version,
                BuildConfig.VERSION_NAME,
                BuildConfig.VERSION_CODE,
                BuildConfig.NOVA_CHECKPOINT,
                BuildConfig.FLAVOR,
                BuildConfig.BUILD_TYPE
            )
            textSize = 10.5f
            setTextColor(Color.WHITE)
            setTypeface(Typeface.MONOSPACE, Typeface.BOLD)
            setPadding(0, dp(5), 0, 0)
        })
        header.addView(titleBox, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(Button(this).apply {
            text = "⚙"
            textSize = 22f
            isAllCaps = false
            contentDescription = getString(R.string.settings)
            setOnClickListener { startActivity(Intent(this@MainActivity, SettingsActivity::class.java)) }
        }, LinearLayout.LayoutParams(dp(58), dp(52)))
        return header
    }

    private fun buildNavigationRow(): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER
        setPadding(0, dp(8), 0, 0)

        addView(LinearLayout(this@MainActivity).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            addView(Button(this@MainActivity).apply {
                text = getString(R.string.gallery_title); isAllCaps = false
                setOnClickListener { startActivity(Intent(this@MainActivity, GalleryActivity::class.java)) }
            }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(Button(this@MainActivity).apply {
                text = getString(R.string.queue_title); isAllCaps = false
                setOnClickListener { startActivity(Intent(this@MainActivity, QueueActivity::class.java)) }
            }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(6) })
            addView(Button(this@MainActivity).apply {
                text = getString(R.string.accounts); isAllCaps = false
                setOnClickListener { startActivity(Intent(this@MainActivity, AccountManagerActivity::class.java)) }
            }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(6) })
        }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))

        if (BuildConfig.HAS_APK_TOOLS) {
            addView(Button(this@MainActivity).apply {
                text = getString(R.string.apk_downloader_tab)
                isAllCaps = false
                setOnClickListener {
                    startActivity(Intent().setClassName(this@MainActivity, "com.nova.downloader.ui.ApkDownloaderActivity"))
                }
            }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                topMargin = dp(6)
            })
        }

    }

    private fun buildDownloadCard(): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(15), dp(16), dp(14))
            background = GradientDrawable().apply {
                setColor(UiPalette.surface(this@MainActivity))
                cornerRadius = dp(20).toFloat()
                setStroke(dp(1), UiPalette.border(this@MainActivity))
            }
        }
        val cardParams = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(12) }

        card.addView(TextView(this).apply {
            text = getString(R.string.secure_https_link)
            textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
        })

        urlInput = EditText(this).apply {
            hint = getString(R.string.url_hint)
            textSize = 15f
            isSingleLine = false
            minLines = 2
            maxLines = 4
            setPadding(dp(12), dp(10), dp(12), dp(10))
            inputType = android.text.InputType.TYPE_CLASS_TEXT or
                android.text.InputType.TYPE_TEXT_VARIATION_URI or
                android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        }
        card.addView(urlInput, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(8) })

        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END
        }
        pasteButton = Button(this).apply {
            text = getString(R.string.paste)
            isAllCaps = false
            setOnClickListener { pasteFromClipboard() }
        }
        buttons.addView(pasteButton, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        downloadButton = Button(this).apply {
            text = getString(R.string.download)
            isAllCaps = false
            setTypeface(typeface, Typeface.BOLD)
            setOnClickListener { requestDownload(urlInput.text?.toString().orEmpty()) }
        }
        buttons.addView(downloadButton, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
            marginStart = dp(8)
        })
        card.addView(buttons)
        card.addView(Button(this).apply {
            text = getString(R.string.browser_auto_button)
            isAllCaps = false
            setOnClickListener {
                val typed = UrlPolicy.extractFirstHttpsUrl(urlInput.text?.toString().orEmpty()).orEmpty()
                startActivity(Intent(this@MainActivity, BrowserActivity::class.java).apply {
                    if (typed.isNotBlank()) putExtra(BrowserActivity.EXTRA_START_URL, typed)
                })
            }
        }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(6)
        })

        card.addView(TextView(this).apply {
            text = getString(R.string.download_card_info)
            textSize = 11.5f
            alpha = 0.72f
            setPadding(0, dp(5), 0, 0)
        })
        return FrameLayout(this).apply { addView(card, cardParams) }
    }

    private fun buildHistoryHeader(): View = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(4), dp(14), dp(2), dp(4))
        addView(TextView(this@MainActivity).apply {
            text = getString(R.string.downloads)
            textSize = 18f
            setTypeface(typeface, Typeface.BOLD)
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        addView(Button(this@MainActivity).apply {
            text = getString(R.string.bulk_actions)
            textSize = 12f
            isAllCaps = false
            setOnClickListener { showBulkActions() }
        })
    }

    private fun requestDownload(rawUrl: String) {
        if (isResolving) return
        val validation = UrlPolicy.validate(rawUrl)
        if (validation is UrlPolicy.Result.Invalid) {
            toast(validation.message)
            return
        }
        val normalized = (validation as UrlPolicy.Result.Valid).normalizedUrl

        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P &&
            checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        ) {
            pendingUrlAfterPermission = normalized
            requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), REQUEST_STORAGE_PERMISSION)
            return
        }
        resolveAndPrepare(normalized)
    }

    private fun resolveAndPrepare(url: String) {
        setResolving(true)
        if (appSettings.backgroundResolutionEnabled) {
            activeResolutionId = BackgroundResolutionService.start(this, url)
            toast(getString(R.string.background_resolution_started))
            PetIntegration.refreshMaybe(this)
            return
        }
        Thread {
            val resolved = repository.resolve(url)
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                setResolving(false)
                when (resolved) {
                    is LinkResolver.Result.Ready -> prepareDownload(resolved.download)
                    is LinkResolver.Result.Unsupported -> showUnsupportedLink(resolved.message)
                    is LinkResolver.Result.Error -> toast(resolved.message)
                }
            }
        }.start()
    }

    private fun prepareDownload(download: ResolvedDownload) {
        if (!appSettings.confirmEachDownload) {
            val selected = applyDefaultMediaSelection(download)
            val cleanDefaultName = FileNameResolver.cleanResolvedDefaultName(selected.title)
            enqueue(selected, cleanDefaultName, appSettings.defaultTreeUri)
            return
        }
        pendingResolvedDownload = applyDefaultMediaSelection(download)
        // Checkpoint 046: clean only the proposed file name. Keep the resolved
        // download object untouched so extractor/fallback/format logic is unchanged.
        pendingFileName = pendingResolvedDownload?.title?.let(FileNameResolver::cleanResolvedDefaultName)
        pendingDestinationTreeUri = appSettings.defaultTreeUri
        showDownloadOptions()
    }

    private fun showDownloadOptions() {
        val download = pendingResolvedDownload ?: return
        var scheduledAt: Long? = null
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(4), dp(18), 0)
        }
        content.addView(optionLabel(getString(R.string.file_name)))
        val nameInput = EditText(this).apply {
            setText(pendingFileName ?: download.title); setSelection(text.length); isSingleLine = true
        }
        content.addView(nameInput)

        var modeGroup: RadioGroup? = null
        var audioRadioId = -1
        var formatSpinner: Spinner? = null
        var formatLabel: TextView? = null
        var audioFormatSpinner: Spinner? = null
        var audioFormatLabel: TextView? = null
        var containerSpinner: Spinner? = null
        var containerLabel: TextView? = null
        var languageSpinner: Spinner? = null
        var languageLabel: TextView? = null
        var playlistCheck: CheckBox? = null
        var liveCheck: CheckBox? = null
        var subtitleCheck: CheckBox? = null
        var autoSubtitleCheck: CheckBox? = null
        var thumbnailCheck: CheckBox? = null
        var descriptionCheck: CheckBox? = null
        var metadataCheck: CheckBox? = null
        var chaptersCheck: CheckBox? = null

        val actualFormats = download.formats.filter { it.hasVideo }
        val selectableFormats: List<MediaFormatOption> = if (actualFormats.isNotEmpty()) actualFormats else
            YtDlpOptionBuilder.qualityPresets.map { preset ->
                MediaFormatOption(
                    preset.id,
                    YtDlpOptionBuilder.videoFormatSelector(preset.id, download.videoContainer),
                    getString(preset.labelRes),
                    download.videoContainer,
                    download.mimeType,
                    null, null, null, null, null, null, null, null, null, true, true
                )
            }

        if (download.engine == DownloadEngine.YT_DLP) {
            content.addView(optionLabel(getString(R.string.output_type)))
            val videoRadio = RadioButton(this).apply { id = View.generateViewId(); text = getString(R.string.video) }
            val audioRadio = RadioButton(this).apply { id = View.generateViewId(); text = getString(R.string.audio_only) }
            audioRadioId = audioRadio.id
            modeGroup = RadioGroup(this).apply {
                orientation = RadioGroup.HORIZONTAL
                addView(videoRadio, RadioGroup.LayoutParams(0, RadioGroup.LayoutParams.WRAP_CONTENT, 1f))
                addView(audioRadio, RadioGroup.LayoutParams(0, RadioGroup.LayoutParams.WRAP_CONTENT, 1f))
                check(if (download.outputMode == YtDlpOptionBuilder.MODE_AUDIO) audioRadio.id else videoRadio.id)
            }
            content.addView(modeGroup)

            formatLabel = optionLabel(if (actualFormats.isNotEmpty()) getString(R.string.source_format_quality) else getString(R.string.video_quality))
            content.addView(formatLabel)
            formatSpinner = Spinner(this).apply {
                adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, selectableFormats.map { it.label })
                setSelection(selectableFormats.indexOfFirst { it.formatId == download.qualityId || it.selector == download.formatSelector }.coerceAtLeast(0))
            }
            content.addView(formatSpinner)

            containerLabel = optionLabel(getString(R.string.output_container))
            content.addView(containerLabel)
            val containers = listOf("MP4", "MKV", "WebM")
            containerSpinner = Spinner(this).apply {
                adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, containers)
                setSelection(when (download.videoContainer?.lowercase()) { "mkv" -> 1; "webm" -> 2; else -> 0 })
            }
            content.addView(containerSpinner)

            audioFormatLabel = optionLabel(getString(R.string.audio_format))
            content.addView(audioFormatLabel)
            audioFormatSpinner = Spinner(this).apply {
                adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, YtDlpOptionBuilder.audioPresets.map { getString(it.labelRes) })
                setSelection(YtDlpOptionBuilder.audioPresets.indexOfFirst { it.id == download.audioFormat }.coerceAtLeast(0))
            }
            content.addView(audioFormatSpinner)

            val cleanAudioLanguages = download.metadata.audioLanguages
                .map { it.trim() }
                .filter { it.isNotEmpty() && !it.equals("null", ignoreCase = true) }
                .distinct()
            val languages = listOf(getString(R.string.auto_language)) + cleanAudioLanguages
            val selectedAudioLanguage = download.selectedAudioLanguage
                ?.trim()
                ?.takeIf { it.isNotEmpty() && !it.equals("null", ignoreCase = true) }
            languageLabel = optionLabel(getString(R.string.audio_language))
            content.addView(languageLabel)
            languageSpinner = Spinner(this).apply {
                adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, languages)
                val selectedIndex = selectedAudioLanguage?.let(languages::indexOf)?.takeIf { it >= 0 } ?: 0
                setSelection(selectedIndex)
            }
            content.addView(languageSpinner)

            if (download.metadata.isPlaylist) {
                playlistCheck = CheckBox(this).apply {
                    text = getString(R.string.playlist_download_all, download.metadata.playlistCount.takeIf { it > 0 }?.toString() ?: getString(R.string.item_count_unknown))
                    isChecked = download.playlistMode == "all" || appSettings.playlistDefaultAll
                }
                content.addView(playlistCheck)
            }
            if (download.metadata.isLive) {
                liveCheck = CheckBox(this).apply { text = getString(R.string.live_from_start); isChecked = download.liveFromStart }
                content.addView(liveCheck)
            }
            if (download.metadata.subtitleLanguages.isNotEmpty()) {
                subtitleCheck = CheckBox(this).apply {
                    text = getString(R.string.download_subtitles, download.metadata.subtitleLanguages.take(6).joinToString()); isChecked = download.writeSubtitles
                }
                content.addView(subtitleCheck)
            }
            if (download.metadata.automaticSubtitleLanguages.isNotEmpty()) {
                autoSubtitleCheck = CheckBox(this).apply { text = getString(R.string.download_auto_subtitles); isChecked = download.writeAutoSubtitles }
                content.addView(autoSubtitleCheck)
            }
            thumbnailCheck = CheckBox(this).apply { text = getString(R.string.download_thumbnail); isChecked = download.writeThumbnail }
            descriptionCheck = CheckBox(this).apply { text = getString(R.string.save_description); isChecked = download.writeDescription }
            metadataCheck = CheckBox(this).apply { text = getString(R.string.embed_metadata); isChecked = download.embedMetadata }
            chaptersCheck = CheckBox(this).apply { text = getString(R.string.embed_chapters); isChecked = download.embedChapters && download.metadata.chapterCount > 0; isEnabled = download.metadata.chapterCount > 0 }
            content.addView(thumbnailCheck); content.addView(descriptionCheck); content.addView(metadataCheck); content.addView(chaptersCheck)

            fun refreshMode() {
                val audioMode = modeGroup?.checkedRadioButtonId == audioRadio.id
                formatLabel?.visibility = if (audioMode) View.GONE else View.VISIBLE
                formatSpinner?.visibility = if (audioMode) View.GONE else View.VISIBLE
                containerLabel?.visibility = if (audioMode) View.GONE else View.VISIBLE
                containerSpinner?.visibility = if (audioMode) View.GONE else View.VISIBLE
                audioFormatLabel?.visibility = if (audioMode) View.VISIBLE else View.GONE
                audioFormatSpinner?.visibility = if (audioMode) View.VISIBLE else View.GONE
            }
            modeGroup.setOnCheckedChangeListener { _, _ -> refreshMode() }; refreshMode()
        }

        content.addView(optionLabel(getString(R.string.same_name_file)))
        val duplicateLabels = listOf(getString(R.string.duplicate_rename), getString(R.string.duplicate_replace), getString(R.string.duplicate_skip))
        val duplicateValues = listOf(DuplicatePolicy.RENAME, DuplicatePolicy.REPLACE, DuplicatePolicy.SKIP)
        val duplicateSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, duplicateLabels)
            setSelection(duplicateValues.indexOf(download.duplicatePolicy).coerceAtLeast(0))
        }
        content.addView(duplicateSpinner)

        val destinationLabel = TextView(this).apply {
            text = getString(R.string.location_label, StorageHelper.destinationLabel(this@MainActivity, pendingDestinationTreeUri))
            textSize = 13f
            setPadding(0, dp(12), 0, dp(6))
        }
        content.addView(destinationLabel)

        val locationButtons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        content.addView(locationButtons)
        content.addView(TextView(this).apply {
            text = download.contentLength.takeIf { it > 0 }?.let { getString(R.string.estimated_max_size, formatBytes(it)) }
                ?: getString(R.string.unknown_size_info)
            textSize = 12f
            alpha = 0.68f
            setPadding(0, dp(8), 0, dp(8))
        })

        // Checkpoint 045: options scroll independently; primary download actions remain fixed and visible.
        val scrollContent = ScrollView(this).apply {
            isFillViewport = true
            addView(content)
        }
        val actionFooter = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(6), dp(18), dp(10))
        }
        val scheduleLabel = TextView(this).apply {
            text = getString(R.string.schedule_now)
            textSize = 13f
            setPadding(0, 0, 0, dp(4))
        }
        actionFooter.addView(scheduleLabel)

        val startNowButton = Button(this).apply {
            text = getString(R.string.download)
            isAllCaps = false
            minHeight = dp(52)
            setTypeface(typeface, Typeface.BOLD)
        }
        actionFooter.addView(
            startNowButton,
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        )

        val secondaryActions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(4), 0, 0)
        }
        val scheduleButton = Button(this).apply {
            text = getString(R.string.schedule_download)
            isAllCaps = false
        }
        val cancelButton = Button(this).apply {
            text = getString(R.string.cancel)
            isAllCaps = false
        }
        secondaryActions.addView(
            scheduleButton,
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        )
        secondaryActions.addView(
            cancelButton,
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(8) }
        )
        actionFooter.addView(secondaryActions)

        val dialogRoot = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(
                scrollContent,
                LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
            )
            addView(
                actionFooter,
                LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            )
        }
        val dialog = AlertDialog.Builder(this)
            .setTitle(getString(R.string.download_details))
            .setView(dialogRoot)
            .create()
        var submissionInProgress = false

        fun enqueueFromDialog(startAt: Long?): Boolean {
            if (submissionInProgress) return false
            var selected = download.copy(duplicatePolicy = duplicateValues[duplicateSpinner.selectedItemPosition])
            if (download.engine == DownloadEngine.YT_DLP) {
                val language = languageSpinner?.selectedItem?.toString()
                    ?.trim()
                    ?.takeIf {
                        it.isNotEmpty() &&
                            it != getString(R.string.auto_language) &&
                            !it.equals("null", ignoreCase = true)
                    }
                val audioMode = modeGroup?.checkedRadioButtonId == audioRadioId
                selected = if (audioMode) {
                    val audio = YtDlpOptionBuilder.audioPresets[audioFormatSpinner?.selectedItemPosition ?: 0]
                    val selector = language?.let { "bestaudio[language=$it]/bestaudio/best" } ?: "bestaudio/best"
                    selected.copy(
                        outputMode = YtDlpOptionBuilder.MODE_AUDIO, formatSelector = selector,
                        mimeType = audio.mimeType, audioFormat = audio.id, videoContainer = null,
                        selectedAudioLanguage = language, title = replaceKnownMediaExtension(download.title, audio.extension)
                    )
                } else {
                    val format = selectableFormats[formatSpinner?.selectedItemPosition ?: 0]
                    val container = when (containerSpinner?.selectedItemPosition ?: 0) { 1 -> "mkv"; 2 -> "webm"; else -> "mp4" }
                    selected.copy(
                        outputMode = YtDlpOptionBuilder.MODE_VIDEO, formatSelector = format.selector,
                        mimeType = YtDlpOptionBuilder.mimeForVideoContainer(container), audioFormat = null,
                        videoContainer = container, qualityId = format.formatId, selectedAudioLanguage = language,
                        title = replaceKnownMediaExtension(download.title, container)
                    )
                }
                selected = selected.copy(
                    playlistMode = if (playlistCheck?.isChecked == true) "all" else "single",
                    liveFromStart = liveCheck?.isChecked == true,
                    writeSubtitles = subtitleCheck?.isChecked == true,
                    writeAutoSubtitles = autoSubtitleCheck?.isChecked == true,
                    subtitleLanguages = (download.metadata.subtitleLanguages + download.metadata.automaticSubtitleLanguages).distinct(),
                    writeThumbnail = thumbnailCheck?.isChecked == true,
                    writeDescription = descriptionCheck?.isChecked == true,
                    embedMetadata = metadataCheck?.isChecked != false,
                    embedChapters = chaptersCheck?.isChecked == true
                )
            }
            val requested = if (selected.engine == DownloadEngine.YT_DLP) {
                replaceKnownMediaExtension(nameInput.text?.toString().orEmpty(), extensionForSelection(selected))
            } else {
                nameInput.text?.toString().orEmpty()
            }
            val finalName = normalizeFileName(requested, selected)
            if (finalName.isBlank()) {
                nameInput.error = getString(R.string.file_name_required)
                return false
            }

            submissionInProgress = true
            startNowButton.isEnabled = false
            scheduleButton.isEnabled = false
            val tree = pendingDestinationTreeUri
            val accepted = enqueue(selected, finalName, tree, startAt)
            if (accepted) {
                pendingResolvedDownload = null
                pendingFileName = null
                pendingDestinationTreeUri = null
                dialog.dismiss()
            } else {
                submissionInProgress = false
                startNowButton.isEnabled = true
                scheduleButton.isEnabled = true
            }
            return accepted
        }

        locationButtons.addView(Button(this).apply {
            text = getString(R.string.choose_another_location)
            isAllCaps = false
            setOnClickListener {
                pendingFileName = nameInput.text?.toString().orEmpty()
                dialog.dismiss()
                openDownloadTreePicker()
            }
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        locationButtons.addView(Button(this).apply {
            text = getString(R.string.use_default)
            isAllCaps = false
            setOnClickListener {
                pendingDestinationTreeUri = appSettings.defaultTreeUri
                destinationLabel.text = getString(
                    R.string.location_label,
                    StorageHelper.destinationLabel(this@MainActivity, pendingDestinationTreeUri)
                )
            }
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(8) })

        startNowButton.setOnClickListener {
            scheduledAt = null
            scheduleLabel.text = getString(R.string.schedule_now)
            enqueueFromDialog(null)
        }
        scheduleButton.setOnClickListener {
            val cal = Calendar.getInstance().apply { add(Calendar.HOUR_OF_DAY, 1) }
            DatePickerDialog(this@MainActivity, { _, y, m, d ->
                TimePickerDialog(this@MainActivity, { _, h, minute ->
                    cal.set(y, m, d, h, minute, 0)
                    scheduledAt = cal.timeInMillis
                    scheduleLabel.text = getString(
                        R.string.scheduled_for,
                        DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(cal.time)
                    )
                    enqueueFromDialog(scheduledAt)
                }, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), true).show()
            }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
        }
        cancelButton.setOnClickListener { dialog.dismiss() }

        dialog.setOnShowListener {
            // Constrain the custom body to the visible screen. The footer stays outside the ScrollView.
            val bodyHeight = (resources.displayMetrics.heightPixels * 0.78f).toInt()
            dialogRoot.layoutParams = dialogRoot.layoutParams.apply { height = bodyHeight }
            scrollContent.post { scrollContent.scrollTo(0, 0) }
        }
        dialog.show()
    }

    private fun applyDefaultMediaSelection(download: ResolvedDownload): ResolvedDownload =
        DefaultMediaSelectionPolicy.apply(download, appSettings)

    private fun optionLabel(textValue: String): TextView = TextView(this).apply {
        text = textValue
        textSize = 13f
        setTypeface(typeface, Typeface.BOLD)
        setPadding(0, dp(9), 0, dp(2))
    }

    private fun extensionForSelection(download: ResolvedDownload): String =
        if (download.outputMode == YtDlpOptionBuilder.MODE_AUDIO) {
            YtDlpOptionBuilder.audioPreset(download.audioFormat).extension
        } else {
            YtDlpOptionBuilder.suggestedVideoExtension(download.videoContainer)
        }

    private fun replaceKnownMediaExtension(name: String, extension: String): String {
        val trimmed = name.trim()
        if (trimmed.isBlank()) return trimmed
        val known = Regex("\\.(mp4|mkv|webm|m4v|mov|avi|3gp|mp3|m4a|aac|ogg|oga|opus|flac|wav|bin|download)$", RegexOption.IGNORE_CASE)
        val stem = trimmed.replace(known, "")
        return "$stem.$extension"
    }

    private fun openDownloadTreePicker() {
        startActivityForResult(
            Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
                addFlags(
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or
                        Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                        Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
                )
            },
            REQUEST_DOWNLOAD_TREE
        )
    }

    private fun enqueue(download: ResolvedDownload, fileName: String, destinationTreeUri: String?, scheduledAt: Long? = null): Boolean =
        when (val result = repository.enqueue(download, fileName, destinationTreeUri, scheduledAt)) {
            is DownloadRepository.EnqueueResult.Success -> {
                urlInput.text?.clear()
                val size = download.contentLength.takeIf { it > 0L }?.let(::formatBytes)
                toast(if (scheduledAt != null) getString(R.string.download_scheduled_message, result.item.title)
                    else if (size == null) getString(R.string.download_started, result.item.title)
                    else getString(R.string.download_started_with_size, result.item.title, size))
                refreshHistory()
                PetIntegration.refreshMaybe(this)
                true
            }
            is DownloadRepository.EnqueueResult.Error -> {
                toast(result.message)
                false
            }
        }

    private fun normalizeFileName(requested: String, download: ResolvedDownload): String =
        FileNameResolver.ensureMediaExtension(
            requestedName = requested,
            mimeType = download.mimeType,
            finalUrl = download.downloadUrl
        )

    private fun handleResolutionIntent(intent: Intent) {
        intent.getLongExtra(EXTRA_RESOLUTION_ID, -1L)
            .takeIf { it > 0L }
            ?.let { activeResolutionId = it }
    }

    private fun processResolutionResults(preferredId: Long? = null) {
        if (!::resolutionTasks.isInitialized || isFinishing || isDestroyed) return
        val tasks = resolutionTasks.list()
        val active = tasks.lastOrNull {
            it.state == ResolutionTaskStore.STATE_PENDING || it.state == ResolutionTaskStore.STATE_RUNNING
        }
        activeResolutionId = active?.id ?: activeResolutionId
        setResolving(active != null)
        val candidate = preferredId?.let(resolutionTasks::get)
            ?: tasks.firstOrNull { it.state !in setOf(ResolutionTaskStore.STATE_PENDING, ResolutionTaskStore.STATE_RUNNING) }
            ?: return
        if (candidate.state !in setOf(ResolutionTaskStore.STATE_PENDING, ResolutionTaskStore.STATE_RUNNING)) {
            BackgroundResolutionService.clearResultNotification(this, candidate.id)
        }
        when (candidate.state) {
            ResolutionTaskStore.STATE_READY -> {
                val payload = candidate.resultPayload
                resolutionTasks.remove(candidate.id)
                activeResolutionId = null
                setResolving(false)
                val download = runCatching { ResolvedDownloadCodec.decode(payload.orEmpty()) }.getOrElse {
                    toast(getString(R.string.media_resolver_decode_failed)); return
                }
                prepareDownload(download)
            }
            ResolutionTaskStore.STATE_AUTO_ENQUEUED -> {
                resolutionTasks.remove(candidate.id)
                activeResolutionId = null
                setResolving(false)
                refreshHistory()
                toast(getString(R.string.background_download_started_message, candidate.message.orEmpty()))
            }
            ResolutionTaskStore.STATE_UNSUPPORTED -> {
                resolutionTasks.remove(candidate.id)
                activeResolutionId = null
                setResolving(false)
                showUnsupportedLink(candidate.message ?: getString(R.string.page_media_unresolved))
            }
            ResolutionTaskStore.STATE_ERROR -> {
                resolutionTasks.remove(candidate.id)
                activeResolutionId = null
                setResolving(false)
                toast(candidate.message ?: getString(R.string.media_resolver_start_failed))
            }
            ResolutionTaskStore.STATE_CANCELLED -> {
                resolutionTasks.remove(candidate.id)
                activeResolutionId = null
                setResolving(false)
                toast(getString(R.string.resolution_cancelled))
            }
        }
    }

    private fun showNextCompletionDialog() {
        if (!::completionEvents.isInitialized || completionDialogShowing || !appSettings.inAppCompletionDialog) return
        val event = completionEvents.pending().firstOrNull() ?: return
        refreshHistory()
        val item = repository.snapshots().firstOrNull { it.stored.downloadId == event.downloadId }?.stored
        completionEvents.remove(event.downloadId)
        if (item == null || item.status != DownloadState.SUCCESSFUL || item.outputUri.isNullOrBlank()) {
            showNextCompletionDialog()
            return
        }

        completionDialogShowing = true
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(8), dp(22), dp(18))
        }
        content.addView(TextView(this).apply {
            text = getString(R.string.in_app_completion_message, item.title)
            textSize = 18f
            setTextColor(Color.rgb(28, 28, 28))
            setPadding(0, 0, 0, dp(8))
        })
        content.addView(TextView(this).apply {
            val size = item.totalBytes.coerceAtLeast(item.bytesDownloaded)
            text = getString(R.string.status_completed, formatBytes(size))
            textSize = 14f
            alpha = 0.72f
            setPadding(0, 0, 0, dp(14))
        })

        val playButton = Button(this).apply {
            text = getString(R.string.play_in_nova)
            isAllCaps = false
        }
        val locationButton = Button(this).apply {
            text = getString(R.string.open_file_location)
            isAllCaps = false
        }
        val closeButton = Button(this).apply {
            text = getString(R.string.close)
            isAllCaps = false
        }
        content.addView(playButton, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ))
        content.addView(locationButton, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(8) })
        content.addView(closeButton, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(8) })

        val dialog = AlertDialog.Builder(this)
            .setTitle(R.string.notification_download_complete)
            .setView(content)
            .create()

        playButton.setOnClickListener {
            dialog.dismiss()
            startActivity(PlayerActivity.intent(this, item))
        }
        locationButton.setOnClickListener {
            dialog.dismiss()
            StorageHelper.openLocation(this, item)
        }
        closeButton.setOnClickListener { dialog.dismiss() }
        dialog.setOnDismissListener {
            completionDialogShowing = false
            showNextCompletionDialog()
        }
        dialog.show()
    }

    private fun setResolving(resolving: Boolean) {
        isResolving = resolving
        urlInput.isEnabled = !resolving
        pasteButton.isEnabled = !resolving
        downloadButton.isEnabled = !resolving
        downloadButton.text = if (resolving) getString(R.string.resolving_video) else getString(R.string.download)
    }

    private fun showUnsupportedLink(message: String) {
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.video_stream_unresolved))
            .setMessage(message)
            .setPositiveButton(getString(R.string.ok), null)
            .show()
    }

    private fun formatBytes(bytes: Long): String = when {
        bytes < 1024L -> getString(R.string.bytes_format, bytes)
        bytes < 1024L * 1024L -> getString(R.string.kilobytes_format, bytes / 1024.0)
        bytes < 1024L * 1024L * 1024L -> getString(R.string.megabytes_format, bytes / 1048576.0)
        bytes < 1024L * 1024L * 1024L * 1024L -> getString(R.string.gigabytes_format, bytes / 1073741824.0)
        else -> getString(R.string.terabytes_format, bytes / 1099511627776.0)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_STORAGE_PERMISSION) {
            val pending = pendingUrlAfterPermission
            pendingUrlAfterPermission = null
            if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED && pending != null) {
                resolveAndPrepare(pending)
            } else {
                AlertDialog.Builder(this)
                    .setTitle(getString(R.string.storage_permission_title))
                    .setMessage(getString(R.string.storage_permission_message))
                    .setPositiveButton(getString(R.string.settings)) { _, _ ->
                        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
                    }
                    .setNegativeButton(getString(R.string.close), null)
                    .show()
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_DOWNLOAD_TREE) {
            if (resultCode == RESULT_OK) {
                pendingDestinationTreeUri = StorageHelper.takeTreePermission(this, data)
            }
            if (pendingResolvedDownload != null) showDownloadOptions()
        } else if (requestCode == REQUEST_BULK_MOVE_TREE && resultCode == RESULT_OK) {
            val tree = StorageHelper.takeTreePermission(this, data) ?: return
            toast(getString(R.string.moving_completed))
            Thread {
                val result = repository.relocateCompleted(tree)
                runOnUiThread {
                    refreshHistory()
                    val detail = if (result.failed == 0) getString(R.string.move_result_success, result.moved)
                    else getString(R.string.move_result_partial, result.moved, result.failed, result.errors.joinToString("\n"))
                    AlertDialog.Builder(this).setTitle(getString(R.string.bulk_move_complete)).setMessage(detail).setPositiveButton(getString(R.string.ok), null).show()
                }
            }.start()
        }
    }

    private fun refreshHistory() {
        adapter.submitList(repository.snapshots())
    }

    private fun pasteFromClipboard() {
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val text = clipboard.primaryClip
            ?.takeIf { it.itemCount > 0 }
            ?.getItemAt(0)
            ?.coerceToText(this)
            ?.toString()
            .orEmpty()
        if (text.isBlank()) {
            toast(getString(R.string.clipboard_empty))
            return
        }
        urlInput.setText(UrlPolicy.extractFirstHttpsUrl(text) ?: text)
        urlInput.setSelection(urlInput.text.length)
    }

    private fun handleIncomingIntent(intent: Intent) {
        if (intent.action != Intent.ACTION_SEND || intent.type != "text/plain") return
        val shared = intent.getStringExtra(Intent.EXTRA_TEXT).orEmpty()
        if (shared.isBlank()) return
        urlInput.setText(UrlPolicy.extractFirstHttpsUrl(shared) ?: shared)
        urlInput.setSelection(urlInput.text.length)
    }

    private fun handleBrowserDownloadIntent(intent: Intent) {
        if (intent.action != BrowserTransfer.ACTION_DOWNLOAD) return
        val rawUrl = intent.getStringExtra(BrowserTransfer.EXTRA_URL).orEmpty()
        val pageUrl = intent.getStringExtra(BrowserTransfer.EXTRA_PAGE_URL).orEmpty()
        val title = intent.getStringExtra(BrowserTransfer.EXTRA_TITLE).orEmpty()
        val mimeType = intent.getStringExtra(BrowserTransfer.EXTRA_MIME_TYPE)
        val headers = BrowserTransfer.readHeaders(intent)
        val kind = runCatching {
            BrowserMediaDetector.Kind.valueOf(intent.getStringExtra(BrowserTransfer.EXTRA_KIND).orEmpty())
        }.getOrDefault(BrowserMediaDetector.Kind.PAGE)

        intent.action = null
        intent.removeExtra(BrowserTransfer.EXTRA_URL)
        intent.removeExtra(BrowserTransfer.EXTRA_PAGE_URL)
        intent.removeExtra(BrowserTransfer.EXTRA_TITLE)
        intent.removeExtra(BrowserTransfer.EXTRA_MIME_TYPE)
        intent.removeExtra(BrowserTransfer.EXTRA_KIND)
        intent.removeExtra(BrowserTransfer.EXTRA_HEADERS)

        val validation = UrlPolicy.validate(rawUrl)
        if (validation !is UrlPolicy.Result.Valid) {
            toast(getString(R.string.browser_invalid_media_url))
            return
        }
        val normalized = validation.normalizedUrl
        if (kind == BrowserMediaDetector.Kind.PAGE || kind == BrowserMediaDetector.Kind.HLS || kind == BrowserMediaDetector.Kind.DASH) {
            val pageValidation = UrlPolicy.validate(pageUrl)
            val extractorTarget = if (
                kind != BrowserMediaDetector.Kind.PAGE && pageValidation is UrlPolicy.Result.Valid
            ) pageValidation.normalizedUrl else normalized
            urlInput.setText(extractorTarget)
            urlInput.setSelection(urlInput.text.length)
            requestDownload(extractorTarget)
            return
        }

        val effectiveMime = mimeType ?: MediaTypePolicy.mimeTypeForExtension(MediaTypePolicy.extensionOf(normalized))
        val seedName = title.takeIf { it.isNotBlank() } ?: FileNameResolver.fromUrl(normalized)
        val finalName = FileNameResolver.ensureMediaExtension(
            requestedName = seedName,
            mimeType = effectiveMime,
            finalUrl = normalized
        )
        prepareDownload(
            ResolvedDownload(
                sourceUrl = pageUrl.takeIf { it.startsWith("https://", true) } ?: normalized,
                downloadUrl = normalized,
                title = finalName,
                mimeType = effectiveMime,
                contentLength = -1L,
                referer = pageUrl.takeIf { it.startsWith("https://", true) },
                headers = headers,
                engine = DownloadEngine.DIRECT
            )
        )
    }

    private fun handleOpenDownloadIntent(intent: Intent) {
        val id = intent.getLongExtra(EXTRA_OPEN_DOWNLOAD_ID, -1L)
        if (id <= 0L) return
        intent.removeExtra(EXTRA_OPEN_DOWNLOAD_ID)
        val item = repository.snapshots().firstOrNull { it.stored.downloadId == id } ?: return
        showDownloadActions(item)
    }

    private fun showDownloadActions(item: DownloadSnapshot) {
        val labels = mutableListOf<String>()
        val actions = mutableListOf<() -> Unit>()
        when (item.status) {
            DownloadState.SUCCESSFUL -> {
                labels += getString(R.string.play_in_nova)
                actions += { startActivity(PlayerActivity.intent(this, item.stored)) }
                labels += getString(R.string.open_external)
                actions += { openDownload(item) }
                labels += getString(R.string.open_file_location)
                actions += { StorageHelper.openLocation(this, item.stored) }
                labels += getString(R.string.rename_downloaded_file)
                actions += { showRenameDownloadedFileDialog(item.stored) }
                labels += getString(R.string.verify_file_integrity)
                actions += {
                    val ok = item.stored.outputUri?.let { uri -> StorageHelper.verifyReadableMedia(this, Uri.parse(uri), item.stored.checksumSha256) } == true
                    toast(if (ok) getString(R.string.integrity_ok) else getString(R.string.integrity_failed))
                }
            }
            DownloadState.PENDING,
            DownloadState.RUNNING -> {
                labels += getString(R.string.pause_download)
                actions += {
                    repository.pause(item.stored.downloadId)
                    toast(getString(R.string.paused_resume_later))
                    refreshHistory()
                }
                labels += getString(R.string.cancel_delete_partial)
                actions += {
                    repository.cancel(item.stored.downloadId)
                    toast(getString(R.string.cancelled_partial_deleted))
                    refreshHistory()
                }
            }
            DownloadState.PAUSED,
            DownloadState.FAILED,
            DownloadState.CANCELLED,
            DownloadState.INVALID_CONTENT -> {
                if (item.stored.hasPartialData) {
                    labels += getString(R.string.resume_download)
                    actions += { resumeDownload(item) }
                } else {
                    labels += getString(R.string.download_again)
                    actions += { requestDownload(item.stored.url) }
                }
                item.stored.errorMessage?.let { message ->
                    labels += getString(R.string.show_error_details)
                    actions += { AlertDialog.Builder(this).setTitle(getString(R.string.download_error_title)).setMessage(message).setPositiveButton(getString(R.string.ok), null).show() }
                }
            }
        }
        labels += getString(R.string.copy_link)
        actions += { copyToClipboard(item.stored.url) }
        labels += if (item.stored.hasPartialData) getString(R.string.delete_record_partial) else getString(R.string.delete_history_record)
        actions += {
            repository.discard(item.stored.downloadId)
            refreshHistory()
        }
        AlertDialog.Builder(this)
            .setTitle(item.stored.title)
            .setItems(labels.toTypedArray()) { _, which -> actions[which].invoke() }
            .setNegativeButton(getString(R.string.close), null)
            .show()
    }



    private fun showRenameDownloadedFileDialog(item: com.nova.downloader.data.StoredDownload) {
        val input = EditText(this).apply {
            setText(item.title)
            setSelection(text.length)
            isSingleLine = true
            hint = getString(R.string.new_file_name)
            imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_DONE
        }
        val cancelButton = Button(this).apply {
            text = getString(R.string.cancel)
            isAllCaps = false
        }
        val applyButton = Button(this).apply {
            text = getString(R.string.apply_changes)
            isAllCaps = false
        }
        val actionRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END
            setPadding(0, dp(14), 0, 0)
            addView(cancelButton, LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f
            ))
            addView(applyButton, LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f
            ).apply { marginStart = dp(10) })
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(8), dp(22), dp(16))
            addView(input)
            addView(TextView(this@MainActivity).apply {
                text = getString(R.string.rename_preserves_extension)
                textSize = 12f
                alpha = 0.7f
                setPadding(0, dp(8), 0, 0)
            })
            addView(actionRow)
        }
        val dialog = AlertDialog.Builder(this)
            .setTitle(getString(R.string.rename_downloaded_file))
            .setView(content)
            .create()

        fun applyRename() {
            val requested = input.text?.toString().orEmpty().trim()
            if (requested.isBlank()) {
                input.error = getString(R.string.file_name_required)
                return
            }
            when (val result = repository.renameCompleted(item.downloadId, requested)) {
                is DownloadRepository.RenameResult.Success -> {
                    toast(getString(R.string.file_renamed_message, result.item.title))
                    dialog.dismiss()
                    refreshHistory()
                }
                is DownloadRepository.RenameResult.Error -> input.error = result.message
            }
        }

        cancelButton.setOnClickListener { dialog.dismiss() }
        applyButton.setOnClickListener { applyRename() }
        input.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == android.view.inputmethod.EditorInfo.IME_ACTION_DONE) {
                applyRename()
                true
            } else {
                false
            }
        }

        dialog.setOnShowListener {
            dialog.window?.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
            input.requestFocus()
        }
        dialog.show()
    }

    private fun resumeDownload(item: DownloadSnapshot) {
        if (item.stored.engine == DownloadEngine.YT_DLP) {
            when (val result = repository.resume(item.stored.downloadId)) {
                is DownloadRepository.EnqueueResult.Success -> {
                    toast(getString(R.string.download_resuming))
                    refreshHistory()
                    PetIntegration.refreshMaybe(this)
                }
                is DownloadRepository.EnqueueResult.Error -> toast(result.message)
            }
            return
        }

        toast(getString(R.string.refreshing_video_url))
        Thread {
            val resolved = repository.resolve(item.stored.url)
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                val result = when (resolved) {
                    is LinkResolver.Result.Ready -> repository.resume(item.stored.downloadId, resolved.download)
                    else -> repository.resume(item.stored.downloadId)
                }
                when (result) {
                    is DownloadRepository.EnqueueResult.Success -> {
                        toast(getString(R.string.download_resuming))
                        refreshHistory()
                        PetIntegration.refreshMaybe(this)
                    }
                    is DownloadRepository.EnqueueResult.Error -> {
                        val message = when (resolved) {
                            is LinkResolver.Result.Unsupported -> resolved.message
                            is LinkResolver.Result.Error -> resolved.message
                            else -> result.message
                        }
                        toast(message)
                    }
                }
            }
        }.start()
    }

    private fun openDownload(item: DownloadSnapshot) {
        if (!StorageHelper.openFile(this, item.stored)) {
            toast(getString(R.string.no_file_handler))
        }
    }

    private fun copyToClipboard(text: String) {
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText(getString(R.string.clipboard_link_label), text))
        toast(getString(R.string.link_copied))
    }

    private fun showBulkActions() {
        if (adapter.count == 0) {
            toast(getString(R.string.download_history_empty))
            return
        }
        val options = arrayOf(
            getString(R.string.move_completed_files),
            getString(R.string.remove_completed_records),
            getString(R.string.clear_incomplete_records),
            getString(R.string.clear_all_history)
        )
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.bulk_actions))
            .setItems(options) { _, which ->
                when (which) {
                    0 -> startActivityForResult(
                        Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
                            addFlags(
                                Intent.FLAG_GRANT_READ_URI_PERMISSION or
                                    Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                                    Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
                            )
                        },
                        REQUEST_BULK_MOVE_TREE
                    )
                    1 -> {
                        val count = repository.clearCompletedRecords()
                        refreshHistory(); toast(getString(R.string.completed_records_removed, count))
                    }
                    2 -> {
                        val count = repository.clearIncompleteRecords()
                        refreshHistory(); toast(getString(R.string.incomplete_records_removed, count))
                    }
                    3 -> confirmClearHistory()
                }
            }
            .setNegativeButton(getString(R.string.close), null)
            .show()
    }

    private fun confirmClearHistory() {
        if (adapter.count == 0) {
            toast(getString(R.string.history_already_empty))
            return
        }
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.clear_history_title))
            .setMessage(getString(R.string.clear_history_message))
            .setPositiveButton(getString(R.string.clear)) { _, _ ->
                repository.clearHistory()
                refreshHistory()
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }

    private fun maybeRequestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQUEST_NOTIFICATION_PERMISSION)
        }
    }

    private fun isNightMode(): Boolean =
        resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK == Configuration.UI_MODE_NIGHT_YES

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()

    companion object {
        const val EXTRA_OPEN_DOWNLOAD_ID = "open_download_id"
        const val EXTRA_RESOLUTION_ID = "resolution_id"
        private const val REQUEST_STORAGE_PERMISSION = 41
        private const val REQUEST_NOTIFICATION_PERMISSION = 42
        private const val REQUEST_DOWNLOAD_TREE = 43
        private const val REQUEST_BULK_MOVE_TREE = 44
        private const val REFRESH_INTERVAL_MS = 1_000L
    }
}
