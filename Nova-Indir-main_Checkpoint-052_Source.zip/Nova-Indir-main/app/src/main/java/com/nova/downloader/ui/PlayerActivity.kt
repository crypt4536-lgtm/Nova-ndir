package com.nova.downloader.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.nova.downloader.R
import com.nova.downloader.data.HistoryStore
import com.nova.downloader.data.StorageHelper
import com.nova.downloader.data.StoredDownload
import com.nova.downloader.diagnostics.LocalLog
import com.nova.downloader.i18n.LocalizedActivity

class PlayerActivity : LocalizedActivity() {
    private var player: ExoPlayer? = null
    private var playerView: PlayerView? = null
    private var downloadId: Long = -1L
    private var mediaUri: Uri? = null
    private var mimeType: String? = null
    private var storedDownload: StoredDownload? = null
    private lateinit var playbackHost: FrameLayout
    private var lastPlaybackErrorDetail: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        downloadId = intent.getLongExtra(EXTRA_DOWNLOAD_ID, -1L)
        storedDownload = runCatching {
            if (downloadId > 0L) HistoryStore(this).get(downloadId) else null
        }.onFailure {
            LocalLog.warn("PlayerActivity", "History lookup failed for internal player", it)
        }.getOrNull()

        val stored = storedDownload
        mediaUri = intent.getStringExtra(EXTRA_URI)?.takeIf(String::isNotBlank)?.let(Uri::parse)
            ?: stored?.outputUri?.takeIf(String::isNotBlank)?.let(Uri::parse)
        mimeType = intent.getStringExtra(EXTRA_MIME)?.takeIf(String::isNotBlank) ?: stored?.mediaType
        val title = intent.getStringExtra(EXTRA_TITLE)?.takeIf(String::isNotBlank)
            ?: stored?.title
            ?: getString(R.string.player_title)

        setContentView(buildView(title))

        val uri = mediaUri
        if (uri == null) {
            showPlaybackError(getString(R.string.player_file_missing))
            return
        }
        mimeType = runCatching { contentResolver.getType(uri) }.getOrNull()
            ?.takeIf(String::isNotBlank)
            ?: mimeType
        logSourceInfo(uri)
        startInternalPlayback(uri)
    }

    private fun buildView(title: String): LinearLayout {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(UiPalette.screenBackground(this@PlayerActivity))
        }
        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        toolbar.addView(Button(this).apply {
            text = getString(R.string.back)
            isAllCaps = false
            setOnClickListener { finish() }
        })
        toolbar.addView(TextView(this).apply {
            text = title
            textSize = 18f
            maxLines = 2
            setPadding(dp(10), 0, dp(8), 0)
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        toolbar.addView(Button(this).apply {
            text = getString(R.string.share)
            isAllCaps = false
            setOnClickListener { mediaUri?.let(::share) }
        })
        root.addView(toolbar)

        playbackHost = FrameLayout(this)
        root.addView(
            playbackHost,
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
        )

        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(8), dp(8), dp(12))
        }
        actions.addView(Button(this).apply {
            text = getString(R.string.open_external)
            isAllCaps = false
            setOnClickListener { mediaUri?.let(::openExternal) }
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        actions.addView(Button(this).apply {
            text = getString(R.string.open_file_location)
            isAllCaps = false
            setOnClickListener { StorageHelper.openLocation(this@PlayerActivity, storedDownload) }
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
            marginStart = dp(8)
        })
        root.addView(actions)
        return root
    }

    /**
     * Internal playback must never take the whole Nova process down. Synchronous Media3 setup
     * failures are caught here; asynchronous decoder/source failures are surfaced by Player.Listener.
     */
    private fun startInternalPlayback(uri: Uri) {
        clearPlaybackHost()
        lastPlaybackErrorDetail = null
        runCatching {
            // Verify that Nova itself can still read the MediaStore/SAF URI before Media3 starts.
            contentResolver.openFileDescriptor(uri, "r")?.use { descriptor ->
                if (descriptor.statSize == 0L) error("Media source is empty")
            } ?: error("Media source could not be opened")

            val view = PlayerView(this).apply {
                useController = true
                keepScreenOn = true
                setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
            }
            playbackHost.addView(
                view,
                FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT
                )
            )
            playerView = view

            val exo = ExoPlayer.Builder(this).build()
            player = exo
            view.player = exo
            exo.addListener(object : Player.Listener {
                override fun onPlayerError(error: PlaybackException) {
                    val detail = playbackErrorDetail(error)
                    LocalLog.warn("PlayerActivity", "Internal playback failed: $detail", error)
                    showPlaybackError(getString(R.string.player_playback_failed), detail)
                }
            })

            // Do not force the MIME stored in history onto Media3. Local MediaStore/SAF files can be
            // sniffed by Media3 itself; a stale or generic MIME can otherwise select the wrong path.
            exo.setMediaItem(MediaItem.fromUri(uri))
            exo.prepare()
            exo.playWhenReady = true
        }.onFailure { error ->
            val detail = "SETUP_${error.javaClass.simpleName}: ${LocalLog.redact(error.message.orEmpty())}"
            LocalLog.error("PlayerActivity", "Internal player setup failed: $detail", error)
            releasePlayer()
            showPlaybackError(getString(R.string.player_playback_failed), detail)
        }
    }

    private fun logSourceInfo(uri: Uri) {
        val size = runCatching {
            contentResolver.openFileDescriptor(uri, "r")?.use { it.statSize }
        }.getOrNull()
        LocalLog.info(
            "PlayerActivity",
            "Playback source id=$downloadId scheme=${uri.scheme.orEmpty()} authority=${uri.authority.orEmpty()} mime=${mimeType.orEmpty()} size=${size ?: -1L}"
        )
    }

    private fun playbackErrorDetail(error: PlaybackException): String {
        val cause = error.cause
        val causeText = if (cause == null) "" else {
            " cause=${cause.javaClass.simpleName}:${LocalLog.redact(cause.message.orEmpty()).take(400)}"
        }
        return "${error.errorCodeName}(${error.errorCode})$causeText"
    }

    private fun showPlaybackError(message: String, detail: String? = null) {
        releasePlayer()
        clearPlaybackHost()
        lastPlaybackErrorDetail = detail
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(24), dp(24), dp(24))
        }
        panel.addView(TextView(this).apply {
            text = message
            textSize = 17f
            gravity = Gravity.CENTER
        })
        if (!detail.isNullOrBlank()) {
            panel.addView(TextView(this).apply {
                text = getString(R.string.player_error_details, detail)
                textSize = 13f
                gravity = Gravity.CENTER
                setPadding(0, dp(18), 0, dp(12))
            })
            panel.addView(Button(this).apply {
                text = getString(R.string.player_copy_error)
                isAllCaps = false
                setOnClickListener { copyPlaybackError() }
            })
        }
        playbackHost.addView(panel, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        ))
    }

    private fun copyPlaybackError() {
        val detail = lastPlaybackErrorDetail ?: return
        val clipboard = getSystemService(ClipboardManager::class.java)
        clipboard.setPrimaryClip(ClipData.newPlainText("Nova Player error", detail))
        Toast.makeText(this, getString(R.string.player_error_copied), Toast.LENGTH_SHORT).show()
    }

    private fun clearPlaybackHost() {
        if (::playbackHost.isInitialized) playbackHost.removeAllViews()
        playerView = null
    }

    private fun openExternal(uri: Uri) {
        val launched = runCatching {
            startActivity(Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, mimeType ?: "*/*")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            })
            true
        }.getOrDefault(false)
        if (!launched) showPlaybackError(getString(R.string.downloaded_file_open_failed))
    }

    private fun share(uri: Uri) {
        runCatching {
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                type = mimeType ?: "*/*"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }, getString(R.string.share)))
        }.onFailure {
            LocalLog.warn("PlayerActivity", "Share sheet could not be opened", it)
        }
    }

    private fun releasePlayer() {
        val current = player
        player = null
        runCatching { current?.pause() }
        runCatching { playerView?.player = null }
        runCatching { current?.release() }
    }

    override fun onStop() {
        runCatching { player?.pause() }
        super.onStop()
    }

    override fun onDestroy() {
        releasePlayer()
        super.onDestroy()
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    companion object {
        const val EXTRA_DOWNLOAD_ID = "download_id"
        const val EXTRA_URI = "uri"
        const val EXTRA_MIME = "mime"
        const val EXTRA_TITLE = "title"

        fun intent(context: Context, id: Long): Intent =
            Intent(context, PlayerActivity::class.java).putExtra(EXTRA_DOWNLOAD_ID, id)

        fun intent(context: Context, item: StoredDownload): Intent =
            Intent(context, PlayerActivity::class.java).apply {
                putExtra(EXTRA_DOWNLOAD_ID, item.downloadId)
                putExtra(EXTRA_URI, item.outputUri)
                putExtra(EXTRA_MIME, item.mediaType)
                putExtra(EXTRA_TITLE, item.title)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
    }
}
