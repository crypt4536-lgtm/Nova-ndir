package com.nova.downloader.ui

import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.nova.downloader.BuildConfig
import com.nova.downloader.R
import com.nova.downloader.i18n.LocalizedActivity

class PrivacyPolicyActivity : LocalizedActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(28))
            setBackgroundColor(UiPalette.screenBackground(this@PrivacyPolicyActivity))
            addView(Button(this@PrivacyPolicyActivity).apply {
                text = getString(R.string.back)
                isAllCaps = false
                setOnClickListener { finish() }
            })
            addView(TextView(this@PrivacyPolicyActivity).apply {
                text = getString(R.string.privacy_policy_title)
                textSize = 22f
                setTypeface(typeface, Typeface.BOLD)
                setPadding(0, dp(14), 0, dp(10))
            })
            addView(TextView(this@PrivacyPolicyActivity).apply {
                text = getString(if (BuildConfig.PLAY_STORE_BUILD) R.string.privacy_policy_play_text else R.string.privacy_policy_independent_text)
                textSize = 14f
                setLineSpacing(0f, 1.12f)
            })
            if (BuildConfig.NOVA_PRIVACY_POLICY_URL.isNotBlank()) {
                addView(Button(this@PrivacyPolicyActivity).apply {
                    text = getString(R.string.open_privacy_policy_online)
                    isAllCaps = false
                    setOnClickListener {
                        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(BuildConfig.NOVA_PRIVACY_POLICY_URL)))
                    }
                }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(14) })
            }
        }
        setContentView(ScrollView(this).apply { addView(content) })
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
