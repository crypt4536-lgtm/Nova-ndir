package com.nova.downloader.ui

import android.app.AlertDialog
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.nova.downloader.R
import com.nova.downloader.data.DownloadQueueCoordinator
import com.nova.downloader.data.DownloadRepository
import com.nova.downloader.data.DownloadSnapshot
import com.nova.downloader.data.DownloadState
import com.nova.downloader.data.QueueOrderStore
import com.nova.downloader.data.ScheduleStore
import com.nova.downloader.i18n.LocalizedActivity
import java.util.Calendar

class QueueActivity : LocalizedActivity() {
    private lateinit var repository: DownloadRepository
    private lateinit var adapter: QueueAdapter
    private lateinit var empty: TextView
    private lateinit var orderStore: QueueOrderStore
    private val refreshHandler = Handler(Looper.getMainLooper())
    private val refreshTask = object : Runnable {
        override fun run() {
            refresh()
            refreshHandler.postDelayed(this, 1_000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        repository = DownloadRepository(this)
        orderStore = QueueOrderStore(this)
        setContentView(buildView())
    }

    override fun onResume() {
        super.onResume()
        refreshHandler.removeCallbacks(refreshTask)
        refreshTask.run()
    }

    override fun onPause() {
        refreshHandler.removeCallbacks(refreshTask)
        super.onPause()
    }

    private fun buildView(): android.view.View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(8))
            setBackgroundColor(UiPalette.screenBackground(this@QueueActivity))
        }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(Button(this).apply { text = getString(R.string.back); isAllCaps = false; setOnClickListener { finish() } })
        top.addView(TextView(this).apply { text = getString(R.string.queue_title); textSize = 22f; setPadding(dp(10), 0, 0, 0) }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        top.addView(Button(this).apply {
            text = getString(R.string.start_queue); isAllCaps = false
            setOnClickListener { DownloadQueueCoordinator.kick(this@QueueActivity); refresh() }
        })
        root.addView(top)
        root.addView(TextView(this).apply {
            text = getString(R.string.queue_drag_info); textSize = 12f; alpha = 0.72f; setPadding(0, dp(8), 0, dp(8))
        })
        adapter = QueueAdapter(this, ::showActions)
        val recycler = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(this@QueueActivity)
            adapter = this@QueueActivity.adapter
        }
        ItemTouchHelper(object : ItemTouchHelper.SimpleCallback(ItemTouchHelper.UP or ItemTouchHelper.DOWN, 0) {
            override fun onMove(rv: RecyclerView, source: RecyclerView.ViewHolder, target: RecyclerView.ViewHolder): Boolean {
                val moved = adapter.move(source.bindingAdapterPosition, target.bindingAdapterPosition)
                if (moved) orderStore.replace(adapter.ids())
                return moved
            }
            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) = Unit
            override fun isLongPressDragEnabled() = true
        }).attachToRecyclerView(recycler)
        empty = TextView(this).apply { text = getString(R.string.queue_empty); gravity = Gravity.CENTER; textSize = 15f }
        val frame = android.widget.FrameLayout(this).apply {
            addView(recycler, android.widget.FrameLayout.LayoutParams(-1, -1))
            addView(empty, android.widget.FrameLayout.LayoutParams(-1, -1))
        }
        root.addView(frame, LinearLayout.LayoutParams(-1, 0, 1f))
        return root
    }

    private fun refresh() {
        val all = repository.snapshots().filter {
            it.status == DownloadState.PENDING || it.status == DownloadState.RUNNING || it.status == DownloadState.PAUSED ||
                ScheduleStore(this).get(it.stored.downloadId) != null
        }
        val byId = all.associateBy { it.stored.downloadId }
        val ordered = orderStore.ordered(byId.keys).mapNotNull(byId::get)
        adapter.submit(ordered)
        empty.visibility = if (ordered.isEmpty()) android.view.View.VISIBLE else android.view.View.GONE
    }

    private fun showActions(item: DownloadSnapshot) {
        val scheduled = ScheduleStore(this).get(item.stored.downloadId)
        val labels = mutableListOf<String>()
        val actions = mutableListOf<() -> Unit>()
        when (item.status) {
            DownloadState.RUNNING -> {
                labels += getString(R.string.pause_download); actions += { repository.pause(item.stored.downloadId); refresh() }
            }
            DownloadState.PAUSED -> {
                labels += getString(R.string.resume_download); actions += { repository.resume(item.stored.downloadId); refresh() }
            }
            else -> {
                labels += getString(R.string.start_now); actions += { repository.startNow(item.stored.downloadId); refresh() }
            }
        }
        labels += if (scheduled == null) getString(R.string.schedule_download) else getString(R.string.change_schedule)
        actions += { chooseSchedule(item.stored.downloadId) }
        if (scheduled != null) {
            labels += getString(R.string.remove_schedule)
            actions += { repository.startNow(item.stored.downloadId); refresh() }
        }
        labels += getString(R.string.cancel_download)
        actions += { repository.cancel(item.stored.downloadId); refresh() }
        AlertDialog.Builder(this).setTitle(item.stored.title).setItems(labels.toTypedArray()) { _, i -> actions[i]() }.show()
    }

    private fun chooseSchedule(downloadId: Long) {
        val cal = Calendar.getInstance().apply { add(Calendar.HOUR_OF_DAY, 1) }
        DatePickerDialog(this, { _, year, month, day ->
            TimePickerDialog(this, { _, hour, minute ->
                cal.set(year, month, day, hour, minute, 0)
                repository.schedule(downloadId, cal.timeInMillis)
                refresh()
            }, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), true).show()
        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}
