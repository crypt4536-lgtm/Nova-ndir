package com.nova.downloader.ui

import android.content.Context
import android.graphics.Typeface
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.nova.downloader.R
import com.nova.downloader.data.DownloadSnapshot
import com.nova.downloader.data.DownloadState
import com.nova.downloader.data.ScheduleStore
import java.text.DateFormat
import java.util.Date
import java.util.Collections

class QueueAdapter(
    private val context: Context,
    private val onClick: (DownloadSnapshot) -> Unit
) : RecyclerView.Adapter<QueueAdapter.Holder>() {
    private val items = mutableListOf<DownloadSnapshot>()
    private val schedules = ScheduleStore(context)

    fun submit(newItems: List<DownloadSnapshot>) {
        items.clear(); items.addAll(newItems); notifyDataSetChanged()
    }

    fun move(from: Int, to: Int): Boolean {
        if (from !in items.indices || to !in items.indices) return false
        Collections.swap(items, from, to)
        notifyItemMoved(from, to)
        return true
    }

    fun ids(): List<Long> = items.map { it.stored.downloadId }
    fun itemAt(position: Int): DownloadSnapshot = items[position]

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
        val row = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(10), dp(10), dp(10))
        }
        val handle = TextView(context).apply {
            text = "☰"; textSize = 24f; gravity = Gravity.CENTER; contentDescription = context.getString(R.string.reorder)
        }
        row.addView(handle, LinearLayout.LayoutParams(dp(44), dp(54)))
        val box = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
        val title = TextView(context).apply { textSize = 15f; maxLines = 1; setTypeface(typeface, Typeface.BOLD) }
        val status = TextView(context).apply { textSize = 12f; alpha = 0.75f; setPadding(0, dp(4), 0, 0) }
        box.addView(title); box.addView(status)
        row.addView(box, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        return Holder(row, title, status)
    }

    override fun onBindViewHolder(holder: Holder, position: Int) {
        val item = items[position]
        holder.title.text = item.stored.title
        val scheduledAt = schedules.get(item.stored.downloadId)
        holder.status.text = when {
            scheduledAt != null -> context.getString(
                R.string.scheduled_for,
                DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(Date(scheduledAt))
            )
            item.status == DownloadState.RUNNING -> context.getString(R.string.status_downloading_simple)
            item.status == DownloadState.PAUSED -> context.getString(R.string.status_paused_simple)
            else -> context.getString(R.string.status_queued)
        }
        holder.itemView.setOnClickListener { onClick(item) }
    }

    override fun getItemCount() = items.size
    private fun dp(value: Int) = (value * context.resources.displayMetrics.density).toInt()
    class Holder(root: LinearLayout, val title: TextView, val status: TextView) : RecyclerView.ViewHolder(root)
}
