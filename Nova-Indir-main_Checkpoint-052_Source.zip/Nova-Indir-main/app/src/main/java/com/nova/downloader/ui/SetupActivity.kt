package com.nova.downloader.ui

import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.nova.downloader.i18n.LocalizedActivity
import com.nova.downloader.BuildConfig
import com.nova.downloader.R
import com.nova.downloader.data.AppSettings
import com.nova.downloader.data.StorageHelper
import com.nova.downloader.distribution.PetIntegration

class SetupActivity : LocalizedActivity() {
    private lateinit var settingsStore: AppSettings
    private lateinit var destinationText: TextView
    private lateinit var petCheck: CheckBox
    private lateinit var statusCheck: CheckBox
    private var selectedTreeUri: String? = null
    private var waitingOverlayPermission = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        settingsStore = AppSettings(this)
        if (settingsStore.onboardingComplete) {
            openMainAndFinish()
            return
        }
        selectedTreeUri = settingsStore.defaultTreeUri
        setContentView(buildContent())
    }

    override fun onResume() {
        super.onResume()
        if (!BuildConfig.HAS_PET_OVERLAY || !waitingOverlayPermission) return
        waitingOverlayPermission = false
        if (PetIntegration.canDrawOverlays(this)) {
            completeSetup(enablePet = true)
        } else {
            AlertDialog.Builder(this)
                .setTitle(getString(R.string.setup_pet_permission_title))
                .setMessage(getString(R.string.setup_pet_permission_message))
                .setPositiveButton(getString(R.string.ok)) { _, _ -> completeSetup(enablePet = false) }
                .setNegativeButton(getString(R.string.try_again)) { _, _ -> requestOverlayPermission() }
                .show()
        }
    }

    private fun buildContent(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(28), dp(24), dp(24))
            setBackgroundColor(UiPalette.screenBackground(this@SetupActivity))

            addView(ImageView(this@SetupActivity).apply {
                setImageResource(R.mipmap.ic_launcher)
                contentDescription = getString(R.string.logo_description)
            }, LinearLayout.LayoutParams(dp(96), dp(96)).apply { gravity = Gravity.CENTER_HORIZONTAL })

            addView(TextView(this@SetupActivity).apply {
                text = getString(R.string.setup_title)
                textSize = 24f
                gravity = Gravity.CENTER
                setTypeface(typeface, Typeface.BOLD)
                setPadding(0, dp(12), 0, dp(6))
            })
            addView(TextView(this@SetupActivity).apply {
                text = getString(R.string.setup_intro)
                textSize = 14f
                gravity = Gravity.CENTER
                alpha = 0.75f
                setPadding(0, 0, 0, dp(22))
            })

            addView(sectionTitle(getString(R.string.setup_default_directory)))
            destinationText = TextView(this@SetupActivity).apply {
                textSize = 15f
                setPadding(dp(2), dp(8), dp(2), dp(8))
            }
            addView(destinationText)
            updateDestinationLabel()

            val locationButtons = LinearLayout(this@SetupActivity).apply {
                orientation = LinearLayout.HORIZONTAL
            }
            locationButtons.addView(Button(this@SetupActivity).apply {
                text = getString(R.string.keep_automatic)
                isAllCaps = false
                setOnClickListener {
                    selectedTreeUri = null
                    updateDestinationLabel()
                }
            }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            locationButtons.addView(Button(this@SetupActivity).apply {
                text = getString(R.string.choose_directory)
                isAllCaps = false
                setOnClickListener { openTreePicker(REQUEST_SETUP_TREE) }
            }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginStart = dp(8)
            })
            addView(locationButtons)

            petCheck = CheckBox(this@SetupActivity).apply {
                text = getString(R.string.setup_pet_enable)
                textSize = 15f
                isChecked = false
            }
            statusCheck = CheckBox(this@SetupActivity).apply {
                text = getString(R.string.setup_pet_status)
                textSize = 14f
                isChecked = true
                isEnabled = false
            }
            petCheck.setOnCheckedChangeListener { _, checked -> statusCheck.isEnabled = checked }
            if (BuildConfig.HAS_PET_OVERLAY) {
                addView(sectionTitle(getString(R.string.setup_pet_section)).apply { setPadding(0, dp(24), 0, 0) })
                addView(petCheck)
                addView(statusCheck)
                addView(TextView(this@SetupActivity).apply {
                    text = getString(R.string.setup_pet_info)
                    textSize = 12f
                    alpha = 0.7f
                    setPadding(dp(2), dp(4), dp(2), dp(18))
                })
            }

            addView(Button(this@SetupActivity).apply {
                text = getString(R.string.complete_setup)
                isAllCaps = false
                textSize = 16f
                setTypeface(typeface, Typeface.BOLD)
                setOnClickListener {
                    settingsStore.defaultTreeUri = selectedTreeUri
                    settingsStore.petShowStatus = statusCheck.isChecked
                    if (BuildConfig.HAS_PET_OVERLAY && petCheck.isChecked && !PetIntegration.canDrawOverlays(this@SetupActivity)) {
                        requestOverlayPermission()
                    } else {
                        completeSetup(enablePet = BuildConfig.HAS_PET_OVERLAY && petCheck.isChecked)
                    }
                }
            }, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(10) })
        }
    }

    private fun completeSetup(enablePet: Boolean) {
        settingsStore.defaultTreeUri = selectedTreeUri
        settingsStore.petShowStatus = statusCheck.isChecked
        settingsStore.petEnabled = enablePet
        settingsStore.onboardingComplete = true
        if (enablePet) PetIntegration.startOrRefresh(this) else PetIntegration.stop(this)
        Toast.makeText(this, getString(R.string.setup_completed), Toast.LENGTH_SHORT).show()
        openMainAndFinish()
    }

    private fun requestOverlayPermission() {
        if (!BuildConfig.HAS_PET_OVERLAY) return
        waitingOverlayPermission = true
        PetIntegration.requestOverlayPermission(this)
    }

    private fun openTreePicker(requestCode: Int) {
        startActivityForResult(
            Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
                addFlags(
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or
                        Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                        Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
                )
            },
            requestCode
        )
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_SETUP_TREE && resultCode == RESULT_OK) {
            selectedTreeUri = StorageHelper.takeTreePermission(this, data)
            updateDestinationLabel()
        }
    }

    private fun updateDestinationLabel() {
        if (::destinationText.isInitialized) {
            destinationText.text = StorageHelper.destinationLabel(this, selectedTreeUri)
        }
    }

    private fun sectionTitle(textValue: String) = TextView(this).apply {
        text = textValue
        textSize = 17f
        setTypeface(typeface, Typeface.BOLD)
    }

    private fun openMainAndFinish() {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    companion object {
        private const val REQUEST_SETUP_TREE = 701
    }
}
