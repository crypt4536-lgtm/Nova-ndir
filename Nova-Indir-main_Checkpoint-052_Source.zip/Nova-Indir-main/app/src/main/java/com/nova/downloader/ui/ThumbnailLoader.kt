package com.nova.downloader.ui

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.util.LruCache
import android.widget.ImageView
import com.nova.downloader.data.StoredDownload
import java.util.concurrent.Executors

object ThumbnailLoader {
    private val cache = LruCache<String, Bitmap>(24)
    private val executor = Executors.newFixedThreadPool(2)

    fun load(context: Context, item: StoredDownload, image: ImageView) {
        val key = item.outputUri.orEmpty()
        image.tag = key
        cache.get(key)?.let { image.setImageBitmap(it); return }
        image.setImageResource(if (item.mediaType?.startsWith("audio/") == true) android.R.drawable.ic_media_ff else android.R.drawable.ic_media_play)
        if (key.isBlank() || item.mediaType?.startsWith("video/") != true) return
        executor.execute {
            val bitmap = runCatching {
                val retriever = MediaMetadataRetriever()
                try {
                    retriever.setDataSource(context, Uri.parse(key))
                    retriever.getFrameAtTime(1_000_000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                } finally {
                    retriever.release()
                }
            }.getOrNull() ?: return@execute
            cache.put(key, bitmap)
            image.post { if (image.tag == key) image.setImageBitmap(bitmap) }
        }
    }
}
