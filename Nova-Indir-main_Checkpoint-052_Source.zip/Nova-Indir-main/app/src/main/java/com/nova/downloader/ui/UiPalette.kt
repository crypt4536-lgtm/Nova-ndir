package com.nova.downloader.ui

import android.content.Context
import android.content.res.Configuration
import com.nova.downloader.R

/** Nova Downloader'ın sabit eski lila zemini ve ortak yüzey paleti. */
object UiPalette {
    fun isNight(context: Context): Boolean =
        context.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK ==
            Configuration.UI_MODE_NIGHT_YES

    fun screenBackground(context: Context): Int = context.getColor(R.color.nova_screen_background)

    fun surface(context: Context): Int = context.getColor(R.color.nova_surface)

    fun border(context: Context): Int = context.getColor(R.color.nova_border)
}
