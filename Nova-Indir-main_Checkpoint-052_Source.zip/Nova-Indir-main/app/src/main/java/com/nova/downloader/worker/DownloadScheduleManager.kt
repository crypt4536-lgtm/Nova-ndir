package com.nova.downloader.worker

import android.content.Context
import androidx.work.Data
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

object DownloadScheduleManager {
    fun schedule(context: Context, downloadId: Long, timeMillis: Long) {
        val delay = (timeMillis - System.currentTimeMillis()).coerceAtLeast(0L)
        val request = OneTimeWorkRequestBuilder<ScheduledDownloadWorker>()
            .setInitialDelay(delay, TimeUnit.MILLISECONDS)
            .setInputData(Data.Builder().putLong(ScheduledDownloadWorker.KEY_DOWNLOAD_ID, downloadId).build())
            .addTag(tag(downloadId))
            .build()
        WorkManager.getInstance(context.applicationContext)
            .enqueueUniqueWork(tag(downloadId), androidx.work.ExistingWorkPolicy.REPLACE, request)
    }

    fun cancel(context: Context, downloadId: Long) {
        WorkManager.getInstance(context.applicationContext).cancelUniqueWork(tag(downloadId))
    }

    private fun tag(id: Long) = "nova_scheduled_$id"
}
