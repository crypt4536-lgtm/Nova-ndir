package com.nova.downloader.worker

import android.content.Context
import androidx.work.Constraints
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import com.nova.downloader.data.AppSettings
import com.nova.downloader.data.RecoveryPolicy

object RecoveryScheduler {
    private const val UNIQUE_WORK = "nova_download_recovery"

    fun schedule(context: Context) {
        val settings = AppSettings(context)
        val networkType = when (settings.recoveryPolicy) {
            RecoveryPolicy.WIFI -> NetworkType.UNMETERED
            RecoveryPolicy.ANY_NETWORK -> NetworkType.CONNECTED
            else -> NetworkType.NOT_REQUIRED
        }
        val request = OneTimeWorkRequestBuilder<RecoveryWorker>()
            .setConstraints(
                Constraints.Builder()
                    .setRequiredNetworkType(networkType)
                    .setRequiresCharging(settings.recoveryChargingOnly)
                    .build()
            )
            .build()
        WorkManager.getInstance(context).enqueueUniqueWork(UNIQUE_WORK, ExistingWorkPolicy.REPLACE, request)
    }
}
