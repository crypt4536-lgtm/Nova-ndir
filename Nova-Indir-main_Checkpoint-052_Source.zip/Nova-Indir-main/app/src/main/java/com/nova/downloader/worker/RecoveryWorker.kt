package com.nova.downloader.worker

import com.nova.downloader.i18n.AppText

import com.nova.downloader.R

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.Worker
import androidx.work.WorkerParameters
import com.nova.downloader.data.AppSettings
import com.nova.downloader.data.DownloadRepository
import com.nova.downloader.data.DownloadState
import com.nova.downloader.data.RecoveryPolicy
import com.nova.downloader.ui.MainActivity

class RecoveryWorker(context: Context, params: WorkerParameters) : Worker(context, params) {
    override fun doWork(): Result {
        val repository = DownloadRepository(applicationContext)
        repository.markInterruptedAsPaused()
        val settings = AppSettings(applicationContext)
        val recoverable = repository.snapshots().map { it.stored }.filter {
            it.status == DownloadState.PAUSED && it.hasPartialData
        }
        if (recoverable.isEmpty()) return Result.success()

        var started = 0
        val automaticRequested = settings.recoveryPolicy != RecoveryPolicy.MANUAL
        val canLaunchForegroundTransfer = Build.VERSION.SDK_INT < Build.VERSION_CODES.S
        if (automaticRequested && canLaunchForegroundTransfer) {
            recoverable.forEach { item ->
                if (repository.resume(item.downloadId) is DownloadRepository.EnqueueResult.Success) started++
            }
        }
        showNotification(
            total = recoverable.size,
            started = started,
            automaticBlockedBySystem = automaticRequested && !canLaunchForegroundTransfer
        )
        return Result.success()
    }

    private fun showNotification(total: Int, started: Int, automaticBlockedBySystem: Boolean) {
        val manager = applicationContext.getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(NotificationChannel(CHANNEL, AppText.get(R.string.recovery_channel_name), NotificationManager.IMPORTANCE_DEFAULT))
        }
        val open = PendingIntent.getActivity(
            applicationContext, ID,
            Intent(applicationContext, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val text = when {
            started > 0 -> AppText.get(R.string.recovery_resumed_count, started, total)
            automaticBlockedBySystem -> AppText.get(R.string.recovery_manual_required, total)
            else -> AppText.get(R.string.recovery_ready_count, total)
        }
        manager.notify(
            ID,
            NotificationCompat.Builder(applicationContext, CHANNEL)
                .setSmallIcon(android.R.drawable.stat_sys_download_done)
                .setContentTitle(AppText.get(R.string.recovery_notification_title))
                .setContentText(text)
                .setAutoCancel(true)
                .setContentIntent(open)
                .build()
        )
    }

    companion object { private const val CHANNEL = "nova_recovery"; private const val ID = 8991 }
}
