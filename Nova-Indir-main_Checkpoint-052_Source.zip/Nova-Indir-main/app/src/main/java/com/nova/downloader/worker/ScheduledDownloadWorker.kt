package com.nova.downloader.worker

import android.content.Context
import androidx.work.Worker
import androidx.work.WorkerParameters
import com.nova.downloader.data.DownloadQueueCoordinator
import com.nova.downloader.data.DownloadState
import com.nova.downloader.data.HistoryStore
import com.nova.downloader.data.ScheduleStore

class ScheduledDownloadWorker(context: Context, params: WorkerParameters) : Worker(context, params) {
    override fun doWork(): Result {
        val id = inputData.getLong(KEY_DOWNLOAD_ID, -1L)
        if (id <= 0L) return Result.failure()
        val history = HistoryStore(applicationContext)
        val item = history.get(id) ?: return Result.success()
        if (item.status == DownloadState.SUCCESSFUL || item.status == DownloadState.CANCELLED) {
            ScheduleStore(applicationContext).remove(id)
            return Result.success()
        }
        history.update(id) { it.copy(status = DownloadState.PENDING, errorMessage = null) }
        ScheduleStore(applicationContext).remove(id)
        DownloadQueueCoordinator.kick(applicationContext)
        return Result.success()
    }

    companion object { const val KEY_DOWNLOAD_ID = "download_id" }
}
