package com.nova.downloader.distribution

import android.content.Context

object DistributionStartup {
    fun initialize(context: Context) = Unit
}
