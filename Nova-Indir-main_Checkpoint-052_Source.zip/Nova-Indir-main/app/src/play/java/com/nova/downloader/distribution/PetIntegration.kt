package com.nova.downloader.distribution

import android.app.Activity
import android.content.Context

/** Google Play build: overlay/pet service is intentionally not compiled or declared. */
object PetIntegration {
    fun canDrawOverlays(context: Context): Boolean = false
    fun requestOverlayPermission(activity: Activity) = Unit
    fun startOrRefresh(context: Context) = Unit
    fun refreshMaybe(context: Context) = Unit
    fun stop(context: Context) = Unit
}
