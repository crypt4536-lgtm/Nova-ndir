package com.nova.downloader.core

import com.nova.downloader.data.DuplicatePolicy
import com.nova.downloader.data.PlatformPolicy
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class CorePolicyTest {
    @Test fun httpsPolicyRejectsUnsafeSchemes() {
        assertTrue(UrlPolicy.check("https://example.com/video.mp4").isValid)
        assertEquals(UrlPolicy.ErrorCode.HTTPS_ONLY, UrlPolicy.check("http://example.com/video.mp4").error)
        assertEquals(UrlPolicy.ErrorCode.HTTPS_ONLY, UrlPolicy.check("file:///tmp/video.mp4").error)
        assertEquals(UrlPolicy.ErrorCode.CREDENTIALS_NOT_ALLOWED, UrlPolicy.check("https://user:pass@example.com/video.mp4").error)
    }

    @Test fun mediaExtensionsAreCorrected() {
        assertEquals("video.mp4", FileNameResolver.ensureMediaExtension("video.bin", "video/mp4"))
        assertEquals("audio.m4a", FileNameResolver.ensureMediaExtension("audio", "audio/mp4"))
        assertEquals("new title.mp4", FileNameResolver.renamePreservingMediaExtension("new title", "old.mp4", "video/mp4"))
        assertEquals("new title.mp4", FileNameResolver.renamePreservingMediaExtension("new title.txt", "old.mp4", "video/mp4"))
        assertEquals("episode.1.mp4", FileNameResolver.renamePreservingMediaExtension("episode.1", "old.mp4", "video/mp4"))
    }

    @Test fun resolvedDefaultNamesDropSocialCountersWithoutTouchingTitleContent() {
        assertEquals(
            "Konya’da gün batımı.mp4",
            FileNameResolver.cleanResolvedDefaultName("49K views · 1.6K reactions _ Konya’da gün batımı.mp4")
        )
        assertEquals(
            "Sahip olduğun farkındalık seni özgürleştirir - Evin Turg.mp4",
            FileNameResolver.cleanResolvedDefaultName(
                "1.8M views · 9.1K reactions _ Sahip olduğun farkındalık seni özgürleştirir _ Evin Turg.mp4"
            )
        )
        assertEquals(
            "my_video_name.mp4",
            FileNameResolver.cleanResolvedDefaultName("my_video_name.mp4")
        )
        assertEquals(
            "Başlık & devamı.mp4",
            FileNameResolver.cleanResolvedDefaultName("12K views | Başlık &amp; devamı | Facebook.mp4")
        )
    }

    @Test fun rangeAppendRequiresMatchingPartialResponse() {
        assertTrue(HttpRangePolicy.canAppend(206, "bytes 500-999/1000", 500L))
        assertFalse(HttpRangePolicy.canAppend(200, null, 500L))
    }

    @Test fun browserDetectorKeepsManifestsAndDropsSegments() {
        assertEquals(BrowserMediaDetector.Kind.VIDEO, BrowserMediaDetector.classify("https://cdn.example.com/video.mp4")?.kind)
        assertEquals(BrowserMediaDetector.Kind.HLS, BrowserMediaDetector.classify("https://cdn.example.com/master.m3u8")?.kind)
        assertEquals("video/mp4", BrowserMediaDetector.classify("https://cdn.example.com/videoplayback?mime=video%2Fmp4")?.mimeType)
        assertEquals(null, BrowserMediaDetector.classify("https://cdn.example.com/chunk.m4s"))
    }

    @Test fun requestedSocialPlatformsAreDetected() {
        assertEquals(PlatformPolicy.TWITTER, PlatformPolicy.platformFor("https://x.com/user/status/1"))
        assertEquals(PlatformPolicy.THREADS, PlatformPolicy.platformFor("https://www.threads.net/@user/post/1"))
        assertEquals(PlatformPolicy.BLUESKY, PlatformPolicy.platformFor("https://bsky.app/profile/user/post/1"))
        assertEquals(PlatformPolicy.MASTODON, PlatformPolicy.platformFor("https://mastodon.social/@user/1"))
        assertEquals(PlatformPolicy.TELEGRAM, PlatformPolicy.platformFor("https://t.me/channel/1"))
        assertTrue(SitePagePolicy.shouldUseExtractor("https://bsky.app/profile/user/post/1"))
        assertTrue(SitePagePolicy.shouldUseExtractor("https://t.me/channel/1"))
    }

    @Test fun platformAndDuplicatePoliciesNormalize() {
        assertEquals(PlatformPolicy.YOUTUBE, PlatformPolicy.platformFor("https://youtu.be/example"))
        assertEquals(PlatformPolicy.INSTAGRAM, PlatformPolicy.platformFor("https://instagram.com/reel/example"))
        assertEquals(DuplicatePolicy.REPLACE, DuplicatePolicy.normalize("REPLACE"))
        assertEquals(DuplicatePolicy.RENAME, DuplicatePolicy.normalize("unknown"))
    }
}
