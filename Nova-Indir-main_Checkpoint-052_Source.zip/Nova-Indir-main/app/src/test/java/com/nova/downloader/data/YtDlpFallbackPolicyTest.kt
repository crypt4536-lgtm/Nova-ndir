package com.nova.downloader.data

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class YtDlpFallbackPolicyTest {
    @Test fun publicBotChallengeCanRetryAnonymously() {
        assertTrue(YtDlpFallbackPolicy.isRetryableExtractionFailure("Sign in to confirm you're not a bot"))
    }

    @Test fun public403CanRetryWithAnotherProfile() {
        assertTrue(YtDlpFallbackPolicy.isRetryableExtractionFailure("HTTP Error 403: Forbidden"))
    }

    @Test fun privateVideoIsHardAccessGate() {
        assertTrue(YtDlpFallbackPolicy.isHardAccessGate("This is a private video"))
        assertFalse(YtDlpFallbackPolicy.isRetryableExtractionFailure("This is a private video"))
    }

    @Test fun membersOnlyIsHardAccessGate() {
        assertTrue(YtDlpFallbackPolicy.isHardAccessGate("This video is members-only"))
    }

    @Test fun ageVerificationIsHardAccessGate() {
        assertTrue(YtDlpFallbackPolicy.isHardAccessGate("Sign in to confirm your age"))
    }
}
