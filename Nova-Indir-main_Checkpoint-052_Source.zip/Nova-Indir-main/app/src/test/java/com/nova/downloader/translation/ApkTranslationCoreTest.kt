package com.nova.downloader.translation

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ApkTranslationCoreTest {
    @Test
    fun masksAndRestoresAndroidFormatting() {
        val source = "Downloaded %1$d of %2$d <b>files</b>\\nVisit https://example.org"
        val masked = ApkTranslationCore.mask(source)
        assertFalse(masked.text.contains("%1\$d"))
        assertEquals(source, masked.restore(masked.text))
    }

    @Test
    fun skipsReferencesAndAllowsHumanText() {
        assertFalse(ApkTranslationCore.shouldTranslate("icon", "@drawable/icon", true))
        assertFalse(ApkTranslationCore.shouldTranslate("app_name", "Nova", false))
        assertTrue(ApkTranslationCore.shouldTranslate("welcome", "Welcome to Nova", true))
    }

    @Test
    fun createsSafeOutputNameAndQualifiers() {
        assertEquals("Demo-tr-translated.apk", ApkTranslationCore.outputName("Demo.apk", "tr"))
        assertEquals("-zh-rCN", ApkTranslationCore.targetQualifier("zh"))
        assertEquals(2, ApkTranslationCore.sourceQualifierMatches("-tr-rTR", "tr"))
    }
}
