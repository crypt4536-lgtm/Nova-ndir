from pathlib import Path
import sys
root=Path(__file__).resolve().parent
checks=[]
def check(n,ok):
    checks.append((n,bool(ok))); print(("PASS" if ok else "FAIL")+" - "+n)
g=(root/"app/build.gradle.kts").read_text(encoding="utf-8")
p=(root/"app/proguard-rules.pro").read_text(encoding="utf-8")
w=(root/".github/workflows/nova-build.yml").read_text(encoding="utf-8")
check("checkpoint 051", 'val novaCheckpoint = "051"' in g)
check("versionCode 53", "val novaVersionCode = 53" in g)
check("AspectRatioFrameLayout constructor keep", "-keep class androidx.media3.ui.AspectRatioFrameLayout" in p and "android.util.AttributeSet" in p)
check("PlayerView constructor keep", "-keep class androidx.media3.ui.PlayerView" in p)
check("PlayerControlView constructor keep", "-keep class androidx.media3.ui.PlayerControlView" in p)
check("all Media3 UI kept", "-keep class androidx.media3.ui.** { *; }" in p)
check("contents write", "contents: write" in w)
check("Release fallback", "gh release" in w and "gh release upload" in w)
check("Play artifact nonfatal", "Google Play AAB çıktılarını yükle\n        continue-on-error: true" in w)
check("Independent artifact nonfatal", "Bağımsız APK çıktılarını yükle\n        continue-on-error: true" in w)
passed=sum(ok for _,ok in checks); print(f"\nRESULT: {passed}/{len(checks)} PASS"); sys.exit(0 if passed==len(checks) else 1)
