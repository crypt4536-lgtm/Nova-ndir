# Checkpoint 051 yeniden kurulum deltası

Bu dosya, fiziksel Checkpoint 050 tam snapshot'ı yeni depoya taşındığında uygulanacak kanonik 051 farkını kaydeder.

## Sürüm kimliği
`app/build.gradle.kts`:

```kotlin
val novaVersionName = "0.10.0-alpha"
val novaVersionCode = 53
val novaCheckpoint = "051"
```

## Media3 release/minify koruması
`app/proguard-rules.pro` sonuna:

```proguard
-keep class androidx.media3.ui.AspectRatioFrameLayout {
    public <init>(android.content.Context);
    public <init>(android.content.Context, android.util.AttributeSet);
    public <init>(android.content.Context, android.util.AttributeSet, int);
}
-keep class androidx.media3.ui.PlayerView {
    public <init>(android.content.Context);
    public <init>(android.content.Context, android.util.AttributeSet);
    public <init>(android.content.Context, android.util.AttributeSet, int);
}
-keep class androidx.media3.ui.PlayerControlView {
    public <init>(android.content.Context);
    public <init>(android.content.Context, android.util.AttributeSet);
    public <init>(android.content.Context, android.util.AttributeSet, int);
}
-keep class androidx.media3.ui.** { *; }
```

## CI fallback
`.github/workflows/nova-build.yml` için kanonik davranış:

- `permissions.contents: write`
- Play ve Independent `actions/upload-artifact@v4` adımları `continue-on-error: true`
- APK/AAB çıktıları ayrıca GitHub Release varlıklarına yüklenir
- Release etiketi `nova-0.10.0-checkpoint-051`
- Bir artifact kanalındaki kota/upload hatası diğer dağıtım kanalını skip ettirmemelidir

Eski depo referansları: Media3 commit `7308082a578c647169ef13297fd3aa4073d4585c`, CI fallback commit `85493d747cc5494a0df3b31558d567413202ad8b`, tetikleyici commit `96d657c4beb7d9548edee1dc683a505118e418e0`.
