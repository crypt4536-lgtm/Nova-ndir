import com.nova.downloader.core.DirectApkLinkParser
import com.nova.downloader.core.FacebookUrlExtractor
import com.nova.downloader.core.FileNameResolver
import com.nova.downloader.core.HtmlMediaExtractor
import com.nova.downloader.core.HttpRangePolicy
import com.nova.downloader.core.MediaSignatureDetector
import com.nova.downloader.core.MediaTypePolicy
import com.nova.downloader.core.PlayStoreLinkParser
import com.nova.downloader.core.SitePagePolicy
import com.nova.downloader.data.DuplicatePolicy
import com.nova.downloader.data.PlatformPolicy
import com.nova.downloader.data.RecoveryPolicy
import com.nova.downloader.translation.ApkTranslationCore

fun main() {
    check(FileNameResolver.fromUrl("https://example.com/path/video.mp4") == "video.mp4")
    check(FileNameResolver.sanitize("a/b:c?.mp4") == "a_b_c_.mp4")
    check(FileNameResolver.sanitize("   ", "fallback.bin") == "fallback.bin")
    check(FileNameResolver.sanitize("x".repeat(180) + ".mp4").length <= 120)
    check(FileNameResolver.ensureMediaExtension("video", "video/mp4") == "video.mp4")
    check(FileNameResolver.ensureMediaExtension("video.bin", "video/mp4") == "video.mp4")
    check(FileNameResolver.ensureMediaExtension("video.webm", "video/mp4") == "video.mp4")
    check(FileNameResolver.ensureMediaExtension("özel.ad", "video/mp4") == "özel.ad")

    check(HttpRangePolicy.parseContentRange("bytes 100-199/1000")?.start == 100L)
    check(HttpRangePolicy.parseContentRange("bytes */1000")?.total == 1000L)
    check(HttpRangePolicy.canAppend(206, "bytes 500-999/1000", 500L))
    check(!HttpRangePolicy.canAppend(200, null, 500L))
    check(HttpRangePolicy.totalBytes(206, 500L, "bytes 500-999/1000", 500L) == 1000L)

    val mp4Header = byteArrayOf(0, 0, 0, 24, 'f'.code.toByte(), 't'.code.toByte(), 'y'.code.toByte(), 'p'.code.toByte(), 'i'.code.toByte(), 's'.code.toByte(), 'o'.code.toByte(), 'm'.code.toByte())
    check(MediaSignatureDetector.detect(mp4Header)?.extension == "mp4")

    check(MediaTypePolicy.isDirectMedia("video/mp4", "https://example.com/watch"))
    check(MediaTypePolicy.isDirectMedia("application/octet-stream", "clip.webm"))
    check(MediaTypePolicy.isDirectMedia("application/mp4", "download"))
    check(!MediaTypePolicy.isDirectMedia("text/html", "clip.mp4"))
    check(MediaTypePolicy.isPlaylist("application/vnd.apple.mpegurl", "stream"))
    check(MediaTypePolicy.isPlaylist("application/dash+xml", "stream"))
    check(MediaTypePolicy.isPlaylist(null, "https://example.com/manifest.mpd"))
    check(MediaTypePolicy.mimeTypeForExtension("mp4") == "video/mp4")
    check(MediaTypePolicy.mimeTypeForExtension("m4a") == "audio/mp4")
    check(DuplicatePolicy.normalize("REPLACE") == DuplicatePolicy.REPLACE)
    check(DuplicatePolicy.normalize("unexpected") == DuplicatePolicy.RENAME)
    check(PlatformPolicy.platformFor("https://youtu.be/test") == PlatformPolicy.YOUTUBE)
    check(PlatformPolicy.platformFor("https://www.instagram.com/reel/test") == PlatformPolicy.INSTAGRAM)
    check(PlatformPolicy.platformFor("https://fb.watch/test") == PlatformPolicy.FACEBOOK)
    check(RecoveryPolicy.WIFI != RecoveryPolicy.ANY_NETWORK)
    check(PlayStoreLinkParser.extractPackageId("org.videolan.vlc") == "org.videolan.vlc")
    check(PlayStoreLinkParser.extractPackageId("https://play.google.com/store/apps/details?id=org.videolan.vlc&hl=tr") == "org.videolan.vlc")
    check(PlayStoreLinkParser.extractPackageId("Paylaş: https://play.google.com/store/apps/details?id=com.github.android).") == "com.github.android")
    check(PlayStoreLinkParser.extractPackageId("market://details?id=com.github.android") == "com.github.android")
    check(PlayStoreLinkParser.extractPackageId("https://example.com/?id=com.github.android") == null)
    check(PlayStoreLinkParser.canonicalUrl("org.videolan.vlc") == "https://play.google.com/store/apps/details?id=org.videolan.vlc")
    check(DirectApkLinkParser.extractHttpsUrl("Download: https://example.org/app.apk).") == "https://example.org/app.apk")
    check(DirectApkLinkParser.isLikelyPackageUrl("https://example.org/releases/app.apks?token=1"))
    check(DirectApkLinkParser.isLikelyPackageUrl("https://example.org/get?file=app.xapk"))
    check(DirectApkLinkParser.fileNameHint("https://example.org/get?file=app.xapk") == "app.xapk")
    check(!DirectApkLinkParser.isLikelyPackageUrl("https://example.org/page"))
    check(DirectApkLinkParser.isGooglePlayPage("https://play.google.com/store/apps/details?id=org.videolan.vlc"))
    check(DirectApkLinkParser.extractHttpsUrl("http://example.org/app.apk") == null)

    check(SitePagePolicy.shouldUseExtractor("https://www.facebook.com/share/v/1PJBWMm2mw/"))
    check(SitePagePolicy.shouldUseExtractor("https://fb.watch/abc123/"))
    check(!SitePagePolicy.shouldUseExtractor("https://example.com/video.mp4"))

    val facebookHtml = """
        <html><head>
        <link rel="canonical" href="https://www.facebook.com/NovaPage/videos/1751298762550248/?rdid=abc">
        <meta property="og:url" content="https:\/\/www.facebook.com\/reel\/792080143266641">
        <meta http-equiv="refresh" content="0;url=https://www.facebook.com/watch/?v=647537299265662">
        </head></html>
    """.trimIndent()
    val facebookCandidates = FacebookUrlExtractor.extractCandidates(
        facebookHtml,
        "https://www.facebook.com/share/v/1BNt6NU62h/"
    )
    check("https://www.facebook.com/NovaPage/videos/1751298762550248/?rdid=abc" in facebookCandidates)
    check("https://www.facebook.com/reel/792080143266641" in facebookCandidates)
    check("https://www.facebook.com/watch/?v=647537299265662" in facebookCandidates)
    check("facebook:1751298762550248" in facebookCandidates)
    check(FacebookUrlExtractor.isShareAlias("https://www.facebook.com/share/v/177n2m4pr6/"))
    check(FacebookUrlExtractor.extractNumericVideoId("https://m.facebook.com/watch/?v=792080143266641&_rdr") == "792080143266641")
    val loginCandidates = FacebookUrlExtractor.expandCandidates(
        listOf("https://www.facebook.com/login/?next=https%3A%2F%2Fwww.facebook.com%2Freel%2F792080143266641"),
        null
    )
    check("https://www.facebook.com/reel/792080143266641" in loginCandidates)

    val html = """
        <html><head>
        <meta property="og:video:secure_url" content="https://cdn.example.com/video.mp4?x=1&amp;y=2">
        <script>{"playable_url_quality_hd":"https:\/\/cdn.example.com\/hd.mp4"}</script>
        <script>{\"playable_url\":\"https:\\/\\/cdn.example.com\\/sd.mp4\"}</script>
        <script>{"videoDeliveryResponseFragment":{"progressive_url":"https:\/\/cdn.example.com\/progressive.mp4"}}</script>
        <a href="/video_redirect/?src=https%3A%2F%2Fcdn.example.com%2Fredirected.mp4%3Fx%3D1&amp;refid=52">video</a>
        <div data-store="{&quot;hd_src&quot;:&quot;https:\/\/cdn.example.com\/entity.mp4&quot;}"></div>
        </head></html>
    """.trimIndent()
    val extracted = HtmlMediaExtractor.extract(html, "https://example.com/page")
    check(extracted.first() == "https://cdn.example.com/video.mp4?x=1&y=2")
    check("https://cdn.example.com/hd.mp4" in extracted)
    check("https://cdn.example.com/sd.mp4" in extracted)
    check("https://cdn.example.com/progressive.mp4" in extracted)
    check("https://cdn.example.com/entity.mp4" in extracted)
    check("https://cdn.example.com/redirected.mp4?x=1" in extracted)

    val protectedText = "Downloaded %1\$d of %2\$d <b>files</b>\\nVisit https://example.org"
    val maskedText = ApkTranslationCore.mask(protectedText)
    check(maskedText.restore(maskedText.text) == protectedText)
    check(ApkTranslationCore.shouldTranslate("welcome", "Welcome to Nova", true))
    check(!ApkTranslationCore.shouldTranslate("app_name", "Nova", false))
    check(ApkTranslationCore.outputName("Demo.apk", "tr") == "Demo-tr-translated.apk")
    check(ApkTranslationCore.targetQualifier("zh") == "-zh-rCN")
    check(ApkTranslationCore.sourceQualifierMatches("-tr-rTR", "tr") == 2)

    println("Source smoke tests passed")
}
