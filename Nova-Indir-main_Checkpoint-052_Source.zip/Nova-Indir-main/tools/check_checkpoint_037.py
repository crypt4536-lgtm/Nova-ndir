from pathlib import Path
import sys, re, xml.etree.ElementTree as ET
root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parents[1]
gradle = (root/'app/build.gradle.kts').read_text(encoding='utf-8')
queue = (root/'app/src/main/java/com/nova/downloader/data/DownloadQueueCoordinator.kt').read_text(encoding='utf-8')
repo = (root/'app/src/main/java/com/nova/downloader/data/DownloadRepository.kt').read_text(encoding='utf-8')
manifest = root/'app/src/main/AndroidManifest.xml'
checks = []
def check(name, cond):
    checks.append((name, bool(cond)))
    if not cond: raise AssertionError(name)
check('checkpoint 037', 'val novaCheckpoint = "037"' in gradle)
check('versionCode 39', 'val novaVersionCode = 39' in gradle)
check('distribution dimension', 'listOf("distribution", "edition")' in gradle)
for flavor in ('play','independent','lite','pro'):
    check(f'flavor {flavor}', f'create("{flavor}")' in gradle)
for task in ('assemblePlayLiteDebug','assemblePlayProDebug','assembleIndependentLiteDebug','assembleIndependentProDebug','bundlePlayLiteRelease','bundlePlayProRelease'):
    check(f'task reference {task}', task in gradle)
check('queue no FAILED->PENDING masking', 'is DownloadRepository.EnqueueResult.Error -> history.update(id)' not in queue)
check('queue rejection logging', 'Service start rejected' in queue)
check('repository start logging', 'Could not start service id=' in repo)
check('play overlay exists', (root/'app/src/play/AndroidManifest.xml').is_file())
check('independent overlay exists', (root/'app/src/independent/AndroidManifest.xml').is_file())
ET.parse(manifest)
check('main manifest valid XML', True)
for n, ok in checks: print(('PASS' if ok else 'FAIL') + ': ' + n)
print(f'PASS: {len(checks)} checkpoint-037 static checks')
