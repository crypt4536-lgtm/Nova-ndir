from pathlib import Path
import sys, re, xml.etree.ElementTree as ET

root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parents[1]
gradle = (root/'app/build.gradle.kts').read_text(encoding='utf-8')
queue = (root/'app/src/main/java/com/nova/downloader/data/DownloadQueueCoordinator.kt').read_text(encoding='utf-8')
repo = (root/'app/src/main/java/com/nova/downloader/data/DownloadRepository.kt').read_text(encoding='utf-8')
main_manifest = root/'app/src/main/AndroidManifest.xml'
play_manifest = root/'app/src/play/AndroidManifest.xml'
ind_manifest = root/'app/src/independent/AndroidManifest.xml'

checks=[]
def check(name, cond):
    ok=bool(cond); checks.append((name,ok))
    if not ok: raise AssertionError(name)

def text(path): return path.read_text(encoding='utf-8')

def parse(path):
    ET.parse(path); return text(path)

# Release identity / Android baseline
check('checkpoint 038', 'val novaCheckpoint = "038"' in gradle)
check('versionCode 40', 'val novaVersionCode = 40' in gradle)
check('compileSdk 36', re.search(r'\bcompileSdk\s*=\s*36\b', gradle))
check('targetSdk 36', re.search(r'\btargetSdk\s*=\s*36\b', gradle))
check('Java/Kotlin 17', 'VERSION_17' in gradle and 'JvmTarget.fromTarget("17")' in gradle)

# Matrix / tasks
check('distribution + edition flavor dimensions', 'listOf("distribution", "edition")' in gradle)
for flavor in ('play','independent','lite','pro'):
    check(f'flavor {flavor}', f'create("{flavor}")' in gradle)
for task in ('bundlePlayLiteRelease','bundlePlayProRelease','assembleIndependentLiteRelease','assembleIndependentProRelease'):
    check(f'task reference {task}', task in gradle)
check('Play release preflight task', 'checkNovaPlayReleaseConfig' in gradle and 'NOVA_PLAY_PRIVACY_URL' in gradle)
check('Independent release export task', 'assembleNovaIndependentRelease' in gradle)

# Play hardening
pm=parse(play_manifest); mm=parse(main_manifest); im=parse(ind_manifest)
check('all manifests valid XML', True)
for forbidden in ('SYSTEM_ALERT_WINDOW','FOREGROUND_SERVICE_SPECIAL_USE','REQUEST_INSTALL_PACKAGES','QUERY_ALL_PACKAGES'):
    check(f'Play manifest defense removes {forbidden}', forbidden in pm and 'tools:node="remove"' in pm)
check('main manifest has no overlay/install permissions', all(x not in mm for x in ('SYSTEM_ALERT_WINDOW','FOREGROUND_SERVICE_SPECIAL_USE','REQUEST_INSTALL_PACKAGES','QUERY_ALL_PACKAGES')))
check('main manifest has no concrete pet service', 'PetOverlayService' not in mm)
check('Play flags disable APK/update/pet', all(x in gradle for x in (
    'buildConfigField("boolean", "HAS_APK_TOOLS", "false")',
    'buildConfigField("boolean", "HAS_SELF_UPDATE", "false")',
    'buildConfigField("boolean", "HAS_PET_OVERLAY", "false")')))
check('Play independent endpoints default blank', all(x in gradle for x in (
    'buildConfigField("String", "NOVA_UPDATE_PUBLIC_KEY_B64", buildConfigString(""))',
    'buildConfigField("String", "NOVA_UPDATE_MANIFEST_URL_FULL", buildConfigString(""))',
    'buildConfigField("String", "NOVA_UPDATE_MANIFEST_URL_LITE", buildConfigString(""))',
    'buildConfigField("String", "NOVA_PLAY_DISPENSER_URL", buildConfigString(""))')))
check('Play verifier forbids pet service', 'PetOverlayService bulunmamalı' in gradle)
check('Play verifier forbids overlay special permissions', 'android.permission.SYSTEM_ALERT_WINDOW' in gradle and 'android.permission.FOREGROUND_SERVICE_SPECIAL_USE' in gradle)

# Concrete overlay implementation only independent
check('PetOverlayService moved out of main', not (root/'app/src/main/java/com/nova/downloader/service/PetOverlayService.kt').exists())
check('PetMenuActivity moved out of main', not (root/'app/src/main/java/com/nova/downloader/ui/PetMenuActivity.kt').exists())
check('Independent pet service source exists', (root/'app/src/independent/java/com/nova/downloader/service/PetOverlayService.kt').is_file())
check('Play no-op PetIntegration exists', 'object PetIntegration' in text(root/'app/src/play/java/com/nova/downloader/distribution/PetIntegration.kt') and 'PetOverlayService' not in text(root/'app/src/play/java/com/nova/downloader/distribution/PetIntegration.kt'))
check('Independent PetIntegration owns overlay API', 'Settings.ACTION_MANAGE_OVERLAY_PERMISSION' in text(root/'app/src/independent/java/com/nova/downloader/distribution/PetIntegration.kt'))

# Independent full feature restore
for permission in ('SYSTEM_ALERT_WINDOW','FOREGROUND_SERVICE_SPECIAL_USE','REQUEST_INSTALL_PACKAGES'):
    check(f'Independent manifest has {permission}', permission in im)
for cls in (
    'ui/ApkDownloaderActivity.kt','ui/DirectApkDownloaderActivity.kt','ui/PlayStoreApkDownloaderActivity.kt','ui/ApkTranslationActivity.kt','ui/UpdateCenterActivity.kt',
    'playstore/AnonymousPlaySession.kt','playstore/PlayDeviceProfileFactory.kt','playstore/PlayStoreDownloadWorker.kt',
    'translation/ApkTranslationCore.kt','translation/ApkTranslationWorker.kt',
    'update/UpdateInstallerActivity.kt','update/ApkVerifier.kt','update/UpdateDownloadService.kt','update/SecureUpdateManager.kt','update/UpdateScheduler.kt','update/UpdateCheckWorker.kt','update/UpdateManifest.kt'):
    check(f'independent source {cls}', (root/'app/src/independent/java/com/nova/downloader'/cls).is_file())
for dep in ('com.auroraoss:gplayapi:3.6.4','io.github.reandroid:ARSCLib:1.4.0','com.google.mlkit:translate:17.0.3','com.android.tools.build:apksig:8.10.1'):
    check(f'independent-only dependency {dep}', f'add("independentImplementation", "{dep}")' in gradle)
check('legacy play-disabled-source removed', not (root/'play-disabled-source').exists())

# Independent secure updater multi-dimension fix
secure=text(root/'app/src/independent/java/com/nova/downloader/update/SecureUpdateManager.kt')
check('self-update no BuildConfig.FLAVOR comparison', 'BuildConfig.FLAVOR' not in secure)
check('self-update chooses full/lite by HAS_FFMPEG', 'expectedEngineFlavor()' in secure and 'BuildConfig.HAS_FFMPEG' in secure)
check('self-update has separate Lite/Full manifest URL', 'NOVA_UPDATE_MANIFEST_URL_FULL' in secure and 'NOVA_UPDATE_MANIFEST_URL_LITE' in secure)

# Download-start bug from 037 remains fixed
check('queue no FAILED->PENDING masking', 'is DownloadRepository.EnqueueResult.Error -> history.update(id)' not in queue)
check('queue rejection logging', 'Service start rejected' in queue)
check('repository start logging', 'Could not start service id=' in repo)

# Privacy / publication artifacts
for f in ('PRIVACY_PLAY.md','PRIVACY_INDEPENDENT.md','DATA_SAFETY_PLAY.md','PLAY_CONSOLE_FGS_DECLARATION.md','PLAY_RELEASE_CHECKLIST.md','RELEASE_SIGNING.md','RELEASE_ENV.example','VERIFY_PLAY_RELEASE.ps1','VERIFY_PLAY_RELEASE.cmd','AUDIT_16KB.ps1'):
    check(f'publication artifact {f}', (root/f).is_file())
check('Play privacy Activity in main manifest', 'PrivacyPolicyActivity' in mm)
privacy_activity=text(root/'app/src/main/java/com/nova/downloader/ui/PrivacyPolicyActivity.kt')
check('privacy activity uses release URL', 'NOVA_PRIVACY_POLICY_URL' in privacy_activity)
check('16KB audit report is checkpoint 038', 'Nova Indir 038 16KB Audit Report.txt' in text(root/'AUDIT_16KB.ps1'))
check('release verifier requires 16KB PASS', 'OVERALL RESULT:\\s*PASS' in text(root/'VERIFY_PLAY_RELEASE.ps1'))
check('16KB audit supports package scoping', 'PackageRoot' in text(root/'AUDIT_16KB.ps1') and 'resolvedPackageRoot' in text(root/'AUDIT_16KB.ps1'))
for f in ('BUILD_PLAY_DEBUG.cmd','BUILD_INDEPENDENT_DEBUG.cmd','BUILD_ALL_DEBUG.cmd','BUILD_PLAY_RELEASE.cmd','BUILD_INDEPENDENT_RELEASE.cmd'):
    check(f'current build launcher {f}', (root/f).is_file())
check('obsolete Full/Lite launchers removed', not (root/'BUILD_FULL_DEBUG.cmd').exists() and not (root/'BUILD_LITE_DEBUG.cmd').exists())

# Basic XML resource well-formedness for all values XML files.
for path in sorted((root/'app/src/main/res').glob('values*/strings.xml')):
    ET.parse(path)
check('all strings.xml files valid XML', True)

for name, ok in checks:
    print(('PASS' if ok else 'FAIL') + ': ' + name)
print(f'PASS: {len(checks)} checkpoint-038 static checks')
