from pathlib import Path
import sys

root = Path(__file__).resolve().parents[1]
checks=[]

def text(rel):
    return (root/rel).read_text(encoding='utf-8-sig')

def check(name, cond):
    checks.append((name, bool(cond)))

b=text('app/build.gradle.kts')
check('checkpoint 039', 'val novaCheckpoint = "039"' in b)
check('versionCode 41', 'val novaVersionCode = 41' in b)
check('distribution flavor dimension', 'flavorDimensions += listOf("distribution", "edition")' in b)
for token in ['create("play")','create("independent")','create("lite")','create("pro")']:
    check('flavor '+token, token in b)
check('release signing external properties', '.nova-indir/release.properties' in b)
check('release signing gate', 'tasks.register("checkNovaReleaseSigning")' in b)
check('combined release task', 'tasks.register("buildNovaDistributionRelease")' in b)
check('combined task Play', 'dependsOn("bundleNovaPlayRelease", "assembleNovaIndependentRelease")' in b)
check('Play clean root', 'Nova İndir 039 Google Play' in b)
check('Independent clean root', 'Nova İndir 039 Bağımsız' in b)
check('clean Lite Play AAB name', 'Nova İndir Lite Google Play.aab' in b)
check('clean Pro Play AAB name', 'Nova İndir Pro Google Play.aab' in b)
check('clean Lite Independent APK name', 'novaIndependentLiteDir.resolve("Nova İndir Lite.apk")' in b)
check('clean Pro Independent APK name', 'novaIndependentProDir.resolve("Nova İndir Pro.apk")' in b)
check('Independent release universal Lite source', 'app-independent-lite-release.apk' in b)
check('Independent release universal Pro source', 'app-independent-pro-release.apk' in b)
check('no Independent unsigned delivery target', '-unsigned.apk' not in b)
# release tasks must not auto-enable APK splits
split_block=b[b.index('val novaApkSplitsEnabled'):b.index('android {')]
for token in ['assembleindependentliterelease','assembleindependentprorelease','assemblenovaindependentrelease']:
    check('release split disabled '+token, token not in split_block.lower())
check('setup signing cmd exists', (root/'SETUP_RELEASE_SIGNING.cmd').is_file())
check('setup signing ps1 exists', (root/'SETUP_RELEASE_SIGNING.ps1').is_file())
check('combined build cmd exists', (root/'BUILD_PLAY_AAB_AND_INDEPENDENT_APK.cmd').is_file())
check('combined build cmd task', ':app:buildNovaDistributionRelease' in text('BUILD_PLAY_AAB_AND_INDEPENDENT_APK.cmd'))
check('release setup uses persistent D key path', 'D:\\NovaSigning' in text('SETUP_RELEASE_SIGNING.ps1'))
check('Play verify publication gate', ':app:checkNovaPlayPublicationConfig' in text('VERIFY_PLAY_RELEASE.ps1'))
check('16KB report 039', 'Nova Indir 039 16KB Audit Report.txt' in text('AUDIT_16KB.ps1'))
# 037 download fix preserved
q=text('app/src/main/java/com/nova/downloader/data/DownloadQueueCoordinator.kt')
check('download FAILED not reset to PENDING', 'reverting to PENDING' in q and 'it.copy(status = DownloadState.PENDING)' not in q)
# CRLF on Windows launchers
for f in root.glob('*.cmd'):
    data=f.read_bytes()
    check(f'{f.name} CRLF', b'\r\n' in data and data.replace(b'\r\n', b'').find(b'\n') == -1)

failed=[n for n,ok in checks if not ok]
for n,ok in checks:
    print(('PASS' if ok else 'FAIL')+': '+n)
print(f'\nTOTAL: {sum(ok for _,ok in checks)}/{len(checks)} PASS')
if failed:
    print('FAILED:', ', '.join(failed))
    sys.exit(1)
