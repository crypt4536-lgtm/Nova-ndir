from pathlib import Path
import sys

root = Path(__file__).resolve().parents[1]
checks=[]

def text(rel):
    return (root/rel).read_text(encoding='utf-8-sig')

def check(name, cond):
    checks.append((name, bool(cond)))

b=text('app/build.gradle.kts')
m=text('app/src/main/java/com/nova/downloader/ui/MainActivity.kt')
q=text('app/src/main/java/com/nova/downloader/data/DownloadQueueCoordinator.kt')
signing=text('SETUP_RELEASE_SIGNING.ps1')

check('checkpoint 040', 'val novaCheckpoint = "040"' in b)
check('versionCode 42', 'val novaVersionCode = 42' in b)
check('versionName 0.10.0-alpha', 'val novaVersionName = "0.10.0-alpha"' in b)
check('distribution flavor dimension', 'flavorDimensions += listOf("distribution", "edition")' in b)
for token in ['create("play")','create("independent")','create("lite")','create("pro")']:
    check('flavor '+token, token in b)
check('Play clean root 040', 'Nova İndir 040 Google Play' in b)
check('Independent clean root 040', 'Nova İndir 040 Bağımsız' in b)
check('clean Lite Play AAB', 'Nova İndir Lite Google Play.aab' in b)
check('clean Pro Play AAB', 'Nova İndir Pro Google Play.aab' in b)
check('clean Lite Independent APK', 'novaIndependentLiteDir.resolve("Nova İndir Lite.apk")' in b)
check('clean Pro Independent APK', 'novaIndependentProDir.resolve("Nova İndir Pro.apk")' in b)
check('no unsigned delivery target', '-unsigned.apk' not in b)
check('combined release task', 'tasks.register("buildNovaDistributionRelease")' in b)
check('combined Play+Independent dependencies', 'dependsOn("bundleNovaPlayRelease", "assembleNovaIndependentRelease")' in b)
check('PowerShell 5.1 RNG allocation', '$bytes = New-Object byte[] 24' in signing)
check('PowerShell 5.1 RNG GetBytes', '$rng.GetBytes($bytes)' in signing)
check('unsupported RNG Fill removed', 'RandomNumberGenerator]::Fill' not in signing)

check('audio languages sanitize trim', '.map { it.trim() }' in m)
check('audio languages remove null string', '!it.equals("null", ignoreCase = true)' in m)
check('auto language fallback', 'val selectedIndex = selectedAudioLanguage?.let(languages::indexOf)?.takeIf { it >= 0 } ?: 0' in m)
check('common enqueueFromDialog helper', 'fun enqueueFromDialog(startAt: Long?): Boolean' in m)
check('immediate button clears schedule', 'scheduledAt = null' in m)
check('immediate button actually enqueues', 'enqueueFromDialog(null)' in m)
check('schedule button actually enqueues', 'enqueueFromDialog(scheduledAt)' in m)
check('double submit guard declared', 'var submissionInProgress = false' in m)
check('double submit guard checked', 'if (submissionInProgress) return false' in m)
check('dialog remains on enqueue failure', 'submissionInProgress = false' in m)
check('dialog dismiss only after accepted', 'if (accepted) {' in m and 'dialog.dismiss()' in m)
check('legacy positive button uses common helper', 'dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {\n                enqueueFromDialog(scheduledAt)' in m)
check('smaller scroll height', 'heightPixels * 0.60f' in m)
check('enqueue returns Boolean', 'private fun enqueue(download: ResolvedDownload, fileName: String, destinationTreeUri: String?, scheduledAt: Long? = null): Boolean' in m)
check('enqueue success true', 'PetIntegration.refreshMaybe(this)\n                true' in m)
check('enqueue error false', 'toast(result.message)\n                false' in m)
check('037 queue FAILED preservation retained', 'reverting to PENDING' in q and 'it.copy(status = DownloadState.PENDING)' not in q)

check('setup signing cmd exists', (root/'SETUP_RELEASE_SIGNING.cmd').is_file())
check('combined build cmd exists', (root/'BUILD_PLAY_AAB_AND_INDEPENDENT_APK.cmd').is_file())
check('combined build cmd 040 label', 'Nova 040' in text('BUILD_PLAY_AAB_AND_INDEPENDENT_APK.cmd'))
check('combined build cmd task', ':app:buildNovaDistributionRelease' in text('BUILD_PLAY_AAB_AND_INDEPENDENT_APK.cmd'))
check('Play verify 040 path', 'Nova İndir 040 Google Play' in text('VERIFY_PLAY_RELEASE.ps1'))
check('16KB report 040', 'Nova Indir 040 16KB Audit Report.txt' in text('AUDIT_16KB.ps1'))
check('checkpoint 040 report exists', (root/'CHECKPOINT_040_REPORT.md').is_file())

# Windows launchers must remain CRLF-only.
for f in root.glob('*.cmd'):
    data=f.read_bytes()
    check(f'{f.name} CRLF', b'\r\n' in data and b'\n' not in data.replace(b'\r\n', b''))

failed=[n for n,ok in checks if not ok]
for n,ok in checks:
    print(('PASS' if ok else 'FAIL')+': '+n)
print(f'\nTOTAL: {sum(ok for _,ok in checks)}/{len(checks)} PASS')
if failed:
    print('FAILED:', ', '.join(failed))
    sys.exit(1)
