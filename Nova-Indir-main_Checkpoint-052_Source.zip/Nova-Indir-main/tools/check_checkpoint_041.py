from pathlib import Path
import sys

root = Path(__file__).resolve().parents[1]
checks=[]

def text(rel):
    return (root/rel).read_text(encoding='utf-8-sig')

def check(name, cond):
    checks.append((name, bool(cond)))

b=text('app/build.gradle.kts')
m=text('app/src/main/java/com/nova/downloader/ui/MainActivity.kt')
q=text('app/src/main/java/com/nova/downloader/data/DownloadQueueCoordinator.kt')
signing=text('SETUP_RELEASE_SIGNING.ps1')

check('checkpoint 041', 'val novaCheckpoint = "041"' in b)
check('versionCode 43', 'val novaVersionCode = 43' in b)
check('versionName 0.10.0-alpha', 'val novaVersionName = "0.10.0-alpha"' in b)
check('distribution flavor dimension', 'flavorDimensions += listOf("distribution", "edition")' in b)
for token in ['create("play")','create("independent")','create("lite")','create("pro")']:
    check('flavor '+token, token in b)
check('Play clean root 041', 'Nova İndir 041 Google Play' in b)
check('Independent clean root 041', 'Nova İndir 041 Bağımsız' in b)
check('clean Lite Play AAB', 'Nova İndir Lite Google Play.aab' in b)
check('clean Pro Play AAB', 'Nova İndir Pro Google Play.aab' in b)
check('clean Lite Independent APK', 'novaIndependentLiteDir.resolve("Nova İndir Lite.apk")' in b)
check('clean Pro Independent APK', 'novaIndependentProDir.resolve("Nova İndir Pro.apk")' in b)
check('no unsigned delivery target', '-unsigned.apk' not in b)
check('combined release task', 'tasks.register("buildNovaDistributionRelease")' in b)
check('combined Play+Independent dependencies', 'dependsOn("bundleNovaPlayRelease", "assembleNovaIndependentRelease")' in b)
check('PowerShell 5.1 RNG allocation', '$bytes = New-Object byte[] 24' in signing)
check('PowerShell 5.1 RNG GetBytes', '$rng.GetBytes($bytes)' in signing)
check('unsupported RNG Fill removed', 'RandomNumberGenerator]::Fill' not in signing)

check('audio languages sanitize trim', '.map { it.trim() }' in m)
check('audio languages remove null string', '!it.equals("null", ignoreCase = true)' in m)
check('auto language fallback', 'val selectedIndex = selectedAudioLanguage?.let(languages::indexOf)?.takeIf { it >= 0 } ?: 0' in m)
check('common enqueueFromDialog helper', 'fun enqueueFromDialog(startAt: Long?): Boolean' in m)
check('immediate button clears schedule', 'scheduledAt = null' in m)
check('immediate button actually enqueues', 'enqueueFromDialog(null)' in m)
check('schedule button actually enqueues', 'enqueueFromDialog(scheduledAt)' in m)
check('double submit guard declared', 'var submissionInProgress = false' in m)
check('double submit guard checked', 'if (submissionInProgress) return false' in m)
check('dialog remains on enqueue failure', 'submissionInProgress = false' in m)
check('dialog dismiss only after accepted', 'if (accepted) {' in m and 'dialog.dismiss()' in m)
check('legacy positive button uses common helper', 'dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {\n                enqueueFromDialog(scheduledAt)' in m)
check('smaller scroll height', 'heightPixels * 0.60f' in m)
check('enqueue returns Boolean', 'private fun enqueue(download: ResolvedDownload, fileName: String, destinationTreeUri: String?, scheduledAt: Long? = null): Boolean' in m)
check('enqueue success true', 'PetIntegration.refreshMaybe(this)\n                true' in m)
check('enqueue error false', 'toast(result.message)\n                false' in m)
check('037 queue FAILED preservation retained', 'reverting to PENDING' in q and 'it.copy(status = DownloadState.PENDING)' not in q)

check('setup signing cmd exists', (root/'SETUP_RELEASE_SIGNING.cmd').is_file())
check('combined build cmd exists', (root/'BUILD_PLAY_AAB_AND_INDEPENDENT_APK.cmd').is_file())
check('combined build cmd 041 label', 'Nova 041' in text('BUILD_PLAY_AAB_AND_INDEPENDENT_APK.cmd'))
check('combined build cmd task', ':app:buildNovaDistributionRelease' in text('BUILD_PLAY_AAB_AND_INDEPENDENT_APK.cmd'))
check('Play verify 041 path', 'Nova İndir 041 Google Play' in text('VERIFY_PLAY_RELEASE.ps1'))
check('16KB report 041', 'Nova Indir 041 16KB Audit Report.txt' in text('AUDIT_16KB.ps1'))
check('checkpoint 041 report exists', (root/'CHECKPOINT_041_REPORT.md').is_file())

# Windows launchers must remain CRLF-only.
for f in root.glob('*.cmd'):
    data=f.read_bytes()
    check(f'{f.name} CRLF', b'\r\n' in data and b'\n' not in data.replace(b'\r\n', b''))


# Checkpoint 041 anonymous/public-media fallback chain.
resolver=text('app/src/main/java/com/nova/downloader/data/YtDlpMediaResolver.kt')
config=text('app/src/main/java/com/nova/downloader/data/YtDlpRequestConfigurator.kt')
policy=text('app/src/main/java/com/nova/downloader/data/YtDlpFallbackPolicy.kt')
service=text('app/src/main/java/com/nova/downloader/service/YtDlpDownloadService.kt')
inspector=text('app/src/main/java/com/nova/downloader/data/YtDlpMetadataInspector.kt')
fallback_test=text('app/src/test/java/com/nova/downloader/data/YtDlpFallbackPolicyTest.kt')
check('profile header defined', 'X-Nova-Internal-Ytdlp-Profile' in config)
check('anonymous default profile', 'anonymous-default' in config)
check('YouTube web_safari fallback', 'youtubePlayerClient = "web_safari"' in config)
check('YouTube web_embedded fallback', 'youtubePlayerClient = "web_embedded"' in config)
check('YouTube android_vr fallback', 'youtubePlayerClient = "android_vr"' in config)
check('mweb PO provider fallback', 'youtubePlayerClient = "mweb"' in config and 'poTokenProviderEnabled' in config)
check('generic mobile browser fallback', 'profiles += MOBILE_BROWSER' in config)
check('generic desktop browser fallback', 'profiles += DESKTOP_BROWSER' in config)
check('stored session only when present', 'CookieVault.bestProfile(context, sourceUrl) != null' in config)
check('anonymous profile does not materialize cookies', 'profile.allowStoredCookies && settings.useCookies' in config)
check('default profile does not inherit configured YouTube client', 'val ANONYMOUS_DEFAULT = RequestProfile(PROFILE_ANONYMOUS_DEFAULT)' in config)
check('resolver automatic profile chain', 'automaticProfiles(sourceUrl)' in resolver)
check('resolver records successful profile', 'PROFILE_HEADER to profile.id' in resolver)
check('resolver skips anonymous after hard gate', 'hardGateSeen && !profile.allowStoredCookies' in resolver)
check('nightly retry retains fallback policy', 'isRetryableExtractionFailure(raw)' in resolver)
check('inspector accepts request profile', 'profile: YtDlpRequestConfigurator.RequestProfile' in inspector)
check('download starts from resolved profile', 'automaticProfiles(task.sourceUrl, task.requestProfileId)' in service)
check('download profile retry loop', 'for ((attemptIndex, profile) in profiles.withIndex())' in service)
check('download profile ID persisted through intent', 'EXTRA_REQUEST_PROFILE' in service and 'requestProfileId(item.headersJson)' in service)
check('download relaxed selector on fallback', 'relaxFormat = attemptIndex > 0' in service)
check('download clears per-attempt cookies', 'attemptAuth?.clear()' in service)
check('hard access gates include private', 'private video' in policy)
check('hard access gates include members only', 'members-only' in policy)
check('hard access gates include age restricted', 'age-restricted' in policy)
check('bot challenge retryable', 'sign in to confirm' in policy and 'not a bot' in policy)
check('403 retryable', 'http error 403' in policy)
check('fallback policy tests', 'publicBotChallengeCanRetryAnonymously' in fallback_test and 'privateVideoIsHardAccessGate' in fallback_test)

failed=[n for n,ok in checks if not ok]
for n,ok in checks:
    print(('PASS' if ok else 'FAIL')+': '+n)
print(f'\nTOTAL: {sum(ok for _,ok in checks)}/{len(checks)} PASS')
if failed:
    print('FAILED:', ', '.join(failed))
    sys.exit(1)
