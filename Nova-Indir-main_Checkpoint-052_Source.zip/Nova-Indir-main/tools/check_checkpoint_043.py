from pathlib import Path
root=Path(__file__).resolve().parents[1]
b=(root/'app/build.gradle.kts').read_text(encoding='utf-8')
m=(root/'app/src/main/java/com/nova/downloader/ui/MainActivity.kt').read_text(encoding='utf-8')
checks=[
 ('checkpoint 043','val novaCheckpoint = "043"' in b),
 ('versionCode 45','val novaVersionCode = 45' in b),
 ('custom completion content','val content = LinearLayout(this).apply' in m),
 ('visible play button','val playButton = Button(this).apply' in m),
 ('visible location button','val locationButton = Button(this).apply' in m),
 ('visible close button','val closeButton = Button(this).apply' in m),
 ('no native completion positive button','.setPositiveButton(R.string.play_in_nova)' not in m),
 ('refresh before completion dialog','refreshHistory()' in m[m.find('private fun showNextCompletionDialog()'):m.find('private fun setResolving')]),
]
failed=[]
for name, ok in checks:
 print(('PASS' if ok else 'FAIL')+': '+name)
 if not ok: failed.append(name)
raise SystemExit(1 if failed else 0)
