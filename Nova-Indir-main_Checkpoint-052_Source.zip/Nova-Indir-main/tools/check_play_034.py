#!/usr/bin/env python3
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
failures: list[str] = []


def read(relative: str) -> str:
    path = ROOT / relative
    if not path.is_file():
        failures.append(f"Eksik dosya: {relative}")
        return ""
    return path.read_text(encoding="utf-8")


def require(condition: bool, message: str) -> None:
    if not condition:
        failures.append(message)

root_build = read("build.gradle.kts")
wrapper = read("gradle/wrapper/gradle-wrapper.properties")
app_build = read("app/build.gradle.kts")
manifest = read("app/src/main/AndroidManifest.xml")
colors = read("app/src/main/res/values/colors.xml")
locales = read("app/src/main/res/xml/locales_config.xml")
report = read("GOOGLE_PLAY_034_RAPOR.md")
audit = read("AUDIT_16KB.ps1")

checks = [
    ('version "8.13.2"', root_build, "AGP 8.13.2 bulunamadı"),
    ('gradle-8.13-bin.zip', wrapper, "Gradle 8.13 wrapper bulunamadı"),
    ('id("org.jetbrains.kotlin.android") version "2.3.21"', root_build, "Kotlin 2.3.21 bulunamadı"),
    ('val novaVersionCode = 36', app_build, "versionCode 36 değil"),
    ('val novaCheckpoint = "034"', app_build, "Checkpoint 034 değil"),
    ('create("lite")', app_build, "Lite flavor eksik"),
    ('create("pro")', app_build, "Pro flavor eksik"),
    ('applicationIdSuffix = ".lite"', app_build, "Lite paket eki eksik"),
    ('applicationIdSuffix = ".pro"', app_build, "Pro paket eki eksik"),
    ('val novaApkSplitsEnabled', app_build, "APK/AAB split ayrımı eksik"),
    ('isEnable = novaApkSplitsEnabled', app_build, "ABI split koşulu eksik"),
    ('isUniversalApk = novaApkSplitsEnabled', app_build, "Universal APK koşulu eksik"),
    ('tasks.register("assembleNovaPlayDebug")', app_build, "Test APK görevi eksik"),
    ('tasks.register("bundleNovaPlayRelease")', app_build, "AAB görevi eksik"),
    ('Nova İndir 034 Google Play', app_build, "Checkpoint 034 çıktı klasörü eksik"),
    ('jniLibs.useLegacyPackaging = false', app_build, "Modern JNI paketleme kapalı"),
    ('localeFilters += listOf("tr", "en", "sv", "fr", "es", "ja", "zh-rCN", "de")', app_build, "Dil sırası veya filtreleri yanlış"),
    ('<color name="nova_screen_background">#EEE6FF</color>', colors, "Eski lila arka plan değişmiş"),
    ('<color name="nova_button_middle">#168FF4</color>', colors, "Mavi glossy palet eksik"),
    ('llvm-readelf', audit, "16 KB ELF denetimi eksik"),
    ('zipalign -P 16', report, "16 KB ZIP denetimi raporda eksik"),
]
for snippet, haystack, message in checks:
    require(snippet in haystack, message)

for forbidden in (
    'android.permission.REQUEST_INSTALL_PACKAGES',
    'android.permission.MANAGE_EXTERNAL_STORAGE',
    'android.permission.QUERY_ALL_PACKAGES',
):
    require(forbidden not in manifest, f"Play manifestinde riskli izin var: {forbidden}")

expected_locales = ['android:name="tr"', 'android:name="en"', 'android:name="sv"', 'android:name="fr"', 'android:name="es"', 'android:name="ja"', 'android:name="zh-CN"']
positions = [locales.find(item) for item in expected_locales]
require(all(pos >= 0 for pos in positions), "Dil listesinde eksik dil var")
require(positions == sorted(positions), "Dil sırası Türkçe, İngilizce, İsveççe, Fransızca, İspanyolca, Japonca, Çince değil")

if failures:
    print("NOVA İNDİR 034 STATİK KONTROL: BAŞARISIZ")
    for failure in failures:
        print(f"- {failure}")
    sys.exit(1)

print("NOVA İNDİR 034 STATİK KONTROL: BAŞARILI")
print("- Lite/Pro ürün yapısı doğrulandı")
print("- APK/AAB ABI split ayrımı doğrulandı")
print("- AGP/Gradle/Kotlin sürümleri doğrulandı")
print("- Lila arka plan ve mavi glossy palet doğrulandı")
print("- Dil sırası doğrulandı; İsveççe 3. dil")
print("- 16 KB denetim betiği doğrulandı")
