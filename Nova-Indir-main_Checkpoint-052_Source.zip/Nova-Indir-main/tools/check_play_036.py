#!/usr/bin/env python3
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
ANDROID = "{http://schemas.android.com/apk/res/android}"
failures: list[str] = []


def read(relative: str) -> str:
    path = ROOT / relative
    if not path.is_file():
        failures.append(f"Eksik dosya: {relative}")
        return ""
    return path.read_text(encoding="utf-8-sig")


def require(condition: bool, message: str) -> None:
    if not condition:
        failures.append(message)


root_build = read("build.gradle.kts")
wrapper = read("gradle/wrapper/gradle-wrapper.properties")
app_build = read("app/build.gradle.kts")
manifest_text = read("app/src/main/AndroidManifest.xml")
colors = read("app/src/main/res/values/colors.xml")
locales = read("app/src/main/res/xml/locales_config.xml")
strings = read("app/src/main/res/values/strings.xml")
report = read("GOOGLE_PLAY_036_RAPOR.md")
fgs_declaration = read("PLAY_CONSOLE_FGS_DECLARATION.md")
audit = read("AUDIT_16KB.ps1")

checks = [
    ('version "8.13.2"', root_build, "AGP 8.13.2 bulunamadı"),
    ("gradle-8.13-bin.zip", wrapper, "Gradle 8.13 wrapper bulunamadı"),
    ('id("org.jetbrains.kotlin.android") version "2.3.21"', root_build, "Kotlin 2.3.21 bulunamadı"),
    ("val novaVersionCode = 38", app_build, "versionCode 38 değil"),
    ('val novaCheckpoint = "036"', app_build, "Checkpoint 036 değil"),
    ('val novaWebsiteUrl = "https://novadwnldr-wdkn6daq.manus.space/"', app_build, "Web adresi BuildConfig kaynağında yok"),
    ('buildConfigField("String", "NOVA_WEBSITE_URL"', app_build, "NOVA_WEBSITE_URL BuildConfig alanı yok"),
    ('create("lite")', app_build, "Lite flavor eksik"),
    ('create("pro")', app_build, "Pro flavor eksik"),
    ('applicationIdSuffix = ".lite"', app_build, "Lite paket eki eksik"),
    ('applicationIdSuffix = ".pro"', app_build, "Pro paket eki eksik"),
    ('tasks.register("assembleNovaPlayDebug")', app_build, "Test APK görevi eksik"),
    ('tasks.register("bundleNovaPlayRelease")', app_build, "AAB görevi eksik"),
    ('tasks.register("checkNovaPlayMergedManifests")', app_build, "Birleştirilmiş manifest denetim görevi eksik"),
    ("dependsOn(checkNovaPlayMergedManifests, exportNovaPlayBundles)", app_build, "AAB görevi manifest denetimine bağlı değil"),
    ("Nova İndir 036 Google Play", app_build, "Checkpoint 036 çıktı klasörü eksik"),
    ("jniLibs.useLegacyPackaging = true", app_build, "Upstream nativeLibraryDir uyumluluğu etkin değil"),
    ('localeFilters += listOf("tr", "en", "sv", "fr", "es", "ja", "zh-rCN", "de")', app_build, "Dil sırası veya filtreleri yanlış"),
    ('<color name="nova_screen_background">#EEE6FF</color>', colors, "Eski lila arka plan değişmiş"),
    ('<color name="nova_button_middle">#168FF4</color>', colors, "Mavi glossy palet eksik"),
    ('<string name="nova_website_url" translatable="false">https://novadwnldr-wdkn6daq.manus.space/</string>', strings, "Web adresi string kaynağında yok"),
    ('android:name="com.nova.indir.WEBSITE_URL"', manifest_text, "Web adresi manifest meta-data girdisi yok"),
    ('android:value="@string/nova_website_url"', manifest_text, "Manifest web adresi kaynak bağlantısı yok"),
    ("Nova Indir 036 16KB Audit Report.txt", audit, "Audit rapor adı Checkpoint 036 değil"),
    ("NOVA INDIR 036 - 16 KB PAGE SIZE AUDIT", audit, "Audit başlığı Checkpoint 036 değil"),
    ("Foreground Service Beyan Taslağı", fgs_declaration, "Play Console FGS beyan taslağı eksik"),
    ("checkNovaPlayMergedManifests", report, "Checkpoint 036 raporunda manifest denetimi açıklanmamış"),
]
for snippet, haystack, message in checks:
    require(snippet in haystack, message)

for forbidden in (
    "android.permission.MANAGE_EXTERNAL_STORAGE",
    "android.permission.REQUEST_INSTALL_PACKAGES",
    "android.permission.QUERY_ALL_PACKAGES",
    "android.permission.READ_EXTERNAL_STORAGE",
    "android.permission.READ_MEDIA_IMAGES",
    "android.permission.READ_MEDIA_VIDEO",
    "android.permission.READ_MEDIA_AUDIO",
    "android.permission.ACCESS_FINE_LOCATION",
    "android.permission.ACCESS_COARSE_LOCATION",
    "android.permission.CAMERA",
    "android.permission.RECORD_AUDIO",
    "android.permission.READ_CONTACTS",
    "android.permission.READ_PHONE_STATE",
    "android.permission.READ_SMS",
    "android.permission.SEND_SMS",
):
    require(forbidden not in manifest_text, f"Kaynak manifestte Nova Play için gereksiz izin var: {forbidden}")

try:
    manifest = ET.fromstring(manifest_text)
except ET.ParseError as exc:
    failures.append(f"AndroidManifest.xml ayrıştırılamadı: {exc}")
    manifest = None

if manifest is not None:
    permissions = {
        element.attrib.get(ANDROID + "name", ""): element
        for element in manifest.findall("uses-permission")
    }
    required_permissions = {
        "android.permission.INTERNET",
        "android.permission.ACCESS_NETWORK_STATE",
        "android.permission.POST_NOTIFICATIONS",
        "android.permission.SYSTEM_ALERT_WINDOW",
        "android.permission.FOREGROUND_SERVICE",
        "android.permission.FOREGROUND_SERVICE_DATA_SYNC",
        "android.permission.FOREGROUND_SERVICE_SPECIAL_USE",
        "android.permission.WAKE_LOCK",
        "android.permission.RECEIVE_BOOT_COMPLETED",
        "android.permission.WRITE_EXTERNAL_STORAGE",
    }
    require(required_permissions.issubset(permissions), "Kaynak manifestte gerekli izinlerden biri veya daha fazlası eksik")
    write_storage = permissions.get("android.permission.WRITE_EXTERNAL_STORAGE")
    require(write_storage is not None and write_storage.attrib.get(ANDROID + "maxSdkVersion") == "28", "WRITE_EXTERNAL_STORAGE maxSdkVersion=28 değil")

    application = manifest.find("application")
    require(application is not None, "Manifestte application öğesi yok")
    if application is not None:
        require(application.attrib.get(ANDROID + "allowBackup") == "false", "allowBackup=false değil")
        require(application.attrib.get(ANDROID + "usesCleartextTraffic") == "false", "usesCleartextTraffic=false değil")

        exported_activities: set[str] = set()
        for activity in application.findall("activity"):
            if activity.attrib.get(ANDROID + "exported") == "true":
                exported_activities.add(activity.attrib.get(ANDROID + "name", ""))
        require(exported_activities == {".ui.MainActivity", ".ui.SetupActivity"}, f"Dışa açık activity listesi yanlış: {sorted(exported_activities)}")

        for tag in ("service", "receiver", "provider"):
            exported = [
                item.attrib.get(ANDROID + "name", "")
                for item in application.findall(tag)
                if item.attrib.get(ANDROID + "exported") == "true"
            ]
            require(not exported, f"Dışa açık {tag} bulundu: {exported}")

        expected_types = {
            ".service.DownloadService": "dataSync",
            ".service.YtDlpDownloadService": "dataSync",
            ".service.BackgroundResolutionService": "dataSync",
            "androidx.work.impl.foreground.SystemForegroundService": "dataSync",
            ".service.PetOverlayService": "specialUse",
        }
        services = {item.attrib.get(ANDROID + "name", ""): item for item in application.findall("service")}
        for service_name, expected_type in expected_types.items():
            service = services.get(service_name)
            require(service is not None, f"Servis eksik: {service_name}")
            if service is not None:
                actual_types = {part.strip() for part in service.attrib.get(ANDROID + "foregroundServiceType", "").split("|") if part.strip()}
                require(expected_type in actual_types, f"{service_name} için {expected_type} FGS türü eksik")

        pet_service = services.get(".service.PetOverlayService")
        if pet_service is not None:
            special_property = next(
                (
                    item for item in pet_service.findall("property")
                    if item.attrib.get(ANDROID + "name") == "android.app.PROPERTY_SPECIAL_USE_FGS_SUBTYPE"
                ),
                None,
            )
            require(
                special_property is not None and bool(special_property.attrib.get(ANDROID + "value", "").strip()),
                "PetOverlayService specialUse açıklaması eksik",
            )

expected_locales = [
    'android:name="tr"',
    'android:name="en"',
    'android:name="sv"',
    'android:name="fr"',
    'android:name="es"',
    'android:name="ja"',
    'android:name="zh-CN"',
]
positions = [locales.find(item) for item in expected_locales]
require(all(pos >= 0 for pos in positions), "Dil listesinde eksik dil var")
require(positions == sorted(positions), "Dil sırası Türkçe, İngilizce, İsveççe, Fransızca, İspanyolca, Japonca, Çince değil")

# Generated audit reports must not be shipped inside the clean source archive.
generated_audit_reports = [
    path for path in ROOT.rglob("*.txt")
    if "16kb" in path.name.lower() and "audit report" in path.name.lower()
]
require(not generated_audit_reports, f"Kaynak pakette üretilmiş audit TXT raporu var: {generated_audit_reports}")
require(not (ROOT / "reports").exists(), "Eski reports klasörü kaynak paketinde kalmış")

if failures:
    print("NOVA İNDİR 036 STATİK KONTROL: BAŞARISIZ")
    for failure in failures:
        print(f"- {failure}")
    sys.exit(1)

print("NOVA İNDİR 036 STATİK KONTROL: BAŞARILI")
print("- Version code 38 / Checkpoint 036 doğrulandı")
print("- Lite/Pro ürün ve çıktı yapısı doğrulandı")
print("- Kaynak manifest izin ve dışa açıklık sınırları doğrulandı")
print("- dataSync / specialUse foreground service eşleşmeleri doğrulandı")
print("- AAB görevine birleştirilmiş manifest doğrulaması bağlandı")
print("- Web adresi kaynakta kalıcılaştırıldı")
print("- 16 KB uyumluluk ayarları ve Checkpoint 036 audit betiği korundu")
print("- Üretilmiş audit TXT raporu kaynak paketine dahil edilmedi")
print("- Lila arka plan, mavi glossy palet ve İsveççe 3. dil korundu")
