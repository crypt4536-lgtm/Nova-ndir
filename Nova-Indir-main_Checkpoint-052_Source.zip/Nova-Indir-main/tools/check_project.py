#!/usr/bin/env python3
from __future__ import annotations

from hashlib import sha256
from pathlib import Path
import re
import xml.etree.ElementTree as ET

from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
ANDROID_NS = "{http://schemas.android.com/apk/res/android}"


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def read(relative: str) -> str:
    return (ROOT / relative).read_text(encoding="utf-8", errors="strict")


# Manifest and permission surface
manifest_path = ROOT / "app/src/main/AndroidManifest.xml"
manifest_text = read("app/src/main/AndroidManifest.xml")
manifest = ET.parse(manifest_path).getroot()
permissions = {
    item.attrib.get(ANDROID_NS + "name"): item.attrib
    for item in manifest.findall("uses-permission")
}
for permission in (
    "android.permission.INTERNET",
    "android.permission.ACCESS_NETWORK_STATE",
    "android.permission.POST_NOTIFICATIONS",
    "android.permission.SYSTEM_ALERT_WINDOW",
    "android.permission.FOREGROUND_SERVICE",
    "android.permission.FOREGROUND_SERVICE_DATA_SYNC",
    "android.permission.FOREGROUND_SERVICE_SPECIAL_USE",
    "android.permission.WAKE_LOCK",
    "android.permission.RECEIVE_BOOT_COMPLETED",
    "android.permission.REQUEST_INSTALL_PACKAGES",
):
    require(permission in permissions, f"Missing required permission: {permission}")
require(
    permissions.get("android.permission.WRITE_EXTERNAL_STORAGE", {}).get(ANDROID_NS + "maxSdkVersion") == "28",
    "Legacy write permission must be limited to API 28",
)
for forbidden in (
    "android.permission.MANAGE_EXTERNAL_STORAGE",
    "android.permission.READ_CONTACTS",
    "android.permission.ACCESS_FINE_LOCATION",
    "android.permission.RECORD_AUDIO",
    "android.permission.CAMERA",
    "android.permission.READ_PHONE_STATE",
):
    require(forbidden not in permissions, f"Forbidden permission found: {forbidden}")

for snippet, message in (
    ('android:name=".NovaApplication"', "Custom Application class missing"),
    ('android:localeConfig="@xml/locales_config"', "Per-app locale config missing"),
    ('android:usesCleartextTraffic="false"', "Cleartext traffic is not disabled"),
    ('android:networkSecurityConfig="@xml/network_security_config"', "Network security config missing"),
    ('android:foregroundServiceType="dataSync"', "dataSync foreground service missing"),
    ('android:foregroundServiceType="specialUse"', "specialUse pet foreground service missing"),
    ('android:process=":media"', "Dedicated media process missing"),
    ('android.webkit.WebView.EnableSafeBrowsing', "WebView Safe Browsing metadata missing"),
    ('androidx.core.content.FileProvider', "FileProvider missing"),
    ('.update.UpdateInstallerActivity', "Update installer activity missing"),
    ('.update.UpdateDownloadService', "Update download service missing"),
    ('.ui.ApkDownloaderActivity', "APK downloader activity missing"),
    ('.ui.DirectApkDownloaderActivity', "Direct APK downloader activity missing"),
    ('.ui.ApkTranslationActivity', "APK translation activity missing"),
):
    require(snippet in manifest_text, message)

network = read("app/src/main/res/xml/network_security_config.xml")
require('cleartextTrafficPermitted="false"' in network, "Network security config allows cleartext")

# Localized resources: complete and referenced.
resource_files = {
    "en": ROOT / "app/src/main/res/values/strings.xml",
    "tr": ROOT / "app/src/main/res/values-tr/strings.xml",
    "de": ROOT / "app/src/main/res/values-de/strings.xml",
}
resources: dict[str, dict[str, str]] = {}
for locale, path in resource_files.items():
    root = ET.parse(path).getroot()
    values = {item.attrib["name"]: item.text or "" for item in root if item.tag == "string"}
    require(len(values) == len([item for item in root if item.tag == "string"]), f"Duplicate string name in {locale}")
    resources[locale] = values
base_names = set(resources["en"])
for locale in ("tr", "de"):
    require(set(resources[locale]) == base_names, f"Translation key mismatch for {locale}")

placeholder_pattern = re.compile(r"%(?:(?:\d+)\$)?(?:[-#+ 0,(<]*)?(?:\d+)?(?:\.\d+)?[a-zA-Z%]")
def placeholders(value: str) -> list[str]:
    return sorted(token for token in placeholder_pattern.findall(value) if token != "%%")
for locale in ("tr", "de"):
    for name in base_names:
        require(
            placeholders(resources[locale][name]) == placeholders(resources["en"][name]),
            f"Format placeholder mismatch for {name} in {locale}",
        )
require(len(base_names) >= 500, "Expected comprehensive string resource catalog")
locale_config = ET.parse(ROOT / "app/src/main/res/xml/locales_config.xml").getroot()
configured_locales = {item.attrib.get(ANDROID_NS + "name") for item in locale_config}
require(configured_locales == {"en", "tr", "de"}, "Locale config must contain en, tr and de")

kotlin_files = sorted((ROOT / "app/src/main/java").rglob("*.kt"))
require(len(kotlin_files) >= 70, "Expected Checkpoint 023 Kotlin sources")
kotlin_text = "\n".join(path.read_text(encoding="utf-8") for path in kotlin_files)
string_refs = set(re.findall(r"R\.string\.([A-Za-z0-9_]+)", kotlin_text))
require(string_refs <= base_names, f"Missing string resources: {sorted(string_refs - base_names)}")
# User-facing Turkish prose must not remain hard-coded in Kotlin. Technical parser markers and comments are excluded naturally.
for path in kotlin_files:
    for line_number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        if re.search(r'"[^"\\n]*[ÇĞİÖŞÜçğıöşü][^"\\n]*"', line):
            raise AssertionError(f"Hard-coded Turkish text in {path.relative_to(ROOT)}:{line_number}")
        if re.search(r'(?:setText|setTitle|setMessage|setContentTitle|setContentText)\(\s*"', line):
            raise AssertionError(f"Hard-coded UI text in {path.relative_to(ROOT)}:{line_number}")
        if re.search(r'\.addAction\([^,]+,\s*"', line):
            raise AssertionError(f"Hard-coded notification action in {path.relative_to(ROOT)}:{line_number}")

# Security/privacy SDK sweep.
all_project_text = "\n".join(
    path.read_text(encoding="utf-8", errors="ignore")
    for base in (ROOT / "app", ROOT / "build.gradle.kts", ROOT / "settings.gradle.kts")
    for path in ([base] if base.is_file() else base.rglob("*"))
    if path.is_file() and path.suffix.lower() in {".kt", ".kts", ".xml", ".properties"}
)
for marker in ("com.google.firebase", "facebook-sdk", "appsflyer", "adjust-sdk", "admob"):
    require(marker.lower() not in all_project_text.lower(), f"Advertising/tracking SDK marker found: {marker}")
require("addJavascriptInterface" not in kotlin_text, "Unsafe WebView JavaScript bridge found")
require("handler?.proceed()" not in kotlin_text, "TLS errors are bypassed")
require("handler?.cancel()" in kotlin_text, "TLS error cancellation missing")

# Requested Checkpoint 012–017 features.
for relative in (
    "app/src/main/java/com/nova/downloader/i18n/AppText.kt",
    "app/src/main/java/com/nova/downloader/i18n/LocaleController.kt",
    "app/src/main/java/com/nova/downloader/diagnostics/LocalLog.kt",
    "app/src/main/java/com/nova/downloader/diagnostics/DiagnosticReportExporter.kt",
    "app/src/main/java/com/nova/downloader/update/SecureUpdateManager.kt",
    "app/src/main/java/com/nova/downloader/update/ApkVerifier.kt",
    "app/src/main/java/com/nova/downloader/update/UpdateDownloadService.kt",
    "app/src/main/java/com/nova/downloader/update/UpdateCheckWorker.kt",
    "app/src/main/java/com/nova/downloader/engine/EngineRecoveryManager.kt",
    "app/src/main/java/com/nova/downloader/runtime/MediaProcessState.kt",
    "app/src/main/java/com/nova/downloader/runtime/FfmpegRuntime.kt",
    "tools/sign_update_manifest.py",
    "UPDATE_CONFIGURATION.md",
    "app/src/main/java/com/nova/downloader/ui/PlayerActivity.kt",
    "app/src/main/java/com/nova/downloader/ui/GalleryActivity.kt",
    "app/src/main/java/com/nova/downloader/ui/QueueActivity.kt",
    "app/src/main/java/com/nova/downloader/ui/AccountManagerActivity.kt",
    "app/src/main/java/com/nova/downloader/ui/AccountLoginActivity.kt",
    "app/src/main/java/com/nova/downloader/data/DownloadQueueCoordinator.kt",
    "app/src/main/java/com/nova/downloader/worker/ScheduledDownloadWorker.kt",
    "app/src/main/java/com/nova/downloader/service/BackgroundResolutionService.kt",
    "app/src/main/java/com/nova/downloader/data/ResolutionTaskStore.kt",
    "app/src/main/java/com/nova/downloader/data/CompletionEventStore.kt",
    "app/src/main/java/com/nova/downloader/core/PlayStoreLinkParser.kt",
    "app/src/main/java/com/nova/downloader/core/DirectApkLinkParser.kt",
    "app/src/main/java/com/nova/downloader/ui/ApkDownloaderActivity.kt",
    "app/src/main/java/com/nova/downloader/ui/DirectApkDownloaderActivity.kt",
    "app/src/main/java/com/nova/downloader/ui/ApkTranslationActivity.kt",
    "app/src/main/java/com/nova/downloader/translation/ApkTranslationCore.kt",
    "app/src/main/java/com/nova/downloader/translation/ApkTranslationWorker.kt",
    "app/src/test/java/com/nova/downloader/translation/ApkTranslationCoreTest.kt",
):
    require((ROOT / relative).is_file(), f"Missing source/document: {relative}")

require("com.google.mlkit.nl.translate.DownloadConditions" not in kotlin_text, "Obsolete ML Kit DownloadConditions import remains")
require("ScrollView.LayoutParams" not in kotlin_text, "Invalid ScrollView.LayoutParams reference remains")
require(') ?: if (!outputApk.isFile)' not in kotlin_text, "Invalid Elvis/if rebuild expression remains")

for snippet, message in (
    ("MAX_FILE_BYTES = 512L * 1024L", "Rotating local log size limit missing"),
    ("LocalLog::redact", "Diagnostic redaction missing"),
    ("DiagnosticReportExporter.create", "Diagnostic report export UI missing"),
    ("SHA256withRSA", "RSA-SHA256 update manifest verification missing"),
    ("manifest.flavor == BuildConfig.FLAVOR", "Update flavor pinning missing"),
    ("currentDigests.intersect(archiveDigests)", "APK signer pinning missing"),
    ("archive.versionName == manifest.versionName", "APK version-name verification missing"),
    ("ApkVerifier.verify(this, file, manifest)", "Final pre-install APK re-verification missing"),
    ("apkSha256", "APK SHA-256 verification missing"),
    ("snapshotCurrent", "Engine known-good snapshot missing"),
    ("restoreSnapshot", "Engine rollback restore missing"),
    ("FAILURE_THRESHOLD = 3", "Automatic rollback threshold missing"),
    ("Process.killProcess(Process.myPid())", "Idle media-process release missing"),
    ("BuildConfig.HAS_FFMPEG", "Optional FFmpeg flavor gate missing"),
    ("MAX_PARALLEL = 1", "Single heavy media download limit missing"),
    ("concurrentFragments.coerceAtMost(2)", "Balanced fragment-memory limit missing"),
    ("--limit-rate", "yt-dlp speed limit missing"),
    ("BandwidthLimiter", "Direct-download speed limiter missing"),
    ("ItemTouchHelper", "Drag-reorder queue support missing"),
    ("OneTimeWorkRequestBuilder<ScheduledDownloadWorker>", "Scheduled download worker missing"),
    ("ExoPlayer.Builder", "Internal Media3 player missing"),
    ("AccountProfileStore", "Account profile management missing"),
    ("renameOutput", "Completed-file rename support missing"),
    ("synchronizeCompletedOutputMetadata", "External rename synchronization missing"),
    ("onClick = { item -> startActivity(PlayerActivity.intent(this, item.downloadId)) }", "Gallery single-tap internal playback missing"),
    ("onLongClick = ::showActions", "Gallery long-press action menu missing"),
    ("setOnItemLongClickListener", "Main-history long-press action menu missing"),
    ("PlayStoreLinkParser.extractPackageId", "Google Play package parser integration missing"),
    ("DownloadManager.Request", "APK DownloadManager integration missing"),
    ("NovaDownloader/APK/", "APK output directory missing"),
    ("apps.evozi.com/apk-downloader", "Evozi provider integration missing"),
    ("DirectApkLinkParser.extractHttpsUrl", "Independent APK URL parser integration missing"),
    ("NovaDownloader/APK/Direct/", "Independent APK output directory missing"),
    ("requireSafePublicHost", "Independent APK local-network protection missing"),
    ("PlayStoreDownloadWorker", "Independent Play Store worker missing"),
    ("AnonymousPlaySession.build", "Anonymous Play session integration missing"),
    ("NovaDownloader/APK/PlayStore", "Independent Play Store output directory missing"),
    ("PurchaseHelper(authData).purchase", "Google Play delivery integration missing"),
    ("OneTimeWorkRequestBuilder<ApkTranslationWorker>", "APK translation WorkManager integration missing"),
    ('Class.forName("com.reandroid.apk.ApkModule")', "Compiled Android resource editor integration missing"),
    ("translator.translate(masked.text)", "On-device string translation integration missing"),
    ("ApkSigner.SignerConfig.Builder", "Translated APK signing integration missing"),
    ("ApkVerifier.Builder(output)", "Translated APK signature verification missing"),
    ("NovaDownloader/APK/Translated", "Translated APK output directory missing"),
    ("ApkTranslationCore.mask", "Android placeholder protection missing"),
    ("R.string.main_full_version", "Main-menu full version label missing"),
    ("BuildConfig.NOVA_CHECKPOINT", "Main-menu checkpoint identity missing"),
    ("com.google.mlkit.common.model.DownloadConditions", "Correct ML Kit DownloadConditions import missing"),
    ("FrameLayout.LayoutParams", "APK translation ScrollView layout params fix missing"),
    ("item.status == DownloadState.SUCCESSFUL && !item.stored.outputUri.isNullOrBlank()", "Main-history single-tap internal playback guard missing"),
    ("BackgroundResolutionService.start(this, url)", "Background foreground-resolution flow missing"),
    ("CompletionEventStore(this).record", "Completion event persistence missing"),
    ("moveTaskToBack(true)", "Pet background-app action missing"),
    ("pet_status_resolving", "Pet resolution status missing"),
):
    require(snippet in kotlin_text, message)

build = read("app/build.gradle.kts")
for relative in (
    "build-debug.ps1",
    "BUILD_FULL_DEBUG.cmd",
    "BUILD_LITE_DEBUG.cmd",
    "BUILD_ALL_DEBUG.cmd",
):
    require((ROOT / relative).is_file(), f"Missing debug build launcher: {relative}")
build_script = read("build-debug.ps1")
for snippet, message in (
    (":app:assembleFullDebug", "Full Debug build task missing"),
    (":app:assembleLiteDebug", "Lite Debug build task missing"),
    ("Nova Downloader 032 v0.9.9 Alpha Lila Mavi Glossy Full", "Clean Full output folder missing"),
    ("Nova Downloader 032 v0.9.9 Alpha Lila Mavi Glossy Lite", "Clean Lite output folder missing"),
    ("Nova Downloader 0.32 v0.9.9 Alpha Mavi Glossy Full", "Clean Full APK naming missing"),
    ("Nova Downloader 0.32 v0.9.9 Alpha Mavi Glossy Lite", "Clean Lite APK naming missing"),
):
    require(snippet in build_script, message)

colors = read("app/src/main/res/values/colors.xml")
for snippet, message in (
    ('<color name="nova_screen_background">#EEE6FF</color>', "Original lilac background changed"),
    ('<color name="nova_button_middle">#168FF4</color>', "Blue glossy button palette missing"),
):
    require(snippet in colors, message)

for snippet, message in (
    ('val novaVersionName = "0.9.9-alpha"', "Version name not updated"),
    ('val novaVersionCode = 33', "Version code not updated"),
    ('val novaCheckpoint = "031"', "Checkpoint number not updated"),
    ('buildConfigField("String", "NOVA_CHECKPOINT"', "Checkpoint BuildConfig field missing"),
    ('tasks.register("assembleNovaDebug")', "Stable assembleNovaDebug task missing"),
    ('tasks.register("exportNovaDebugApks")', "Clean APK export task missing"),
    ('create("full")', "Full flavor missing"),
    ('create("lite")', "Lite flavor missing"),
    ('add("fullImplementation", "io.github.junkfood02.youtubedl-android:ffmpeg:0.18.1")', "FFmpeg must be full-flavor only"),
    ('isMinifyEnabled = true', "R8 code shrinking missing"),
    ('isShrinkResources = true', "Resource shrinking missing"),
    ('isUniversalApk = true', "Universal APK output missing"),
    ('include("arm64-v8a", "armeabi-v7a")', "ARM ABI split missing"),
    ('localeFilters += listOf("en", "tr", "de")', "Locale resource filtering missing"),
    ('language { enableSplit = true }', "App Bundle language split missing"),
    ('NOVA_UPDATE_MANIFEST_URL', "Secure update endpoint build field missing"),
    ('NOVA_UPDATE_MANIFEST_URL_FULL', "Full-flavor update endpoint missing"),
    ('NOVA_UPDATE_MANIFEST_URL_LITE', "Lite-flavor update endpoint missing"),
    ('NOVA_UPDATE_PUBLIC_KEY_B64', "Secure update public key build field missing"),
    ('androidx.media3:media3-exoplayer:1.10.1', "Media3 ExoPlayer dependency missing"),
    ('androidx.recyclerview:recyclerview:1.4.0', "RecyclerView dependency missing"),
    ('com.auroraoss:gplayapi:3.6.4', "GPlayAPI dependency missing"),
    ('NOVA_PLAY_DISPENSER_URL', "Anonymous Play dispenser build field missing"),
    ('io.github.reandroid:ARSCLib:1.4.0', "ARSCLib dependency missing"),
    ('com.google.mlkit:translate:17.0.3', "ML Kit translation dependency missing"),
    ('com.android.tools.build:apksig:8.10.1', "apksig dependency missing"),
):
    require(snippet in build, message)

# Lilac theme and glossy button regression guards.
for relative in (
    "app/src/main/res/drawable/nova_glossy_button.xml",
    "app/src/main/res/drawable/nova_glossy_button_normal.xml",
    "app/src/main/res/drawable/nova_glossy_button_pressed.xml",
    "app/src/main/res/drawable/nova_glossy_button_disabled.xml",
    "app/src/main/res/color/nova_glossy_button_text.xml",
):
    require((ROOT / relative).is_file(), f"Missing lilac/glossy theme resource: {relative}")

colors = read("app/src/main/res/values/colors.xml")
styles = read("app/src/main/res/values/styles.xml")
glossy_normal = read("app/src/main/res/drawable/nova_glossy_button_normal.xml")
ui_palette = read("app/src/main/java/com/nova/downloader/ui/UiPalette.kt")
for snippet, message in (
    ('<color name="nova_screen_background">#EEE6FF</color>', "Light lilac screen background missing"),
    ('<color name="nova_surface">#F9F5FF</color>', "Light lilac surface missing"),
    ('<color name="nova_border">#D7C7F2</color>', "Lilac border missing"),
):
    require(snippet in colors, message)
require(not (ROOT / 'app/src/main/res/values-night/colors.xml').exists(), 'Night colors must not override the original lilac')
require(not (ROOT / 'app/src/main/res/values-night/styles.xml').exists(), 'Night style must not override the original light theme')
require('@color/nova_screen_background' in styles, 'Theme background is not resource-driven')
require('@style/Widget.NovaDownloader.GlossyButton' in styles, 'Glossy button style is not global')
require('<item name="android:forceDarkAllowed">false</item>' in styles, 'System force-dark must stay disabled')
require('@color/nova_button_shine_top' in glossy_normal, "Glossy upper reflection layer missing")
require('@color/nova_button_shadow' in glossy_normal, "Glossy raised shadow layer missing")
require('R.color.nova_screen_background' in ui_palette, "UiPalette is not tied to the lilac resource")
require('Color.rgb(238, 230, 255)' not in ui_palette, "UiPalette still hard-codes the old lilac value")

gradle_properties = read("gradle.properties")
require("android.useAndroidX=true" in gradle_properties, "AndroidX must be enabled")
require("android.enableJetifier=false" in gradle_properties, "Jetifier should stay disabled")
require("android.r8.optimizedResourceShrinking=true" in gradle_properties, "Optimized resource shrinking must be enabled")

# Launcher assets.
expected_sizes = {
    "mipmap-mdpi": 48,
    "mipmap-hdpi": 72,
    "mipmap-xhdpi": 96,
    "mipmap-xxhdpi": 144,
    "mipmap-xxxhdpi": 192,
}
for folder, size in expected_sizes.items():
    for name in ("ic_launcher.png", "ic_launcher_round.png"):
        path = ROOT / "app/src/main/res" / folder / name
        require(path.is_file(), f"Missing launcher asset: {path}")
        image = Image.open(path)
        require(image.size == (size, size), f"Unexpected launcher size: {path} {image.size}")

# Wrapper integrity and update-signing helper syntax.
wrapper = ROOT / "gradle/wrapper/gradle-wrapper.jar"
wrapper_hash = sha256(wrapper.read_bytes()).hexdigest()
require(wrapper_hash == "2db75c40782f5e8ba1fc278a5574bab070adccb2d21ca5a6e5ed840888448046", "Gradle wrapper JAR hash changed")
wrapper_properties = read("gradle/wrapper/gradle-wrapper.properties")
require("distributionSha256Sum=" in wrapper_properties, "Gradle distribution checksum is not pinned")
compile((ROOT / "tools/sign_update_manifest.py").read_text(encoding="utf-8"), "sign_update_manifest.py", "exec")

print("Project integrity checks passed")
print(f"Localized string keys: {len(base_names)} in en/tr/de")
print(f"Kotlin source files: {len(kotlin_files)}")
require("android.overridePathCheck=true" in gradle_properties, "Windows non-ASCII path fallback missing")
print(f"Gradle wrapper SHA-256: {wrapper_hash}")
