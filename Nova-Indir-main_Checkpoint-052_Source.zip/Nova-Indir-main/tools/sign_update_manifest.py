#!/usr/bin/env python3
"""Create and RSA-sign a Nova Downloader update manifest.

The private key never belongs in the Android project. Keep it offline or in CI secrets.
"""
from __future__ import annotations

import argparse
import base64
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding, rsa


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def canonical_payload(data: dict[str, object]) -> str:
    notes_hash = hashlib.sha256(str(data["notes"]).encode("utf-8")).hexdigest()
    return "\n".join(
        [
            str(data["versionCode"]),
            str(data["versionName"]),
            str(data["flavor"]),
            str(data["minSdk"]),
            str(data["apkUrl"]),
            str(data["apkSha256"]).lower(),
            str(data["publishedAt"]),
            notes_hash,
        ]
    )


def main() -> None:
    parser = argparse.ArgumentParser(description="Sign a Nova Downloader update manifest")
    parser.add_argument("--apk", required=True, type=Path)
    parser.add_argument("--apk-url", required=True)
    parser.add_argument("--version-code", required=True, type=int)
    parser.add_argument("--version-name", required=True)
    parser.add_argument("--flavor", choices=("full", "lite"), required=True)
    parser.add_argument("--min-sdk", type=int, default=26)
    parser.add_argument("--notes", default="")
    parser.add_argument("--notes-file", type=Path)
    parser.add_argument("--published-at", default=None)
    parser.add_argument("--private-key", required=True, type=Path, help="PEM RSA private key")
    parser.add_argument("--private-key-password", default=None)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--write-public-key-b64", type=Path)
    args = parser.parse_args()

    if not args.apk.is_file():
        parser.error(f"APK not found: {args.apk}")
    if not args.apk_url.lower().startswith("https://"):
        parser.error("--apk-url must use HTTPS")
    notes = args.notes_file.read_text(encoding="utf-8") if args.notes_file else args.notes
    published_at = args.published_at or datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")

    password = args.private_key_password.encode("utf-8") if args.private_key_password else None
    key = serialization.load_pem_private_key(args.private_key.read_bytes(), password=password)
    if not isinstance(key, rsa.RSAPrivateKey):
        parser.error("The update key must be an RSA private key")

    manifest: dict[str, object] = {
        "versionCode": args.version_code,
        "versionName": args.version_name,
        "flavor": args.flavor,
        "minSdk": args.min_sdk,
        "apkUrl": args.apk_url,
        "apkSha256": sha256_file(args.apk),
        "publishedAt": published_at,
        "notes": notes,
    }
    signature = key.sign(
        canonical_payload(manifest).encode("utf-8"),
        padding.PKCS1v15(),
        hashes.SHA256(),
    )
    manifest["signature"] = base64.b64encode(signature).decode("ascii")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    if args.write_public_key_b64:
        public_der = key.public_key().public_bytes(
            serialization.Encoding.DER,
            serialization.PublicFormat.SubjectPublicKeyInfo,
        )
        args.write_public_key_b64.write_text(base64.b64encode(public_der).decode("ascii") + "\n", encoding="utf-8")

    print(f"Wrote {args.output}")
    print(f"APK SHA-256: {manifest['apkSha256']}")
    print(f"Canonical payload:\n{canonical_payload(manifest)}")


if __name__ == "__main__":
    main()
